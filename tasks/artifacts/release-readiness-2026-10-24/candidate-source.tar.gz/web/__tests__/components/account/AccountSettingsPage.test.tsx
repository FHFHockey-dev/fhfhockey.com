import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const accountState = vi.hoisted(() => ({
  routerQuery: {},
  replace: vi.fn(),
  authUser: {
    id: "user-1",
    email: "tim@example.com",
    displayName: "Tim Tester",
    avatarUrl: null,
    isEmailVerified: true,
  } as any,
  profileMaybeSingle: vi.fn(),
  profileUpsert: vi.fn(),
  refreshProfileAvatar: vi.fn(),
  settingsMaybeSingle: vi.fn(),
  settingsUpsert: vi.fn(),
  connectedAccountMaybeSingle: vi.fn(),
  connectedAccountsCountEq: vi.fn(),
  externalLeaguesOrder: vi.fn(),
  externalLeaguesCountEq: vi.fn(),
  externalTeamsOrder: vi.fn(),
  providerPreferencesMaybeSingle: vi.fn(),
  providerPreferencesUpsert: vi.fn(),
  providerSyncRunMaybeSingle: vi.fn(),
  savedTeamsRows: [] as Array<any>,
  savedTeamsCountEq: vi.fn(),
  savedTeamsInsert: vi.fn(),
  savedTeamsUpdate: vi.fn(),
  savedTeamsDelete: vi.fn(),
  authGetSession: vi.fn(),
  draftProEligible: true,
}));

vi.mock("next/router", () => ({
  useRouter: () => ({
    query: accountState.routerQuery,
    replace: accountState.replace,
  }),
}));

vi.mock("contexts/AuthProviderContext", () => ({
  useAuth: () => ({
    user: accountState.authUser,
    refreshProfileAvatar: accountState.refreshProfileAvatar,
  }),
}));

vi.mock("hooks/useProviderSyncAccess", () => ({
  useProviderSyncAccess: () => ({ status: "ready", access: { eligible: accountState.draftProEligible }, refresh: vi.fn() }),
}));

vi.mock("lib/supabase/client", () => ({
  default: {
    auth: {
      getSession: accountState.authGetSession,
    },
    from: (table: string) => {
      if (table === "user_profiles") {
        return {
          select: () => ({
            eq: () => ({
              maybeSingle: accountState.profileMaybeSingle,
            }),
          }),
          upsert: accountState.profileUpsert,
        };
      }

      if (table === "user_settings") {
        return {
          select: () => ({
            eq: () => ({
              maybeSingle: accountState.settingsMaybeSingle,
            }),
          }),
          upsert: accountState.settingsUpsert,
        };
      }

      if (table === "connected_accounts") {
        return {
          select: (_columns?: string, options?: { count?: string }) =>
            options?.count
              ? { eq: accountState.connectedAccountsCountEq }
              : {
                  eq: (_field: string, _value: string) => ({
                    eq: (_nextField: string, _nextValue: string) => ({
                      maybeSingle: accountState.connectedAccountMaybeSingle,
                    }),
                  }),
                },
        };
      }

      if (table === "external_leagues") {
        return {
          select: (_columns?: string, options?: { count?: string }) =>
            options?.count
              ? { eq: accountState.externalLeaguesCountEq }
              : {
                  eq: (_field: string, _value: string) => ({
                    eq: (_nextField: string, _nextValue: string) => ({
                      order: accountState.externalLeaguesOrder,
                    }),
                  }),
                },
        };
      }

      if (table === "external_teams") {
        return {
          select: () => ({
            eq: (_field: string, _value: string) => ({
              eq: (_nextField: string, _nextValue: string) => ({
                order: accountState.externalTeamsOrder,
              }),
            }),
          }),
        };
      }

      if (table === "user_provider_preferences") {
        return {
          select: () => ({
            eq: (_field: string, _value: string) => ({
              eq: (_nextField: string, _nextValue: string) => ({
                maybeSingle: accountState.providerPreferencesMaybeSingle,
              }),
            }),
          }),
          upsert: accountState.providerPreferencesUpsert,
        };
      }

      if (table === "provider_sync_runs") {
        return {
          select: () => ({
            eq: (_field: string, _value: string) => ({
              eq: (_nextField: string, _nextValue: string) => ({
                order: () => ({
                  limit: () => ({
                    maybeSingle: accountState.providerSyncRunMaybeSingle,
                  }),
                }),
              }),
            }),
          }),
        };
      }

      if (table === "user_saved_teams") {
        return {
          select: (_columns?: string, options?: { count?: string }) =>
            options?.count
              ? { eq: accountState.savedTeamsCountEq }
              : {
                  eq: () => ({
                    order: () =>
                      Promise.resolve({
                        data: [...accountState.savedTeamsRows].sort((a, b) =>
                          a.created_at < b.created_at ? 1 : -1,
                        ),
                        error: null,
                      }),
                  }),
                },
          insert: (payload: any) => {
            accountState.savedTeamsInsert(payload);
            const row = {
              id:
                payload.id || `team-${accountState.savedTeamsRows.length + 1}`,
              created_at: payload.created_at || "2026-03-27T12:00:00.000Z",
              updated_at: payload.updated_at || "2026-03-27T12:00:00.000Z",
              ...payload,
            };
            accountState.savedTeamsRows = [row, ...accountState.savedTeamsRows];
            return Promise.resolve({ error: null });
          },
          update: (payload: any) => ({
            eq: (field: string, value: string) => {
              accountState.savedTeamsUpdate(payload, field, value);
              accountState.savedTeamsRows = accountState.savedTeamsRows.map(
                (row) =>
                  row[field] === value
                    ? {
                        ...row,
                        ...payload,
                        updated_at: "2026-03-27T13:00:00.000Z",
                      }
                    : row,
              );
              return Promise.resolve({ error: null });
            },
          }),
          delete: () => ({
            eq: (field: string, value: string) => {
              accountState.savedTeamsDelete(field, value);
              accountState.savedTeamsRows = accountState.savedTeamsRows.filter(
                (row) => row[field] !== value,
              );
              return Promise.resolve({ error: null });
            },
          }),
        };
      }

      throw new Error(`Unexpected table: ${table}`);
    },
  },
}));

import AccountSettingsPage from "components/account/AccountSettingsPage";

describe("AccountSettingsPage profile section", () => {
  beforeEach(() => {
    accountState.routerQuery = {};
    accountState.draftProEligible = true;
    accountState.authUser = {
      id: "user-1",
      email: "tim@example.com",
      displayName: "Tim Tester",
      avatarUrl: null,
      isEmailVerified: true,
    };
    accountState.replace.mockReset();
    accountState.profileMaybeSingle.mockReset();
    accountState.profileUpsert.mockReset();
    accountState.refreshProfileAvatar.mockReset().mockResolvedValue(undefined);
    accountState.settingsMaybeSingle.mockReset();
    accountState.settingsUpsert.mockReset();
    accountState.connectedAccountMaybeSingle.mockReset();
    accountState.connectedAccountsCountEq.mockReset();
    accountState.externalLeaguesOrder.mockReset();
    accountState.externalLeaguesCountEq.mockReset();
    accountState.externalTeamsOrder.mockReset();
    accountState.providerPreferencesMaybeSingle.mockReset();
    accountState.providerPreferencesUpsert.mockReset();
    accountState.providerSyncRunMaybeSingle.mockReset();
    accountState.savedTeamsRows = [];
    accountState.savedTeamsCountEq.mockReset();
    accountState.savedTeamsInsert.mockReset();
    accountState.savedTeamsUpdate.mockReset();
    accountState.savedTeamsDelete.mockReset();
    accountState.authGetSession.mockReset();
    accountState.settingsMaybeSingle.mockResolvedValue({
      data: null,
      error: null,
    });
    accountState.connectedAccountMaybeSingle.mockResolvedValue({
      data: null,
      error: null,
    });
    accountState.connectedAccountsCountEq.mockResolvedValue({
      count: 1,
      error: null,
    });
    accountState.externalLeaguesOrder.mockResolvedValue({
      data: [],
      error: null,
    });
    accountState.externalLeaguesCountEq.mockResolvedValue({
      count: 2,
      error: null,
    });
    accountState.externalTeamsOrder.mockResolvedValue({
      data: [],
      error: null,
    });
    accountState.providerPreferencesMaybeSingle.mockResolvedValue({
      data: null,
      error: null,
    });
    accountState.providerPreferencesUpsert.mockResolvedValue({
      error: null,
    });
    accountState.providerSyncRunMaybeSingle.mockResolvedValue({
      data: null,
      error: null,
    });
    accountState.savedTeamsCountEq.mockResolvedValue({
      count: 3,
      error: null,
    });
    accountState.authGetSession.mockResolvedValue({
      data: {
        session: {
          access_token: "session-token",
        },
      },
    });
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        json: async () => ({
          configured: false,
          account: null,
          entitlement: null,
          latestRun: null,
        }),
      }),
    );
  });

  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it("retains saved Yahoo data and disconnect access while blocking free sync", async () => {
    accountState.routerQuery = { section: "connected-accounts" };
    accountState.draftProEligible = false;
    accountState.profileMaybeSingle.mockResolvedValue({ data: null, error: null });
    render(<AccountSettingsPage />);
    await waitFor(() => expect(accountState.externalLeaguesOrder).toHaveBeenCalled());
    expect(accountState.externalTeamsOrder).toHaveBeenCalled();
    expect((screen.getByRole("button", { name: "Connect Yahoo Fantasy" }) as HTMLButtonElement).disabled).toBe(true);
    expect(screen.queryByLabelText("Active Yahoo League")).toBeNull();
  });

  it("loads persisted profile fields into the editor", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Commissioner Tim",
        avatar_url: "https://example.com/tim.png",
        timezone: "America/Chicago",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    expect(await screen.findByDisplayValue("Commissioner Tim")).toBeTruthy();
    expect(
      screen.getByDisplayValue("https://example.com/tim.png"),
    ).toBeTruthy();
    expect(screen.getByDisplayValue("America/Chicago")).toBeTruthy();
    expect(
      screen.getByAltText("Commissioner Tim profile avatar"),
    ).toBeTruthy();
  });

  it("renders truthful account status, counts, and a read-only verified email", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/New_York",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    const emailInput = (await screen.findByLabelText(
      "Email Address",
    )) as HTMLInputElement;
    expect(emailInput.value).toBe("tim@example.com");
    expect(emailInput.readOnly).toBe(true);
    expect(screen.getByText("Verified")).toBeTruthy();
    expect(screen.getByText("Signed In")).toBeTruthy();
    expect(
      await screen.findByRole("button", { name: /Connected Leagues 2/ }),
    ).toBeTruthy();
    expect(
      screen.getByRole("button", { name: /Saved Teams 3/ }),
    ).toBeTruthy();
    expect(
      screen.getByRole("button", { name: /Connected Accounts 1/ }),
    ).toBeTruthy();
  });

  it("omits the verification badge when the account email is unverified", async () => {
    accountState.authUser = {
      ...accountState.authUser,
      isEmailVerified: false,
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/New_York",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    await screen.findByLabelText("Email Address");
    expect(screen.queryByText("Verified")).toBeNull();
  });

  it("navigates through the account tabs and summary rows", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/New_York",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    fireEvent.click(
      await screen.findByRole("button", { name: /Connected Leagues 2/ }),
    );
    expect(accountState.replace).toHaveBeenCalledWith(
      {
        pathname: "/account",
        query: { section: "connected-accounts" },
      },
      undefined,
      { shallow: true },
    );

    fireEvent.click(screen.getByRole("tab", { name: "Saved Teams" }));
    expect(accountState.replace).toHaveBeenLastCalledWith(
      {
        pathname: "/account",
        query: { section: "saved-teams" },
      },
      undefined,
      { shallow: true },
    );
  });

  it("uses the current account identity when the profile row is missing", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({
      data: null,
      error: null,
    });

    render(<AccountSettingsPage />);

    expect(await screen.findByDisplayValue("Tim Tester")).toBeTruthy();
  });

  it("saves updated profile settings", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/New_York",
      },
      error: null,
    });
    accountState.profileUpsert.mockResolvedValue({ error: null });

    render(<AccountSettingsPage />);

    await screen.findByDisplayValue("Tim Tester");
    fireEvent.change(screen.getByLabelText("Display Name"), {
      target: { value: "Tim The Commissioner" },
    });
    fireEvent.change(screen.getByLabelText("Timezone"), {
      target: { value: "America/Chicago" },
    });
    fireEvent.change(screen.getByLabelText("Avatar URL"), {
      target: { value: "https://fixture.test/updated.png" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save Profile" }));

    await waitFor(() => {
      expect(accountState.profileUpsert).toHaveBeenCalledWith(
        {
          user_id: "user-1",
          display_name: "Tim The Commissioner",
          avatar_url: "https://fixture.test/updated.png",
          timezone: "America/Chicago",
        },
        {
          onConflict: "user_id",
        },
      );
    });

    expect(await screen.findByText("Profile settings saved.")).toBeTruthy();
    expect(accountState.refreshProfileAvatar).toHaveBeenCalledWith("user-1");
  });

  it("does not refresh the shared avatar when profile saving fails", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({ data: null, error: null });
    accountState.profileUpsert.mockResolvedValue({ error: { message: "Profile save failed" } });
    render(<AccountSettingsPage />);
    await screen.findByDisplayValue("Tim Tester");
    fireEvent.click(screen.getByRole("button", { name: "Save Profile" }));
    expect(await screen.findByText("Profile save failed")).toBeTruthy();
    expect(accountState.refreshProfileAvatar).not.toHaveBeenCalled();
  });

  it("keeps save feedback when the shared avatar refresh reloads the same profile", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({ data: null, error: null });
    accountState.profileUpsert.mockResolvedValue({ error: null });
    const { rerender } = render(<AccountSettingsPage />);
    await screen.findByDisplayValue("Tim Tester");
    fireEvent.click(screen.getByRole("button", { name: "Save Profile" }));
    await screen.findByText("Profile settings saved.");
    accountState.authUser = { ...accountState.authUser, avatarUrl: "https://fixture.test/saved.png" };
    rerender(<AccountSettingsPage />);
    await screen.findByDisplayValue("https://fixture.test/saved.png");
    expect(screen.getByText("Profile settings saved.")).toBeTruthy();
  });

  it("scopes a late successful save refresh to the original account", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({ data: null, error: null });
    let resolve!: (result: { error: null }) => void;
    accountState.profileUpsert.mockReturnValue(new Promise(res => { resolve = res; }));
    const { rerender } = render(<AccountSettingsPage />);
    await screen.findByDisplayValue("Tim Tester");
    fireEvent.click(screen.getByRole("button", { name: "Save Profile" }));
    accountState.authUser = { ...accountState.authUser, id: "user-2", displayName: "Morgan Example" };
    rerender(<AccountSettingsPage />);
    resolve({ error: null });
    await waitFor(() => expect(accountState.refreshProfileAvatar).toHaveBeenCalledWith("user-1"));
    expect(accountState.refreshProfileAvatar).not.toHaveBeenCalledWith("user-2");
  });

  it("disables the profile save action while a save is in progress", async () => {
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/New_York",
      },
      error: null,
    });
    let resolveUpsert: ((value: { error: null }) => void) | undefined;
    accountState.profileUpsert.mockReturnValue(
      new Promise((resolve) => {
        resolveUpsert = resolve;
      }),
    );

    render(<AccountSettingsPage />);

    await screen.findByDisplayValue("Tim Tester");
    fireEvent.click(screen.getByRole("button", { name: "Save Profile" }));

    await waitFor(() => {
      expect(
        (screen.getByRole("button", { name: "Saving..." }) as HTMLButtonElement)
          .disabled,
      ).toBe(true);
    });

    resolveUpsert?.({ error: null });
    expect(await screen.findByText("Profile settings saved.")).toBeTruthy();
  });

  it("loads persisted league settings into the league editor", async () => {
    accountState.routerQuery = {
      section: "league-settings",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.settingsMaybeSingle.mockResolvedValue({
      data: {
        league_type: "categories",
        scoring_categories: {
          GOALS: 5,
          ASSISTS: 4,
        },
        category_weights: {
          GOALS: 2,
          HITS: 3,
        },
        roster_config: {
          C: 3,
          bench: 5,
          utility: 2,
        },
        ui_preferences: {
          account_settings_section: "league-settings",
        },
        active_context: {
          source_type: "yahoo",
          provider: "yahoo",
          external_team_id: "team-9",
          external_league_id: "league-2",
        },
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    await waitFor(() => {
      expect(
        (screen.getByLabelText("League Type") as HTMLSelectElement).value,
      ).toBe("categories");
    });
    expect(
      (screen.getByLabelText("Points · Goals") as HTMLInputElement).value,
    ).toBe("5");
    expect(screen.getByText("Source: yahoo")).toBeTruthy();
    expect(screen.getByText("Team: team-9")).toBeTruthy();
  });

  it("shows site defaults when the league settings row is missing", async () => {
    accountState.routerQuery = {
      section: "league-settings",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.settingsMaybeSingle.mockResolvedValue({
      data: null,
      error: null,
    });

    render(<AccountSettingsPage />);

    expect(
      await screen.findByText(
        "Site defaults are shown until you save your own league settings.",
      ),
    ).toBeTruthy();
    expect(
      (screen.getByLabelText("League Type") as HTMLSelectElement).value,
    ).toBe("points");
  });

  it("saves updated league defaults", async () => {
    accountState.routerQuery = {
      section: "league-settings",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.settingsMaybeSingle.mockResolvedValue({
      data: null,
      error: null,
    });
    accountState.settingsUpsert.mockResolvedValue({ error: null });

    render(<AccountSettingsPage />);

    await waitFor(() => {
      expect(
        (screen.getByLabelText("League Type") as HTMLSelectElement).value,
      ).toBe("points");
    });
    fireEvent.change(screen.getByLabelText("League Type"), {
      target: { value: "categories" },
    });
    fireEvent.change(screen.getByLabelText("Points · Goals"), {
      target: { value: "4.5" },
    });
    fireEvent.change(screen.getByLabelText("Roster · Centers"), {
      target: { value: "3" },
    });
    fireEvent.click(
      screen.getByRole("button", { name: "Save League Defaults" }),
    );

    await waitFor(() => {
      expect(accountState.settingsUpsert).toHaveBeenCalledWith(
        {
          user_id: "user-1",
          league_type: "categories",
          scoring_categories: {
            GOALS: 4.5,
            ASSISTS: 2,
            PP_POINTS: 1,
            SHOTS_ON_GOAL: 0.2,
            HITS: 0.2,
            BLOCKED_SHOTS: 0.25,
          },
          goalie_scoring_categories: {
            GOALS_AGAINST_GOALIE: -1,
            SAVES_GOALIE: 0.2,
            SHUTOUTS_GOALIE: 3,
            WINS_GOALIE: 4,
          },
          category_weights: {
            GOALS: 1,
            ASSISTS: 1,
            PP_POINTS: 1,
            SHOTS_ON_GOAL: 1,
            HITS: 1,
            BLOCKED_SHOTS: 1,
            WINS_GOALIE: 1,
            SAVES_GOALIE: 1,
            SAVE_PERCENTAGE: 1,
          },
          roster_config: {
            C: 3,
            LW: 2,
            RW: 2,
            D: 4,
            G: 2,
            bench: 4,
            utility: 1,
          },
          team_count: 12,
          draft_order_type: "snake",
          ui_preferences: {
            account_settings_section: "league-settings",
            league_settings_panel_open: true,
          },
          active_context: {
            source_type: "manual",
            provider: null,
            connected_account_id: null,
            external_league_id: null,
            external_team_id: null,
            external_league_key: null,
            external_team_key: null,
            applied_settings_hash: null,
            applied_at: null,
          },
        },
        {
          onConflict: "user_id",
        },
      );
    });

    expect(await screen.findByText("League defaults saved.")).toBeTruthy();
  });

  it("surfaces synced Yahoo league scoring and roster data in league settings", async () => {
    accountState.routerQuery = {
      section: "league-settings",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.settingsMaybeSingle.mockResolvedValue({
      data: {
        league_type: "points",
        scoring_categories: {},
        category_weights: {},
        roster_config: {},
        ui_preferences: {},
        active_context: {
          source_type: "external-provider",
          provider: "yahoo",
          external_team_id: "team-1",
          external_league_id: "league-1",
        },
      },
      error: null,
    });
    accountState.connectedAccountMaybeSingle.mockResolvedValue({
      data: {
        id: "yahoo-account-1",
        user_id: "user-1",
        provider: "yahoo",
        provider_user_id: "guid-123",
        account_label: "Tim's Yahoo",
        status: "connected",
        scopes: [],
        metadata: {},
        last_synced_at: "2026-03-27T12:00:00.000Z",
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });
    accountState.externalLeaguesOrder.mockResolvedValue({
      data: [
        {
          id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_league_key: "465.l.23204",
          league_name: "Keeper League",
          season_key: "2025",
          league_metadata: {
            season: "2025",
            game_key: "465",
            scoring_type: "headpoint",
            league_type: "private",
            num_teams: 12,
            current_week: 22,
            roster_type: "date",
            weekly_deadline: "intraday",
          },
          scoring_settings: {
            stat_modifiers: {
              stats: [{ stat: { stat_id: 1, value: "6" } }],
            },
            stat_categories: [{ stat_id: 1, name: "Goals", abbr: "G" }],
          },
          roster_settings: {
            roster_positions: [
              { position: "C", count: 2, is_starting_position: 1 },
              { position: "BN", count: 4, is_starting_position: 0 },
            ],
          },
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
      ],
      error: null,
    });
    accountState.externalTeamsOrder.mockResolvedValue({
      data: [
        {
          id: "team-1",
          external_league_id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_team_key: "465.l.23204.t.2",
          team_name: "Tim's Test Team",
          team_metadata: {},
          roster_snapshot: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
      ],
      error: null,
    });
    accountState.providerPreferencesMaybeSingle.mockResolvedValue({
      data: {
        id: "pref-1",
        user_id: "user-1",
        provider: "yahoo",
        connected_account_id: "yahoo-account-1",
        default_external_league_id: "league-1",
        default_external_team_id: "team-1",
        refresh_on_login: false,
        active_context: {},
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    expect(await screen.findByText("Selected Yahoo League")).toBeTruthy();
    expect(screen.getAllByText("Keeper League").length).toBeGreaterThan(0);
    expect(screen.getByText("Team context: Tim's Test Team")).toBeTruthy();
    expect(screen.getByText("headpoint")).toBeTruthy();
    expect(screen.getByText("Goals (G)")).toBeTruthy();
    expect(screen.getByText("6 pts")).toBeTruthy();
    expect(screen.getByText("2 starting slots")).toBeTruthy();
    expect(screen.getByText("4 bench slots")).toBeTruthy();
  });

  it("persists active Yahoo league and team changes from league settings", async () => {
    accountState.routerQuery = {
      section: "league-settings",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.settingsMaybeSingle.mockResolvedValue({
      data: {
        league_type: "points",
        scoring_categories: {},
        category_weights: {},
        roster_config: {},
        ui_preferences: {},
        active_context: {
          source_type: "external-provider",
          provider: "yahoo",
          external_team_id: "team-1",
          external_league_id: "league-1",
        },
      },
      error: null,
    });
    accountState.connectedAccountMaybeSingle.mockResolvedValue({
      data: {
        id: "yahoo-account-1",
        user_id: "user-1",
        provider: "yahoo",
        provider_user_id: "guid-123",
        account_label: "Tim's Yahoo",
        status: "connected",
        scopes: [],
        metadata: {},
        last_synced_at: "2026-03-27T12:00:00.000Z",
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });
    accountState.externalLeaguesOrder.mockResolvedValue({
      data: [
        {
          id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_league_key: "465.l.1",
          league_name: "Keeper League",
          season_key: "2025",
          league_metadata: {},
          scoring_settings: {},
          roster_settings: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
        {
          id: "league-2",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_league_key: "465.l.2",
          league_name: "Dynasty League",
          season_key: "2025",
          league_metadata: {},
          scoring_settings: {},
          roster_settings: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
      ],
      error: null,
    });
    accountState.externalTeamsOrder.mockResolvedValue({
      data: [
        {
          id: "team-1",
          external_league_id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_team_key: "465.l.1.t.1",
          team_name: "Keeper Team",
          team_metadata: {},
          roster_snapshot: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
        {
          id: "team-2",
          external_league_id: "league-2",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_team_key: "465.l.2.t.7",
          team_name: "Dynasty Team",
          team_metadata: {},
          roster_snapshot: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
      ],
      error: null,
    });
    accountState.providerPreferencesMaybeSingle.mockResolvedValue({
      data: {
        id: "pref-1",
        user_id: "user-1",
        provider: "yahoo",
        connected_account_id: "yahoo-account-1",
        default_external_league_id: "league-1",
        default_external_team_id: "team-1",
        refresh_on_login: false,
        active_context: {},
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });
    accountState.providerPreferencesUpsert.mockResolvedValue({
      error: null,
    });
    accountState.settingsUpsert.mockResolvedValue({ error: null });

    render(<AccountSettingsPage />);

    const leagueSelect = (await screen.findByLabelText(
      "Active Yahoo League",
    )) as HTMLSelectElement;
    fireEvent.change(leagueSelect, {
      target: { value: "league-2" },
    });

    await waitFor(() => {
      expect(accountState.providerPreferencesUpsert).toHaveBeenCalledWith(
        {
          user_id: "user-1",
          provider: "yahoo",
          connected_account_id: "yahoo-account-1",
          default_external_league_id: "league-1",
          default_external_team_id: "team-1",
          refresh_on_login: false,
          active_context: {
            source_type: "external-provider",
            provider: "yahoo",
            external_league_id: "league-2",
            external_team_id: "team-2",
            external_league_key: "465.l.2",
            external_team_key: "465.l.2.t.7",
          },
        },
        {
          onConflict: "user_id,provider",
        },
      );
      expect(accountState.settingsUpsert).toHaveBeenCalledWith(
        {
          user_id: "user-1",
          active_context: {
            source_type: "external-provider",
            provider: "yahoo",
            external_league_id: "league-2",
            external_team_id: "team-2",
            external_league_key: "465.l.2",
            external_team_key: "465.l.2.t.7",
          },
        },
        {
          onConflict: "user_id",
        },
      );
    });

    expect(
      await screen.findByText(
        "Active Yahoo context updated to Dynasty League / Dynasty Team.",
      ),
    ).toBeTruthy();
  });

  it("lists saved teams and creates a new manual saved team", async () => {
    accountState.routerQuery = {
      section: "saved-teams",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.savedTeamsRows = [
      {
        id: "team-1",
        user_id: "user-1",
        name: "Dynasty Squad",
        source_type: "manual",
        provider: null,
        external_team_key: null,
        external_league_key: null,
        roster_json: { manualNotes: "Keeper-heavy roster." },
        settings_snapshot: { league_type: "points" },
        is_default: true,
        created_at: "2026-03-20T12:00:00.000Z",
        updated_at: "2026-03-22T12:00:00.000Z",
      },
    ];

    render(<AccountSettingsPage />);

    expect(await screen.findByText("Dynasty Squad")).toBeTruthy();
    expect(screen.getByText("Keeper-heavy roster.")).toBeTruthy();
    expect(screen.getByText("Default")).toBeTruthy();

    fireEvent.change(screen.getByLabelText("Team Name"), {
      target: { value: "Playoff Push" },
    });
    fireEvent.change(screen.getByLabelText("Manual Notes"), {
      target: { value: "Streaming-focused bench." },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save Team" }));

    await waitFor(() => {
      expect(accountState.savedTeamsInsert).toHaveBeenCalledWith(
        expect.objectContaining({
          user_id: "user-1",
          name: "Playoff Push",
          source_type: "manual",
          is_default: false,
          roster_json: {
            manualNotes: "Streaming-focused bench.",
          },
          settings_snapshot: expect.objectContaining({
            league_type: "points",
          }),
        }),
      );
    });

    expect(await screen.findByText("Saved team created.")).toBeTruthy();
    expect(screen.getByText("Playoff Push")).toBeTruthy();
  });

  it("shows Yahoo context switchers on the saved teams tab", async () => {
    accountState.routerQuery = {
      section: "saved-teams",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.connectedAccountMaybeSingle.mockResolvedValue({
      data: {
        id: "yahoo-account-1",
        user_id: "user-1",
        provider: "yahoo",
        provider_user_id: "guid-123",
        account_label: "Tim's Yahoo",
        status: "connected",
        scopes: [],
        metadata: {},
        last_synced_at: "2026-03-27T12:00:00.000Z",
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });
    accountState.externalLeaguesOrder.mockResolvedValue({
      data: [
        {
          id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_league_key: "465.l.1",
          league_name: "Keeper League",
          season_key: "2025",
          league_metadata: {},
          scoring_settings: {},
          roster_settings: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
      ],
      error: null,
    });
    accountState.externalTeamsOrder.mockResolvedValue({
      data: [
        {
          id: "team-1",
          external_league_id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_team_key: "465.l.1.t.1",
          team_name: "Keeper Team",
          team_metadata: {},
          roster_snapshot: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
      ],
      error: null,
    });
    accountState.providerPreferencesMaybeSingle.mockResolvedValue({
      data: {
        id: "pref-1",
        user_id: "user-1",
        provider: "yahoo",
        connected_account_id: "yahoo-account-1",
        default_external_league_id: "league-1",
        default_external_team_id: "team-1",
        refresh_on_login: false,
        active_context: {},
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    expect(await screen.findByLabelText("Active Yahoo League")).toBeTruthy();
    expect(screen.getByLabelText("Active Yahoo Team")).toBeTruthy();
    expect(screen.getByText("League: Keeper League")).toBeTruthy();
    expect(screen.getByText("Team: Keeper Team")).toBeTruthy();
  });

  it("edits a saved team and promotes another team to default", async () => {
    accountState.routerQuery = {
      section: "saved-teams",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.savedTeamsRows = [
      {
        id: "team-1",
        user_id: "user-1",
        name: "Dynasty Squad",
        source_type: "manual",
        provider: null,
        external_team_key: null,
        external_league_key: null,
        roster_json: { manualNotes: "Keeper-heavy roster." },
        settings_snapshot: { league_type: "points" },
        is_default: true,
        created_at: "2026-03-20T12:00:00.000Z",
        updated_at: "2026-03-22T12:00:00.000Z",
      },
      {
        id: "team-2",
        user_id: "user-1",
        name: "Redraft Flyers",
        source_type: "manual",
        provider: null,
        external_team_key: null,
        external_league_key: null,
        roster_json: { manualNotes: "High-upside late-round build." },
        settings_snapshot: { league_type: "categories" },
        is_default: false,
        created_at: "2026-03-24T12:00:00.000Z",
        updated_at: "2026-03-24T12:00:00.000Z",
      },
    ];

    render(<AccountSettingsPage />);

    expect(await screen.findByText("Redraft Flyers")).toBeTruthy();
    fireEvent.click(screen.getAllByRole("button", { name: "Edit" })[0]);
    expect(screen.getByDisplayValue("Redraft Flyers")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Team Name"), {
      target: { value: "Redraft Rockets" },
    });
    fireEvent.click(screen.getByLabelText("Set as default team"));
    fireEvent.click(screen.getByRole("button", { name: "Update Saved Team" }));

    await waitFor(() => {
      expect(accountState.savedTeamsUpdate).toHaveBeenCalledWith(
        expect.objectContaining({
          is_default: false,
        }),
        "id",
        "team-1",
      );
      expect(accountState.savedTeamsUpdate).toHaveBeenCalledWith(
        expect.objectContaining({
          name: "Redraft Rockets",
          is_default: true,
        }),
        "id",
        "team-2",
      );
    });

    expect(await screen.findByText("Saved team updated.")).toBeTruthy();
    expect(screen.getByText("Redraft Rockets")).toBeTruthy();
  });

  it("deletes a saved team from the manual list", async () => {
    accountState.routerQuery = {
      section: "saved-teams",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.savedTeamsRows = [
      {
        id: "team-1",
        user_id: "user-1",
        name: "Dynasty Squad",
        source_type: "manual",
        provider: null,
        external_team_key: null,
        external_league_key: null,
        roster_json: { manualNotes: "Keeper-heavy roster." },
        settings_snapshot: { league_type: "points" },
        is_default: true,
        created_at: "2026-03-20T12:00:00.000Z",
        updated_at: "2026-03-22T12:00:00.000Z",
      },
    ];

    render(<AccountSettingsPage />);

    expect(await screen.findByText("Dynasty Squad")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));

    await waitFor(() => {
      expect(accountState.savedTeamsDelete).toHaveBeenCalledWith(
        "id",
        "team-1",
      );
    });

    expect(
      await screen.findByText('"Dynasty Squad" was removed.'),
    ).toBeTruthy();
    expect(
      screen.getByText(
        "No saved teams yet. Create one to get started.",
      ),
    ).toBeTruthy();
  });

  it("shows user-facing provider tabs in connected accounts", async () => {
    accountState.routerQuery = {
      section: "connected-accounts",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    expect(
      await screen.findByRole("tab", { name: "Yahoo Fantasy" }),
    ).toBeTruthy();
    expect(
      screen.getByRole("button", { name: "Connect Yahoo Fantasy" }),
    ).toBeTruthy();
    expect(screen.getByRole("tab", { name: "Fantrax import" })).toBeTruthy();
    expect(screen.getByRole("tab", { name: "ESPN import" })).toBeTruthy();
    expect(screen.queryByText("No live token flow yet")).toBeNull();
    expect(screen.queryByText("Linked League and Team Context")).toBeNull();
  });

  it("shows discovered Yahoo leagues and teams when the user is connected", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        success: true,
        message: "Loaded and cached the roster for League Rival.",
        externalTeamId: "team-2",
        fetchedAt: "2026-03-27T13:00:00.000Z",
        rosterSnapshot: {
          players: [
            {
              player_key: "nhl.p.1",
              name: { full: "Connor Example" },
              display_position: "C",
            },
          ],
          visibility: "league",
          fetched_at: "2026-03-27T13:00:00.000Z",
        },
        cached: false,
      }),
    });
    vi.stubGlobal("fetch", fetchMock);
    accountState.routerQuery = {
      section: "connected-accounts",
      yahoo_status: "connected",
      yahoo_message: "Yahoo synced 2 teams across 2 leagues.",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });
    accountState.connectedAccountMaybeSingle.mockResolvedValue({
      data: {
        id: "yahoo-account-1",
        user_id: "user-1",
        provider: "yahoo",
        provider_user_id: "guid-123",
        account_label: "Tim's Yahoo",
        status: "connected",
        scopes: [],
        metadata: {},
        last_synced_at: "2026-03-27T12:00:00.000Z",
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });
    accountState.externalLeaguesOrder.mockResolvedValue({
      data: [
        {
          id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_league_key: "nhl.l.1",
          league_name: "Keeper League",
          season_key: "2026",
          league_metadata: {},
          scoring_settings: {},
          roster_settings: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
      ],
      error: null,
    });
    accountState.externalTeamsOrder.mockResolvedValue({
      data: [
        {
          id: "team-1",
          external_league_id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_team_key: "nhl.l.1.t.1",
          team_name: "Tim's Test Team",
          team_metadata: {},
          roster_snapshot: {},
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
        {
          id: "team-2",
          external_league_id: "league-1",
          connected_account_id: "yahoo-account-1",
          user_id: "user-1",
          provider: "yahoo",
          external_team_key: "nhl.l.1.t.2",
          team_name: "League Rival",
          team_metadata: {
            is_owned: false,
            standings: { rank: 1 },
          },
          roster_snapshot: {
            players: [],
            visibility: "not_fetched",
          },
          imported_at: "2026-03-27T12:00:00.000Z",
          created_at: "2026-03-27T12:00:00.000Z",
          updated_at: "2026-03-27T12:00:00.000Z",
        },
      ],
      error: null,
    });
    accountState.providerPreferencesMaybeSingle.mockResolvedValue({
      data: {
        id: "pref-1",
        user_id: "user-1",
        provider: "yahoo",
        connected_account_id: "yahoo-account-1",
        default_external_league_id: "league-1",
        default_external_team_id: "team-1",
        refresh_on_login: false,
        active_context: {},
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    expect(
      await screen.findByText("Yahoo synced 2 teams across 2 leagues."),
    ).toBeTruthy();
    expect(screen.getByText("Keeper League (default league)")).toBeTruthy();
    expect(screen.getAllByText("Tim's Test Team").length).toBeGreaterThan(0);
    expect(screen.getByText("League Rival")).toBeTruthy();
    expect(screen.getByText("League opponent · Standings rank 1")).toBeTruthy();
    expect(
      screen.getAllByText("Default team: Tim's Test Team").length,
    ).toBeGreaterThan(0);
    expect(
      screen.getByRole("button", { name: "Disconnect Yahoo" }),
    ).toBeTruthy();
    expect(screen.getByText("Default Team")).toBeTruthy();

    fireEvent.click(
      screen.getByRole("button", { name: "View League Rival roster" }),
    );

    expect(await screen.findByText("Connor Example")).toBeTruthy();
    expect(screen.getByText("1 rostered player")).toBeTruthy();
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/account/yahoo/team-roster",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ externalTeamId: "team-2" }),
      }),
    );
    expect(
      screen.getByRole("button", { name: "Hide League Rival roster" }),
    ).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: "Save Imported Team" }));

    await waitFor(() => {
      expect(accountState.savedTeamsInsert).toHaveBeenCalledWith(
        expect.objectContaining({
          user_id: "user-1",
          name: "Tim's Test Team",
          source_type: "external-provider",
          provider: "yahoo",
          external_league_key: "nhl.l.1",
          external_team_key: "nhl.l.1.t.1",
          is_default: true,
        }),
      );
    });
    expect(
      await screen.findByText('"Tim\'s Test Team" was saved from Yahoo.'),
    ).toBeTruthy();
  });

  it("shows Patreon membership controls without developer notes", async () => {
    accountState.routerQuery = {
      section: "patreon",
    };
    accountState.profileMaybeSingle.mockResolvedValue({
      data: {
        display_name: "Tim Tester",
        avatar_url: null,
        timezone: "America/Chicago",
      },
      error: null,
    });

    render(<AccountSettingsPage />);

    expect(await screen.findByText("Patreon Membership")).toBeTruthy();
    expect(
      screen.getByText("Patreon connections are unavailable right now."),
    ).toBeTruthy();
    expect(screen.queryByText("Connection Intent")).toBeNull();
    expect(screen.queryByText("Entitlement Model")).toBeNull();
    expect(screen.queryByText("Anti-Sharing Controls")).toBeNull();
  });
});
