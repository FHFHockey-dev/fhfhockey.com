import { cleanup, fireEvent, render, screen, within } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import DraftSettings from "../../../components/DraftDashboard/DraftSettings";
import type { DraftSettings as DraftSettingsContract } from "../../../components/DraftDashboard/DraftDashboard";
import { applyCategoryBoosts } from "../../../lib/draftDashboard/categoryBoosts";
import { deriveYahooDraftDashboardConfiguration } from "../../../lib/draftDashboard/yahooLiveDraft";
import DraftScoringSettings from "../../../components/DraftDashboard/DraftScoringSettings";

vi.mock("components/PlayerAutocomplete", () => ({ default: () => null }));

const settings: DraftSettingsContract = {
  teamCount: 2,
  draftOrder: ["Team 1", "Team 2"],
  scoringCategories: { GOALS: 3 },
  rosterConfig: { C: 1, LW: 0, RW: 0, D: 0, G: 1, utility: 0, bench: 0 },
  isKeeper: false,
};

afterEach(cleanup);

it("shows imported Yahoo goalie categories only in the goalie group, including the goals-against penalty", () => {
  const configuration = deriveYahooDraftDashboardConfiguration({
    session: { id: "yahoo-points", status: "predraft" }, teams: [], picks: [],
    settings: { leagueType: "points", scoringCategories: {
      GOALS: 6, HITS: 0.5, WINS_GOALIE: 5, SAVES_GOALIE: 0.6,
      SHUTOUTS_GOALIE: 5, GOALS_AGAINST_GOALIE: -2.5,
    } },
  });
  render(<DraftScoringSettings
    settings={{ ...settings, leagueType: "points", scoringCategories: configuration.scoringCategories!, categoryBoosts: { HITS: 50 } }}
    goalieScoring={configuration.goalieScoringCategories}
    onSettingsChange={vi.fn()} onGoalieScoringChange={vi.fn()}
    availableSkaterStats={[]} availableGoalieStats={[]} hasPicks={false} draftProEligible
  />);
  const skaters = within(screen.getByRole("region", { name: "Skaters scoring" }));
  const goalies = within(screen.getByRole("region", { name: "Goalies scoring" }));
  for (const label of ["W", "SV", "SHO", "GA"]) {
    expect(skaters.queryByText(label, { exact: true })).toBeNull();
    expect(goalies.getByText(label, { exact: true })).toBeTruthy();
  }
  expect(goalies.getByDisplayValue("-2.5")).toBeTruthy();
  expect(goalies.getByDisplayValue("0.6")).toBeTruthy();
  expect(skaters.getByDisplayValue("0.5")).toBeTruthy();
});

describe("Draft Pro category boosts", () => {
  it("keeps league scoring at 0.2 while displaying 0.3 for a 50% Hits boost", () => {
    const onSettingsChange = vi.fn();
    render(
      <DraftSettings
        settings={{ ...settings, scoringCategories: { HITS: 0.2 }, categoryBoosts: { HITS: 50 } }}
        onSettingsChange={onSettingsChange}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={vi.fn()}
        resetDraft={vi.fn()}
        draftHistory={[]}
        draftedPlayers={[]}
        currentPick={1}
        draftProEligible
      />,
    );
    expect((screen.getByRole("spinbutton", { name: "HITS skater weight" }) as HTMLInputElement).value).toBe("0.2");
    expect(screen.getByLabelText("HITS effective value").textContent).toBe("= 0.3");
    const rawScoring = { HITS: 0.2 };
    expect(applyCategoryBoosts(rawScoring, { HITS: 50 }).HITS).toBeCloseTo(0.3);
    expect(rawScoring.HITS).toBe(0.2);
    fireEvent.change(screen.getByRole("spinbutton", { name: "HITS skater Draft Pro boost percent" }), { target: { value: "75" } });
    expect(onSettingsChange).toHaveBeenCalledWith({ categoryBoosts: { HITS: 75 } });
    expect(onSettingsChange).not.toHaveBeenCalledWith(expect.objectContaining({ scoringCategories: expect.anything() }));
  });

  it("keeps league scoring locked during Yahoo sync while allowing Pro boosts", () => {
    const onSettingsChange = vi.fn();
    render(
      <DraftSettings
        settings={{ ...settings, scoringCategories: { HITS: 0.2 } }}
        onSettingsChange={onSettingsChange}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={vi.fn()}
        resetDraft={vi.fn()}
        draftHistory={[]}
        draftedPlayers={[]}
        currentPick={1}
        draftLocked
        draftProEligible
      />,
    );
    expect((screen.getByRole("spinbutton", { name: "HITS skater weight" }) as HTMLInputElement).disabled).toBe(true);
    const boost = screen.getByRole("spinbutton", { name: "HITS skater Draft Pro boost percent" }) as HTMLInputElement;
    expect(boost.disabled).toBe(false);
    fireEvent.change(boost, { target: { value: "50" } });
    expect(onSettingsChange).toHaveBeenCalledWith({ categoryBoosts: { HITS: 50 } });
  });

  it("does not expose boost editing to free users", () => {
    render(
      <DraftSettings
        settings={{ ...settings, scoringCategories: { HITS: 0.2 }, categoryBoosts: { HITS: 50 } }}
        onSettingsChange={vi.fn()}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={vi.fn()}
        resetDraft={vi.fn()}
        draftHistory={[]}
        draftedPlayers={[]}
        currentPick={1}
      />,
    );
    const boost = screen.getByRole("spinbutton", { name: "HITS skater Draft Pro boost percent" }) as HTMLInputElement;
    expect(boost.disabled).toBe(true);
    expect(boost.value).toBe("0");
  });
});

describe("Draft Pro position weights", () => {
  const renderWeights = (
    positionWeights: DraftSettingsContract["positionWeights"],
    draftProEligible = true,
    rawSettingsLocked = false,
  ) => {
    const onSettingsChange = vi.fn();
    render(
      <DraftScoringSettings
        settings={{ ...settings, positionWeights, categoryBoosts: { GOALS: 50 } }}
        onSettingsChange={onSettingsChange}
        availableSkaterStats={[]}
        availableGoalieStats={[]}
        hasPicks={false}
        draftProEligible={draftProEligible}
        rawSettingsLocked={rawSettingsLocked}
      />,
    );
    return onSettingsChange;
  };

  it("labels all positions and changes only valuation weights while raw scoring is locked", () => {
    const onSettingsChange = renderWeights({ C: 1.2, D: 0.8 }, true, true);
    const section = within(screen.getByRole("region", { name: "Position weights" }));
    for (const position of ["C", "LW", "RW", "D", "G"]) {
      expect(section.getByRole("spinbutton", { name: `${position} position weight percent` })).toBeTruthy();
    }
    expect((screen.getByRole("spinbutton", { name: "GOALS skater weight" }) as HTMLInputElement).disabled).toBe(true);
    const defense = section.getByRole("spinbutton", { name: "D position weight percent" }) as HTMLInputElement;
    expect(defense.value).toBe("80");
    expect(defense.disabled).toBe(false);
    fireEvent.change(defense, { target: { value: "50" } });
    expect(onSettingsChange).toHaveBeenCalledExactlyOnceWith({ positionWeights: { C: 1.2, D: 0.5 } });
    expect(section.getByText(/selected Yahoo or Fantrax source/)).toBeTruthy();
    expect(section.getByText(/highest eligible weight once/)).toBeTruthy();
    expect(section.getByText(/negative values toward zero/)).toBeTruthy();
  });

  it("clamps invalid percentages and resets weights independently", () => {
    const onSettingsChange = renderWeights({ D: 0.8 });
    const defense = screen.getByRole("spinbutton", { name: "D position weight percent" });
    fireEvent.change(defense, { target: { value: "250" } });
    expect(onSettingsChange).toHaveBeenLastCalledWith({ positionWeights: { D: 2 } });
    fireEvent.change(defense, { target: { value: "-10" } });
    expect(onSettingsChange).toHaveBeenLastCalledWith({ positionWeights: { D: 0 } });
    fireEvent.change(defense, { target: { value: "" } });
    expect(onSettingsChange).toHaveBeenLastCalledWith({ positionWeights: {} });
    fireEvent.click(screen.getByRole("button", { name: "Reset Position Weights" }));
    expect(onSettingsChange).toHaveBeenLastCalledWith({ positionWeights: {} });
  });

  it("shows neutral effective weights and disables edits without Draft Pro", () => {
    const onSettingsChange = renderWeights({ D: 0.5 }, false);
    const defense = screen.getByRole("spinbutton", { name: "D position weight percent" }) as HTMLInputElement;
    expect(defense.value).toBe("100");
    expect(defense.disabled).toBe(true);
    expect((screen.getByRole("button", { name: "Reset Position Weights" }) as HTMLButtonElement).disabled).toBe(true);
    expect(onSettingsChange).not.toHaveBeenCalled();
  });
});

describe("DraftSettings A&G component confirmation", () => {
  afterEach(() => vi.restoreAllMocks());

  const renderSources = (
    sourceControls: Record<string, { isSelected: boolean; weight: number }>,
  ) => {
    const onSourceControlsChange = vi.fn();
    render(
      <DraftSettings
        settings={settings}
        onSettingsChange={vi.fn()}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={vi.fn()}
        resetDraft={vi.fn()}
        draftHistory={[]}
        draftedPlayers={[]}
        currentPick={1}
        sourceControls={sourceControls}
        onSourceControlsChange={onSourceControlsChange}
      />,
    );
    expect(screen.queryByText(/2026–27 public sources only/)).toBeNull();
    fireEvent.click(screen.getByTestId("open-weights-popover"));
    expect(screen.queryByText(/Use the A&G aggregate or its/)).toBeNull();
    return onSourceControlsChange;
  };

  it.each([
    ["blake_ag_skaters", "Blake A&G (component)", true],
    ["nate_ag_skaters", "Nate A&G (component)", true],
    ["blake_ag_skaters", "Blake A&G (component)", false],
    ["nate_ag_skaters", "Nate A&G (component)", false],
  ] as const)(
    "confirms enabling %s (%s), aggregate selected=%s, and preserves cancellation",
    (id, displayName, aggregateSelected) => {
      const confirm = vi.spyOn(window, "confirm").mockReturnValue(false);
      const controls = {
        ag_skaters: { isSelected: aggregateSelected, weight: 1 },
        [id]: { isSelected: false, weight: 0.75 },
      };
      const onChange = renderSources(controls);
      const toggle = screen.getByRole("checkbox", {
        name: `Toggle source ${displayName}`,
      }) as HTMLInputElement;

      fireEvent.click(toggle);
      expect(confirm).toHaveBeenCalledWith(
        'Enabling "AG Blake" or "AG Nate" alongside "Apples & Ginos" double-weights those projections. Proceed?',
      );
      expect(onChange).not.toHaveBeenCalled();
      expect(toggle.checked).toBe(false);

      confirm.mockReturnValue(true);
      fireEvent.click(toggle);
      expect(confirm).toHaveBeenCalledTimes(2);
      expect(onChange).toHaveBeenCalledExactlyOnceWith({
        ...controls,
        [id]: { isSelected: true, weight: 0.75 },
      });
    },
  );

  it.each([
    ["blake_ag_skaters", "Blake A&G (component)"],
    ["nate_ag_skaters", "Nate A&G (component)"],
  ])("does not confirm disabling %s", (id, displayName) => {
    const confirm = vi.spyOn(window, "confirm").mockReturnValue(false);
    const onChange = renderSources({ [id]: { isSelected: true, weight: 1 } });
    fireEvent.click(screen.getByRole("checkbox", {
      name: `Toggle source ${displayName}`,
    }));
    expect(confirm).not.toHaveBeenCalled();
    expect(onChange).toHaveBeenCalledExactlyOnceWith({
      [id]: { isSelected: false, weight: 1 },
    });
  });

  it("does not confirm enabling other projection sources", () => {
    const confirm = vi.spyOn(window, "confirm").mockReturnValue(false);
    const onChange = renderSources({ dtz_skaters: { isSelected: false, weight: 1 } });
    fireEvent.click(screen.getByRole("checkbox", { name: "Toggle source DTZ" }));
    expect(confirm).not.toHaveBeenCalled();
    expect(onChange).toHaveBeenCalledExactlyOnceWith({
      dtz_skaters: { isSelected: true, weight: 1 },
    });
  });
});

describe("DraftSettings inline league views", () => {
  it("keeps the format default compact while exposing schedule and management controls on demand", () => {
    render(
      <DraftSettings
        variant="inline"
        activeSection="league"
        matchupWeeks={[{ week: 24, start_date: "2027-03-15", end_date: "2027-03-21" }]}
        settings={settings}
        onSettingsChange={vi.fn()}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={vi.fn()}
        resetDraft={vi.fn()}
        draftHistory={[]}
        draftedPlayers={[]}
        currentPick={1}
      />,
    );

    expect(screen.getByRole("button", { name: "Format" }).getAttribute("aria-pressed")).toBe("true");
    const playoffWeeks = screen.getByLabelText("Playoff Weeks");
    const teamCount = screen.getByLabelText("Number of teams");
    expect(playoffWeeks.closest("[hidden]")).toBeTruthy();
    expect(teamCount.closest("[hidden]")).toBeNull();

    fireEvent.click(screen.getByRole("button", { name: "Schedule" }));
    expect(playoffWeeks.closest("[hidden]")).toBeNull();
    expect(teamCount.closest("[hidden]")).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: "Management" }));
    expect(screen.getByRole("button", { name: "Export Settings" })).toBeTruthy();
  });
});

describe("DraftSettings goalie scoring manager", () => {
  it("edits exact custom reversed rounds and locks them after drafting starts", () => {
    const onDraftOrderPatternChange = vi.fn();
    const props = {
      settings,
      onSettingsChange: vi.fn(),
      draftOrderPattern: {
        mode: "custom" as const,
        reversedRounds: [] as number[],
      },
      onDraftOrderPatternChange,
      myTeamId: "Team 1",
      onMyTeamIdChange: vi.fn(),
      undoLastPick: vi.fn(),
      resetDraft: vi.fn(),
      draftHistory: [],
      draftedPlayers: [],
      currentPick: 1,
    };
    const view = render(<DraftSettings {...props} />);

    expect(
      screen.getByRole("button", { name: "Custom" }).getAttribute(
        "aria-pressed",
      ),
    ).toBe("true");
    fireEvent.click(screen.getByRole("button", { name: "Round 2, forward" }));
    expect(onDraftOrderPatternChange).toHaveBeenCalledWith({
      mode: "custom",
      reversedRounds: [2],
    });

    view.rerender(
      <DraftSettings
        {...props}
        structuralSettingsLocked
        draftOrderPattern={{ mode: "custom", reversedRounds: [2] }}
      />,
    );
    expect(
      (screen.getByRole("button", { name: "Standard" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    expect(
      (screen.getByRole("button", {
        name: "Round 2, reversed",
      }) as HTMLButtonElement).disabled,
    ).toBe(true);
  });

  it("manages goalie stats independently with duplicate-safe add options", () => {
    const onGoalieScoringChange = vi.fn();
    render(
      <DraftSettings
        settings={settings}
        onSettingsChange={vi.fn()}
        isSnakeDraft
        onSnakeDraftChange={vi.fn()}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={vi.fn()}
        resetDraft={vi.fn()}
        draftHistory={[]}
        draftedPlayers={[]}
        currentPick={1}
        goalieScoringCategories={{ WINS_GOALIE: 3, SAVES_GOALIE: 0.2 }}
        onGoalieScoringChange={onGoalieScoringChange}
        availableGoalieStatKeys={[
          "WINS_GOALIE",
          "SAVES_GOALIE",
          "SHUTOUTS_GOALIE",
        ]}
      />,
    );

    const skaterManager = screen.getByTitle("Manage / Add scoring stats");
    const goalieManager = screen.getByTitle("Manage / Add goalie stats");
    expect(skaterManager.getAttribute("aria-expanded")).toBe("false");
    fireEvent.click(goalieManager);
    expect(skaterManager.getAttribute("aria-expanded")).toBe("false");

    const select = screen.getByLabelText(
      "Select goalie stat to add",
    ) as HTMLSelectElement;
    expect(Array.from(select.options).map((option) => option.value)).toEqual([
      "",
      "SHUTOUTS_GOALIE",
    ]);
    fireEvent.change(select, { target: { value: "SHUTOUTS_GOALIE" } });
    fireEvent.change(screen.getByLabelText("New goalie stat point value"), {
      target: { value: "4" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Add Stat" }));
    expect(onGoalieScoringChange).toHaveBeenCalledWith({
      WINS_GOALIE: 3,
      SAVES_GOALIE: 0.2,
      SHUTOUTS_GOALIE: 4,
    });

    fireEvent.click(screen.getByRole("button", { name: "Remove WINS_GOALIE" }));
    expect(onGoalieScoringChange).toHaveBeenCalledWith({ SAVES_GOALIE: 0.2 });
    fireEvent.click(
      screen.getByRole("button", { name: "Reset Goalie Scoring" }),
    );
    expect(onGoalieScoringChange).toHaveBeenCalledTimes(3);
  });
});

describe("DraftSettings SHA selectors", () => {
  it("offers derived SHA in both Points and Categories configuration", () => {
    const { unmount } = render(
      <DraftSettings
        settings={settings}
        onSettingsChange={vi.fn()}
        isSnakeDraft
        onSnakeDraftChange={vi.fn()}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={vi.fn()}
        resetDraft={vi.fn()}
        draftHistory={[]}
        draftedPlayers={[]}
        currentPick={1}
        availableSkaterStatKeys={["GOALS", "SH_ASSISTS"]}
      />,
    );

    fireEvent.click(screen.getByTitle("Manage / Add scoring stats"));
    expect(
      Array.from(
        (screen.getByLabelText("Select stat to add") as HTMLSelectElement)
          .options,
      ).map((option) => [option.value, option.text]),
    ).toContainEqual(["SH_ASSISTS", "SHA"]);

    unmount();
    render(
      <DraftSettings
        settings={{
          ...settings,
          leagueType: "categories",
          categoryWeights: {},
        }}
        onSettingsChange={vi.fn()}
        isSnakeDraft
        onSnakeDraftChange={vi.fn()}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={vi.fn()}
        resetDraft={vi.fn()}
        draftHistory={[]}
        draftedPlayers={[]}
        currentPick={1}
        availableSkaterStatKeys={["GOALS", "SH_ASSISTS"]}
      />,
    );

    fireEvent.click(screen.getByTitle("Manage / Add categories"));
    expect(
      Array.from(
        (screen.getByLabelText("Select category to add") as HTMLSelectElement)
          .options,
      ).map((option) => [option.value, option.text]),
    ).toContainEqual(["SH_ASSISTS", "SHA"]);
  });
});

describe("DraftSettings Yahoo lock", () => {
  it("visibly disables draft structure, roster, scoring, undo, and reset controls", () => {
    const onSettingsChange = vi.fn();
    const onSnakeDraftChange = vi.fn();
    const undoLastPick = vi.fn();
    const resetDraft = vi.fn();
    render(
      <DraftSettings
        settings={{ ...settings, isKeeper: true }}
        onSettingsChange={onSettingsChange}
        isSnakeDraft
        onSnakeDraftChange={onSnakeDraftChange}
        myTeamId="Team 1"
        onMyTeamIdChange={vi.fn()}
        undoLastPick={undoLastPick}
        resetDraft={resetDraft}
        draftHistory={[{ players: [], pickNumber: 1 }]}
        draftedPlayers={[
          {
            playerId: "1",
            teamId: "Team 1",
            pickNumber: 1,
            round: 1,
            pickInRound: 1,
          },
        ]}
        currentPick={2}
        draftLocked
        draftLockReason="Yahoo live sync controls this draft."
      />,
    );

    expect(screen.getByRole("status").textContent).toContain("Yahoo live sync");
    expect(
      (screen.getByTestId("team-count-select") as HTMLInputElement).disabled,
    ).toBe(true);
    expect(
      (screen.getByTestId("roster-input-C") as HTMLInputElement).closest(
        "fieldset",
      )?.hasAttribute("disabled"),
    ).toBe(true);
    expect(
      (
        screen.getByRole("button", {
          name: "Snake",
          hidden: true,
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    expect(
      (screen.getByTestId("undo-pick-btn") as HTMLButtonElement).disabled,
    ).toBe(true);
    expect(
      (screen.getByTestId("reset-draft-btn") as HTMLButtonElement).disabled,
    ).toBe(true);

    fireEvent.click(screen.getByTestId("undo-pick-btn"));
    fireEvent.click(screen.getByTestId("reset-draft-btn"));
    expect(undoLastPick).not.toHaveBeenCalled();
    expect(resetDraft).not.toHaveBeenCalled();
    expect(onSettingsChange).not.toHaveBeenCalled();
    expect(onSnakeDraftChange).not.toHaveBeenCalled();
  });
});


it("selects nonconsecutive playoff weeks and clears playoff scope", () => {
  const onSettingsChange = vi.fn();
  render(<DraftSettings settings={{ ...settings, playoffWeeks: [24, 27], scheduleScope: "playoffs" }} onSettingsChange={onSettingsChange} myTeamId="Team 1" onMyTeamIdChange={vi.fn()} undoLastPick={vi.fn()} resetDraft={vi.fn()} draftHistory={[]} draftedPlayers={[]} currentPick={1} matchupWeeks={[24, 25, 27].map((week) => ({ week, start_date: "2027-03-15", end_date: "2027-03-21" }))} />);
  const select = screen.getByRole("listbox", { name: "Playoff Weeks" }) as HTMLSelectElement;
  expect([...select.selectedOptions].map((option) => option.value)).toEqual(["24", "27"]);
  select.options[0].selected = false;
  fireEvent.change(select);
  expect(onSettingsChange).toHaveBeenLastCalledWith({ playoffWeeks: [27] });
  fireEvent.click(screen.getByRole("button", { name: "Clear playoff weeks" }));
  expect(onSettingsChange).toHaveBeenLastCalledWith({ playoffWeeks: [], scheduleScope: "season" });
});


describe("Settings team names and stable draft order", () => {
  const setup = (extra = {}) => {
    const onUpdateTeamName = vi.fn(), onSettingsChange = vi.fn();
    render(<DraftSettings settings={settings} onSettingsChange={onSettingsChange} onUpdateTeamName={onUpdateTeamName}
      myTeamId="Team 1" onMyTeamIdChange={vi.fn()} undoLastPick={vi.fn()} resetDraft={vi.fn()} draftHistory={[]}
      draftedPlayers={[]} currentPick={1} customTeamNames={{ "Team 1": "Ice Owls" }} {...extra} />);
    return { onUpdateTeamName, onSettingsChange };
  };
  it("renames shared IDs and moves IDs without renumbering them", () => {
    const callbacks = setup();
    fireEvent.change(screen.getByLabelText("Team name at draft position 1"), { target: { value: "Snow Owls" } });
    expect(callbacks.onUpdateTeamName).toHaveBeenCalledWith("Team 1", "Snow Owls");
    fireEvent.click(screen.getByRole("button", { name: "Move Ice Owls down" }));
    expect(callbacks.onSettingsChange).toHaveBeenCalledWith({ draftOrder: ["Team 2", "Team 1"] });
    expect((screen.getByRole("button", { name: "Move Ice Owls up" }) as HTMLButtonElement).disabled).toBe(true);
  });
  it.each([{ structuralSettingsLocked: true }, { draftedPlayers: [{}] }, { keepers: [{ cost: "none", teamId: "Team 1", playerId: "1" }] }, { pickTrades: [{ round: 1 }] }])("locks reordering while retaining manual name edits: %j", extra => {
    setup(extra);
    expect((screen.getByRole("button", { name: "Move Ice Owls down" }) as HTMLButtonElement).disabled).toBe(true);
    expect((screen.getByLabelText("Team name at draft position 1") as HTMLInputElement).disabled).toBe(false);
  });
  it("locks both controls during authoritative sync", () => {
    setup({ draftLocked: true });
    expect((screen.getByRole("button", { name: "Move Ice Owls down" }) as HTMLButtonElement).disabled).toBe(true);
    expect((screen.getByLabelText("Team name at draft position 1") as HTMLInputElement).disabled).toBe(true);
  });
});
