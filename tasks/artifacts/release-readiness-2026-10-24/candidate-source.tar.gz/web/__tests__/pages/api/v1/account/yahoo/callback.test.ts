import { ProviderSyncAccessError, requireProviderSyncAccess } from "lib/integrations/providerSyncAccessServer";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const {
  consumeYahooOAuthTransactionMock,
  exchangeYahooAuthorizationCodeMock,
  buildYahooAccountRedirectMock,
  readYahooOAuthBrowserBindingMock,
  clearYahooOAuthBrowserCookieMock,
  syncYahooDiscoveryMock,
  maybeSingleMock,
  insertSingleMock,
} = vi.hoisted(() => ({
  consumeYahooOAuthTransactionMock: vi.fn(),
  exchangeYahooAuthorizationCodeMock: vi.fn(),
  buildYahooAccountRedirectMock: vi.fn(),
  readYahooOAuthBrowserBindingMock: vi.fn(),
  clearYahooOAuthBrowserCookieMock: vi.fn(),
  syncYahooDiscoveryMock: vi.fn(),
  maybeSingleMock: vi.fn(),
  insertSingleMock: vi.fn(),
}));

vi.mock("lib/integrations/yahoo/oauth", () => ({
  consumeYahooOAuthTransaction: consumeYahooOAuthTransactionMock,
  exchangeYahooAuthorizationCode: exchangeYahooAuthorizationCodeMock,
  buildYahooAccountRedirect: buildYahooAccountRedirectMock,
  readYahooOAuthBrowserBinding: readYahooOAuthBrowserBindingMock,
  clearYahooOAuthBrowserCookie: clearYahooOAuthBrowserCookieMock,
}));

vi.mock("lib/integrations/yahoo/discovery", () => ({
  syncYahooDiscovery: syncYahooDiscoveryMock,
}));

vi.mock("lib/supabase/server", () => ({
  default: {
    from: (table: string) => {
      if (table !== "connected_accounts") {
        throw new Error(`Unexpected table ${table}`);
      }

      return {
        select: () => ({
          eq: (_field: string, _value: string) => ({
            eq: (_nextField: string, _nextValue: string) => ({
              maybeSingle: maybeSingleMock,
            }),
          }),
        }),
        insert: (_payload: any) => ({
          select: () => ({
            single: insertSingleMock,
          }),
        }),
        update: () => ({
          eq: () => ({
            select: () => ({
              single: insertSingleMock,
            }),
          }),
        }),
      };
    },
  },
}));

import handler from "../../../../../../pages/api/v1/account/yahoo/callback";

function createMockRes() {
  const res: any = {
    headers: {} as Record<string, unknown>,
    redirectedTo: null as string | null,
    redirect(location: string) {
      this.redirectedTo = location;
      return this;
    },
    setHeader(name: string, value: unknown) {
      this.headers[name.toLowerCase()] = value;
    },
    status() {
      return this;
    },
    json() {
      return this;
    },
  };

  return res;
}

describe("/api/v1/account/yahoo/callback", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-08-24T12:00:00.000Z"));
    consumeYahooOAuthTransactionMock.mockResolvedValue({
      userId: "user-1",
      safeNextPath: "/account?section=connected-accounts",
      redirectUri: "https://fhfhockey.com/api/v1/account/yahoo/callback",
      pkceCodeVerifier: "v".repeat(64),
    });
    readYahooOAuthBrowserBindingMock.mockReturnValue("browser-binding");
    clearYahooOAuthBrowserCookieMock.mockReturnValue(
      "fhfh_yahoo_oauth=; Max-Age=0",
    );
    exchangeYahooAuthorizationCodeMock.mockResolvedValue({
      access_token: "access-token",
      expires_in: 3600,
      refresh_token: "refresh-token",
      token_type: "bearer",
      xoauth_yahoo_guid: "guid-123",
    });
    buildYahooAccountRedirectMock.mockImplementation(
      (_next: string, status: string, message: string) =>
        `/account?section=connected-accounts&yahoo_status=${status}&yahoo_message=${encodeURIComponent(message)}`
    );
    maybeSingleMock.mockResolvedValue({
      data: null,
      error: null,
    });
    insertSingleMock.mockResolvedValue({
      data: {
        id: "yahoo-account-1",
        user_id: "user-1",
        provider: "yahoo",
        provider_user_id: "guid-123",
        account_label: "Yahoo Fantasy",
        status: "syncing",
        scopes: [],
        metadata: {},
        last_synced_at: null,
        created_at: "2026-03-27T12:00:00.000Z",
        updated_at: "2026-03-27T12:00:00.000Z",
      },
      error: null,
    });
    syncYahooDiscoveryMock.mockResolvedValue({
      leagueCount: 2,
      teamCount: 3,
      defaultExternalLeagueId: "league-1",
      defaultExternalTeamId: "team-1",
    });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("creates a yahoo account row and redirects with success state", async () => {
    const req: any = {
      method: "GET",
      query: {
        code: "auth-code",
        state: "signed-state",
      },
    };
    const res = createMockRes();

    await handler(req, res);

    expect(consumeYahooOAuthTransactionMock).toHaveBeenCalledWith({
      browserBinding: "browser-binding",
      state: "signed-state",
    });
    expect(exchangeYahooAuthorizationCodeMock).toHaveBeenCalledWith({
      code: "auth-code",
      codeVerifier: "v".repeat(64),
      redirectUri: "https://fhfhockey.com/api/v1/account/yahoo/callback",
    });
    expect(syncYahooDiscoveryMock).toHaveBeenCalledWith(
      expect.objectContaining({
        expiresAt: "2026-08-24T13:00:00.000Z",
      }),
    );
    expect(res.redirectedTo).toContain("yahoo_status=connected");
    expect(res.headers["set-cookie"]).toContain("Max-Age=0");
  });

  it("clears the browser binding even when state consumption fails", async () => {
    consumeYahooOAuthTransactionMock.mockRejectedValue(
      new Error("Yahoo authorization state is missing, expired, or already used."),
    );
    const res = createMockRes();
    await handler(
      { method: "GET", query: { code: "auth-code", state: "replayed-state" } } as any,
      res,
    );
    expect(res.headers["set-cookie"]).toContain("Max-Age=0");
    expect(exchangeYahooAuthorizationCodeMock).not.toHaveBeenCalled();
    expect(res.redirectedTo).toContain("yahoo_status=error");
  });
});

vi.mock("lib/integrations/providerSyncAccessServer", async (importOriginal) => ({ ...await importOriginal<typeof import("lib/integrations/providerSyncAccessServer")>(), requireProviderSyncAccess: vi.fn().mockResolvedValue({ eligible: true }) }));

 it.each([403, 503])("rechecks callback access before token exchange or persistence (%s)", async (status) => {
   vi.clearAllMocks();
   consumeYahooOAuthTransactionMock.mockResolvedValue({ userId: "transaction-owner", safeNextPath: "/account", redirectUri: "https://fixture.invalid/callback", pkceCodeVerifier: "fixture" });
   vi.mocked(requireProviderSyncAccess).mockRejectedValueOnce(new ProviderSyncAccessError(status, status === 403 ? "expired" : "verification_unavailable", status === 403 ? "Premium access required" : "Access unavailable; retry"));
   const res: any = { setHeader: vi.fn(), redirect: vi.fn() };
   await handler({ method: "GET", query: { code: "fixture-code", state: "fixture-state", userId: "injected-user" } } as any, res);
   expect(requireProviderSyncAccess).toHaveBeenCalledWith("transaction-owner");
   expect(exchangeYahooAuthorizationCodeMock).not.toHaveBeenCalled();
   expect(syncYahooDiscoveryMock).not.toHaveBeenCalled();
   expect(maybeSingleMock).not.toHaveBeenCalled(); expect(insertSingleMock).not.toHaveBeenCalled();
   expect(buildYahooAccountRedirectMock).toHaveBeenCalledWith("/account", "error", status === 403 ? "Premium access required" : "Access unavailable; retry");
 });
