// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ supabase: null as any }));
vi.mock("utils/adminOnlyMiddleware", () => ({ default: (handler: any) => (req: any, res: any) => { req.supabase = mocks.supabase; return handler(req, res); } }));
vi.mock("lib/sources/tweetAttribution", () => ({ retryTweetAttribution: async () => ({ resolved: 0, skipped: true }) }));
vi.mock("lib/sources/lineSourceProcessing", () => ({ fetchRosterEntriesByTeam: async () => new Map([[30, []]]), fetchPlayerNameAliases: async () => [],
  applyPlayerNameAliasesToRosterMap: ({ rosterByTeam }: any) => rosterByTeam, sendPlayerAliasReviewEmailForQueuedNames: async () => null }));
vi.mock("lib/sources/playerIdentity", async (importOriginal) => ({ ...await importOriginal<typeof import("lib/sources/playerIdentity")>(),
  resolvePlayerIdentity: () => ({ status: "matched", player: { playerId: 8400001 } }) }));
import handler from "pages/api/v1/db/replay-player-aliases";

const now = "2026-10-17T16:00:00.000Z";
// X Snowflake IDs carry their publication time, which the route uses to pick the report date.
const tweetIdAt = (iso: string) => ((BigInt(Date.parse(iso)) - BigInt("1288834974657")) << BigInt(22)).toString();
const row = (id: number, publishedAt: string) => ({ id, raw_name: "Synthetic Skater", tweet_id: tweetIdAt(publishedAt), source: "gamedaygoalies",
  status: "pending", created_at: publishedAt, metadata: { sourceKey: "gamedaygoalies" } });

function fixture() {
  const job = { job_key: "alias-replay:100", payload: { normalizedName: "synthetic skater", teamId: 30, playerId: 8400001, alias: "Synthetic", afterId: null } };
  const rows = [row(101, "2026-10-14T23:00:00.000Z"), row(102, "2026-10-17T15:30:00.000Z")];
  const writes: Array<{ table: string; value: any; filters: unknown[][] }> = [];
  mocks.supabase = {
    rpc: async () => ({ data: true, error: null }),
    from: (table: string) => {
      const filters: unknown[][] = [];
      let write: any = null;
      const query: any = {};
      for (const method of ["select", "like", "in", "lt", "lte", "gt", "eq", "is", "order", "limit"]) query[method] = (...args: unknown[]) => { filters.push([method, ...args]); return query; };
      query.update = (value: unknown) => { write = { table, value, filters }; writes.push(write); return query; };
      query.then = (resolve: any, reject: any) => Promise.resolve(write ? { error: null }
        : { data: table === "tweet_pipeline_jobs" ? [job] : rows, error: null }).then(resolve, reject);
      return query;
    },
  };
  const res: any = { statusCode: 200, body: null, status: (code: number) => { res.statusCode = code; return res; }, json: (body: unknown) => { res.body = body; return res; }, end: () => res };
  const fetchMock = vi.fn(async () => new Response("{}", { status: 200 }));
  vi.stubGlobal("fetch", fetchMock);
  return { req: { method: "GET", query: {} } as any, res, writes, fetchMock, rows };
}

const resolvedIds = (writes: Array<{ table: string; value: any; filters: unknown[][] }>) => writes
  .filter((write) => write.table === "lineup_unresolved_player_names" && write.value.status === "resolved")
  .map((write) => write.filters.find(([method, column]) => method === "eq" && column === "id")?.[2]);
const jobWrite = (writes: Array<{ table: string; value: any }>) => writes.find((write) => write.table === "tweet_pipeline_jobs")?.value;

describe("alias replay cron", () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ["Date"] }); vi.setSystemTime(new Date(now));
    vi.stubEnv("TWEET_PIPELINE_INTERPRETATION_ENABLED", "true"); vi.stubEnv("TWEET_PIPELINE_PUBLISHING_ENABLED", "false");
    vi.stubEnv("NEXT_PUBLIC_SITE_URL", "https://trusted.example"); vi.stubEnv("CRON_SECRET", "fixture");
    for (const name of ["IFTTT_RECEIPT_VARIANTS_ENABLED", "IFTTT_INTAKE_POLICY", "IFTTT_INTAKE_STOP"]) vi.stubEnv(name, undefined);
  });
  afterEach(() => { vi.useRealTimers(); vi.unstubAllEnvs(); vi.unstubAllGlobals(); });

  it("resolves history and replays a current-day name through the processor without pilot configuration", async () => {
    const { req, res, writes, fetchMock, rows } = fixture();
    await handler(req, res);
    expect(res.body).toMatchObject({ success: true, resolved: 2 });
    expect(resolvedIds(writes)).toEqual([101, 102]);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const url = new URL(String((fetchMock.mock.calls[0] as unknown[])[0]));
    expect(url.pathname).toBe("/api/v1/db/update-line-sources");
    expect(Object.fromEntries(url.searchParams)).toEqual({ date: "2026-10-17", tweetId: rows[1].tweet_id, reprocess: "true", limit: "1", sourceKey: "gamedaygoalies" });
    expect(jobWrite(writes)).toMatchObject({ status: "complete", attempts: 0, payload: { afterId: 102 } });
  });

  it.each([
    ["an active pilot", { IFTTT_RECEIPT_VARIANTS_ENABLED: "true", IFTTT_INTAKE_POLICY: "{}", TWEET_CLAIMS_MODE: "shadow" }],
    ["a stopped pilot", { IFTTT_INTAKE_STOP: "true" }],
  ])("keeps %s retain-only: history still resolves, the current-day row and job wait", async (_label, env) => {
    for (const [name, value] of Object.entries(env)) vi.stubEnv(name, value);
    const { req, res, writes, fetchMock } = fixture();
    await handler(req, res);
    expect(fetchMock).not.toHaveBeenCalled();
    expect(res.body).toMatchObject({ success: true, resolved: 1 });
    expect(resolvedIds(writes)).toEqual([101]);
    expect(jobWrite(writes)).toMatchObject({ status: "pending", attempts: 0, payload: { afterId: 101 } });
  });
});
