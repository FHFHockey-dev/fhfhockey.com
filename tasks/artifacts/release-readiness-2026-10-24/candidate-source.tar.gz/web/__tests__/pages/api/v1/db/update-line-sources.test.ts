// @vitest-environment node
import * as claimIntake from "lib/sources/tweetClaimEvaluationIntake";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

function paginatedRoster(result: { data: any[]; error: null }) {
  const query: any = {
    in: vi.fn(() => query), eq: vi.fn(() => query), order: vi.fn(() => query),
    range: vi.fn((from: number, to: number) => Promise.resolve({ ...result, data: result.data.slice(from, to + 1) })),
  };
  return query;
}

function matchedJobUpdate(values: Record<string, unknown>) {
  const filters: Record<string, unknown> = {};
  const query: any = { eq: (key: string, value: unknown) => { filters[key] = value; return query; },
    gt: () => query, select: () => query,
    maybeSingle: async () => ({ data: { ...values, job_key: filters.job_key, owner: filters.owner }, error: null }) };
  return query;
}

const mocks = vi.hoisted(() => ({
  getCurrentSeason: vi.fn(),
  getTeams: vi.fn(),
  from: vi.fn(),
  rpc: vi.fn(),
  syncLineCombinationSourceWinners: vi.fn(),
  capturePlayerForecastSourceRows: vi.fn(),
  auditInsert: vi.fn().mockResolvedValue({ error: null }),
}));

vi.mock("lib/NHL/server", () => ({
  getCurrentSeason: mocks.getCurrentSeason,
  getTeams: mocks.getTeams,
}));

vi.mock("utils/adminOnlyMiddleware", () => ({
  default: (handler: any) => async (req: any, res: any) =>
    handler(
      {
        ...req,
        supabase: {
          from: mocks.from,
          rpc: mocks.rpc,
        },
      },
      res,
    ),
}));

vi.mock("lib/supabase/server", () => ({
  default: {
    from: (table: string) => {
      if (table !== "cron_job_audit") throw new Error(`Unexpected audit table ${table}`);
      return { insert: mocks.auditInsert };
    },
  },
}));

vi.mock("lib/sources/lineSourceLineCombinations", () => ({
  syncLineCombinationSourceWinners: mocks.syncLineCombinationSourceWinners,
}));
vi.mock("lib/player-forecasts/sourceObservations", () => ({
  capturePlayerForecastSourceRows: mocks.capturePlayerForecastSourceRows,
}));

import handler from "../../../../../pages/api/v1/db/update-line-sources";
import cccHandler from "../../../../../pages/api/v1/db/update-lines-ccc";
import releaseHandler from "../../../../../pages/api/v1/db/starter-board-release";
import { projectionInputHash } from "lib/projections/inputCapture";
import { ForecastScheduleError, type ForecastScheduleRejection } from "lib/player-forecasts/scopeReads";
import * as tweetProjectionStorage from "lib/sources/tweetProjectionStorage";
import * as lineProcessor from "lib/lines/processor";
import * as tweetClaimRegistry from "lib/sources/tweetClaimRegistry";

type LineSourceEventFixture = {
  id: string;
  source: string;
  source_group: string;
  source_key: string;
  source_account: string;
  username: string;
  text: string;
  link_to_tweet: string;
  tweet_id: string;
  tweet_created_at: string | null;
  created_at_label: string;
  processing_status: string;
  raw_payload: Record<string, unknown>;
  received_at: string;
};

function createMockReq(overrides: Record<string, unknown> = {}) {
  return {
    method: "POST",
    query: {
      date: "2026-04-29",
      limit: "10",
    },
    ...overrides,
  } as any;
}

function createMockRes() {
  return {
    statusCode: 200,
    headers: {} as Record<string, unknown>,
    body: undefined as unknown,
    setHeader(name: string, value: unknown) {
      this.headers[name] = value;
      return this;
    },
    status(code: number) {
      this.statusCode = code;
      return this;
    },
    json(body: unknown) {
      this.body = body;
      return this;
    },
  } as any;
}

function buildEvent(args: {
  id: string;
  sourceKey: string;
  sourceAccount: string;
  tweetId: string;
  text: string;
  receivedAt?: string;
}): LineSourceEventFixture {
  return {
    id: args.id,
    source: "ifttt",
    source_group: "gdl_suite",
    source_key: args.sourceKey,
    source_account: args.sourceAccount,
    username: args.sourceAccount,
    text: args.text,
    link_to_tweet: `https://twitter.com/${args.sourceAccount}/status/${args.tweetId}`,
    tweet_id: args.tweetId,
    tweet_created_at: "2026-04-29T23:11:00.000Z",
    created_at_label: "April 29, 2026 at 07:11PM",
    processing_status: "pending",
    raw_payload: {
      linesCccOembed: {
        wrapper: {
          status: "failed",
          tweetId: args.tweetId,
          tweetUrl: `https://twitter.com/i/web/status/${args.tweetId}`,
          attemptCount: 1,
          lastAttemptAt: "2026-04-29T23:12:00.000Z",
          httpStatus: 500,
          lastError: "oembed_http_500",
        },
      },
    },
    received_at: args.receivedAt ?? "2026-04-29T23:11:16.000Z",
  };
}

function createLineSourceEventsQuery(eventRows: LineSourceEventFixture[]) {
  const filters: Array<{
    type: "eq" | "in" | "gte" | "lt";
    column: string;
    value: unknown;
  }> = [];
  const query: any = {
    eq: vi.fn((column: string, value: unknown) => {
      filters.push({ type: "eq", column, value });
      return query;
    }),
    in: vi.fn((column: string, value: unknown[]) => {
      filters.push({ type: "in", column, value });
      return query;
    }),
    gte: vi.fn((column: string, value: string) => { filters.push({ type: "gte", column, value }); return query; }),
    lt: vi.fn((column: string, value: string) => { filters.push({ type: "lt", column, value }); return query; }),
    order: vi.fn(() => query),
    limit: vi.fn(async (limit: number) => {
      const filteredRows = eventRows.filter((row) =>
        filters.every((filter) => {
          const rowValue = row[filter.column as keyof LineSourceEventFixture];
          if (filter.type === "gte") return String(rowValue) >= String(filter.value);
          if (filter.type === "lt") return String(rowValue) < String(filter.value);
          return filter.type === "eq"
            ? rowValue === filter.value
            : (filter.value as unknown[]).includes(rowValue);
        }),
      );
      return {
        data: filteredRows.slice(0, limit),
        error: null,
      };
    }),
  };
  return query;
}

function createSupabaseMocks(eventRows: LineSourceEventFixture[]) {
  const lineSourceSnapshotsUpsertMock = vi
    .fn()
    .mockResolvedValue({ error: null });
  const staleRowUpdateQuery: any = {
    eq: vi.fn(() => staleRowUpdateQuery),
    neq: vi.fn(() => staleRowUpdateQuery),
    then: (resolve: any) => Promise.resolve({ error: null }).then(resolve),
  };
  const staleRowUpdateMock = vi.fn(() => staleRowUpdateQuery);
  const eventUpdateEqMock = vi.fn().mockResolvedValue({ error: null });
  const eventUpdateMock = vi.fn((_values: Record<string, unknown>) => ({
    eq: eventUpdateEqMock,
  }));
  const unresolvedNamesUpsertMock = vi.fn((rows: any[]) => ({ select: vi.fn().mockResolvedValue({ data: rows.map((_, index) => ({ id: String(index) })), error: null }) }));
  const lineSourceEventsQuery = createLineSourceEventsQuery(eventRows);

  const tables: Record<string, any> = {
    games: {
      select: vi.fn(() => ({
        eq: vi.fn(() => ({
          order: vi.fn().mockResolvedValue({
            data: [
              {
                id: 2025030111,
                date: "2026-04-29",
                homeTeamId: 8,
                awayTeamId: 14,
              },
            ],
            error: null,
          }),
        })),
      })),
    },
    rosters: {
      select: vi.fn(() => ({
        in: vi.fn((_column: string, teamIds: number[]) => ({
          eq: vi.fn(() => paginatedRoster({
            data: [
              {
                teamId: 8,
                playerId: 8480018,
                players: { fullName: "Cole Caufield", lastName: "Caufield", position: "F" },
              },
              {
                teamId: 8,
                playerId: 8480019,
                players: { fullName: "Nick Suzuki", lastName: "Suzuki", position: "F" },
              },
              {
                teamId: 8,
                playerId: 8480020,
                players: {
                  fullName: "Juraj Slafkovsky",
                  lastName: "Slafkovsky",
                  position: "F",
                },
              },
              {
                teamId: 8,
                playerId: 8482487,
                players: { fullName: "Jakub Dobes", lastName: "Dobes", position: "G" },
              },
              {
                teamId: 14,
                playerId: 8476883,
                players: {
                  fullName: "Andrei Vasilevskiy",
                  lastName: "Vasilevskiy",
                  position: "G",
                },
              },
              {
                teamId: 14,
                playerId: 8477404,
                players: { fullName: "Nikita Kucherov", lastName: "Kucherov", position: "F" },
              },
              {
                teamId: 14,
                playerId: 8476453,
                players: { fullName: "Brayden Point", lastName: "Point", position: "F" },
              },
              {
                teamId: 14,
                playerId: 8482201,
                players: { fullName: "Gage Goncalves", lastName: "Goncalves", position: "F" },
              },
              {
                teamId: 54,
                playerId: 8474565,
                players: { fullName: "Ivan Barbashev", lastName: "Barbashev", position: "F" },
              },
              {
                teamId: 54,
                playerId: 8478403,
                players: { fullName: "Jack Eichel", lastName: "Eichel", position: "F" },
              },
              {
                teamId: 54,
                playerId: 8479353,
                players: { fullName: "Brett Howden", lastName: "Howden", position: "F" },
              },
              {
                teamId: 54,
                playerId: 8475191,
                players: { fullName: "Reilly Smith", lastName: "Smith", position: "F" },
              },
              {
                teamId: 54,
                playerId: 8478483,
                players: { fullName: "Mitch Marner", lastName: "Marner", position: "F" },
              },
              {
                teamId: 54,
                playerId: 8475913,
                players: { fullName: "Mark Stone", lastName: "Stone", position: "F" },
              },
              {
                teamId: 54,
                playerId: 8479394,
                players: { fullName: "Carter Hart", lastName: "Hart", position: "G" },
              },
              {
                teamId: 24,
                playerId: 8478873,
                players: { fullName: "Troy Terry", lastName: "Terry", position: "F" },
              },
              {
                teamId: 24,
                playerId: 8482745,
                players: { fullName: "Lukas Dostal", lastName: "Dostal", position: "G" },
              },
              {
                teamId: 59,
                playerId: 8479979,
                players: { fullName: "Karel Vejmelka", lastName: "Vejmelka", position: "G" },
              },
              {
                teamId: 7,
                playerId: 8479312,
                players: { fullName: "Alex Lyon", lastName: "Lyon", position: "G" },
              },
              {
                teamId: 30,
                playerId: 8476958,
                players: { fullName: "Nico Sturm", lastName: "Sturm", position: "F" },
              },
              {
                teamId: 25,
                playerId: 8477504,
                players: { fullName: "Michael Bunting", lastName: "Bunting", position: "F" },
              },
              {
                teamId: 25,
                playerId: 8475692,
                players: {
                  fullName: "Alexander Petrovic",
                  lastName: "Petrovic",
                  position: "D",
                },
              },
            ].filter((row) => teamIds.includes(row.teamId)),
            error: null,
          })),
        })),
      })),
    },
    lineup_player_name_aliases: {
      select: vi.fn(() => {
        const query: any = { or: () => query, is: () => query, order: () => query,
          range: () => Promise.resolve({ data: [], error: null }) };
        return query;
      }),
    },
    line_source_ifttt_events: {
      select: vi.fn(() => lineSourceEventsQuery),
      update: eventUpdateMock,
    },
    line_source_snapshots: {
      update: staleRowUpdateMock,
      upsert: lineSourceSnapshotsUpsertMock,
    },
    lineup_unresolved_player_names: {
      update: staleRowUpdateMock,
      upsert: unresolvedNamesUpsertMock,
    },
  };

  mocks.from.mockImplementation((tableName: string) => tables[tableName]);
  return {
    lineSourceEventsQuery,
    eventUpdateMock,
    eventUpdateEqMock,
    lineSourceSnapshotsUpsertMock,
    staleRowUpdateMock,
    unresolvedNamesUpsertMock,
  };
}

function getUpsertedRows(upsertMock: ReturnType<typeof vi.fn>) {
  return upsertMock.mock.calls.flatMap((call) => call[0]);
}

describe("private Starter Board release operations", () => {
  beforeEach(() => vi.clearAllMocks());
  const policy = { version: "starter-board-policy-v1", featureDefinitionHash: "a".repeat(64),
    candidateRuleHash: "b".repeat(64), refitPolicyHash: "c".repeat(64), components: [{ component: "skaters", baselineId: "FORGE",
      primaryTarget: "fantasy_points", primaryMetric: "mae", protectedMetrics: [{ target: "shots", metric: "mae" }], probability: false }] };
  const releaseId = "00000000-0000-4000-8000-000000000003";
  it("registers a server-hashed frozen policy without activating it", async () => {
    const insert = vi.fn().mockReturnValue({ select: () => ({ single: async () => ({ data: { id: releaseId, policy_hash: projectionInputHash(policy) }, error: null }) }) });
    mocks.from.mockReturnValue({ insert });
    const res = createMockRes();
    await releaseHandler(createMockReq({ body: { action: "register_release", release: { releaseKey: "canary-1", codeVersion: "sha-1",
      modelIdentity: "FORGE", evaluationVersion: "daily-v1", policy } } }), res);
    expect(res.statusCode).toBe(200);
    expect(res.headers["Cache-Control"]).toBe("private, no-store");
    expect(insert).toHaveBeenCalledWith(expect.objectContaining({ policy, policy_hash: projectionInputHash(policy) }));
    expect(mocks.rpc).not.toHaveBeenCalled();
  });
  it("publishes a matching review as evidence without promoting a model or intervals", async () => {
    const report = { contractVersion: "starter-board-review-v1", evaluationVersion: "daily-v1", policyHash: projectionInputHash(policy),
      dataHash: "d".repeat(64), forecastHash: "e".repeat(64), asOf: "2025-12-31T23:00:00Z", windowStart: "2025-12-01", windowEnd: "2025-12-31",
      evidenceClass: "captured_live", gameType: "regular_season", settledGames: 0, settledSlates: 0, settledForecasts: 0, metrics: [], comparisons: [] };
    const insert = vi.fn().mockReturnValue({ select: () => ({ single: async () => ({ data: { id: "review-1" }, error: null }) }) });
    mocks.from.mockImplementation((table: string) => table === "forge_board_releases"
      ? { select: () => ({ eq: () => ({ single: async () => ({ data: { policy, policy_hash: projectionInputHash(policy), evaluation_version: "daily-v1" }, error: null }) }) }) }
      : { insert });
    const req = { action: "publish_review", releaseId, kind: "weekly", report };
    const res = createMockRes();
    await releaseHandler(createMockReq({ body: req }), res);
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({ modelActivated: false, intervalsActivated: false,
      decisions: [{ decision: "retain_serving_component", reasons: ["comparison_missing"] }] });
    expect(insert).toHaveBeenCalledWith(expect.objectContaining({ report, report_hash: projectionInputHash(report) }));
    expect(mocks.rpc).not.toHaveBeenCalled();
    insert.mockClear();
    const mismatch = createMockRes();
    await releaseHandler(createMockReq({ body: { ...req, report: { ...report, policyHash: "f".repeat(64) } } }), mismatch);
    expect(mismatch.statusCode).toBe(409);
    expect(insert).not.toHaveBeenCalled();
    insert.mockReturnValue({ select: () => ({ single: async () => ({ data: null, error: { message: "private milestone details" } }) }) });
    const early = createMockRes();
    await releaseHandler(createMockReq({ body: { ...req, kind: "day14" } }), early);
    expect(early.statusCode).toBe(409);
    expect(JSON.stringify(early.body)).not.toContain("private milestone details");
  });
  it("returns a no-store bounded report with honest empty evidence", async () => {
    mocks.rpc.mockResolvedValueOnce({ data: [], error: null });
    const res = createMockRes();
    await releaseHandler(createMockReq({ body: { action: "report", from: "2026-01-01T00:00:00Z", until: "2026-01-02T00:00:00Z",
      asOf: "2026-01-02T00:00:00Z" } }), res);
    expect(res.statusCode).toBe(200);
    expect(res.headers["Cache-Control"]).toBe("private, no-store");
    expect(res.body).toMatchObject({ version: "starter-board-operations-v1", reviewStatus: "insufficient_operational_evidence",
      cohorts: { regularSeason: { acceptedEvents: 0, onTimeShare: null } } });
  });
  it("rejects unbounded windows and does not disclose database errors", async () => {
    const invalid = createMockRes();
    await releaseHandler(createMockReq({ body: { action: "report", from: "2026-01-01T00:00:00Z", until: "2026-03-02T00:00:00Z" } }), invalid);
    expect(invalid.statusCode).toBe(400);
    expect(mocks.rpc).not.toHaveBeenCalled();
    mocks.rpc.mockResolvedValueOnce({ data: null, error: { message: "private database evidence" } });
    const failed = createMockRes();
    await releaseHandler(createMockReq({ body: { action: "report", from: "2026-01-01T00:00:00Z", until: "2026-01-02T00:00:00Z" } }), failed);
    expect(failed.statusCode).toBe(503);
    expect(JSON.stringify(failed.body)).not.toContain("private database evidence");
  });
  it("records render time separately while retaining legacy receipt compatibility", async () => {
    const probeId = "00000000-0000-4000-8000-000000000001", revisionId = "00000000-0000-4000-8000-000000000002";
    mocks.rpc.mockResolvedValue({ data: 1, error: null });
    const res = createMockRes();
    await releaseHandler(createMockReq({ body: { action: "visibility", probeId, revisionIds: [revisionId], renderedAt: "2026-01-01T00:00:00Z" } }), res);
    expect(res.statusCode).toBe(200);
    expect(mocks.rpc).toHaveBeenLastCalledWith("record_starter_board_visibility_timed", { p_probe_id: probeId, p_revision_ids: [revisionId], p_rendered_at: "2026-01-01T00:00:00Z" });
    await releaseHandler(createMockReq({ body: { action: "visibility", probeId, revisionIds: [revisionId] } }), createMockRes());
    expect(mocks.rpc).toHaveBeenLastCalledWith("record_starter_board_visibility", { p_probe_id: probeId, p_revision_ids: [revisionId] });
  });
});

describe("/api/v1/db/update-line-sources", () => {
  afterEach(() => { vi.unstubAllEnvs(); vi.useRealTimers(); });
  beforeEach(() => {
    vi.clearAllMocks();
    vi.unstubAllGlobals();
    mocks.capturePlayerForecastSourceRows.mockResolvedValue({ goalieObservations: 0, lineupSnapshots: 0,
      lineupAssignments: 0, conflicts: 0, jobsQueued: 0 });
    mocks.getCurrentSeason.mockResolvedValue({ seasonId: 20252026 });
    mocks.syncLineCombinationSourceWinners.mockResolvedValue({
      sourceRows: 3,
      eligibleWinners: 1,
      written: 1,
      failures: [],
    });
    mocks.getTeams.mockResolvedValue([
      {
        id: 8,
        name: "Montréal Canadiens",
        abbreviation: "MTL",
        logo: "/teamLogos/MTL.png",
      },
      {
        id: 14,
        name: "Tampa Bay Lightning",
        abbreviation: "TBL",
        logo: "/teamLogos/TBL.png",
      },
      {
        id: 54,
        name: "Vegas Golden Knights",
        abbreviation: "VGK",
        logo: "/teamLogos/VGK.png",
      },
      {
        id: 24,
        name: "Anaheim Ducks",
        abbreviation: "ANA",
        logo: "/teamLogos/ANA.png",
      },
      {
        id: 7,
        name: "Buffalo Sabres",
        abbreviation: "BUF",
        logo: "/teamLogos/BUF.png",
      },
      {
        id: 30,
        name: "Minnesota Wild",
        abbreviation: "MIN",
        logo: "/teamLogos/MIN.png",
      },
      {
        id: 25,
        name: "Dallas Stars",
        abbreviation: "DAL",
        logo: "/teamLogos/DAL.png",
      },
      {
        id: 59,
        name: "Utah Mammoth",
        abbreviation: "UTA",
        logo: "/teamLogos/UTA.png",
      },
    ]);
  });

  it("avoids empty-queue roster work while retaining scheduled reconciliation and audit", async () => {
    createSupabaseMocks([]);
    const reconcile = vi.spyOn(lineProcessor, "processLineSnapshotEvidence").mockResolvedValue({ enabled: true, claims: 0, reconciled: 2 });
    try {
      const res = createMockRes();
      await handler(createMockReq(), res);
      expect(res.body.summary.eventsLoaded).toBe(0);
      expect(mocks.getTeams).not.toHaveBeenCalled();
      expect(mocks.from).not.toHaveBeenCalledWith("rosters");
      expect(mocks.from).not.toHaveBeenCalledWith("lineup_player_name_aliases");
      expect(reconcile).toHaveBeenCalledWith(expect.anything(), [], [8, 14]);
      expect(mocks.auditInsert).toHaveBeenCalledOnce();
    } finally { reconcile.mockRestore(); }
  });

  it("stops a closed prospective intake budget before roster or enrichment work", async () => {
    createSupabaseMocks([buildEvent({ id: "budget-stop",sourceKey: "gamedaylines",sourceAccount: "GameDayLines",tweetId: "100",text: "Caufield starts tonight." })]);
    const intake = vi.spyOn(claimIntake,"admitTweetClaimEvaluationIntake").mockResolvedValue({ active: true,events: [],reason: "ended" });
    try {
      const res = createMockRes();await handler(createMockReq(),res);
      expect(res.body).toMatchObject({ mode: "claim_shadow_stopped",delivery: "not_requested",reason: "ended" });
      expect(mocks.getCurrentSeason).not.toHaveBeenCalled();expect(mocks.getTeams).not.toHaveBeenCalled();
    } finally { intake.mockRestore(); }
  });

  it("isolates shadow capture before snapshot/forecast/line/review publishers even when their flags are enabled", async () => {
    const events = [buildEvent({ id: "shadow-event", sourceKey: "gamedaylines", sourceAccount: "GameDayLines", tweetId: "100", text: "#GoHabsGo Caufield starts tonight." })];
    const db = createSupabaseMocks(events);
    vi.stubEnv("TWEET_CLAIMS_MODE", "shadow");
    vi.stubEnv("TWEET_PIPELINE_PUBLISHING_ENABLED", "true"); vi.stubEnv("STARTER_BOARD_CAPTURE_ENABLED", "true");
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: false, status: 503 }));
    const shadow = vi.spyOn(tweetClaimRegistry, "processTweetClaimShadowBatch").mockResolvedValue({ mode: "claim_shadow", capture: { skipped: false, scopes: [] }, eventsProcessed: 1, eventsDeferred: 0, delivery: "not_requested" });
    const legacy = vi.spyOn(tweetProjectionStorage, "persistTweetProjectionReports");
    const reconcile = vi.spyOn(lineProcessor, "processLineSnapshotEvidence");
    try {
      const res = createMockRes(); await handler(createMockReq(), res);
      expect(res.statusCode).toBe(200); expect(res.body).toMatchObject({ mode: "claim_shadow", delivery: "not_requested" });
      expect(shadow).toHaveBeenCalledWith(expect.objectContaining({ table: "line_source_ifttt_events", events: expect.arrayContaining([expect.objectContaining({ id: "shadow-event" })]) }));
      expect(db.lineSourceSnapshotsUpsertMock).not.toHaveBeenCalled(); expect(db.unresolvedNamesUpsertMock).not.toHaveBeenCalled();
      expect(mocks.capturePlayerForecastSourceRows).not.toHaveBeenCalled(); expect(mocks.syncLineCombinationSourceWinners).not.toHaveBeenCalled();
      expect(legacy).not.toHaveBeenCalled(); expect(reconcile).not.toHaveBeenCalled();
    } finally { shadow.mockRestore(); legacy.mockRestore(); reconcile.mockRestore(); }
  });

  it("leaves a concurrent arrival pending for the next unchanged scheduler cycle", async () => {
    const events: LineSourceEventFixture[] = [];
    const { lineSourceEventsQuery, eventUpdateMock } = createSupabaseMocks(events);
    lineSourceEventsQuery.limit.mockImplementationOnce(async () => {
      events.push(buildEvent({ id: "late-event", sourceKey: "gamedaygoalies", sourceAccount: "GameDayGoalies", tweetId: "2047809041154625899", text: "Canadiens Starting Goalie: Jakub Dobes" }));
      return { data: [], error: null };
    });
    const first = createMockRes();
    await handler(createMockReq(), first);
    expect(first.body.summary.eventsLoaded).toBe(0);
    expect(eventUpdateMock).not.toHaveBeenCalled();
    const next = createMockRes();
    await handler(createMockReq(), next);
    expect(next.body.summary.eventsLoaded).toBe(1);
    expect(eventUpdateMock).toHaveBeenCalled();
    expect(mocks.auditInsert).toHaveBeenCalledTimes(2);
  });

  it("audits queue-read failures rather than treating them as empty", async () => {
    const { lineSourceEventsQuery } = createSupabaseMocks([]);
    lineSourceEventsQuery.limit.mockResolvedValue({ data: null, error: new Error("queue unavailable") });
    const res = createMockRes();
    await handler(createMockReq(), res);
    expect(res.statusCode).toBe(500);
    expect(mocks.getTeams).not.toHaveBeenCalled();
    expect(mocks.auditInsert).toHaveBeenCalledWith(expect.objectContaining({ status: "failure" }));
  });

  async function rejectDuringProjection(error: Error) {
    vi.stubEnv("TWEET_PIPELINE_INTERPRETATION_ENABLED", "true");
    vi.stubEnv("TWEET_PIPELINE_PUBLISHING_ENABLED", "true");
    vi.stubGlobal("fetch", vi.fn(async () => new Response(null, { status: 404 })));
    const event = buildEvent({ id: "schedule-rejection", sourceKey: "gamedaylines", sourceAccount: "GameDayLines",
      tweetId: "2049626619221008663", text: "#Habs lines\nCaufield - Suzuki - Slafkovsky" });
    const { eventUpdateMock } = createSupabaseMocks([event]);
    const baseFrom = mocks.from.getMockImplementation()!;
    const jobUpdate = vi.fn(matchedJobUpdate);
    mocks.from.mockImplementation((table: string) => {
      if (table === "tweet_pipeline_jobs") return { update: jobUpdate };
      if (["rosters", "tweet_player_memberships", "fhfh_player_identities", "fhfh_player_identity_aliases"].includes(table)) {
        return { select: () => paginatedRoster({ data: [], error: null }) };
      }
      return baseFrom(table);
    });
    mocks.rpc.mockResolvedValue({ data: true, error: null });
    const projection = vi.spyOn(tweetProjectionStorage, "persistTweetProjectionReports").mockRejectedValueOnce(error);
    const res = createMockRes();
    try { await handler(createMockReq(), res); } finally { projection.mockRestore(); }
    expect(jobUpdate).toHaveBeenCalledWith(expect.objectContaining({ status: "failed", failure_stage: "projection_storage", lease_expires_at: null }));
    expect(eventUpdateMock).not.toHaveBeenCalled();
    expect(res.statusCode).toBe(500);
    const audit = mocks.auditInsert.mock.calls.at(-1)![0];
    expect(audit).toMatchObject({ status: "failure", rows_affected: null, details: { statusCode: 500 } });
    expect(JSON.parse(audit.details.response)).toEqual(res.body);
    return { res, audit };
  }

  it("retains a bounded safe receipt for complete schedule reconciliation rejection in the failed response and audit", async () => {
    const reasons: ForecastScheduleRejection["reasons"] = ["season_mismatch", "type_mismatch",
      "date_mismatch", "identity_conflict", "invalid_start", "start_time_mismatch", "invalid_receipt", "unknown_status", "missing_sides", "conflicting_versions", "conflicting_sides"];
    const receipt: ForecastScheduleRejection = { readStatus: "complete", validationStatus: "rejected", stage: "reconciliation",
      scope: { fromDate: "2026-10-10", throughDate: null, teamId: 5 }, discoveredGames: 80, checkedGames: 80, unreadGames: 0, reasons,
      rejectedGames: Array.from({ length: 6 }, (_, index) => ({ gameId: 2026020983 + index, reasons: index === 0 ? ["start_time_mismatch"] : reasons })) };
    Object.assign(receipt, { rawSource: "PRIVATE_SENTINEL" });
    Object.assign(receipt.scope, { credentials: "PRIVATE_SENTINEL" });
    Object.assign(receipt.rejectedGames[0]!, { rawSource: "PRIVATE_SENTINEL" });
    const error = Object.assign(new ForecastScheduleError(receipt), { credentials: "PRIVATE_SENTINEL" });
    const { res, audit } = await rejectDuringProjection(error);
    expect(res.body).toMatchObject({ success: false, error: error.message, scheduleRejection: {
      readStatus: "complete", validationStatus: "rejected", stage: "reconciliation", scope: { fromDate: "2026-10-10", throughDate: null, teamId: 5 },
      discoveredGames: 80, checkedGames: 80, unreadGames: 0, reasons, rejectedGameCount: 6, rejectedGameSampleTruncated: true,
    } });
    expect(res.body.scheduleRejection.scope).toEqual({ fromDate: "2026-10-10", throughDate: null, teamId: 5 });
    expect(res.body.scheduleRejection.rejectedGames).toHaveLength(5);
    expect(res.body.scheduleRejection.rejectedGames[0]).toEqual({ gameId: 2026020983, reasons: ["start_time_mismatch"] });
    expect(JSON.stringify(res.body)).not.toContain("PRIVATE_SENTINEL");
    expect(audit.details.response.length).toBeLessThan(4000);
    expect(res.body.timing.durationMs).toBeTypeOf("number");
  });
  it.each(["canonical_games", "team_game_status"] as const)("distinguishes an incomplete %s schedule read without inventing unknown counts", async (stage) => {
    const receipt: ForecastScheduleRejection = { readStatus: "incomplete", validationStatus: "rejected", stage,
      scope: { fromDate: "2026-10-10", throughDate: null, teamId: 5 }, discoveredGames: null, checkedGames: 0, unreadGames: null,
      reasons: [stage === "canonical_games" ? "read_deadline" : "incomplete_read"], rejectedGames: [] };
    const { res } = await rejectDuringProjection(new ForecastScheduleError(receipt));
    expect(res.body).toMatchObject({ success: false, scheduleRejection: {
      ...receipt, rejectedGameCount: 0, rejectedGameSampleTruncated: false,
    } });
  });
  it("keeps generic errors on the existing failure path without serializing an arbitrary schedule receipt", async () => {
    const error = Object.assign(new Error("Projection temporarily unavailable"), {
      name: "ForecastScheduleError", receipt: { credentials: "PRIVATE_SENTINEL", stage: "reconciliation" }, rawSource: "PRIVATE_SENTINEL",
    });
    const { res, audit } = await rejectDuringProjection(error);
    expect(res.body).toMatchObject({ success: false, error: "Projection temporarily unavailable" });
    expect(res.body.scheduleRejection).toBeUndefined();
    expect(JSON.stringify(res.body)).not.toContain("PRIVATE_SENTINEL");
    expect(audit.details.error).toBe("Projection temporarily unavailable");
  });

  it("leaves events pending when required immutable evidence capture fails", async () => {
    vi.stubEnv("STARTER_BOARD_CAPTURE_ENABLED", "true");
    const event = buildEvent({ id: "retry", sourceKey: "gamedaylines", sourceAccount: "GameDayLines",
      tweetId: "2049626619221008663", text: "#Habs lines\nCaufield - Suzuki - Slafkovsky" });
    const { eventUpdateMock } = createSupabaseMocks([event]);
    mocks.capturePlayerForecastSourceRows.mockRejectedValueOnce(new Error("Capture temporarily unavailable"));
    const res = createMockRes();
    await handler(createMockReq(), res);
    expect(res.statusCode).toBe(500);
    expect(eventUpdateMock).not.toHaveBeenCalled();
    const retry = createMockRes();
    await handler(createMockReq(), retry);
    expect(retry.statusCode).toBe(200);
    expect(eventUpdateMock).toHaveBeenCalledWith(expect.objectContaining({ processing_status: "processed" }));
  });

  it("replays the frozen 11 regression and 24 candidate records equivalently through GDL and CCC with mocked enrichment and storage", async () => {
    const outcomes = new Map<string, unknown>();
    vi.useFakeTimers({ toFake: ["Date"] });
    vi.setSystemTime(new Date("2026-10-01T03:59:59Z"));
    for (const path of ["gdl", "ccc"]) {
      vi.stubEnv("TWEET_PIPELINE_INTERPRETATION_ENABLED", "true");
      vi.stubEnv("TWEET_PIPELINE_PUBLISHING_ENABLED", "true");
      vi.stubGlobal("fetch", vi.fn(async () => new Response(null, { status: 404 })));
      const audit = JSON.parse(readFileSync(resolve(process.cwd(), "../tasks/TASKS/lines-gdl-ingestion/audit/2026-10-01-classification-seeds.json"), "utf8"));
      const frozenGames = JSON.parse(readFileSync(resolve(process.cwd(), "../tasks/TASKS/lines-gdl-ingestion/audit/2026-10-01-classification-games.json"), "utf8")).games;
      const holdout = JSON.parse(readFileSync(resolve(process.cwd(), "../tasks/TASKS/lines-gdl-ingestion/audit/2026-10-01-classification-holdout-context.json"), "utf8"));
      const labels = JSON.parse(readFileSync(resolve(process.cwd(), "../tasks/TASKS/lines-gdl-ingestion/audit/2026-10-01-classification-labels.json"), "utf8"));
      audit.snapshots.push(...holdout.snapshots.map((snapshot: any) => ({ tweet_id: snapshot.tweetId, team_id: snapshot.teamId, team_abbreviation: snapshot.teamAbbreviation,
        metadata: { interpretation: { rosterRevision: snapshot.rosterRevision } } })));
      audit.events.push(...audit.holdoutCandidates.map((candidate: any) => ({ id: `frozen-${candidate.tweet_id}`, tweet_id: candidate.tweet_id, source_key: candidate.source_key,
        username: candidate.source_key, text: candidate.raw_text, tweet_created_at: candidate.tweet_posted_at, received_at: candidate.observed_at })));
      const metrics: Record<string, { posts: number; accepted: number; review: number; emittedEvents: number; confirmedFacts: number }> = {};
      const teamNames: Record<string, string> = { CBJ: "Columbus Blue Jackets", SJS: "San Jose Sharks", OTT: "Ottawa Senators", NYI: "New York Islanders", WSH: "Washington Capitals", TBL: "Tampa Bay Lightning", NJD: "New Jersey Devils", PHI: "Philadelphia Flyers", STL: "St. Louis Blues", CHI: "Chicago Blackhawks", VGK: "Vegas Golden Knights", FLA: "Florida Panthers", TOR: "Toronto Maple Leafs", LAK: "Los Angeles Kings", COL: "Colorado Avalanche" };
      const teams = [...new Map(audit.snapshots.filter((snapshot: any) => snapshot.team_id).map((snapshot: any) => [snapshot.team_id,
        { id: snapshot.team_id, abbreviation: snapshot.team_abbreviation, name: teamNames[snapshot.team_abbreviation] }])).values()];
      mocks.getTeams.mockResolvedValue(teams);
      const emptyQuery = () => {
        const query: any = { eq: () => query, lt: () => query, in: () => query, or: () => query, order: () => query, neq: () => query,
          range: async () => ({ data: [], error: null }), limit: async () => ({ data: [], error: null }), then: (resolve: any) => Promise.resolve({ error: null }).then(resolve) };
        return query;
      };
      for (const captured of audit.events) {
        const snapshot = audit.snapshots.find((row: any) => row.tweet_id === captured.tweet_id);
        const revision = snapshot.metadata.interpretation?.rosterRevision ?? "";
        const rosterRows = revision.split("|").filter(Boolean).map((entry: string) => {
          const [playerId, fullName, lastName, teamId, position] = entry.split(":");
          return { playerId: Number(playerId), teamId: Number(teamId), players: { fullName, lastName, position } };
        });
        const event = buildEvent({ id: captured.id, sourceKey: captured.source_key, sourceAccount: captured.username,
          tweetId: captured.tweet_id, text: captured.text, receivedAt: captured.received_at });
        event.tweet_created_at = captured.tweet_created_at;
        const fixtureMocks = createSupabaseMocks([event]);
        const originalFrom = mocks.from.getMockImplementation()!;
        const reportUpsert = vi.fn().mockResolvedValue({ error: null });
        const eventUpsert = vi.fn().mockResolvedValue({ error: null });
        const derivedParents = new Map<string, any>();
        const derivedUpsert = vi.fn(async (rows: any[]) => {
          for (const row of rows) if (!derivedParents.has(row.capture_key)) derivedParents.set(row.capture_key, structuredClone(row));
          return { error: null };
        });
        const sourceSelect = (table: string) => {
          const filters: Array<(row: any) => boolean> = [];
          const result = () => ({ data: [
            ...((path === "gdl" && table === "line_source_snapshots" || path === "ccc" && table === "lines_ccc")
              ? getUpsertedRows(fixtureMocks.lineSourceSnapshotsUpsertMock) : []),
            ...(table === "line_source_snapshots" ? [...derivedParents.values()] : []),
          ].filter((row) => filters.every((filter) => filter(row))), error: null });
          const query: any = { in: (key: string, values: any[]) => { filters.push((row) => values.includes(row[key])); return query; },
            order: () => query, range: () => query, then: (resolve: any) => Promise.resolve(result()).then(resolve) };
          return query;
        };
        mocks.rpc.mockResolvedValue({ data: true, error: null });
        mocks.from.mockImplementation((table: string) => {
          if (table === "games") return { select: () => ({ eq: (_column: string, date: string) => ({ order: async () => ({ data: frozenGames.filter((game: any) => game.date === date), error: null }) }) }) };
          if (table === "rosters") return { select: () => paginatedRoster({ data: rosterRows, error: null }) };
          if (["tweet_player_memberships", "fhfh_player_identities", "fhfh_player_identity_aliases", "player_status_history"].includes(table)) return { select: emptyQuery };
          if (table === "tweet_pipeline_jobs") return { update: matchedJobUpdate };
          if (table === "tweet_projection_reports") return { upsert: reportUpsert, select: () => {
            const filters: Record<string, unknown> = {};
            const query: any = { eq: (key: string, value: unknown) => { filters[key] = value; return query; }, order: () => query,
              range: async () => ({ data: getUpsertedRows(reportUpsert).filter((row: any) => Object.entries(filters).every(([key, value]) => row[key] === value)), error: null }) };
            return query;
          } };
          if (table === "tweet_player_events") return { select: emptyQuery, upsert: eventUpsert };
          if (table === "lines_ccc_ifttt_events") return originalFrom("line_source_ifttt_events");
          if (table === "line_source_snapshots") return { ...originalFrom(table), select: () => sourceSelect(table),
            upsert: (rows: any[], options: any) => options?.ignoreDuplicates ? derivedUpsert(rows) : originalFrom(table).upsert(rows, options) };
          if (table === "lines_ccc") return { ...originalFrom("line_source_snapshots"), select: () => sourceSelect(table) };
          return originalFrom(table);
        });
        const res = createMockRes();
        const forecastCallStart = mocks.capturePlayerForecastSourceRows.mock.calls.length;
        await (path === "gdl" ? handler : cccHandler)(createMockReq({ query: { date: new Intl.DateTimeFormat("en-CA", { timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(captured.tweet_created_at)), limit: "10", tweetId: captured.tweet_id } }), res);
        expect(res.statusCode, `${path}:${captured.tweet_id}:${JSON.stringify(res.body)}`).toBe(200);
        const rows = getUpsertedRows(fixtureMocks.lineSourceSnapshotsUpsertMock);
        expect(rows).toHaveLength(1);
        const interpretation = rows[0].metadata.interpretation;
        const split = labels.records.find((label: any) => label.tweetId === captured.tweet_id).split;
        metrics[split] ??= { posts: 0, accepted: 0, review: 0, emittedEvents: 0, confirmedFacts: 0 };
        const metric = metrics[split]!;
        metric.posts++; if (rows[0].nhl_filter_status === "accepted") metric.accepted++; else metric.review++;
        metric.emittedEvents += interpretation.events.length;
        metric.confirmedFacts += interpretation.events.filter((event: any) => ["available", "out"].includes(event.availability) || event.kind === "goalie" && event.state === "confirmed").length;
        const outcome = { classification: rows[0].classification, teamId: rows[0].team_id, filterStatus: rows[0].nhl_filter_status, interpretation,
          reports: getUpsertedRows(reportUpsert), persistedEvents: getUpsertedRows(eventUpsert),
          forecasts: mocks.capturePlayerForecastSourceRows.mock.calls.slice(forecastCallStart).flatMap(([call]) => call.rows).map((row: any) => ({ classification: row.classification,
            gameId: row.game_id, teamId: row.team_id, sourceKey: row.source_key, interpretation: row.metadata?.interpretation })) };
        if (path === "gdl") outcomes.set(captured.tweet_id, outcome);
        else expect(outcome, captured.tweet_id).toEqual(outcomes.get(captured.tweet_id));
        for (const parsedEvent of interpretation.events) {
          expect(parsedEvent.availability, captured.tweet_id).not.toBe("available");
          expect(parsedEvent.availability, captured.tweet_id).not.toBe("out");
        }
        if (["2105378254983205114", "2105375596687843639", "2105366758089695718"].includes(captured.tweet_id)) {
          expect(interpretation.units.filter((unit: any) => unit.situation === "pp" && unit.complete)).toHaveLength(2);
          expect(reportUpsert).toHaveBeenCalled();
        }
        if (["2105434836500680857", "2105370362964004937"].includes(captured.tweet_id)) expect(interpretation.events.length).toBeGreaterThan(0);
        const persistedEvents = getUpsertedRows(eventUpsert);
        expect(persistedEvents.every((row: any) => !["available", "out"].includes(row.availability))).toBe(true);
      }
      console.info(`Frozen ${path} equivalent-route evaluation`, JSON.stringify(metrics));
      const forecastRows = mocks.capturePlayerForecastSourceRows.mock.calls.flatMap(([call]) => call.rows);
      expect(forecastRows.filter((row: any) => row.metadata?.interpretation)).toEqual(expect.arrayContaining([expect.objectContaining({ source_group: "tweet_projection", classification: "goalie_start" })]));
      for (const row of forecastRows) {
        for (const event of row.metadata?.interpretation?.events ?? []) {
          expect(event.availability).not.toBe("out"); expect(event.availability).not.toBe("available"); expect(event.state).not.toBe("confirmed");
        }
      }
    }
  });

  it.each(["gdl", "ccc"])("retains both validated goalie teams and finalizes one raw receipt through %s", async (path) => {
    vi.stubEnv("TWEET_PIPELINE_INTERPRETATION_ENABLED", "true");
    vi.stubEnv("TWEET_PIPELINE_PUBLISHING_ENABLED", "false");
    vi.stubGlobal("fetch", vi.fn(async () => new Response(null, { status: 404 })));
    mocks.getTeams.mockResolvedValue([
      { id: 6, name: "Boston Bruins", abbreviation: "BOS", logo: "/teamLogos/BOS.png" },
      { id: 4, name: "Philadelphia Flyers", abbreviation: "PHI", logo: "/teamLogos/PHI.png" },
    ]);
    const text = "Confirmed Bruins Starting Goalie: Jeremy Swayman\nConfirmed Flyers Starting Goalie: Dan Vladar https://t.co/4hXg9xv9LV";
    const event = buildEvent({ id: "dual-team", sourceKey: "gamedaygoalies", sourceAccount: "CcCMiddleton", tweetId: "2108958735309865096", text, receivedAt: "2026-10-10T16:39:40Z" });
    event.tweet_created_at = "2026-10-10T16:31:00Z";
    const fixture = createSupabaseMocks([event]);
    mocks.rpc.mockResolvedValue({ data: true, error: null });
    const originalFrom = mocks.from.getMockImplementation()!;
    const emptyQuery = () => { const query: any = { eq: () => query, in: () => query, order: () => query, range: async () => ({ data: [], error: null }), then: (resolve: any) => Promise.resolve({ error: null }).then(resolve) }; return query; };
    mocks.from.mockImplementation((table: string) => {
      if (table === "games") return { select: () => ({ eq: () => ({ order: async () => ({ data: [{ id: 2026020070, date: "2026-10-10", homeTeamId: 6, awayTeamId: 4 }], error: null }) }) }) };
      if (table === "rosters") return { select: () => paginatedRoster({ data: [
        { teamId: 6, playerId: 8480280, players: { fullName: "Jeremy Swayman", lastName: "Swayman", position: "G" } },
        { teamId: 4, playerId: 8478435, players: { fullName: "Dan Vladar", lastName: "Vladar", position: "G" } },
      ], error: null }) };
      if (["tweet_player_memberships", "fhfh_player_identities", "fhfh_player_identity_aliases"].includes(table)) return { select: emptyQuery };
      if (table === "tweet_pipeline_jobs") return { update: matchedJobUpdate };
      if (table === "lines_ccc_ifttt_events") return originalFrom("line_source_ifttt_events");
      if (table === "lines_ccc") return originalFrom("line_source_snapshots");
      return originalFrom(table);
    });
    const res = createMockRes();
    await (path === "gdl" ? handler : cccHandler)(createMockReq({ query: { date: "2026-10-10", tweetId: event.tweet_id, limit: "10" } }), res);
    expect(res.statusCode, JSON.stringify(res.body)).toBe(200);
    const rows = getUpsertedRows(fixture.lineSourceSnapshotsUpsertMock);
    expect(rows).toHaveLength(2);
    expect(rows.map((row: any) => row.team_id)).toEqual([6, 4]);
    for (const row of rows) expect(row).toMatchObject({ tweet_id: event.tweet_id, raw_text: text, tweet_posted_at: new Date(event.tweet_created_at!).toISOString(),
      observed_at: event.received_at, game_id: 2026020070, classification: "goalie_start", nhl_filter_status: "accepted" });
    expect(fixture.eventUpdateMock).toHaveBeenCalledTimes(1);
    const update = fixture.eventUpdateMock.mock.calls[0]![0] as any;
    expect(update.processing_status).toBe("processed");
    const processing = update.raw_payload[path === "gdl" ? "lineSourceProcessing" : "linesCccProcessing"];
    expect(processing.teamCaptures.map((capture: any) => capture.captureKey)).toEqual(rows.map((row: any) => row.capture_key));
    expect(fixture.staleRowUpdateMock).not.toHaveBeenCalled();
  });

  it("limits automatic retries to receipts on the Eastern slate, including UTC midnight", async () => {
    const events = ["2026-04-28T23:00:00Z", "2026-04-30T02:00:00Z", "2026-04-30T06:00:00Z"].map((receivedAt, index) =>
      buildEvent({ id: `bounded-${index}`, sourceKey: "gamedaylines", sourceAccount: "GameDayLines",
        tweetId: `204962661922100866${index}`, receivedAt, text: "#Habs lines\nCaufield - Suzuki - Slafkovsky" }));
    const { eventUpdateEqMock } = createSupabaseMocks(events);
    const res = createMockRes();
    await handler(createMockReq({ query: { date: "2026-04-29", currentDayOnly: "true" } }), res);
    expect(res.statusCode).toBe(200);
    expect(res.body.summary).toMatchObject({ eventsLoaded: 1, acceptedNhl: 1 });
    expect(eventUpdateEqMock).toHaveBeenCalledWith("id", "bounded-1");
  });

  it.each([
    [null, "#Habs lines\nCaufield - Suzuki - Slafkovsky", "unknown_report_date"],
    ["2026-04-28T23:00:00Z", "#Habs lines\nCaufield - Suzuki - Slafkovsky", "report_date_mismatch"],
    ["2026-04-30T02:00:00Z", "#Habs lines tomorrow\nCaufield - Suzuki - Slafkovsky", "relative_game_date_requires_review"],
  ])("withholds game applicability for %s / %s", async (postedAt, text, reason) => {
    const event = buildEvent({ id: "old", sourceKey: "gamedaylines", sourceAccount: "GameDayLines",
      tweetId: "2049626619221008663", text });
    event.tweet_created_at = postedAt;
    if (postedAt === null) event.link_to_tweet = "https://twitter.com/reporter/status/123";
    const { lineSourceSnapshotsUpsertMock } = createSupabaseMocks([event]);
    const res = createMockRes();
    await handler(createMockReq(), res);
    expect(res.statusCode).toBe(200);
    expect(getUpsertedRows(lineSourceSnapshotsUpsertMock)[0]).toMatchObject({ game_id: null,
      nhl_filter_status: "rejected_ambiguous", nhl_filter_reason: reason });
  });

  it("processes GDL goalie, lines, news, non-NHL, and ambiguous events by source key", async () => {
    const events = [
      buildEvent({
        id: "event-goalie",
        sourceKey: "gamedaygoalies",
        sourceAccount: "GameDayGoalies",
        tweetId: "2049619999812391371",
        text: "confirmed Canadiens Starting Goalie: Jakub Dobes https://t.co/p3wzJmJJUd",
      }),
      buildEvent({
        id: "event-lines",
        sourceKey: "gamedaylines",
        sourceAccount: "GameDayLines",
        tweetId: "2049626619221008663",
        text: "#Habs lines vs #Lightning\nCaufield - Suzuki - Slafkovsky",
      }),
      buildEvent({
        id: "event-news",
        sourceKey: "gamedaynewsnhl",
        sourceAccount: "GameDayNewsNHL",
        tweetId: "2049629478754943139",
        text: "Canadiens forward Nick Suzuki is out tonight with an injury.",
      }),
      buildEvent({
        id: "event-ahl",
        sourceKey: "gamedaylines",
        sourceAccount: "GameDayLines",
        tweetId: "2049622696678535527",
        text: "AHL Rocket lines\nAHL Rocket Starting Goalie: Kaapo Kahkonen https://t.co/Rz6hbYZ6CN",
      }),
      buildEvent({
        id: "event-ambiguous",
        sourceKey: "gamedaygoalies",
        sourceAccount: "GameDayGoalies",
        tweetId: "2049625325911605526",
        text: "confirmed Flyers Starting Goalie: Dan Vladar\nconfirmed Penguins Starting Goalie: Arturs Silovs",
      }),
    ];
    const {
      eventUpdateMock,
      eventUpdateEqMock,
      lineSourceSnapshotsUpsertMock,
    } = createSupabaseMocks(events);
    const req = createMockReq();
    const res = createMockRes();

    await handler(req, res);

    expect(mocks.getTeams).toHaveBeenCalledWith(20252026, {
      mode: "current-canonical",
    });

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      sourceGroup: "gdl_suite",
      summary: {
        sourcesProcessed: 3,
        eventsLoaded: 5,
        tweetsParsed: 5,
        acceptedNhl: 3,
        nonNhlRejected: 1,
        ambiguousRejected: 1,
        rowsUpserted: 5,
        lineCombinationSync: {
          sourceRows: 3,
          eligibleWinners: 1,
          written: 1,
          failures: [],
        },
        eventsProcessed: 3,
        eventsRejected: 2,
        bySourceKey: {
          gamedaygoalies: {
            total: 2,
            processed: 1,
            rejected: 1,
          },
          gamedaylines: {
            total: 2,
            processed: 1,
            rejected: 1,
          },
          gamedaynewsnhl: {
            total: 1,
            processed: 1,
            rejected: 0,
            byClassification: {
              injury: 1,
            },
          },
        },
      },
    });
    expect(mocks.syncLineCombinationSourceWinners).toHaveBeenCalledWith({
      supabase: expect.any(Object),
      date: "2026-04-29",
    });

    const upsertedRows = getUpsertedRows(lineSourceSnapshotsUpsertMock);
    expect(upsertedRows).toHaveLength(5);
    expect(upsertedRows).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          source_group: "gdl_suite",
          source_key: "gamedaygoalies",
          source_account: "GameDayGoalies",
          source: "gamedaygoalies",
          tweet_id: "2049619999812391371",
          team_abbreviation: "MTL",
          classification: "goalie_start",
          nhl_filter_status: "accepted",
          goalie_1_name: "Jakub Dobes",
          goalie_1_player_id: 8482487,
        }),
        expect.objectContaining({
          source_key: "gamedaylines",
          tweet_id: "2049626619221008663",
          team_abbreviation: "MTL",
          classification: "lineup",
          nhl_filter_status: "accepted",
          line_1_player_ids: [8480020, 8480019, 8480018],
        }),
        expect.objectContaining({
          source_key: "gamedaynewsnhl",
          tweet_id: "2049629478754943139",
          team_abbreviation: "MTL",
          classification: "injury",
          nhl_filter_status: "accepted",
        }),
        expect.objectContaining({
          source_key: "gamedaylines",
          tweet_id: "2049622696678535527",
          team_id: null,
          status: "rejected",
          detected_league: "AHL",
          nhl_filter_status: "rejected_non_nhl",
        }),
        expect.objectContaining({
          source_key: "gamedaygoalies",
          tweet_id: "2049625325911605526",
          team_id: null,
          status: "rejected",
          nhl_filter_status: "rejected_ambiguous",
        }),
      ]),
    );
    expect(
      upsertedRows.every((row: any) =>
        row.capture_key.startsWith(`${row.source_key}:`),
      ),
    ).toBe(true);

    expect(eventUpdateMock).toHaveBeenCalledTimes(5);
    expect(eventUpdateMock.mock.calls.map((call) => call[0])).toEqual([
      expect.objectContaining({ processing_status: "processed" }),
      expect.objectContaining({ processing_status: "processed" }),
      expect.objectContaining({ processing_status: "processed" }),
      expect.objectContaining({ processing_status: "rejected" }),
      expect.objectContaining({ processing_status: "rejected" }),
    ]);
    expect(
      (eventUpdateEqMock.mock.calls as Array<[unknown, unknown]>).map(
        (call) => call[1],
      ),
    ).toEqual([
      "event-goalie",
      "event-lines",
      "event-news",
      "event-ahl",
      "event-ambiguous",
    ]);
  });

  it("prefixes capture keys so duplicate tweet ids from different sources do not collide", async () => {
    const events = [
      buildEvent({
        id: "event-goalie",
        sourceKey: "gamedaygoalies",
        sourceAccount: "GameDayGoalies",
        tweetId: "2049619999812391371",
        text: "confirmed Canadiens Starting Goalie: Jakub Dobes https://t.co/p3wzJmJJUd",
      }),
      buildEvent({
        id: "event-lines",
        sourceKey: "gamedaylines",
        sourceAccount: "GameDayLines",
        tweetId: "2049619999812391371",
        text: "confirmed Canadiens Starting Goalie: Jakub Dobes https://t.co/p3wzJmJJUd",
      }),
    ];
    const { lineSourceSnapshotsUpsertMock } = createSupabaseMocks(events);
    const req = createMockReq({
      query: {
        date: "2026-04-29",
        limit: "10",
        reprocess: "true",
      },
    });
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      summary: {
        eventsLoaded: 2,
        acceptedNhl: 2,
        duplicatesSkipped: 0,
        rowsUpserted: 2,
      },
    });
    const captureKeys = getUpsertedRows(lineSourceSnapshotsUpsertMock).map(
      (row: any) => row.capture_key,
    );
    expect(captureKeys).toHaveLength(2);
    expect(captureKeys[0]).toContain("gamedaygoalies:");
    expect(captureKeys[1]).toContain("gamedaylines:");
    expect(captureKeys[0]).not.toEqual(captureKeys[1]);
  });

  it.each([
    ["2049560345441206272", "", "accepted", null],
    ["2047808467969220779", "", "rejected_ambiguous", "report_date_mismatch"],
    ["2049560345441206272", " tomorrow", "rejected_ambiguous", "relative_game_date_requires_review"],
  ])("uses the quoted report date and text for %s%s", async (quoteId, relativeDay, status, reason) => {
    const fetchMock = vi.fn(async (url: string) => {
      if (url === "https://t.co/9cZkBXydVn") {
        return new Response(null, {
          status: 302,
          headers: {
            location:
              `https://x.com/BenjaminJReport/status/${quoteId}`,
          },
        });
      }
      if (url.startsWith("https://publish.twitter.com/oembed?")) {
        return new Response(
          JSON.stringify({
            author_name: "Benjamin Pierce",
            author_url: "https://twitter.com/BenjaminJReport",
            html: `<blockquote><p>The #GoBolts lines unchanged in warmups${relativeDay}:<br>Goncalves-Point-Kucherov<br><br>Vasilevskiy</p>&mdash; Benjamin Pierce <a href="https://twitter.com/BenjaminJReport/status/${quoteId}">April 29, 2026</a></blockquote>`,
          }),
          {
            status: 200,
            headers: {
              "Content-Type": "application/json",
            },
          },
        );
      }
      throw new Error(`Unexpected fetch: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock);
    const events = [
      buildEvent({
        id: "event-quote",
        sourceKey: "gamedaylines",
        sourceAccount: "GameDayLines",
        tweetId: "2047808711494902155",
        text: "Lightning lines https://t.co/9cZkBXydVn",
      }),
    ];
    const { lineSourceSnapshotsUpsertMock } = createSupabaseMocks(events);
    const req = createMockReq();
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      summary: {
        eventsLoaded: 1,
        quoteTweetsResolved: 1,
        quoteResolveAttempts: 1,
        quoteResolveFailures: 0,
        acceptedNhl: status === "accepted" ? 1 : 0,
        rowsUpserted: 1,
      },
    });
    const [quoteRow] = getUpsertedRows(lineSourceSnapshotsUpsertMock);
    expect(quoteRow).toMatchObject({
      source_group: "gdl_suite",
      source_key: "gamedaylines",
      source_account: "GameDayLines",
      source: "gamedaylines",
      tweet_id: "2047808711494902155",
      quoted_tweet_id: quoteId,
      quoted_tweet_url: `https://twitter.com/i/web/status/${quoteId}`,
      quoted_author_handle: "BenjaminJReport",
      quoted_author_name: "Benjamin Pierce",
      primary_text_source: "quoted_oembed",
      team_abbreviation: "TBL",
      nhl_filter_status: status,
      nhl_filter_reason: reason,
      tweet_posted_at: quoteId === "2049560345441206272" ? "2026-04-29T18:44:00.000Z" : "2026-04-24T22:42:39.862Z",
    });
    expect(quoteRow.capture_key).toMatch(/^gamedaylines:/);
    expect(quoteRow.quoted_enriched_text).toContain("Goncalves-Point-Kucherov");
    expect(quoteRow.metadata).toMatchObject({
      preferredQuotedTweet: true,
      sourceGroup: "gdl_suite",
      sourceKey: "gamedaylines",
      sourceAccount: "GameDayLines",
    });
  });

  it("loads rosters for accepted teams that are not on the requested date schedule", async () => {
    const events = [
      buildEvent({
        id: "event-vgk",
        sourceKey: "gamedaylines",
        sourceAccount: "GameDayLines",
        tweetId: "2049666976247947332",
        text: "VGK lines for warmups before Game 5\nBarbashev-Eichel-Howden\nSmith-Marner-Stone\nHart",
      }),
    ];
    const { lineSourceSnapshotsUpsertMock } = createSupabaseMocks(events);
    const req = createMockReq({
      query: {
        date: "2026-04-29",
        limit: "10",
      },
    });
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      rosterTeamsLoaded: 3,
      summary: {
        acceptedNhl: 1,
        rowsUpserted: 1,
      },
    });
    const [row] = getUpsertedRows(lineSourceSnapshotsUpsertMock);
    expect(row).toMatchObject({
      source_key: "gamedaylines",
      team_abbreviation: "VGK",
      nhl_filter_status: "accepted",
      line_1_player_ids: [8479353, 8478403, 8474565],
      goalie_1_player_id: 8479394,
    });
  });

  it("uses beat-writer handles and NHL hashtag hints to avoid false ambiguous GDL rejections", async () => {
    const events = [
      buildEvent({
        id: "event-ducks-goalie",
        sourceKey: "gamedaygoalies",
        sourceAccount: "GameDayGoalies",
        tweetId: "2049909539970122058",
        text: "Terry IN, Dostál starting, per Quenneville.#FlyTogether https://t.co/yquWQ5hKMK",
      }),
      buildEvent({
        id: "event-sabres-boston",
        sourceKey: "gamedaygoalies",
        sourceAccount: "GameDayGoalies",
        tweetId: "2049866903368110544",
        text: "Hi from KeyBank Center — the #Sabres practice before heading to Boston for Game 6 on Friday.\nAlex Lyon is in the starter’s net.",
      }),
      buildEvent({
        id: "event-wild-news",
        sourceKey: "gamedaynewsnhl",
        sourceAccount: "GameDayNewsNHL",
        tweetId: "2049873426932797786",
        text: "In other #mnwild lineup news, Brink will come out, and Sturm comes in.",
      }),
      buildEvent({
        id: "event-stars-news",
        sourceKey: "gamedaynewsnhl",
        sourceAccount: "GameDayNewsNHL",
        tweetId: "2049885673360916596",
        text: "Glen Gulutzan and staff are shaking up the lines and the lineup.\nIt appears that Michael Bunting & Alexander Petrovic will make their 2026 playoff debuts.",
      }),
      buildEvent({
        id: "event-moose",
        sourceKey: "gamedaynewsnhl",
        sourceAccount: "GameDayNewsNHL",
        tweetId: "2049890927775486457",
        text: "#MBMoose coach Mark Morrison just told us Elias Salomonsson is having season-ending surgery due to injury.",
      }),
    ];
    events[0]!.username = "Derek_Lee27";
    events[1]!.username = "rachelmlenzi";
    events[2]!.username = "JoeSmithNHL";
    events[3]!.username = "OwenNewkirk";
    events[4]!.username = "mikemcintyrewpg";
    const { lineSourceSnapshotsUpsertMock } = createSupabaseMocks(events);
    const req = createMockReq({
      query: {
        date: "2026-04-29",
        limit: "10",
      },
    });
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      summary: {
        acceptedNhl: 4,
        nonNhlRejected: 1,
        ambiguousRejected: 0,
        rowsUpserted: 5,
      },
    });
    const rows = getUpsertedRows(lineSourceSnapshotsUpsertMock);
    expect(rows).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          tweet_id: "2049909539970122058",
          team_abbreviation: "ANA",
          nhl_filter_status: "accepted",
        }),
        expect.objectContaining({
          tweet_id: "2049866903368110544",
          team_abbreviation: "BUF",
          nhl_filter_status: "accepted",
        }),
        expect.objectContaining({
          tweet_id: "2049873426932797786",
          team_abbreviation: "MIN",
          nhl_filter_status: "accepted",
        }),
        expect.objectContaining({
          tweet_id: "2049885673360916596",
          team_abbreviation: "DAL",
          nhl_filter_status: "accepted",
        }),
        expect.objectContaining({
          tweet_id: "2049890927775486457",
          team_id: null,
          detected_league: "AHL",
          nhl_filter_status: "rejected_non_nhl",
        }),
      ]),
    );
  });

  it("accepts Utah goalie tweets after second-pass roster loading when #TusksUp is the only team hint", async () => {
    const events = [
      buildEvent({
        id: "event-utah-goalie",
        sourceKey: "gamedaygoalies",
        sourceAccount: "GameDayGoalies",
        tweetId: "2050000000000000001",
        text: "#TusksUp Vejmelka in the starter's net",
      }),
    ];
    const { lineSourceSnapshotsUpsertMock } = createSupabaseMocks(events);
    const req = createMockReq({
      query: {
        date: "2026-04-29",
        limit: "10",
      },
    });
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      summary: {
        acceptedNhl: 1,
        ambiguousRejected: 0,
        rowsUpserted: 1,
      },
    });
    const [row] = getUpsertedRows(lineSourceSnapshotsUpsertMock);
    expect(row).toMatchObject({
      source_key: "gamedaygoalies",
      tweet_id: "2050000000000000001",
      team_abbreviation: "UTA",
      nhl_filter_status: "accepted",
      goalie_1_player_id: 8479979,
      goalie_1_name: "Karel Vejmelka",
    });
  });

  it("uses decisive roster-density fallback for short tweets with multiple same-team player hits", async () => {
    const events = [
      buildEvent({
        id: "event-ducks-roster-density",
        sourceKey: "gamedaygoalies",
        sourceAccount: "GameDayGoalies",
        tweetId: "2049909539970122058",
        text: "Terry IN, Dostál starting, per Quenneville.",
      }),
    ];
    const { lineSourceSnapshotsUpsertMock } = createSupabaseMocks(events);
    const req = createMockReq({
      query: {
        date: "2026-04-29",
        limit: "10",
      },
    });
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      summary: {
        acceptedNhl: 1,
        ambiguousRejected: 0,
        rowsUpserted: 1,
      },
    });
    const [row] = getUpsertedRows(lineSourceSnapshotsUpsertMock);
    expect(row).toMatchObject({
      team_abbreviation: "ANA",
      nhl_filter_status: "accepted",
      matched_player_ids: [8478873, 8482745],
    });
  });
});
