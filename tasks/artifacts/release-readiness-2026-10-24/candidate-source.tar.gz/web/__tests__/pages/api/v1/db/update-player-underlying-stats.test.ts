import { beforeEach, describe, expect, it, vi } from "vitest";

const {
  resolveRequestedGameIdsMock,
  ingestNhlApiRawGamesBestEffortMock,
  refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock,
  resolvePlayerStatsIncrementalSelectionMock,
  refreshTeamUnderlyingSummaryRowsForGameIdsMock,
} = vi.hoisted(() => ({
  resolveRequestedGameIdsMock: vi.fn(),
  ingestNhlApiRawGamesBestEffortMock: vi.fn(),
  refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock: vi.fn(),
  resolvePlayerStatsIncrementalSelectionMock: vi.fn(),
  refreshTeamUnderlyingSummaryRowsForGameIdsMock: vi.fn(),
}));

vi.mock("lib/cron/withCronJobAudit", () => ({
  withCronJobAudit: (handler: any) => handler,
}));

vi.mock("utils/adminOnlyMiddleware", () => ({
  default: (handler: any) => handler,
}));

vi.mock("lib/supabase/server", () => ({
  default: {},
}));

vi.mock("lib/supabase/Upserts/nhlRawGamecenterRoute", () => ({
  resolveRequestedGameIds: resolveRequestedGameIdsMock,
}));

vi.mock("lib/supabase/Upserts/nhlRawGamecenter.mjs", () => ({
  ingestNhlApiRawGamesBestEffort: ingestNhlApiRawGamesBestEffortMock,
}));

vi.mock("lib/underlying-stats/playerStatsSummaryRefresh", async (importOriginal) => ({
  ...await importOriginal<typeof import("lib/underlying-stats/playerStatsSummaryRefresh")>(),
  refreshPlayerUnderlyingSummarySnapshotsForGameIds:
    refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock,
}));

vi.mock("lib/underlying-stats/playerStatsRefreshWindow", () => ({
  resolvePlayerStatsIncrementalSelection:
    resolvePlayerStatsIncrementalSelectionMock,
}));

vi.mock("lib/underlying-stats/teamStatsSummaryRefresh", () => ({
  refreshTeamUnderlyingSummaryRowsForGameIds:
    refreshTeamUnderlyingSummaryRowsForGameIdsMock,
}));

import handler from "../../../../../pages/api/v1/db/update-player-underlying-stats";
import { PlayerStatsSummaryWriteBusyError } from "lib/underlying-stats/playerStatsSummaryRefresh";

function createMockApiContext(args?: {
  method?: string;
  query?: Record<string, string>;
}) {
  const response = {
    statusCode: 200,
    body: null as unknown,
    setHeader: vi.fn(),
    status: vi.fn((code: number) => {
      response.statusCode = code;
      return response;
    }),
    json: vi.fn((payload: unknown) => {
      response.body = payload;
      return response;
    }),
  };

  return {
    req: {
      method: args?.method ?? "POST",
      query: args?.query ?? {},
      headers: {},
    },
    res: response,
  };
}

describe("/api/v1/db/update-player-underlying-stats", () => {
  beforeEach(() => {
    vi.clearAllMocks();

    resolveRequestedGameIdsMock.mockResolvedValue({
      mode: "game",
      seasonId: 20252026,
      gameIds: [2025020955],
    });
    ingestNhlApiRawGamesBestEffortMock.mockResolvedValue({
      results: [
        {
          gameId: 2025020955,
          rosterCount: 40,
          eventCount: 326,
          shiftCount: 774,
          rawEndpointsStored: 4,
          idempotent: false,
        },
      ],
      failures: [],
    });
    refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock.mockResolvedValue({
      rowsUpserted: 1,
      migratedGameIds: [],
      rawBuildGameIds: [2025020955],
    });
    resolvePlayerStatsIncrementalSelectionMock.mockResolvedValue({
      mode: "incremental",
      seasonId: 20252026,
      requestedGameType: 2,
      startDate: "2026-04-04",
      endDate: "2026-04-05",
      latestCoveredDate: "2026-04-04",
      gameIds: [2025021184, 2025021196],
    });
    refreshTeamUnderlyingSummaryRowsForGameIdsMock.mockResolvedValue({
      rowsUpserted: 0,
      gameIdsProcessed: [],
    });
  });

  it("rebuilds team summaries for the same successfully ingested games", async () => {
    refreshTeamUnderlyingSummaryRowsForGameIdsMock.mockResolvedValue({
      rowsUpserted: 140,
      gameIdsProcessed: [2025020955],
    });
    const { req, res } = createMockApiContext({ query: { gameId: "2025020955" } });

    await handler(req as never, res as never);

    expect(refreshTeamUnderlyingSummaryRowsForGameIdsMock).toHaveBeenCalledWith({
      gameIds: [2025020955],
      seasonId: 20252026,
      requestedGameType: 2,
      shouldWarmLandingCache: true,
      supabase: {},
    });
    expect(res.body).toMatchObject({
      success: true,
      summaryRowsUpserted: 1,
      teamSummaryRowsUpserted: 140,
      rowsUpserted: 1281,
    });
  });

  it.each([2026020033, 2026020030, 2026020023, 2026020025, 2026020029])(
    "retains game %s writer contention without summarizing or warming a failed ingest",
    async (gameId) => {
      const message = JSON.stringify({
        code: "P0001", details: null, hint: null,
        message: "NHL_NORMALIZATION_WRITER_BUSY",
      });
      resolveRequestedGameIdsMock.mockResolvedValue({
        mode: "game", seasonId: 20262027, gameIds: [gameId],
      });
      ingestNhlApiRawGamesBestEffortMock.mockResolvedValue({
        results: [], failures: [{ gameId, message }],
      });
      const { req, res } = createMockApiContext({
        query: { gameId: String(gameId), warmLandingCache: "true" },
      });

      await handler(req as never, res as never);

      expect(ingestNhlApiRawGamesBestEffortMock).toHaveBeenCalledWith({}, [gameId]);
      expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).not.toHaveBeenCalled();
      expect(refreshTeamUnderlyingSummaryRowsForGameIdsMock).not.toHaveBeenCalled();
      expect(res.statusCode).toBe(502);
      expect(res.body).toEqual({
        success: false,
        error: "Player underlying stats ingest failed for every requested game.",
        issues: [`${gameId}: ${message}`],
        failures: [{ gameId, message }],
      });
    },
  );

  it.each([false, true])("preserves capture diagnostics with partial success=%s", async (partialSuccess) => {
    const failure = {
      gameId: 2026020030,
      message: "NHL_NORMALIZATION_WRITER_BUSY",
      code: "P0001",
      stage: "capture_raw_sources",
      endpoint: "shiftcharts",
      attempts: 2,
    };
    const result = {
      gameId: 2026020031,
      rosterCount: 40,
      eventCount: 308,
      shiftCount: 703,
      rawEndpointsStored: 4,
      idempotent: false,
      rawCaptureBusyRetries: 1,
    };
    resolveRequestedGameIdsMock.mockResolvedValue({
      mode: "game",
      seasonId: 20262027,
      gameIds: partialSuccess ? [2026020030, 2026020031] : [2026020030],
    });
    ingestNhlApiRawGamesBestEffortMock.mockResolvedValue({
      results: partialSuccess ? [result] : [],
      failures: [failure],
    });
    const { req, res } = createMockApiContext({
      query: { gameId: "2026020030", warmLandingCache: "true" },
    });

    await handler(req as never, res as never);

    expect(res.statusCode).toBe(partialSuccess ? 200 : 502);
    expect(res.body).toMatchObject({ success: partialSuccess, failures: [failure] });
    if (partialSuccess) {
      expect(res.body).toMatchObject({
        results: [result],
        failedGameIds: [2026020030],
        warmedLandingCache: false,
      });
      expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).toHaveBeenCalledWith({
        gameIds: [2026020031],
        seasonId: 20262027,
        requestedGameType: 2,
        shouldWarmLandingCache: false,
        shouldMigrateLegacySummaries: false,
        supabase: {},
      });
    } else {
      expect(res.body).not.toHaveProperty("rawRowsUpserted");
      expect(res.body).not.toHaveProperty("rowsUpserted");
      expect(res.body).not.toHaveProperty("results");
      expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).not.toHaveBeenCalled();
    }
  });

  it("reports summary-stage exhaustion without replaying normalization or claiming zero writes", async () => {
    refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock.mockRejectedValue(
      new PlayerStatsSummaryWriteBusyError([2026020039], 2),
    );
    const { req, res } = createMockApiContext();
    await handler(req as never, res as never);

    expect(res.statusCode).toBe(500);
    expect(res.body).toEqual({
      success: false,
      error: "NHL_NORMALIZATION_WRITER_BUSY",
      issues: ["NHL_NORMALIZATION_WRITER_BUSY"],
      summaryFailure: {
        code: "P0001", stage: "persist_player_summaries", endpoint: "landing",
        gameIds: [2026020039], attempts: 2,
      },
    });
    expect(ingestNhlApiRawGamesBestEffortMock).toHaveBeenCalledTimes(1);
    expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).toHaveBeenCalledTimes(1);
  });

  it("retains a successful summary retry count", async () => {
    refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock.mockResolvedValue({
      rowsUpserted: 27, summaryWriteBusyRetries: 1,
      migratedGameIds: [], rawBuildGameIds: [2025020955],
    });
    const { req, res } = createMockApiContext();
    await handler(req as never, res as never);
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true, summaryRowsUpserted: 27, summaryWriteBusyRetries: 1,
    });
    expect(ingestNhlApiRawGamesBestEffortMock).toHaveBeenCalledTimes(1);
  });

  it("refreshes raw gamecenter inputs and per-game player summaries for one game", async () => {
    const { req, res } = createMockApiContext({
      query: {
        gameId: "2025020955",
      },
    });

    await handler(req as never, res as never);

    expect(resolveRequestedGameIdsMock).toHaveBeenCalledWith(req.query, {});
    expect(ingestNhlApiRawGamesBestEffortMock).toHaveBeenCalledWith({}, [2025020955]);
    expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).toHaveBeenCalledWith({
      gameIds: [2025020955],
      seasonId: 20252026,
      requestedGameType: 2,
      shouldWarmLandingCache: true,
      shouldMigrateLegacySummaries: false,
      supabase: {},
    });
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.body).toEqual({
      success: true,
      route: "/api/v1/db/update-player-underlying-stats",
      mode: "game",
      seasonId: 20252026,
      requestedGameCount: 1,
      processedGameCount: 1,
      failedGameCount: 0,
      gameIds: [2025020955],
      rawRowsUpserted: 1140,
      summaryRowsUpserted: 1,
      teamSummaryRowsUpserted: 0,
      rowsUpserted: 1141,
      warmedLandingCache: true,
      results: [
        {
          gameId: 2025020955,
          rosterCount: 40,
          eventCount: 326,
          shiftCount: 774,
          rawEndpointsStored: 4,
          idempotent: false,
        },
      ],
      message:
        "Player underlying stats ingest completed. Raw NHL gamecenter payloads were refreshed first, then per-game player and team underlying summaries were rebuilt.",
    });
  });

  it("reports an idempotent raw replay as zero writes while rebuilding the player summary", async () => {
    ingestNhlApiRawGamesBestEffortMock.mockResolvedValue({
      results: [
        {
          gameId: 2025020955,
          rosterCount: 40,
          eventCount: 326,
          shiftCount: 774,
          rawEndpointsStored: 4,
          idempotent: true,
        },
      ],
      failures: [],
    });

    const { req, res } = createMockApiContext({
      query: {
        gameId: "2025020955",
      },
    });

    await handler(req as never, res as never);

    expect(res.body).toMatchObject({
      rawRowsUpserted: 0,
      summaryRowsUpserted: 1,
      rowsUpserted: 1,
      results: [
        {
          gameId: 2025020955,
          idempotent: true,
        },
      ],
    });
  });

  it("returns early when the selection resolves to no games", async () => {
    resolveRequestedGameIdsMock.mockResolvedValue({
      mode: "date_range",
      seasonId: 20252026,
      gameIds: [],
    });

    const { req, res } = createMockApiContext({
      query: {
        startDate: "2026-04-02",
        endDate: "2026-04-02",
      },
    });

    await handler(req as never, res as never);

    expect(ingestNhlApiRawGamesBestEffortMock).not.toHaveBeenCalled();
    expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).not.toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.body).toEqual({
      success: true,
      route: "/api/v1/db/update-player-underlying-stats",
      mode: "date_range",
      seasonId: 20252026,
      requestedGameCount: 0,
      gameIds: [],
      rawRowsUpserted: 0,
      summaryRowsUpserted: 0,
      teamSummaryRowsUpserted: 0,
      rowsUpserted: 0,
      warmedLandingCache: false,
      results: [],
      message: "No matching games found for the requested selection.",
    });
  });

  it("supports incremental refresh from the latest covered date through current finished games", async () => {
    ingestNhlApiRawGamesBestEffortMock.mockResolvedValue({
      results: [
        {
          gameId: 2025021184,
          rosterCount: 80,
          eventCount: 600,
          shiftCount: 1200,
          rawEndpointsStored: 8,
          idempotent: false,
        },
      ],
      failures: [],
    });
    refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock.mockResolvedValue({
      rowsUpserted: 2,
      migratedGameIds: [],
      rawBuildGameIds: [2025021184, 2025021196],
    });

    const { req, res } = createMockApiContext({
      query: {
        incremental: "true",
        warmLandingCache: "true",
      },
    });

    await handler(req as never, res as never);

    expect(resolveRequestedGameIdsMock).not.toHaveBeenCalled();
    expect(resolvePlayerStatsIncrementalSelectionMock).toHaveBeenCalledWith({
      seasonId: null,
      requestedGameType: null,
      supabase: {},
    });
    expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).toHaveBeenCalledWith({
      gameIds: [2025021184],
      seasonId: 20252026,
      requestedGameType: 2,
      shouldWarmLandingCache: true,
      shouldMigrateLegacySummaries: false,
      supabase: {},
    });
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.body).toEqual({
      success: true,
      route: "/api/v1/db/update-player-underlying-stats",
      mode: "incremental",
      seasonId: 20252026,
      startDate: "2026-04-04",
      endDate: "2026-04-05",
      latestCoveredDate: "2026-04-04",
      requestedGameCount: 2,
      processedGameCount: 1,
      failedGameCount: 0,
      gameIds: [2025021184, 2025021196],
      rawRowsUpserted: 1880,
      summaryRowsUpserted: 2,
      teamSummaryRowsUpserted: 0,
      rowsUpserted: 1882,
      warmedLandingCache: true,
      results: [
        {
          gameId: 2025021184,
          rosterCount: 80,
          eventCount: 600,
          shiftCount: 1200,
          rawEndpointsStored: 8,
          idempotent: false,
        },
      ],
      message:
        "Player underlying stats ingest completed. Raw NHL gamecenter payloads were refreshed first, then per-game player and team underlying summaries were rebuilt.",
    });
  });

  it("supports batched catch-up mode for incremental refreshes", async () => {
    resolvePlayerStatsIncrementalSelectionMock.mockResolvedValue({
      mode: "incremental",
      seasonId: 20252026,
      requestedGameType: 2,
      startDate: "2026-04-04",
      endDate: "2026-04-05",
      latestCoveredDate: "2026-04-04",
      gameIds: [2025021184, 2025021196, 2025021197],
    });
    ingestNhlApiRawGamesBestEffortMock
      .mockResolvedValueOnce({
        results: [
          {
            gameId: 2025021184,
            rosterCount: 10,
            eventCount: 20,
            shiftCount: 30,
            rawEndpointsStored: 4,
            idempotent: false,
          },
          {
            gameId: 2025021196,
            rosterCount: 40,
            eventCount: 50,
            shiftCount: 60,
            rawEndpointsStored: 4,
            idempotent: false,
          },
        ],
        failures: [],
      })
      .mockResolvedValueOnce({
        results: [
          {
            gameId: 2025021197,
            rosterCount: 70,
            eventCount: 80,
            shiftCount: 90,
            rawEndpointsStored: 4,
            idempotent: false,
          },
        ],
        failures: [],
      });
    refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock
      .mockResolvedValueOnce({
        rowsUpserted: 2,
        migratedGameIds: [],
        rawBuildGameIds: [2025021184, 2025021196],
      })
      .mockResolvedValueOnce({
        rowsUpserted: 1,
        migratedGameIds: [],
        rawBuildGameIds: [2025021197],
      });

    const { req, res } = createMockApiContext({
      query: {
        incremental: "true",
        catchUp: "true",
        batchSize: "2",
        warmLandingCache: "true",
      },
    });

    await handler(req as never, res as never);

    expect(ingestNhlApiRawGamesBestEffortMock).toHaveBeenNthCalledWith(1, {}, [
      2025021184,
      2025021196,
    ]);
    expect(ingestNhlApiRawGamesBestEffortMock).toHaveBeenNthCalledWith(2, {}, [2025021197]);
    expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).toHaveBeenNthCalledWith(1, {
      gameIds: [2025021184, 2025021196],
      seasonId: 20252026,
      requestedGameType: 2,
      shouldWarmLandingCache: false,
      shouldMigrateLegacySummaries: false,
      supabase: {},
    });
    expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).toHaveBeenNthCalledWith(2, {
      gameIds: [2025021197],
      seasonId: 20252026,
      requestedGameType: 2,
      shouldWarmLandingCache: true,
      shouldMigrateLegacySummaries: false,
      supabase: {},
    });
    expect(res.body).toEqual({
      success: true,
      route: "/api/v1/db/update-player-underlying-stats",
      mode: "incremental",
      seasonId: 20252026,
      startDate: "2026-04-04",
      endDate: "2026-04-05",
      latestCoveredDate: "2026-04-04",
      catchUpCompleted: true,
      batchSize: 2,
      batchesProcessed: 2,
      requestedGameCount: 3,
      processedGameCount: 3,
      failedGameCount: 0,
      gameIds: [2025021184, 2025021196, 2025021197],
      rawRowsUpserted: 450,
      summaryRowsUpserted: 3,
      teamSummaryRowsUpserted: 0,
      rowsUpserted: 453,
      warmedLandingCache: true,
      results: [
        {
          gameId: 2025021184,
          rosterCount: 10,
          eventCount: 20,
          shiftCount: 30,
          rawEndpointsStored: 4,
          idempotent: false,
        },
        {
          gameId: 2025021196,
          rosterCount: 40,
          eventCount: 50,
          shiftCount: 60,
          rawEndpointsStored: 4,
          idempotent: false,
        },
        {
          gameId: 2025021197,
          rosterCount: 70,
          eventCount: 80,
          shiftCount: 90,
          rawEndpointsStored: 4,
          idempotent: false,
        },
      ],
      message:
        "Player underlying stats ingest completed. Raw NHL gamecenter payloads were refreshed first, then per-game player and team underlying summaries were rebuilt.",
    });
  });

  it("returns partial success details when one or more games fail during catch-up", async () => {
    resolvePlayerStatsIncrementalSelectionMock.mockResolvedValue({
      mode: "incremental",
      seasonId: 20252026,
      requestedGameType: 2,
      startDate: "2026-04-04",
      endDate: "2026-04-05",
      latestCoveredDate: "2026-04-04",
      gameIds: [2025021184, 2025021196],
    });
    ingestNhlApiRawGamesBestEffortMock.mockResolvedValue({
      results: [
        {
          gameId: 2025021184,
          rosterCount: 10,
          eventCount: 20,
          shiftCount: 30,
          rawEndpointsStored: 4,
          idempotent: false,
        },
      ],
      failures: [{ gameId: 2025021196, message: "TypeError: fetch failed" }],
    });
    refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock.mockResolvedValue({
      rowsUpserted: 1,
      migratedGameIds: [],
      rawBuildGameIds: [2025021184],
    });

    const { req, res } = createMockApiContext({
      query: {
        incremental: "true",
        catchUp: "true",
        warmLandingCache: "true",
      },
    });

    await handler(req as never, res as never);

    expect(refreshPlayerUnderlyingSummarySnapshotsForGameIdsMock).toHaveBeenCalledWith({
      gameIds: [2025021184],
      seasonId: 20252026,
      requestedGameType: 2,
      shouldWarmLandingCache: false,
      shouldMigrateLegacySummaries: false,
      supabase: {},
    });
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.body).toEqual({
      success: true,
      route: "/api/v1/db/update-player-underlying-stats",
      mode: "incremental",
      seasonId: 20252026,
      startDate: "2026-04-04",
      endDate: "2026-04-05",
      latestCoveredDate: "2026-04-04",
      catchUpCompleted: false,
      batchSize: 5,
      batchesProcessed: 1,
      requestedGameCount: 2,
      processedGameCount: 1,
      failedGameCount: 1,
      failedGameIds: [2025021196],
      failures: [{ gameId: 2025021196, message: "TypeError: fetch failed" }],
      gameIds: [2025021184, 2025021196],
      rawRowsUpserted: 60,
      summaryRowsUpserted: 1,
      teamSummaryRowsUpserted: 0,
      rowsUpserted: 61,
      warmedLandingCache: false,
      results: [
        {
          gameId: 2025021184,
          rosterCount: 10,
          eventCount: 20,
          shiftCount: 30,
          rawEndpointsStored: 4,
          idempotent: false,
        },
      ],
      message:
        "Player underlying stats ingest completed with partial failures. Successful games were refreshed and summarized; failed games can be retried with the same URL.",
    });
  });
});
