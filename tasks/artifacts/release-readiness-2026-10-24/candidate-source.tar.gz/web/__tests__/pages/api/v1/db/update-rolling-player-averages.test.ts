import { beforeEach, describe, expect, it, vi } from "vitest";

const { mainMock, auditInsertMock, auditSelectMock, getUserMock } = vi.hoisted(() => ({
  mainMock: vi.fn(),
  auditInsertMock: vi.fn().mockResolvedValue({ error: null }),
  auditSelectMock: vi.fn(),
  getUserMock: vi.fn()
}));

function createRollingRunSummary(overrides: Record<string, unknown> = {}) {
  return {
    rowsUpserted: 10,
    processedPlayers: 2,
    playersWithRows: 2,
    coverageWarnings: 0,
    suspiciousOutputWarnings: 0,
    unknownGameIds: 0,
    freshnessBlockers: 0,
    sourceTracking: {
      missingSources: {
        counts: 0,
        rates: 0,
        countsOi: 0,
        pp: 0,
        ppUnit: 0,
        line: 0,
        lineAssignment: 0,
        knownGameId: 0
      },
      wgoFallbacks: {
        goals: 0,
        assists: 0,
        primary_assists: 0,
        secondary_assists: 0,
        shots: 0,
        hits: 0,
        blocks: 0,
        points: 0,
        ixg: 0
      },
      rateReconstructions: {
        sog_per_60: 0,
        ixg_per_60: 0
      },
      ixgPer60Sources: {
        counts_raw: 0,
        wgo_raw: 0,
        rate_reconstruction: 0,
        unavailable: 0
      },
      toiSources: {
        counts: 0,
        counts_oi: 0,
        rates: 0,
        fallback: 0,
        wgo: 0,
        none: 0
      },
      toiFallbackSeeds: {
        counts: 0,
        counts_oi: 0,
        wgo: 0,
        none: 0
      },
      toiTrustTiers: {
        authoritative: 0,
        supplementary: 0,
        fallback: 0,
        none: 0
      },
      toiWgoNormalizations: {
        minutes_to_seconds: 0,
        already_seconds: 0,
        missing: 0,
        invalid: 0
      },
      toiSuspiciousReasons: {
        non_finite: 0,
        non_positive: 0,
        above_max_seconds: 0
      }
    },
    ...overrides
  };
}

vi.mock("lib/supabase/Upserts/fetchRollingPlayerAverages", () => ({
  main: mainMock
}));

vi.mock("lib/supabase", () => ({
  createClientWithToken: vi.fn(() => ({
    auth: {
      getUser: getUserMock
    }
  })),
  default: {
    from: vi.fn(() => ({
      insert: auditInsertMock
    }))
  }
}));

vi.mock("lib/supabase/server", () => ({
  default: {
    from: vi.fn(() => {
      const query: Record<string, unknown> = { insert: auditInsertMock };
      const filters: unknown[][] = [];
      for (const method of ["select", "eq", "gte", "order"]) {
        query[method] = (...args: unknown[]) => {
          filters.push([method, ...args]);
          return query;
        };
      }
      query.limit = async () => auditSelectMock(filters);
      return query;
    })
  }
}));

import protectedHandler, {
  handler
} from "../../../../../pages/api/v1/db/update-rolling-player-averages";

function createMockRes() {
  const res: any = {
    statusCode: 200,
    headers: {} as Record<string, string | string[]>,
    body: null as any,
    headersSent: false,
    setHeader(key: string, value: string | string[]) {
      this.headers[key] = value;
    },
    status(code: number) {
      this.statusCode = code;
      return this;
    },
    json(payload: any) {
      this.body = payload;
      this.headersSent = true;
      return this;
    },
    send(payload: any) {
      this.body = payload;
      this.headersSent = true;
      return this;
    }
  };
  return res;
}

describe("/api/v1/db/update-rolling-player-averages", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mainMock.mockResolvedValue(createRollingRunSummary());
    getUserMock.mockResolvedValue({
      error: { message: "Invalid authentication credentials" }
    });
  });

  it("rejects unauthenticated writer requests before recompute work", async () => {
    const req: any = {
      method: "GET",
      headers: {},
      query: {},
      url: "/api/v1/db/update-rolling-player-averages"
    };
    const res = createMockRes();

    await protectedHandler(req, res);

    expect(res.statusCode).toBe(401);
    expect(res.body).toEqual({
      message: "Unauthorized.",
      success: false
    });
    expect(mainMock).not.toHaveBeenCalled();
  });

  it("returns 405 for unsupported methods", async () => {
    const req: any = {
      method: "DELETE",
      query: {},
      url: "/api/v1/db/update-rolling-player-averages"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(405);
    expect(res.headers.Allow).toBe("GET, POST, HEAD");
    expect(res.body).toEqual({ message: "Method not allowed" });
  });

  it("forwards dry-run and debug upsert controls with fast-mode defaults to main", async () => {
    const req: any = {
      method: "GET",
      query: {
        playerId: "8478402",
        season: "20252026",
        resumeFrom: "8478000",
        fullRefresh: "false",
        fullRefreshMode: "overwrite_only",
        deleteChunkSize: "25000",
        upsertBatchSize: "900",
        dryRunUpsert: "yes",
        debugUpsertPayload: "true",
        fastMode: "true"
      },
      url: "/api/v1/db/update-rolling-player-averages?playerId=8478402"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).toHaveBeenCalledWith({
      playerId: 8478402,
      season: 20252026,
      startDate: undefined,
      endDate: undefined,
      strengths: undefined,
      resumePlayerId: 8478000,
      maxPlayers: undefined,
      forceFullRefresh: false,
      fullRefreshMode: "overwrite_only",
      fullRefreshDeleteChunkSize: 25000,
      playerConcurrency: 4,
      upsertBatchSize: 900,
      upsertConcurrency: 4,
      skipDiagnostics: true,
      dryRunUpsert: true,
      debugUpsertPayload: true
    });
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      message: "Rolling player averages processed successfully.",
      executionProfile: "targeted_repair",
      runSummary: expect.objectContaining({
        freshnessBlockers: 0
      }),
      dependencyContract: {
        version: "rolling-forge-operator-order-v2",
        currentStage: {
          id: "rolling_player_recompute",
          order: 4
        }
      },
      runtimeBudget: expect.objectContaining({
        budgetMs: 600000,
        withinBudget: true
      })
    });
  });

  it("infers overnight tuning defaults for broad fast-mode season sweeps", async () => {
    const req: any = {
      method: "GET",
      query: {
        season: "20252026",
        fastMode: "true"
      },
      url: "/api/v1/db/update-rolling-player-averages?season=20252026&fastMode=true"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).toHaveBeenCalledWith({
      playerId: undefined,
      season: 20252026,
      startDate: undefined,
      endDate: undefined,
      strengths: undefined,
      resumePlayerId: undefined,
      maxPlayers: undefined,
      forceFullRefresh: undefined,
      fullRefreshMode: undefined,
      fullRefreshDeleteChunkSize: undefined,
      playerConcurrency: 4,
      upsertBatchSize: 250,
      upsertConcurrency: 2,
      skipDiagnostics: true,
      dryRunUpsert: undefined,
      debugUpsertPayload: undefined
    });
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      executionProfile: "overnight",
      runtimeBudget: expect.objectContaining({
        budgetMs: 1800000,
        withinBudget: true
      })
    });
  });

  it("bounds bare GET cron calls to an implicit recent daily window", async () => {
    const req: any = {
      method: "GET",
      query: {},
      url: "/api/v1/db/update-rolling-player-averages"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).toHaveBeenCalledTimes(1);
    const args = mainMock.mock.calls[0][0];
    expect(args.playerId).toBeUndefined();
    expect(args.season).toBeUndefined();
    expect(args.resumePlayerId).toBeUndefined();
    expect(args.startDate).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(args.endDate).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(args.playerConcurrency).toBe(4);
    expect(args.upsertBatchSize).toBe(500);
    expect(args.upsertConcurrency).toBe(4);
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      executionProfile: "daily_incremental",
      executionScope: {
        startDate: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/),
        endDate: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/),
        historyReadMode: "full_selected_scope_through_end_date",
        implicitDailyWindowApplied: true,
        windowDays: 15,
        smokeTestComparable: false,
        smokeTestGuidance:
          "This run is not a one-day smoke test. Use explicit startDate=endDate for a true one-day operational probe."
      },
      runtimeBudget: expect.objectContaining({
        budgetMs: 210000,
        withinBudget: true
      })
    });
  });

  it("allows POST body params to bound cron runs explicitly", async () => {
    const req: any = {
      method: "POST",
      query: {},
      body: {
        startDate: "2026-03-10",
        endDate: "2026-03-14",
        fastMode: true,
        executionProfile: "daily_incremental"
      },
      url: "/api/v1/db/update-rolling-player-averages"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).toHaveBeenCalledWith({
      playerId: undefined,
      season: undefined,
      startDate: "2026-03-10",
      endDate: "2026-03-14",
      strengths: undefined,
      resumePlayerId: undefined,
      maxPlayers: undefined,
      forceFullRefresh: undefined,
      fullRefreshMode: undefined,
      fullRefreshDeleteChunkSize: undefined,
      playerConcurrency: 4,
      upsertBatchSize: 500,
      upsertConcurrency: 4,
      skipDiagnostics: true,
      dryRunUpsert: undefined,
      debugUpsertPayload: undefined,
      stopClaimingPlayersAtMs: expect.any(Number),
      abortInFlightAtMs: expect.any(Number)
    });
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      executionProfile: "daily_incremental",
      executionScope: {
        startDate: "2026-03-10",
        endDate: "2026-03-14",
        implicitDailyWindowApplied: false,
        windowDays: 5,
        smokeTestComparable: false,
        smokeTestGuidance:
          "This run is not a one-day smoke test. Use explicit startDate=endDate for a true one-day operational probe."
      }
    });
  });

  it("passes through a bounded true-5v5 strength scope", async () => {
    const req: any = {
      method: "GET",
      query: {
        season: "20252026",
        startDate: "2026-03-01",
        endDate: "2026-04-16",
        strength: "5v5",
        fastMode: "true",
        skipDiagnostics: "true",
        maxPlayers: "10"
      },
      url: "/api/v1/db/update-rolling-player-averages?season=20252026&startDate=2026-03-01&endDate=2026-04-16&strength=5v5&fastMode=true&skipDiagnostics=true&maxPlayers=10"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).toHaveBeenCalledWith(
      expect.objectContaining({
        season: 20252026,
        startDate: "2026-03-01",
        endDate: "2026-04-16",
        strengths: ["5v5"],
        maxPlayers: 10,
        playerConcurrency: 4,
        upsertConcurrency: 4,
        skipDiagnostics: true
      })
    );
    expect(res.statusCode).toBe(200);
  });

  it("auto-resumes bounded batches until the cursor is exhausted", async () => {
    mainMock
      .mockResolvedValueOnce(
        createRollingRunSummary({
          rowsUpserted: 100,
          processedPlayers: 25,
          lastProcessedPlayerId: 8475000,
          nextResumeFrom: 8475000,
          remainingPlayerCount: 25,
          totalPlayersAfterResumeFilter: 50
        })
      )
      .mockResolvedValueOnce(
        createRollingRunSummary({
          rowsUpserted: 80,
          processedPlayers: 25,
          lastProcessedPlayerId: 8476000,
          nextResumeFrom: null,
          remainingPlayerCount: 0,
          totalPlayersAfterResumeFilter: 25
        })
      );
    const req: any = {
      method: "GET",
      query: {
        season: "20252026",
        startDate: "2025-10-07",
        endDate: "2026-04-16",
        strength: "5v5",
        executionProfile: "overnight",
        autoResume: "true",
        autoResumeMaxBatches: "3"
      },
      url: "/api/v1/db/update-rolling-player-averages?autoResume=true"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).toHaveBeenCalledTimes(2);
    expect(mainMock.mock.calls[0][0]).toMatchObject({
      season: 20252026,
      strengths: ["5v5"],
      resumePlayerId: undefined,
      maxPlayers: 25,
      playerConcurrency: 1,
      upsertBatchSize: 50,
      upsertConcurrency: 1,
      skipDiagnostics: true
    });
    expect(mainMock.mock.calls[1][0]).toMatchObject({
      resumePlayerId: 8475000,
      maxPlayers: 25
    });
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      runSummary: {
        rowsUpserted: 180,
        processedPlayers: 50,
        nextResumeFrom: null
      },
      autoResume: {
        enabled: true,
        batchesRun: 2,
        runtimeBudgetDisabled: false,
        stoppedReason: "complete",
        nextResumeFrom: null,
        maxPlayersPerBatch: 25
      }
    });
  });

  it("allows manual auto-resume runs to disable the loop runtime budget", async () => {
    mainMock.mockResolvedValueOnce(
      createRollingRunSummary({
        rowsUpserted: 100,
        processedPlayers: 25,
        lastProcessedPlayerId: 8475000,
        nextResumeFrom: 8475000,
        remainingPlayerCount: 25,
        totalPlayersAfterResumeFilter: 50
      })
    );
    const req: any = {
      method: "GET",
      query: {
        season: "20252026",
        startDate: "2025-10-07",
        endDate: "2026-04-16",
        strength: "5v5",
        executionProfile: "overnight",
        autoResume: "true",
        autoResumeMaxBatches: "1",
        disableAutoResumeRuntimeBudget: "true"
      },
      url: "/api/v1/db/update-rolling-player-averages?autoResume=true&disableAutoResumeRuntimeBudget=true"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).toHaveBeenCalledTimes(1);
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      autoResume: {
        enabled: true,
        maxRuntimeMs: null,
        runtimeBudgetDisabled: true,
        stoppedReason: "max_batches",
        nextResumeFrom: 8475000
      }
    });
  });

  it("returns a truthful 207 with a resume request when the daily run reaches its budget", async () => {
    mainMock.mockResolvedValueOnce(
      createRollingRunSummary({
        processedPlayers: 120,
        lastProcessedPlayerId: 8478000,
        nextResumeFrom: 8478000,
        remainingPlayerCount: 480,
        totalPlayersAfterResumeFilter: 600,
        stoppedReason: "runtime_budget"
      })
    );
    const req: any = {
      method: "POST",
      query: {},
      body: {},
      url: "/api/v1/db/update-rolling-player-averages"
    };
    const res = createMockRes();
    const before = Date.now();

    await handler(req, res);

    const args = mainMock.mock.calls[0][0];
    expect(args.stopClaimingPlayersAtMs).toBeGreaterThanOrEqual(before + 180_000);
    expect(args.stopClaimingPlayersAtMs).toBeLessThanOrEqual(Date.now() + 180_000);
    // In-flight players are abandoned 40 s after claiming stops, 20 s before the cap.
    expect(args.abortInFlightAtMs).toBe(args.stopClaimingPlayersAtMs + 40_000);
    expect(res.body.inFlightDeadlineAt).toBe(args.abortInFlightAtMs);
    expect(res.statusCode).toBe(207);
    expect(Object.keys(res.body)[0]).toBe("resumeCursor");
    expect(res.body).toMatchObject({
      resumeCursor: {
        v: 1,
        windowStartDate: args.startDate,
        windowEndDate: args.endDate,
        strengths: "default",
        status: "partial",
        nextResumeFrom: 8478000
      },
      success: false,
      operationStatus: "partial",
      playerClaimBudgetMs: 180000,
      resume: {
        required: true,
        nextResumeFrom: 8478000,
        remainingPlayerCount: 480,
        request: {
          startDate: args.startDate,
          endDate: args.endDate,
          executionProfile: "daily_incremental",
          resumeFrom: 8478000
        }
      }
    });
  });

  it("passes an explicit deadlineAt to the writer and drops it with disableRuntimeBudget", async () => {
    mainMock.mockResolvedValue(createRollingRunSummary({ stoppedReason: "complete" }));
    const invoke = async (query: Record<string, string>) => {
      const req: any = {
        method: "GET",
        query: { startDate: "2026-10-20", endDate: "2026-10-20", fastMode: "true", executionProfile: "daily_incremental", ...query },
        url: "/api/v1/db/update-rolling-player-averages"
      };
      const res = createMockRes();
      await handler(req, res);
      return res;
    };

    const explicit = await invoke({ deadlineAt: "1792580000000" });
    expect(explicit.statusCode).toBe(200);
    expect(mainMock.mock.calls[0][0].abortInFlightAtMs).toBe(1792580000000);
    expect(explicit.body.inFlightDeadlineAt).toBe(1792580000000);

    const disabled = await invoke({ disableRuntimeBudget: "true" });
    expect(mainMock.mock.calls[1][0].abortInFlightAtMs).toBeUndefined();
    expect(mainMock.mock.calls[1][0].stopClaimingPlayersAtMs).toBeUndefined();
    expect(disabled.body.inFlightDeadlineAt).toBeNull();
  });

  it("continues today's daily window from the cursor a prior partial run left in the audit", async () => {
    mainMock.mockResolvedValueOnce(
      createRollingRunSummary({
        nextResumeFrom: 8478000,
        remainingPlayerCount: 480,
        stoppedReason: "runtime_budget"
      })
    );
    const url = "/api/v1/db/update-rolling-player-averages";
    const first = createMockRes();
    await handler({ method: "POST", query: {}, body: {}, url } as any, first);
    // withCronJobAudit stores a 4000-character preview of the response.
    const preview = JSON.stringify(first.body).slice(0, 3999) + "…";
    auditSelectMock.mockResolvedValue({
      data: [
        { run_time: "later", details: { response: "{\"success\":false,\"error\":\"timeout\"}" } },
        { run_time: "earlier", details: { response: preview } }
      ],
      error: null
    });
    mainMock.mockResolvedValueOnce(
      createRollingRunSummary({ nextResumeFrom: null, stoppedReason: "complete" })
    );

    const second = createMockRes();
    await handler(
      { method: "POST", query: {}, body: { continueDailyWindow: true }, url } as any,
      second
    );

    const firstArgs = mainMock.mock.calls[0][0];
    const secondArgs = mainMock.mock.calls[1][0];
    expect(secondArgs).toMatchObject({
      startDate: firstArgs.startDate,
      endDate: firstArgs.endDate,
      resumePlayerId: 8478000
    });
    expect(auditSelectMock.mock.calls[0][0]).toEqual(
      expect.arrayContaining([
        ["eq", "job_name", url],
        ["gte", "run_time", `${firstArgs.endDate}T00:00:00.000Z`]
      ])
    );
    expect(second.statusCode).toBe(200);
    expect(second.body.resumeCursor).toMatchObject({
      status: "complete",
      nextResumeFrom: null
    });

    // Once today's window is complete, a further continuation does no work.
    auditSelectMock.mockResolvedValue({
      data: [{ run_time: "latest", details: { response: JSON.stringify(second.body) } }],
      error: null
    });
    const third = createMockRes();
    await handler(
      { method: "POST", query: {}, body: { continueDailyWindow: true }, url } as any,
      third
    );
    expect(mainMock).toHaveBeenCalledTimes(2);
    expect(third.statusCode).toBe(200);
    expect(third.body.message).toMatch(/already complete/);
  });

  it("refuses continueDailyWindow outside the implicit daily window", async () => {
    const res = createMockRes();
    await handler(
      {
        method: "GET",
        query: { startDate: "2026-10-01", endDate: "2026-10-02", continueDailyWindow: "true" },
        url: "/api/v1/db/update-rolling-player-averages"
      } as any,
      res
    );
    expect(res.statusCode).toBe(400);
    expect(mainMock).not.toHaveBeenCalled();
  });

  it("blocks unbounded multi-week date-window recomputes", async () => {
    const req: any = {
      method: "GET",
      query: {
        season: "20252026",
        startDate: "2026-03-01",
        endDate: "2026-04-16",
        strength: "5v5",
        fastMode: "true",
        skipDiagnostics: "true"
      },
      url: "/api/v1/db/update-rolling-player-averages?season=20252026&startDate=2026-03-01&endDate=2026-04-16&strength=5v5&fastMode=true&skipDiagnostics=true"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).not.toHaveBeenCalled();
    expect(res.statusCode).toBe(422);
    expect(res.body).toMatchObject({
      success: false,
      operationStatus: "blocked",
      executionProfile: "daily_incremental",
      executionScope: {
        startDate: "2026-03-01",
        endDate: "2026-04-16",
        implicitDailyWindowApplied: false,
        windowDays: 47,
        smokeTestComparable: false
      }
    });
    expect(res.body.message).toContain("maxPlayers");
    expect(res.body.message).toContain("executionProfile=overnight");
    expect(res.body.progressGuidance).toMatchObject({
      responseMode: "buffered",
      progressEndpoint: null
    });
    expect(res.body.progressGuidance.recommendedOperatorPath).toContain(
      "future async job table"
    );
  });

  it("allows deliberate broad true-5v5 recomputes with the overnight profile", async () => {
    const req: any = {
      method: "GET",
      query: {
        season: "20252026",
        startDate: "2026-03-01",
        endDate: "2026-04-16",
        strength: "5v5",
        fastMode: "true",
        skipDiagnostics: "true",
        executionProfile: "overnight"
      },
      url: "/api/v1/db/update-rolling-player-averages?season=20252026&startDate=2026-03-01&endDate=2026-04-16&strength=5v5&fastMode=true&skipDiagnostics=true&executionProfile=overnight"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(mainMock).toHaveBeenCalledWith(
      expect.objectContaining({
        season: 20252026,
        startDate: "2026-03-01",
        endDate: "2026-04-16",
        strengths: ["5v5"],
        playerConcurrency: 4,
        upsertBatchSize: 250,
        upsertConcurrency: 2,
        skipDiagnostics: true
      })
    );
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      executionProfile: "overnight",
      appliedPlayerLimit: undefined,
      progressGuidance: {
        responseMode: "buffered",
        progressEndpoint: null
      }
    });
    expect(res.body.progressGuidance.resumeStrategy).toContain(
      "Overnight runs are intentionally buffered"
    );
  });

  it("marks explicit same-day rolling runs as smoke-test comparable", async () => {
    const req: any = {
      method: "GET",
      query: {
        startDate: "2026-03-14",
        endDate: "2026-03-14",
        executionProfile: "daily_incremental"
      },
      url: "/api/v1/db/update-rolling-player-averages?startDate=2026-03-14&endDate=2026-03-14&executionProfile=daily_incremental"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      executionProfile: "daily_incremental",
      executionScope: {
        startDate: "2026-03-14",
        endDate: "2026-03-14",
        implicitDailyWindowApplied: false,
        windowDays: 1,
        smokeTestComparable: true,
        smokeTestGuidance: null
      }
    });
  });

  it("returns 500 when the rolling writer throws", async () => {
    mainMock.mockRejectedValueOnce(new Error("upsert blocker"));

    const req: any = {
      method: "GET",
      query: {
        playerId: "8478402"
      },
      url: "/api/v1/db/update-rolling-player-averages?playerId=8478402"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(500);
    expect(res.body).toEqual({
      message: "upsert blocker",
      dependencyContract: expect.objectContaining({
        currentStage: expect.objectContaining({
          id: "rolling_player_recompute"
        })
      }),
      runSummary: undefined
    });
  });

  it("returns 422 when upstream freshness blockers remain", async () => {
    mainMock.mockResolvedValueOnce(
      createRollingRunSummary({
        freshnessBlockers: 3
      })
    );

    const req: any = {
      method: "GET",
      query: {
        startDate: "2026-03-10",
        endDate: "2026-03-14"
      },
      url: "/api/v1/db/update-rolling-player-averages?startDate=2026-03-10&endDate=2026-03-14"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(422);
    expect(res.body).toMatchObject({
      message:
        "Freshness dependency checks failed. Refresh stale upstream sources or use bypassFreshnessBlockers=true to override.",
      success: false,
      operationStatus: "blocked",
      warning:
        "Rolling player averages were blocked because required upstream freshness checks failed.",
      executionScope: {
        startDate: "2026-03-10",
        endDate: "2026-03-14",
        implicitDailyWindowApplied: false,
        windowDays: 5,
        smokeTestComparable: false,
        smokeTestGuidance:
          "This run is not a one-day smoke test. Use explicit startDate=endDate for a true one-day operational probe."
      },
      runSummary: expect.objectContaining({
        freshnessBlockers: 3
      }),
      freshnessGate: {
        status: "FAIL",
        blockerCount: 3,
        bypassed: false
      }
    });
  });

  it("returns warning status and successful audit semantics when freshness blockers are bypassed", async () => {
    mainMock.mockResolvedValueOnce(
      createRollingRunSummary({
        freshnessBlockers: 2
      })
    );
    const previousServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const previousCronSecret = process.env.CRON_SECRET;
    process.env.SUPABASE_SERVICE_ROLE_KEY = "test-service-role";
    process.env.CRON_SECRET = "test-cron-secret";

    try {
      const req: any = {
        method: "GET",
        headers: {
          authorization: "Bearer test-cron-secret"
        },
        query: {
          startDate: "2026-03-14",
          endDate: "2026-03-14",
          bypassFreshnessBlockers: "true"
        },
        url: "/api/v1/db/update-rolling-player-averages?startDate=2026-03-14&endDate=2026-03-14&bypassFreshnessBlockers=true"
      };
      const res = createMockRes();

      await protectedHandler(req, res);

      expect(res.statusCode).toBe(200);
      expect(res.body).toMatchObject({
        message:
          "Rolling player averages processed with freshness blockers bypassed.",
        success: true,
        operationStatus: "warning",
        warning:
          "Upstream freshness blockers were bypassed. Treat this recompute as degraded until stale sources are refreshed.",
        executionScope: {
          startDate: "2026-03-14",
          endDate: "2026-03-14",
          implicitDailyWindowApplied: false,
          windowDays: 1,
          smokeTestComparable: true,
          smokeTestGuidance: null
        },
        freshnessGate: {
          status: "FAIL",
          blockerCount: 2,
          bypassed: true,
          action:
            "Refresh stale upstream sources or use bypassFreshnessBlockers=true to override."
        }
      });
      expect(auditInsertMock).toHaveBeenCalled();
      const insertedAuditRow = auditInsertMock.mock.calls.at(-1)?.[0];
      expect(insertedAuditRow).toMatchObject({
        status: "success",
        job_name: "/api/v1/db/update-rolling-player-averages"
      });
    } finally {
      if (previousServiceRoleKey === undefined) {
        delete process.env.SUPABASE_SERVICE_ROLE_KEY;
      } else {
        process.env.SUPABASE_SERVICE_ROLE_KEY = previousServiceRoleKey;
      }
      if (previousCronSecret === undefined) {
        delete process.env.CRON_SECRET;
      } else {
        process.env.CRON_SECRET = previousCronSecret;
      }
    }
  });

  it("downgrades freshness blockers to warning status for the implicit daily cron shape", async () => {
    mainMock.mockResolvedValueOnce(
      createRollingRunSummary({
        freshnessBlockers: 1
      })
    );

    const req: any = {
      method: "GET",
      query: {},
      url: "/api/v1/db/update-rolling-player-averages"
    };
    const res = createMockRes();

    await handler(req, res);

    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      operationStatus: "warning",
      message:
        "Rolling player averages processed with freshness warnings on the implicit daily window.",
      warning:
        "Implicit daily maintenance tolerated upstream freshness blockers. Treat this recompute as degraded until stale sources are refreshed.",
      executionProfile: "daily_incremental",
      executionScope: expect.objectContaining({
        implicitDailyWindowApplied: true
      }),
      freshnessGate: {
        status: "FAIL",
        blockerCount: 1,
        bypassed: true,
        action:
          "Refresh stale upstream sources or use bypassFreshnessBlockers=true to override."
      }
    });
  });

  it.each([
    [{ playerId: "8478402" }, "playerId"],
    [{ dryRunUpsert: "true" }, "dryRunUpsert"],
    [{ maxPlayers: "10" }, "maxPlayers"],
    [{ season: "20252026" }, "season"],
    [{ autoResume: "true" }, "maxPlayers"]
  ])(
    "refuses a table-clearing full refresh combined with %o",
    async (extraQuery, conflictingFlag) => {
      for (const fullRefreshMode of ["rpc_truncate", "delete"]) {
        const req: any = {
          method: "GET",
          query: { fullRefresh: "true", fullRefreshMode, ...extraQuery },
          url: "/api/v1/db/update-rolling-player-averages"
        };
        const res = createMockRes();

        await handler(req, res);

        expect(res.statusCode).toBe(400);
        expect(res.body).toMatchObject({
          success: false,
          operationStatus: "blocked",
          message: expect.stringContaining(conflictingFlag)
        });
      }
      expect(mainMock).not.toHaveBeenCalled();
    }
  );

  it("treats a bare fullRefresh as overwrite-only and passes an explicit unscoped truncate through", async () => {
    const scopedReq: any = {
      method: "GET",
      query: { fullRefresh: "true", playerId: "8478402", dryRunUpsert: "true" },
      url: "/api/v1/db/update-rolling-player-averages"
    };
    const scopedRes = createMockRes();
    await handler(scopedReq, scopedRes);

    expect(scopedRes.statusCode).toBe(200);
    expect(mainMock).toHaveBeenLastCalledWith(
      expect.objectContaining({
        playerId: 8478402,
        forceFullRefresh: true,
        fullRefreshMode: undefined,
        dryRunUpsert: true
      })
    );

    const truncateReq: any = {
      method: "GET",
      query: { fullRefresh: "true", fullRefreshMode: "rpc_truncate" },
      url: "/api/v1/db/update-rolling-player-averages"
    };
    const truncateRes = createMockRes();
    await handler(truncateReq, truncateRes);

    expect(truncateRes.statusCode).toBe(200);
    expect(mainMock).toHaveBeenLastCalledWith(
      expect.objectContaining({
        playerId: undefined,
        maxPlayers: undefined,
        forceFullRefresh: true,
        fullRefreshMode: "rpc_truncate"
      })
    );
  });
});
