import React from "react";
import { renderToString } from "react-dom/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";

import type {
  UnderlyingStatsLandingRating,
  UnderlyingStatsLandingSnapshot
} from "../../../lib/underlying-stats/teamLandingRatings";
import type { UlsRouteStatus } from "../../../lib/underlying-stats/ulsRouteStatus";
import { buildUnderlyingStatsLandingDashboard } from "../../../lib/underlying-stats/teamLandingDashboard";

const routerState = vi.hoisted(() => ({
  isReady: true,
  pathname: "/underlying-stats",
  query: { date: "2026-04-05" } as Record<string, string>,
  replace: vi.fn()
}));

class ResizeObserverMock {
  constructor(private readonly callback: ResizeObserverCallback) {}

  observe(target: Element) {
    this.callback(
      [
        {
          target,
          contentRect: { width: 800, height: 420 } as DOMRectReadOnly
        } as ResizeObserverEntry
      ],
      this as unknown as ResizeObserver
    );
  }

  unobserve() {}
  disconnect() {}
}

vi.mock("next/head", () => ({
  default: ({ children }: { children: React.ReactNode }) => <>{children}</>
}));

vi.mock("next/router", () => ({
  useRouter: () => routerState
}));

import UnderlyingStatsLanding, {
  TeamPowerRankingsPage
} from "../../../pages/underlying-stats";

const buildRating = (
  teamAbbr: string,
  overrides: Partial<UnderlyingStatsLandingRating> = {}
): UnderlyingStatsLandingRating => ({
  teamAbbr,
  date: "2026-04-05",
  offRating: 100,
  defRating: 100,
  paceRating: 100,
  ppTier: 2,
  pkTier: 2,
  trend10: 0,
  components: {
    xgf60: 3.1,
    gf60: 3,
    sf60: 27,
    xga60: 3,
    ga60: 3,
    sa60: 28,
    pace60: 57
  },
  finishingRating: 100,
  goalieRating: 100,
  dangerRating: 100,
  specialRating: 100,
  disciplineRating: 100,
  varianceFlag: 0,
  sos: 100,
  sosPast: 0.55,
  sosPastRank: 10,
  sosFuture: 0.53,
  sosFutureRank: 14,
  ppPct: 22.4,
  ppRank: 11,
  pkPct: 81.1,
  pkRank: 8,
  trendSeries: [
    { date: "2026-03-28", value: 99 },
    { date: "2026-04-01", value: 100 },
    { date: "2026-04-05", value: 101 }
  ],
  luckSeries: [
    { date: "2026-03-28", value: 99.5 },
    { date: "2026-04-01", value: 100.1 },
    { date: "2026-04-05", value: 100.4 }
  ],
  luckStatus: "normal",
  luckPdo: 100.4,
  luckPdoZ: 0.3,
  narrative: [
    "5v5 offense is rising as expected goals and shot volume improve.",
    "Upcoming schedule looks softer than league average."
  ],
  scheduleTexture: {
    backToBacksNext14: 1,
    gamesNext14: 5,
    gamesNext7: 3,
    homeGamesNext14: 2,
    restAdvantageGamesNext14: 1,
    restDisadvantageGamesNext14: 0,
    roadGamesNext14: 3,
    threeInFourNext14: 1
  },
  ...overrides
});

function jsonResponse(data: unknown, ok = true, status = 200): Response {
  return {
    ok,
    status,
    json: async () => data
  } as Response;
}

const buildSnapshot = (
  ratings: UnderlyingStatsLandingRating[],
  resolvedDate = "2026-04-05"
): UnderlyingStatsLandingSnapshot => ({
  dashboard: buildUnderlyingStatsLandingDashboard(ratings),
  requestedDate: resolvedDate,
  resolvedDate,
  ratings
});

const routeStatus: UlsRouteStatus = {
  teamRatings: { latestSnapshotDate: "2026-04-05", rowCount: 32, status: "ready" },
  skaterOffenseRatings: { latestSnapshotDate: null, rowCount: 0, status: "pending" },
  skaterDefenseRatings: { latestSnapshotDate: null, rowCount: 0, status: "pending" },
  goalieRatings: { latestSnapshotDate: null, rowCount: 0, status: "pending" },
  gamePredictions: { latestSnapshotDate: null, rowCount: 0, status: "pending" },
  playerPredictions: { latestSnapshotDate: null, rowCount: 0, status: "pending" },
  modelMarketFlags: { latestSnapshotDate: null, rowCount: 0, status: "pending" }
};

describe("/underlying-stats landing page", () => {
  beforeEach(() => {
    routerState.replace.mockReset();
    routerState.query = { date: "2026-04-05" };
    vi.restoreAllMocks();
    vi.stubGlobal("ResizeObserver", ResizeObserverMock);
  });

  afterEach(() => {
    cleanup();
  });

  it("serves the ghost first, then replaces it with the requested snapshot", async () => {
    const payload = {
      availableDates: ["2026-04-05"],
      initialSnapshot: buildSnapshot([buildRating("TOR")]),
      routeStatus
    };
    const fetchMock = vi.fn(async () => jsonResponse(payload));
    vi.stubGlobal("fetch", fetchMock);

    expect(renderToString(<UnderlyingStatsLanding />)).toContain(
      "Loading team rankings and the latest snapshot"
    );

    render(<UnderlyingStatsLanding />);
    expect(screen.getByRole("status").textContent).toContain("Loading team rankings");
    expect(screen.queryByRole("table", { name: "Detailed team table" })).toBeNull();
    expect(await screen.findByRole("table", { name: "Detailed team table" })).toBeTruthy();
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/underlying-stats/landing?date=2026-04-05",
      expect.objectContaining({ signal: expect.any(AbortSignal) })
    );
  });

  it("offers retry when the initial snapshot fails", async () => {
    const payload = {
      availableDates: ["2026-04-05"],
      initialSnapshot: buildSnapshot([buildRating("TOR")]),
      routeStatus
    };
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(jsonResponse({}, false, 503))
      .mockResolvedValueOnce(jsonResponse(payload));
    vi.stubGlobal("fetch", fetchMock);

    render(<UnderlyingStatsLanding />);
    expect((await screen.findByRole("alert")).textContent).toContain(
      "Unable to load Underlying Stats (503)"
    );
    fireEvent.click(screen.getByRole("button", { name: "Try again" }));
    expect(await screen.findByRole("table", { name: "Detailed team table" })).toBeTruthy();
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("restores the URL snapshot after history changes and rejects a late response", async () => {
    let resolveOlder!: (response: Response) => void;
    const older = new Promise<Response>((resolve) => { resolveOlder = resolve; });
    const initialSnapshot = buildSnapshot([buildRating("TOR")]);
    const fetchMock = vi.fn((input: RequestInfo | URL, _init?: RequestInit) => {
      if (String(input).includes("/landing")) return Promise.resolve(jsonResponse({
        availableDates: ["2026-04-05", "2026-04-04", "2026-04-03"], initialSnapshot, routeStatus
      }));
      if (String(input).includes("2026-04-04")) return older;
      return Promise.resolve(jsonResponse(buildSnapshot([buildRating("VAN")], "2026-04-03")));
    });
    vi.stubGlobal("fetch", fetchMock);
    const { rerender } = render(<UnderlyingStatsLanding />);
    await screen.findByRole("table", { name: "Detailed team table" });

    routerState.query = { date: "2026-04-04" };
    rerender(<UnderlyingStatsLanding />);
    await waitFor(() => expect((screen.getByLabelText("Snapshot date") as HTMLSelectElement).value).toBe("2026-04-04"));
    await waitFor(() => expect(fetchMock).toHaveBeenCalledWith(
      "/api/underlying-stats/team-ratings?date=2026-04-04", expect.objectContaining({ signal: expect.any(AbortSignal) })
    ));
    const pendingSignal = fetchMock.mock.calls.find(([url]) => String(url).includes("team-ratings?date=2026-04-04"))![1] as RequestInit;

    routerState.query = { date: "2026-04-03" };
    rerender(<UnderlyingStatsLanding />);
    await waitFor(() => expect(within(screen.getByRole("table", { name: "Detailed team table" })).getByText("VAN")).toBeTruthy());
    expect(pendingSignal.signal?.aborted).toBe(true);
    await act(async () => resolveOlder(jsonResponse(buildSnapshot([buildRating("BOS")], "2026-04-04"))));
    expect((screen.getByLabelText("Snapshot date") as HTMLSelectElement).value).toBe("2026-04-03");
    expect(within(screen.getByRole("table", { name: "Detailed team table" })).queryByText("BOS")).toBeNull();
  });

  it("hides the previous snapshot while loading and restores it after a failed date request", async () => {
    let failRequest!: (response: Response) => void;
    vi.stubGlobal("fetch", vi.fn(() => new Promise<Response>((resolve) => { failRequest = resolve; })));
    render(<TeamPowerRankingsPage availableDates={["2026-04-05", "2026-04-04"]}
      initialSnapshot={buildSnapshot([buildRating("TOR")])} routeStatus={routeStatus} />);
    const select = screen.getByLabelText("Snapshot date");
    fireEvent.change(select, { target: { value: "2026-04-04" } });
    expect(within(screen.getByRole("table", { name: "Detailed team table" })).queryByText("TOR")).toBeNull();
    await act(async () => failRequest(jsonResponse({}, false, 503)));
    expect(screen.getAllByText("Unable to load ratings (503)").length).toBeGreaterThan(0);
    fireEvent.change(select, { target: { value: "2026-04-05" } });
    await waitFor(() => expect(within(screen.getByRole("table", { name: "Detailed team table" })).getByText("TOR")).toBeTruthy());
    expect(screen.queryByText("Unable to load ratings (503)")).toBeNull();
  });

  it("opens the latest snapshot when navigation removes an initial historical date", async () => {
    routerState.query = { date: "2026-04-04" };
    const fetchMock = vi.fn(async () => jsonResponse(buildSnapshot([buildRating("TOR")])));
    vi.stubGlobal("fetch", fetchMock);
    const props = { availableDates: ["2026-04-05", "2026-04-04"], routeStatus,
      initialSnapshot: buildSnapshot([buildRating("VAN")], "2026-04-04") };
    const { rerender } = render(<TeamPowerRankingsPage {...props} />);
    expect((screen.getByLabelText("Snapshot date") as HTMLSelectElement).value).toBe("2026-04-04");
    routerState.query = {};
    rerender(<TeamPowerRankingsPage {...props} />);
    await waitFor(() => expect((screen.getByLabelText("Snapshot date") as HTMLSelectElement).value).toBe("2026-04-05"));
    await waitFor(() => expect(within(screen.getByRole("table", { name: "Detailed team table" })).getByText("TOR")).toBeTruthy());
  });

  it("shows the four-link rail, Power Leaders, advanced rankings, and readiness", () => {
    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05", "2026-04-04", "2026-04-03"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot([
          buildRating("TOR", {
            offRating: 110,
            defRating: 108,
            paceRating: 107,
            ppTier: 1,
            pkTier: 1,
            trend10: 2.34,
            sosPast: 0.612,
            sosPastRank: 3,
            sosFuture: 0.558,
            sosFutureRank: 9
          }),
          buildRating("VAN", {
            offRating: 102,
            defRating: 101,
            paceRating: 100,
            trend10: -1.12,
            sosPast: 0.521,
            sosFuture: 0.509
          })
        ])}
      />
    );

    const select = screen.getByLabelText("Snapshot date");
    expect(within(select).getAllByRole("option")).toHaveLength(3);
    const links = within(screen.getByRole("navigation", { name: "Underlying Stats Hub Navigation" })).getAllByRole("link");
    expect(links.map((link) => link.getAttribute("aria-label"))).toEqual([
      "Team Explorer", "Skater Stats", "Goalie Stats", "xG Lab"
    ]);
    expect(links.map((link) => new URL(link.getAttribute("href")!, "http://localhost").pathname)).toEqual([
      "/underlying-stats/teamStats",
      "/underlying-stats/playerStats",
      "/underlying-stats/goalieStats",
      "/underlying-stats/xg"
    ]);
    expect(screen.getByRole("region", { name: "Power leaders" })).toBeTruthy();
    expect(links[0]!.compareDocumentPosition(screen.getByRole("region", { name: "Power leaders" })) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
    expect(screen.getByRole("tab", { name: "Team Rankings" }).getAttribute("aria-selected")).toBe("true");
    expect(screen.queryByRole("region", { name: "Process quadrant" })).toBeNull();
    expect(screen.queryByRole("region", { name: "Team movers" })).toBeNull();
    expect(screen.queryByText("What looks real?")).toBeNull();
    expect(screen.queryByText("Schedule texture")).toBeNull();
    expect(screen.queryByText("Under the radar")).toBeNull();
    expect(screen.queryByText("Latest snapshot")).toBeNull();
    expect(screen.getByText("2 NHL Teams")).toBeTruthy();
    fireEvent.click(screen.getByText("About this dashboard"));
    expect(screen.getByRole("heading", { name: "Data readiness" })).toBeTruthy();
    expect(
      screen.getByText("Team snapshot").closest("article")?.textContent
    ).toContain("Apr 5, 2026");

    const table = screen.getByRole("table", { name: "Detailed team table" });
    expect(
      within(table).getByRole("columnheader", { name: /SoS Future/ })
    ).toBeTruthy();
    expect(
      within(table).getByRole("columnheader", { name: /SoS Past/ })
    ).toBeTruthy();
    expect(screen.getByRole("tab", { name: "Advanced" }).getAttribute("aria-selected")).toBe("true");

    const bodyRows = within(table).getAllByRole("row").slice(1);
    expect(within(bodyRows[0]!).getByText("TOR")).toBeTruthy();
    expect(within(bodyRows[0]!).getByText("55.8%")).toBeTruthy();
    expect(within(bodyRows[0]!).getByText("▲ 2.3")).toBeTruthy();
    expect(
      within(table)
        .getAllByRole("columnheader")
        .slice(0, 7)
        .map((header) => header.textContent?.replace(/[↕↑↓]/g, "").trim())
    ).toEqual([
      "Rank", "Team", "Power Score", "Offense", "Defense", "Trend", "Why it's moving"
    ]);
  });

  it("opens and closes real metric explanations independently through their focusable summaries", () => {
    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot([buildRating("TOR", { offRating: 110 })])}
      />
    );

    const table = screen.getByRole("table", { name: "Detailed team table" });
    const row = within(table).getAllByRole("row")[1]!;
    const power = within(row).getByText("Power Score").closest("details")!;
    const offense = within(row).getByText("Offense").closest("details")!;
    const powerSummary = power.querySelector("summary")!;
    const offenseSummary = offense.querySelector("summary")!;

    expect(power.open).toBe(false);
    expect(offense.open).toBe(false);
    expect(powerSummary.textContent).toMatch(/\d/);
    expect(offenseSummary.textContent).toBe("110.0i");
    powerSummary.focus();
    expect(document.activeElement).toBe(powerSummary);

    fireEvent.click(powerSummary);
    expect(power.open).toBe(true);
    expect(offense.open).toBe(false);
    expect(within(power).getByText(
      "Power Score averages offense, defense, and pace, then adds a small PP/PK tier bonus."
    )).toBeTruthy();
    expect(within(power).getByText("Offense: 110.0")).toBeTruthy();

    offenseSummary.focus();
    expect(document.activeElement).toBe(offenseSummary);
    fireEvent.click(offenseSummary);
    expect(offense.open).toBe(true);
    expect(power.open).toBe(true);
    expect(within(offense).getByText(
      "Higher is better. Formula: 70% xGF/60, 20% SF/60, 10% GF/60."
    )).toBeTruthy();
    expect(within(offense).getByText(/xGF\/60: 3\.10 vs league 3\.10/)).toBeTruthy();

    fireEvent.click(powerSummary);
    expect(power.open).toBe(false);
    expect(offense.open).toBe(true);
    fireEvent.click(offenseSummary);
    expect(offense.open).toBe(false);
  });

  it("keeps the populated quadrant map out of server markup before mounting it on the client", async () => {
    const pageProps = {
      availableDates: ["2026-04-05"],
      routeStatus,
      initialSnapshot: buildSnapshot([buildRating("TOR")])
    };

    const serverMarkup = renderToString(<TeamPowerRankingsPage {...pageProps} />);
    expect(serverMarkup).not.toContain("Smothering");

    render(<TeamPowerRankingsPage {...pageProps} />);

    fireEvent.click(screen.getByRole("tab", { name: "Chart" }));
    expect(screen.getByRole("tab", { name: "Chart" }).getAttribute("aria-selected")).toBe("true");
    expect(screen.getByRole("region", { name: "Process quadrant" })).toBeTruthy();
    expect(screen.getByRole("region", { name: "Team movers" })).toBeTruthy();
    expect(screen.queryByRole("table", { name: "Detailed team table" })).toBeNull();
    fireEvent.keyDown(screen.getByRole("tab", { name: "Chart" }), { key: "Home" });
    expect(screen.getByRole("tab", { name: "Team Rankings" }).getAttribute("aria-selected")).toBe("true");
    fireEvent.keyDown(screen.getByRole("tab", { name: "Team Rankings" }), { key: "ArrowRight" });

    await waitFor(() => {
      expect(screen.getByText("Smothering")).toBeTruthy();
    });
  });

  it("fetches updated landing ratings when the snapshot date changes", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      expect(String(input)).toContain(
        "/api/underlying-stats/team-ratings?date=2026-04-04"
      );

      const payload = buildSnapshot(
        [
          buildRating("VAN", {
            date: "2026-04-04",
            offRating: 112,
            defRating: 110,
            paceRating: 108,
            trend10: 3.21,
            sosPast: 0.621,
            sosFuture: 0.589
          })
        ],
        "2026-04-04"
      );

      return jsonResponse(payload);
    });
    vi.stubGlobal("fetch", fetchMock);

    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05", "2026-04-04"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot([
          buildRating("TOR", {
            offRating: 110,
            defRating: 108,
            paceRating: 107,
            trend10: 2.34,
            sosPast: 0.612,
            sosFuture: 0.558
          })
        ])}
      />
    );

    fireEvent.change(screen.getByLabelText("Snapshot date"), {
      target: { value: "2026-04-04" }
    });

    await waitFor(() => {
      const table = screen.getByRole("table", { name: "Detailed team table" });
      const bodyRows = within(table).getAllByRole("row").slice(1);
      expect(within(bodyRows[0]!).getByText("VAN")).toBeTruthy();
      expect(within(bodyRows[0]!).getByText("58.9%")).toBeTruthy();
      expect(within(bodyRows[0]!).getByText("▲ 3.2")).toBeTruthy();
    });

    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(routerState.replace).toHaveBeenCalledWith(
      {
        pathname: "/underlying-stats",
        query: { date: "2026-04-04" }
      },
      undefined,
      { shallow: true }
    );
  });

  it("surfaces failed freshness when a snapshot request fails", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => jsonResponse({}, false, 503))
    );

    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05", "2026-04-04"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot([buildRating("TOR")])}
      />
    );

    fireEvent.change(screen.getByLabelText("Snapshot date"), {
      target: { value: "2026-04-04" }
    });

    await waitFor(() => {
      expect(screen.getAllByText("Unable to load ratings (503)").length).toBeGreaterThan(
        0
      );
    });

    expect(screen.getByText("Failed")).toBeTruthy();
    const leaders = screen.getByRole("region", { name: "Power leaders" });
    expect(within(leaders).getByText("No power leaders are available.")).toBeTruthy();
    expect(
      screen.queryByRole("table", { name: "Detailed team table" })
    ).toBeNull();
  });

  it("switches to simple mode and hides the advanced component columns", () => {
    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot([buildRating("TOR"), buildRating("VAN")])}
      />
    );

    fireEvent.click(screen.getByRole("tab", { name: "Simple" }));

    const table = screen.getByRole("table", { name: "Detailed team table" });
    expect(within(table).queryByRole("columnheader", { name: /SoS Past/ })).toBeNull();
    expect(within(table).getByRole("columnheader", { name: /Why it's moving/ })).toBeTruthy();
  });

  it("sorts simple mode rows by trend when the trend header is clicked", () => {
    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot([
          buildRating("TOR", { trend10: 1.2 }),
          buildRating("VAN", { trend10: 4.4 })
        ])}
      />
    );

    fireEvent.click(screen.getByRole("tab", { name: "Simple" }));
    fireEvent.click(screen.getByRole("button", { name: /Trend/ }));

    const table = screen.getByRole("table", { name: "Detailed team table" });
    const bodyRows = within(table).getAllByRole("row").slice(1);
    expect(within(bodyRows[0]!).getByText("VAN")).toBeTruthy();
  });

  it("pins a chart team by keyboard across dashboard modules and the link rail", async () => {
    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot([
          buildRating("TOR", {
            offRating: 110,
            defRating: 108,
            paceRating: 107,
            trend10: 2.3
          }),
          buildRating("VAN", { trend10: -2.1 })
        ])}
      />
    );

    fireEvent.click(screen.getByRole("tab", { name: "Chart" }));
    const quadrant = screen.getByRole("region", { name: "Process quadrant" });
    fireEvent.keyDown(
      await within(quadrant).findByRole("button", {
        name: "Pin Vancouver Canucks"
      }),
      { key: "Enter", code: "Enter" }
    );

    fireEvent.click(screen.getByRole("tab", { name: "Team Rankings" }));
    const table = screen.getByRole("table", { name: "Detailed team table" });
    expect(
      within(table)
        .getByRole("button", { name: "Pin Vancouver Canucks" })
        .getAttribute("aria-pressed")
    ).toBe("true");

    const explorers = screen.getByRole("navigation", { name: "Underlying Stats Hub Navigation" });
    expect(
      within(explorers)
        .getByRole("link", { name: /Team Explorer/ })
        .getAttribute("href")
    ).toContain("teamId=23");

    fireEvent.click(screen.getByRole("tab", { name: "Chart" }));
    const activeQuadrant = screen.getByRole("region", { name: "Process quadrant" });
    const torontoMarker = within(activeQuadrant).getByRole("button", {
      name: "Pin Toronto Maple Leafs"
    });
    fireEvent.focus(torontoMarker);
    expect(
      within(activeQuadrant).getByLabelText(
        "Toronto Maple Leafs selected-team context"
      )
    ).toBeTruthy();
    expect(
      within(explorers)
        .getByRole("link", { name: /Team Explorer/ })
        .getAttribute("href")
    ).toContain("teamId=23");

    const chart = activeQuadrant.querySelector(".recharts-wrapper");
    expect(chart).toBeTruthy();
    fireEvent.mouseLeave(chart as Element);
    expect(
      within(activeQuadrant).getByLabelText(
        "Vancouver Canucks selected-team context"
      )
    ).toBeTruthy();
  });

  it("shows every available team with a range footer and no row cap", () => {
    const teamAbbreviations = [
      "ANA",
      "BOS",
      "BUF",
      "CAR",
      "CBJ",
      "CGY",
      "CHI",
      "COL",
      "DAL",
      "DET",
      "EDM",
      "FLA",
      "LAK",
      "MIN"
    ];

    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot(
          teamAbbreviations.map((teamAbbr, index) =>
            buildRating(teamAbbr, { offRating: 114 - index })
          )
        )}
      />
    );

    const table = screen.getByRole("table", { name: "Detailed team table" });
    expect(within(table).getAllByRole("row").slice(1)).toHaveLength(14);
    expect(screen.getByText("Showing 1–14 of 14 teams")).toBeTruthy();
    expect(screen.queryByRole("button", { name: /Show top 12/ })).toBeNull();
  });

  it("switches workspaces by keyboard and returns to rankings from Power Leaders", () => {
    render(
      <TeamPowerRankingsPage
        availableDates={["2026-04-05"]}
        routeStatus={routeStatus}
        initialSnapshot={buildSnapshot([buildRating("TOR"), buildRating("VAN")])}
      />
    );

    const rankingsTab = screen.getByRole("tab", { name: "Team Rankings" });
    fireEvent.keyDown(rankingsTab, { key: "ArrowRight" });
    const chartTab = screen.getByRole("tab", { name: "Chart" });
    expect(chartTab.getAttribute("aria-selected")).toBe("true");
    expect(document.activeElement).toBe(chartTab);
    expect(screen.queryByRole("tab", { name: "Advanced" })).toBeNull();

    fireEvent.click(screen.getByRole("button", { name: /View full rankings/ }));
    expect(rankingsTab.getAttribute("aria-selected")).toBe("true");
    expect(document.activeElement).toBe(rankingsTab);
    expect(screen.getByRole("tab", { name: "Advanced" })).toBeTruthy();
  });
});
