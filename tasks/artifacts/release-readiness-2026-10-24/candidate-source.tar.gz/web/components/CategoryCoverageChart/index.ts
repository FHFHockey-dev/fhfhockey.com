export { default } from "./CategoryCoverageChart";
