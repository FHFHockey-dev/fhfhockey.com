import { canonicalScheduleTeam } from "lib/draftDashboard/scheduleMetrics";
// components/DraftDashboard/ProjectionsTable.tsx

import { estimatePlayerAvailability, type SelectionHorizon } from "lib/draftDashboard/availability";
import type { PlayerScheduleMetrics } from "lib/draftDashboard/scheduleMetrics";
import React, { useState, useMemo, useEffect, useCallback } from "react";
import { DraftedPlayer } from "./DraftDashboard";
// Import ProcessedPlayer from the correct location
import { ProcessedPlayer } from "hooks/useProcessedProjectionsData";
import { PlayerVorpMetrics } from "hooks/useVORPCalculations";
import styles from "./ProjectionsTable.module.scss";
import controls from "styles/Controls.module.scss";
import supabase from "lib/supabase";
import { STATS_MASTER_LIST } from "lib/projectionsConfig/statsMasterList";
import type { StatDefinition } from "lib/projectionsConfig/statsMasterList";
import ComparePlayersModal from "./ComparePlayersModal";
import type { YahooMappingDiagnostics } from "lib/draftDashboard/yahooMapping";
import { findMissingProjectionPlayers } from "lib/draftDashboard/projectionCrosscheck";
import type { SourceRankImpact } from "lib/draftDashboard/sourceRankImpact";
import type { ProjectionInclusionDiagnostics } from "lib/draftDashboard/projectionInclusionDiagnostics";
import {
  diagnoseProjectionVisibility,
  getProjectionDisplayPosition,
  matchesProjectionPosition,
  matchesProjectionSearch,
} from "lib/draftDashboard/projectionVisibility";
import { getRosterPositions } from "lib/draftDashboard/forwardGrouping";
import { fetchAllSupabaseFilterChunks } from "lib/supabase/pagination";
import { selectLatestSeasonRows } from "lib/draftDashboard/previousSeasonTotals";
import type { DraftDashboardDustInsight } from "hooks/useRosterScheduleOptimizer";
import {
  canProrateStat,
  getProratedStat,
  NHL_REGULAR_SEASON_GAMES,
} from "lib/projectionsConfig/proration";

interface ProjectionsTableProps {
  draftUnavailableReason?: string;
  onRefresh?: () => void;
  picksBeforeTurn?: number;
  scheduleMetrics?: PlayerScheduleMetrics;
  projectionSeasonId?: string | number;
  players: ProcessedPlayer[];
  // Full pool including drafted; used for diagnostics cross-check
  allPlayers?: ProcessedPlayer[];
  draftedPlayers: DraftedPlayer[];
  unavailablePlayerIds?: ReadonlySet<string>;
  isLoading: boolean;
  error: string | null;
  onDraftPlayer: (playerId: string) => void;
  canDraft: boolean;
  draftProEligible?: boolean;
  adpSource?: "yahoo" | "fantrax";
  positionSource?: "yahoo" | "fantrax";
  fantraxLeagueEligibilityAvailable?: boolean;
  fantraxPlayerDataLoaded?: boolean;
  // VORP metrics map
  vorpMetrics?: Map<string, PlayerVorpMetrics>;
  //  replacement baselines for tooltip/context
  replacementByPos?: Record<string, { vorp: number; vols: number }>;
  //  baseline mode controls
  baselineMode?: "remaining" | "full";
  onBaselineModeChange?: (mode: "remaining" | "full") => void;
  //  expected position runs before next pick
  expectedRuns?: { byPos: Record<string, number>; N: number };
  // pick risk context: absolute next pick number (currentPick + picksUntilNext)
  nextPickNumber?: number;
  selectionHorizon?: SelectionHorizon | null;
  riskSd?: number;
  onRiskSdChange?: (value: number) => void;
  // league type for value semantics
  leagueType?: "points" | "categories";
  // forward grouping display mode (C/LW/RW vs FWD)
  forwardGrouping?: "split" | "fwd";
  activeCategoryKeys?: string[];
  // Enabled stat keys coming from DraftSettings (only these show in Stat Columns mode)
  enabledSkaterStatKeys?: string[];
  enabledGoalieStatKeys?: string[];
  yahooMappingDiagnostics?: Partial<
    Record<"skater" | "goalie", YahooMappingDiagnostics | null>
  >;
  sourceRankImpacts?: Record<string, SourceRankImpact>;
  inclusionDiagnostics?: Partial<
    Record<"skater" | "goalie", ProjectionInclusionDiagnostics | null>
  >;
  dataNotices?: string[];
  emptyStateMessage?: string;
  personalRankByPlayerId?: Readonly<Record<string, number>>;
  dustInsights?: ReadonlyMap<string, DraftDashboardDustInsight>;
  onFavoriteIdsChange?: (ids: string[]) => void;
  onOpenRosterImpact?: (selectedIds: readonly string[]) => void;
}

type SortableField =
  | keyof ProcessedPlayer
  | "fantasyPoints"
  | "score"
  | "vorp"
  | "vona"
  | "vbd"
  | "valueDelta"
  | "risk"
  | "off"
  | "b2b";

const DEFAULT_SKATER_STAT_KEYS = [
  "GOALS",
  "ASSISTS",
  "POINTS",
  "SHOTS_ON_GOAL",
  "HITS",
  "BLOCKED_SHOTS",
  "PP_POINTS",
];
const DEFAULT_GOALIE_STAT_KEYS = [
  "WINS_GOALIE",
  "GOALS_AGAINST_AVERAGE",
  "SAVE_PERCENTAGE",
  "SHUTOUTS_GOALIE",
];

type RgbColor = readonly [number, number, number];

const mixRgb = (from: RgbColor, to: RgbColor, amount: number) =>
  `rgb(${from.map((channel, index) =>
    Math.round(channel + (to[index] - channel) * amount),
  ).join(", ")})`;

const getOffNightRankColor = (rankPercentile: number) => {
  const quartiles: readonly [RgbColor, RgbColor][] = [
    [[22, 163, 74], [163, 230, 53]],
    [[250, 204, 21], [249, 115, 22]],
    [[249, 115, 22], [239, 68, 68]],
    [[239, 68, 68], [153, 27, 27]],
  ];
  const scaled = Math.min(Math.max(rankPercentile, 0), 1) * quartiles.length;
  const quartileIndex = Math.min(Math.floor(scaled), quartiles.length - 1);
  const [from, to] = quartiles[quartileIndex];
  return mixRgb(from, to, scaled - quartileIndex);
};

const ProjectionsTable: React.FC<ProjectionsTableProps> = ({
  draftUnavailableReason = "Manual drafting is unavailable",
  onRefresh,
  projectionSeasonId,
  players,
  allPlayers,
  draftedPlayers,
  unavailablePlayerIds,
  isLoading,
  error,
  onDraftPlayer,
  canDraft,
  draftProEligible = false,
  adpSource = "yahoo",
  positionSource = "yahoo",
  fantraxLeagueEligibilityAvailable = false,
  fantraxPlayerDataLoaded = false,
  personalRankByPlayerId,
  vorpMetrics,
  replacementByPos,
  baselineMode = "remaining",
  onBaselineModeChange,
  expectedRuns,
  nextPickNumber,
  selectionHorizon,
  riskSd = 12,
  onRiskSdChange,
  forwardGrouping = "split",
  leagueType = "points",
  activeCategoryKeys = [],
  enabledSkaterStatKeys,
  enabledGoalieStatKeys,
  yahooMappingDiagnostics,
  sourceRankImpacts = {},
  inclusionDiagnostics,
  dataNotices = [],
  emptyStateMessage = "No players found matching your filters.",
  dustInsights,
  picksBeforeTurn,
  scheduleMetrics,
  onFavoriteIdsChange,
  onOpenRosterImpact,
}) => {
  const [sortField, setSortField] = useState<SortableField>("yahooAvgPick");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [positionFilter, setPositionFilter] = useState<string>("ALL");
  const canFilterMultiplePositions = draftProEligible && (positionSource === "yahoo" || fantraxLeagueEligibilityAvailable);
  const activePositionFilter = !positionFilter.startsWith("ELIGIBLE_") || canFilterMultiplePositions ? positionFilter : "ALL";
  useEffect(() => {
    if ((!draftProEligible || (positionSource === "fantrax" && fantraxPlayerDataLoaded && !fantraxLeagueEligibilityAvailable)) && positionFilter.startsWith("ELIGIBLE_")) setPositionFilter("ALL");
  }, [draftProEligible, positionSource, fantraxPlayerDataLoaded, fantraxLeagueEligibilityAvailable, positionFilter]);
  const [searchTerm, setSearchTerm] = useState("");
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(50);
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
  // Value band scope: overall or per-position (default per-position)
  const [bandScope, setBandScope] = useState<"overall" | "position">(
    "position",
  );
  // configurable risk standard deviation (in picks)
  // Favorites
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(() => {
    if (typeof window === "undefined") return new Set();
    try {
      const raw = window.localStorage.getItem("projections.favorites");
      if (!raw) return new Set();
      const arr = JSON.parse(raw);
      return new Set((Array.isArray(arr) ? arr : []).map(String));
    } catch {
      return new Set();
    }
  });
  const [favoritesOnly, setFavoritesOnly] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem("projections.favoritesOnly") === "true";
  });
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(
        "projections.favorites",
        JSON.stringify(Array.from(favoriteIds)),
      );
      window.localStorage.setItem(
        "projections.favoritesOnly",
        String(favoritesOnly),
      );
    } catch {}
  }, [favoriteIds, favoritesOnly]);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const refreshFavorites = () => {
      try {
        const parsed = JSON.parse(window.localStorage.getItem("projections.favorites") ?? "[]");
        setFavoriteIds(new Set((Array.isArray(parsed) ? parsed : []).map(String)));
      } catch {
        setFavoriteIds(new Set());
      }
    };
    window.addEventListener("draft-saved-favorites-changed", refreshFavorites);
    return () => window.removeEventListener("draft-saved-favorites-changed", refreshFavorites);
  }, []);
  const toggleFavorite = (id: string) => {
    const next = new Set(favoriteIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setFavoriteIds(next);
    onFavoriteIdsChange?.(Array.from(next));
  };
  const [draggedFavorite, setDraggedFavorite] = useState<string | null>(null);
  const favoriteOrder = useMemo(() => Array.from(favoriteIds), [favoriteIds]);
  const moveFavorite = (id: string, target: string) => {
    if (!favoritesOnly || id === target) return;
    const order = Array.from(favoriteIds);
    const from = order.indexOf(id);
    const to = order.indexOf(target);
    if (from < 0 || to < 0) return;
    order.splice(from, 1);
    order.splice(to, 0, id);
    setFavoriteIds(new Set(order));
    onFavoriteIdsChange?.(order);
  };
  // Optional stat sort
  const [statSortKey, setStatSortKey] = useState<string>("");
  const statDefByKey = useMemo(() => {
    const m = new Map<string, StatDefinition>();
    STATS_MASTER_LIST.forEach((s) => m.set(s.key, s));
    return m;
  }, []);

  // Toggle: show stat columns instead of value columns
  const [statColumnsMode, setStatColumnsMode] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return (
      window.localStorage.getItem("projections.statColumnsMode") === "true"
    );
  });
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(
        "projections.statColumnsMode",
        String(statColumnsMode),
      );
    } catch {}
  }, [statColumnsMode]);

  // Full-season proration toggle (skater counting stats pacing)
  const [prorate84, setProrate84] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    const current = window.localStorage.getItem("projections.prorate84");
    return current == null
      ? window.localStorage.getItem("projections.prorate82") === "true"
      : current === "true";
  });
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem("projections.prorate84", String(prorate84));
    } catch {}
  }, [prorate84]);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && typeof detail.value === "boolean") {
        setProrate84(detail.value);
      }
    };
    window.addEventListener("projections:prorate84", handler as EventListener);
    return () =>
      window.removeEventListener(
        "projections:prorate84",
        handler as EventListener,
      );
  }, []);

  const goalieStatColumns = useMemo(() => {
    const src = enabledGoalieStatKeys
      ? enabledGoalieStatKeys // if provided (even empty) respect it
      : DEFAULT_GOALIE_STAT_KEYS;
    return src.filter(Boolean);
  }, [enabledGoalieStatKeys]);

  const statColumns = useMemo(() => {
    if (positionFilter === "G") return goalieStatColumns;
    const base = enabledSkaterStatKeys
      ? enabledSkaterStatKeys
      : DEFAULT_SKATER_STAT_KEYS;
    return base.filter(Boolean);
  }, [positionFilter, enabledSkaterStatKeys, goalieStatColumns]);

  // If current stat sort key is no longer in visible stat columns, clear it
  useEffect(() => {
    if (statSortKey && !statColumns.includes(statSortKey)) {
      setStatSortKey("");
    }
  }, [statColumns, statSortKey]);

  const handleStatHeaderSort = (key: string) => {
    if (statSortKey === key) {
      setSortDirection((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setStatSortKey(key);
      const higher = statDefByKey.get(key)?.higherIsBetter;
      setSortDirection(higher ? "desc" : "asc");
    }
  };

  const formatStatValue = (key: string, value: number | null | undefined) => {
    if (value == null || Number.isNaN(value)) return "-";
    const def = statDefByKey.get(key);
    if (!def) return String(value);
    if (def.formatter) return def.formatter(value);
    if (key === "SAVE_PERCENTAGE") return value.toFixed(3);
    const dp = def.decimalPlaces ?? (def.dataType === "percentage" ? 1 : 2);
    if (def.dataType === "percentage") {
      return `${(value * 100).toFixed(dp)}%`;
    }
    return String(Number(value.toFixed(dp)));
  };
  // hide drafted toggle (persisted)
  const [hideDrafted, setHideDrafted] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    const v = window.localStorage.getItem("projections.hideDrafted");
    return v === "true";
  });
  // Temporary diagnostics toggle to surface excluded counts
  const [showDiagnostics, setShowDiagnostics] = useState<boolean>(false);
  // Cross-check results against projection source tables
  const [crosscheckRunning, setCrosscheckRunning] = useState(false);
  const [crosscheckError, setCrosscheckError] = useState<string | null>(null);
  const [crosscheckMissing, setCrosscheckMissing] = useState<
    Array<{ player_id: number; name: string | null; sourceIds: string[] }>
  >([]);
  // settings drawer visibility
  const [settingsOpen, setSettingsOpen] = useState(false);
  // compare players modal state
  const [compareOpen, setCompareOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [compareSelectionMessage, setCompareSelectionMessage] = useState("");
  const toggleSelected = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
      setCompareSelectionMessage("");
    } else if (next.size >= 2) {
      setCompareSelectionMessage(
        "Compare supports exactly two players. Remove one before selecting another.",
      );
      return;
    } else {
      next.add(id);
      setCompareSelectionMessage("");
    }
    setSelectedIds(next);
  };
  const resetComparison = () => {
    setSelectedIds(new Set());
    setCompareSelectionMessage("");
    setCompareOpen(false);
  };

  // Expand/collapse and last season totals cache per player
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [seasonTotals, setSeasonTotals] = useState<
    Record<
      string,
      {
        type: "skater" | "goalie";
        seasonLabel: string;
        data: any;
      } | null
    >
  >({});
  const [seasonLoading, setSeasonLoading] = useState<Record<string, boolean>>(
    {},
  );
  const [seasonError, setSeasonError] = useState<Record<string, string | null>>(
    {},
  );
  const loadedSeasonIdsRef = React.useRef(new Set<string>());
  const seasonBatchPromiseRef = React.useRef<Promise<void> | null>(null);

  const isGoaliePlayer = (player: ProcessedPlayer) => {
    const pos = player.displayPosition?.toUpperCase() || "";
    // Treat pure G or multi-position including G as goalie
    return pos
      .split(",")
      .map((p) => p.trim())
      .includes("G");
  };

  // Map raw displayPosition to UI display based on forward grouping
  const getDisplayPos = useCallback(
    (player: ProcessedPlayer): string =>
      getProjectionDisplayPosition(player, forwardGrouping),
    [forwardGrouping],
  );

  const formatSeasonLabel = (season: string | number | null) => {
    if (season == null) return "";
    const s = String(season);
    if (s.length === 8) {
      const start = s.slice(0, 4);
      const end = s.slice(6, 8);
      return `${start}-${end}`;
    }
    return s;
  };

  const fetchLastSeasonTotalsBatch = async () => {
    if (seasonBatchPromiseRef.current) return seasonBatchPromiseRef.current;
    const pendingPlayers = players.filter(
      (player) => !loadedSeasonIdsRef.current.has(String(player.playerId)),
    );
    if (!pendingPlayers.length) return;
    const pendingIds = pendingPlayers.map((player) => String(player.playerId));
    setSeasonLoading((current) => ({
      ...current,
      ...Object.fromEntries(pendingIds.map((id) => [id, true])),
    }));
    setSeasonError((current) => ({
      ...current,
      ...Object.fromEntries(pendingIds.map((id) => [id, null])),
    }));

    const request = (async () => {
      try {
        const skaterIds = pendingPlayers
          .filter((player) => !isGoaliePlayer(player))
          .map((player) => Number(player.playerId));
        const goalieIds = pendingPlayers
          .filter(isGoaliePlayer)
          .map((player) => Number(player.playerId));
        const [skaterRows, goalieRows] = await Promise.all([
          fetchAllSupabaseFilterChunks<any, number>(skaterIds, (chunk, range) =>
            supabase
              .from("wgo_skater_stats_totals")
              .select(
                "player_id, season, games_played, goals, assists, points, shots, hits, blocked_shots, pp_points, toi_per_game, plus_minus, shooting_percentage, gw_goals",
              )
              .in("player_id", chunk)
              .order("player_id", { ascending: true })
              .order("season", { ascending: false })
              .range(range.from, range.to),
          ),
          fetchAllSupabaseFilterChunks<any, number>(goalieIds, (chunk, range) =>
            supabase
              .from("wgo_goalie_stats_totals")
              .select(
                "goalie_id, season_id, games_played, wins, losses, ot_losses, goals_against_avg, save_pct, shutouts, saves",
              )
              .in("goalie_id", chunk)
              .order("goalie_id", { ascending: true })
              .order("season_id", { ascending: false })
              .range(range.from, range.to),
          ),
        ]);
        const latestSkaters = selectLatestSeasonRows(
          skaterRows,
          "player_id",
          "season",
          projectionSeasonId,
        );
        const latestGoalies = selectLatestSeasonRows(
          goalieRows,
          "goalie_id",
          "season_id",
          projectionSeasonId,
        );
        setSeasonTotals((current) => {
          const next = { ...current };
          for (const player of pendingPlayers) {
            const id = String(player.playerId);
            const row = isGoaliePlayer(player)
              ? latestGoalies.get(id)
              : latestSkaters.get(id);
            next[id] = row
              ? {
                  type: isGoaliePlayer(player) ? "goalie" : "skater",
                  seasonLabel: formatSeasonLabel(
                    isGoaliePlayer(player) ? row.season_id : row.season,
                  ),
                  data: row,
                }
              : null;
            loadedSeasonIdsRef.current.add(id);
          }
          return next;
        });
      } catch (error: any) {
        setSeasonError((current) => ({
          ...current,
          ...Object.fromEntries(
            pendingIds.map((id) => [
              id,
              error?.message || "Failed to load prior-season totals",
            ]),
          ),
        }));
      } finally {
        setSeasonLoading((current) => ({
          ...current,
          ...Object.fromEntries(pendingIds.map((id) => [id, false])),
        }));
        seasonBatchPromiseRef.current = null;
      }
    })();
    seasonBatchPromiseRef.current = request;
    return request;
  };

  const toggleExpand = async (player: ProcessedPlayer) => {
    const id = String(player.playerId);
    setExpanded((m) => ({ ...m, [id]: !m[id] }));
    const next = !expanded[id];
    if (next && seasonTotals[id] === undefined) {
      await fetchLastSeasonTotalsBatch();
    }
  };

  // Load persisted bandScope on mount
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const saved = window.localStorage.getItem("projections.bandScope");
      if (saved === "overall" || saved === "position") {
        setBandScope(saved);
      }
      // Load position filter
      const savedPos = window.localStorage.getItem(
        "projections.positionFilter",
      );
      if (savedPos) setPositionFilter(savedPos);
      // Load sort
      const allowedSort: string[] = [
        "fullName",
        "displayPosition",
        "displayTeam",
        "yahooAvgPick",
        "fantasyPoints",
        "score",
        "vorp",
        "vona",
        "vbd",
        "valueDelta",
        "risk",
      ];
      const savedSortField = window.localStorage.getItem(
        "projections.sortField",
      );
      if (savedSortField && allowedSort.includes(savedSortField)) {
        setSortField(savedSortField as SortableField);
      }
      const savedSortDir = window.localStorage.getItem(
        "projections.sortDirection",
      );
      if (savedSortDir === "asc" || savedSortDir === "desc") {
        setSortDirection(savedSortDir);
      }
    } catch {}
  }, []);

  // Persist bandScope on change
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem("projections.bandScope", bandScope);
    } catch {}
  }, [bandScope]);

  // Persist hide drafted on change
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(
        "projections.hideDrafted",
        String(hideDrafted),
      );
    } catch {}
  }, [hideDrafted]);

  // Persist position filter
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem("projections.positionFilter", positionFilter);
    } catch {}
  }, [positionFilter]);

  // Persist sort prefs
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem("projections.sortField", String(sortField));
      window.localStorage.setItem(
        "projections.sortDirection",
        String(sortDirection),
      );
    } catch {}
  }, [sortField, sortDirection]);

  // Load/persist stat sort key
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const savedStatKey = window.localStorage.getItem(
        "projections.statSortKey",
      );
      if (savedStatKey) setStatSortKey(savedStatKey);
    } catch {}
  }, []);
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      if (!statSortKey)
        window.localStorage.removeItem("projections.statSortKey");
      else window.localStorage.setItem("projections.statSortKey", statSortKey);
    } catch {}
  }, [statSortKey]);

  useEffect(() => {
    // Exit stat sort when leaving stat columns mode
    if (!statColumnsMode && statSortKey) setStatSortKey("");
  }, [statColumnsMode, statSortKey]);

  useEffect(() => {
    const id = setTimeout(() => setDebouncedSearchTerm(searchTerm), 150);
    return () => clearTimeout(id);
  }, [searchTerm]);

  // drafted player ID set for quick checks (moved before diagnostics)
  const draftedIdSet = useMemo(() => {
    const s = new Set<string>();
    draftedPlayers?.forEach((dp) => s.add(String(dp.playerId)));
    unavailablePlayerIds?.forEach((playerId) => s.add(String(playerId)));
    return s;
  }, [draftedPlayers, unavailablePlayerIds]);

  const diagnostics = useMemo(() => {
    return diagnoseProjectionVisibility({
      players,
      positionFilter: activePositionFilter,
      forwardGrouping,
      searchTerm: debouncedSearchTerm,
      hideDrafted,
      draftedIds: draftedIdSet,
      favoritesOnly,
      favoriteIds,
    });
  }, [
    players,
    activePositionFilter,
    debouncedSearchTerm,
    hideDrafted,
    draftedIdSet,
    forwardGrouping,
    favoriteIds,
    favoritesOnly,
  ]);

  // League-wide values remain raw; roster-aware ranking belongs to Draft Pro suggestions.
  const vorpMap = useMemo(() => {
    const m = new Map<
      string,
      {
        vorp: number;
        vona: number;
        vbd: number;
        bestPos?: string;
        vbdAdj: number;
        value?: number;
        unweightedValue?: number;
      }
    >();
    if (vorpMetrics) {
      vorpMetrics.forEach((metrics, id) => {
        const baseVbd = metrics.vbd;
        const vbdAdj = baseVbd;
        m.set(id, {
          vorp: metrics.vorp,
          vona: metrics.vona,
          vbd: baseVbd,
          bestPos: metrics.bestPos,
          vbdAdj,
          value: metrics.value,
          unweightedValue: metrics.unweightedValue,
        });
      });
    }
    return m;
  }, [vorpMetrics]);

  // The ADP comparison uses the complete league pool, including drafted
  // players, ranked strictly by projected fantasy points (never VORP/value or
  // a user's separate personal ranking list).
  const leagueRankByPlayerId = useMemo(() => {
    const rankByPlayerId = new Map<string, number>();
    const rankedPlayers = (allPlayers ?? players)
      .map((player, index) => ({
        player,
        index,
        points: player.fantasyPoints.projected,
      }))
      .filter((entry): entry is typeof entry & { points: number } =>
        typeof entry.points === "number" && Number.isFinite(entry.points),
      )
      .sort((a, b) => b.points - a.points || a.index - b.index);
    let previousPoints: number | null = null;
    let rank = 0;
    rankedPlayers.forEach((entry, index) => {
      if (entry.points !== previousPoints) rank = index + 1;
      rankByPlayerId.set(String(entry.player.playerId), rank);
      previousPoints = entry.points;
    });
    return rankByPlayerId;
  }, [allPlayers, players]);

  const riskMap = useMemo(() => {
    const risks = new Map<string, number>();
    for (const player of players) {
      const id = String(player.playerId);
      if (unavailablePlayerIds?.has(id) || draftedPlayers.some(pick => String(pick.playerId) === id)) continue;
      const availability = estimatePlayerAvailability(player.yahooAvgPick, selectionHorizon, riskSd);
      if (availability !== null) risks.set(id, 1 - availability);
    }
    return risks;
  }, [players, draftedPlayers, unavailablePlayerIds, selectionHorizon, riskSd]);

  // Filter and sort players
  const filteredAndSortedPlayers = useMemo(() => {
    let filtered = [...players];
    // Position filter predicate
    if (activePositionFilter !== "ALL") {
      filtered = filtered.filter((player) =>
        matchesProjectionPosition(player, activePositionFilter, forwardGrouping),
      );
    }

    // Apply search filter
    if (debouncedSearchTerm) {
      filtered = filtered.filter((player) =>
        matchesProjectionSearch(player, debouncedSearchTerm),
      );
    }

    // Apply favorites-only filter
    if (favoritesOnly) {
      filtered = filtered.filter((p) => favoriteIds.has(String(p.playerId)));
    }

    // Helper: treat ADP <= 0 as missing
    const normAdp = (v: any): number | null =>
      typeof v === "number" && Number.isFinite(v) && v > 0 ? v : null;

    // Sort players
    const queueRanks = new Map(Array.from(favoriteIds, (id, index) => [id, index]));
    filtered.sort((a, b) => {
      if (favoritesOnly) return queueRanks.get(String(a.playerId))! - queueRanks.get(String(b.playerId))!;
      let aValue: any;
      let bValue: any;

      if (!statSortKey && (sortField === "off" || sortField === "b2b")) {
        const av = scheduleMetrics?.get(String(a.playerId))?.[sortField];
        const bv = scheduleMetrics?.get(String(b.playerId))?.[sortField];
        if (av == null) return bv == null ? 0 : 1;
        if (bv == null) return -1;
        return (sortDirection === "asc" ? 1 : -1) * (av - bv);
      }
      if (statSortKey) {
        const av = getProratedStat(a, statSortKey, prorate84);
        const bv = getProratedStat(b, statSortKey, prorate84);
        aValue = typeof av === "number" ? av : -Infinity;
        bValue = typeof bv === "number" ? bv : -Infinity;
      } else if (sortField === "fantasyPoints") {
        const aMetrics = vorpMap.get(String(a.playerId));
        const bMetrics = vorpMap.get(String(b.playerId));
        aValue = aMetrics?.unweightedValue ?? aMetrics?.value ?? a.fantasyPoints.projected;
        bValue = bMetrics?.unweightedValue ?? bMetrics?.value ?? b.fantasyPoints.projected;
      } else if (sortField === "yahooAvgPick") {
        const aAdp = normAdp(a.yahooAvgPick);
        const bAdp = normAdp(b.yahooAvgPick);
        // Place missing ADP at bottom for asc; at top for desc
        if (aAdp == null && bAdp == null) {
          // Tie-breakers for missing ADP: project FP desc, then name asc
          const aFp = a.fantasyPoints.projected ?? -Infinity;
          const bFp = b.fantasyPoints.projected ?? -Infinity;
          if (aFp !== bFp) return bFp - aFp;
          const aName = a.fullName || "";
          const bName = b.fullName || "";
          return aName.localeCompare(bName);
        }
        if (aAdp == null) return sortDirection === "asc" ? 1 : -1;
        if (bAdp == null) return sortDirection === "asc" ? -1 : 1;
        return sortDirection === "asc" ? aAdp - bAdp : bAdp - aAdp;
      } else if (sortField === "score") {
        aValue = vorpMap.get(String(a.playerId))?.value ?? 0;
        bValue = vorpMap.get(String(b.playerId))?.value ?? 0;
      } else if (sortField === "vorp") {
        aValue = vorpMap.get(String(a.playerId))?.vorp ?? 0;
        bValue = vorpMap.get(String(b.playerId))?.vorp ?? 0;
      } else if (sortField === "vona") {
        aValue = vorpMap.get(String(a.playerId))?.vona ?? 0;
        bValue = vorpMap.get(String(b.playerId))?.vona ?? 0;
      } else if (sortField === "vbd") {
        const aM = vorpMap.get(String(a.playerId));
        const bM = vorpMap.get(String(b.playerId));
        aValue = aM?.vbd ?? 0;
        bValue = bM?.vbd ?? 0;
      } else if (sortField === "valueDelta") {
        const aRank = leagueRankByPlayerId.get(String(a.playerId));
        const bRank = leagueRankByPlayerId.get(String(b.playerId));
        aValue = typeof a.yahooAvgPick === "number" && a.yahooAvgPick > 0 && aRank != null
          ? a.yahooAvgPick - aRank
          : undefined;
        bValue = typeof b.yahooAvgPick === "number" && b.yahooAvgPick > 0 && bRank != null
          ? b.yahooAvgPick - bRank
          : undefined;
      } else if (sortField === "risk") {
        aValue = riskMap.has(String(a.playerId)) ? 1 - riskMap.get(String(a.playerId))! : undefined;
        bValue = riskMap.has(String(b.playerId)) ? 1 - riskMap.get(String(b.playerId))! : undefined;
      } else {
        if (sortField === "displayPosition") {
          aValue = getDisplayPos(a);
          bValue = getDisplayPos(b);
        } else {
          aValue = (a as any)[sortField];
          bValue = (b as any)[sortField]; // fix: use 'b'
        }
      }

      // Handle null/undefined
      if (aValue == null && bValue == null) return 0;
      if (aValue == null) return sortDirection === "asc" ? 1 : -1;
      if (bValue == null) return sortDirection === "asc" ? -1 : 1;

      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortDirection === "asc"
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      if (typeof aValue === "number" && typeof bValue === "number") {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
      }

      return 0;
    });

    return filtered;
  }, [
    players,
    scheduleMetrics,
    activePositionFilter,
    debouncedSearchTerm,
    sortField,
    sortDirection,
    vorpMap,
    riskMap,
    statSortKey,
    prorate84,
    favoritesOnly,
    favoriteIds,
    getDisplayPos,
    forwardGrouping,
    leagueRankByPlayerId,
  ]);

  // Helpers for percentile calculations
  const getPrimaryPos = useCallback(
    (p: ProcessedPlayer, bestPos?: string): string => {
      if (bandScope === "overall") return "ALL";
      if (bestPos) return bestPos;
      const first = getDisplayPos(p)?.split(",")[0]?.trim();
      return first || "ALL";
    },
    [bandScope, getDisplayPos],
  );

  const percentileBands = useMemo(() => {
    // Consider only players left in the list
    const eligible = filteredAndSortedPlayers.filter(
      (p) =>
        // Exclude already drafted from banding; bands represent remaining pool
        !draftedIdSet.has(String(p.playerId)),
    );

    // Group values by scope key (ALL or position)
    const groups: Record<string, { vbdVals: number[]; valVals: number[] }> = {};
    const pushVal = (key: string, vbd?: number | null, val?: number | null) => {
      if (!groups[key]) groups[key] = { vbdVals: [], valVals: [] };
      if (typeof vbd === "number") groups[key].vbdVals.push(vbd);
      if (typeof val === "number") groups[key].valVals.push(val);
    };

    eligible.forEach((p) => {
      const key = String(p.playerId);
      const m = vorpMap.get(key);
      const vbd = m?.vbd;
      const fpOrScore = m?.value ?? p.fantasyPoints.projected;
      const scopeKey = getPrimaryPos(p, m?.bestPos);
      pushVal(scopeKey, vbd, fpOrScore);
    });

    // Sort arrays ascending for percentile rank
    Object.values(groups).forEach((g) => {
      g.vbdVals.sort((a, b) => a - b);
      g.valVals.sort((a, b) => a - b);
    });

    const rank = (val: number, arr: number[]): number | null => {
      const n = arr.length;
      if (n < 2) return null;
      // position of last <= val
      let idx = 0;
      for (let i = 0; i < n; i++) {
        if (val >= arr[i]) idx = i;
        else break;
      }
      return n > 1 ? idx / (n - 1) : 0;
    };

    const toBand = (
      pct: number | null,
    ): "valueSuccess" | "valueWarning" | "valueDanger" | null => {
      if (pct == null) return null;
      // Map deciles to 3 colors: bottom 0-30%=danger, 30-70%=warning, 70-100%=success
      if (pct >= 0.7) return "valueSuccess";
      if (pct >= 0.3) return "valueWarning";
      return "valueDanger";
    };

    const vbdBandById = new Map<string, string | null>();
    const valBandById = new Map<string, string | null>();

    eligible.forEach((p) => {
      const id = String(p.playerId);
      const m = vorpMap.get(id);
      const scopeKey = getPrimaryPos(p, m?.bestPos);
      const vbd = m?.vbd;
      const fpOrScore = m?.value ?? p.fantasyPoints.projected;
      const g = groups[scopeKey];
      if (g) {
        const vbdPct = typeof vbd === "number" ? rank(vbd, g.vbdVals) : null;
        const valPct =
          typeof fpOrScore === "number" ? rank(fpOrScore, g.valVals) : null;
        vbdBandById.set(id, toBand(vbdPct));
        valBandById.set(id, toBand(valPct));
      } else {
        vbdBandById.set(id, null);
        valBandById.set(id, null);
      }
    });

    return { vbdBandById, valBandById };
  }, [
    filteredAndSortedPlayers,
    draftedIdSet,
    getPrimaryPos,
    vorpMap,
  ]);

  const offNightRankById = useMemo(() => {
    const ranked = filteredAndSortedPlayers
      .map((player) => ({
        id: String(player.playerId),
        total: scheduleMetrics?.get(String(player.playerId))?.off,
      }))
      .filter((entry): entry is { id: string; total: number } =>
        typeof entry.total === "number" && Number.isFinite(entry.total),
      )
      .sort((a, b) => b.total - a.total);
    const result = new Map<string, { color: string; quartile: number }>();

    for (let start = 0; start < ranked.length;) {
      let end = start;
      while (end + 1 < ranked.length && ranked[end + 1].total === ranked[start].total) {
        end += 1;
      }
      const rankPercentile = ranked.length === 1
        ? 0
        : ((start + end) / 2) / (ranked.length - 1);
      const rankStyle = {
        color: getOffNightRankColor(rankPercentile),
        quartile: Math.min(4, Math.floor(rankPercentile * 4) + 1),
      };
      for (let index = start; index <= end; index += 1) {
        result.set(ranked[index].id, rankStyle);
      }
      start = end + 1;
    }

    return result;
  }, [filteredAndSortedPlayers, scheduleMetrics]);

  const handleSort = (field: SortableField) => {
    if (statSortKey) setStatSortKey("");
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection(
        field === "vorp" ||
          field === "fantasyPoints" ||
          field === "vona" ||
          field === "vbd" ||
          field === "risk"
          ? "desc"
          : "asc",
      );
    }
  };

  // Cross-check helper: fetch unique player_ids from all projection sources and compare to allPlayers
  const runCrosscheck = async () => {
    setCrosscheckRunning(true);
    setCrosscheckError(null);
    setCrosscheckMissing([]);
    try {
      // Build set of player_ids present in UI pool (include drafted via allPlayers when provided)
      const pool =
        (allPlayers && allPlayers.length ? allPlayers : players) || [];
      const uiIds = new Set<string>(pool.map((p) => String(p.playerId)));

      // Import config dynamically
      const { PROJECTION_SOURCES_CONFIG } =
        await import("lib/projectionsConfig/projectionSourcesConfig");

      const out = await findMissingProjectionPlayers(
        PROJECTION_SOURCES_CONFIG,
        uiIds,
        async ({ tableName, selectColumns, idKey, from, to }) => {
          const { data, error } = await supabase
            .from(tableName as any)
            .select(selectColumns)
            .not(idKey, "is", null)
            .order(idKey, { ascending: true })
            .range(from, to);
          return {
            data: (data ?? []) as unknown as Record<string, unknown>[],
            error,
          };
        },
      );
      setCrosscheckMissing(out);
    } catch (e: any) {
      setCrosscheckError(e?.message || "Cross-check failed");
    } finally {
      setCrosscheckRunning(false);
    }
  };

  const handleDraftClick = (playerId: number) => {
    if (!canDraft) return;
    onDraftPlayer(String(playerId));
  };

  // Get unique positions for filter
  const availablePositions = useMemo(() => {
    const positions = new Set<string>();
    players.forEach((player) => {
      const disp = getDisplayPos(player);
      if (disp) {
        disp.split(",").forEach((pos) => {
          positions.add(pos.trim());
        });
      }
    });
    return Array.from(positions).sort();
  }, [getDisplayPos, players]);

  const getAriaSort = (
    field: SortableField,
  ): "none" | "ascending" | "descending" => {
    if (statSortKey || sortField !== field) return "none";
    return sortDirection === "asc" ? "ascending" : "descending";
  };

  useEffect(() => {
    setPageIndex(0);
  }, [debouncedSearchTerm, positionFilter, favoritesOnly, hideDrafted, pageSize]);
  const orderedPlayers = hideDrafted
    ? filteredAndSortedPlayers.filter((player) => !draftedIdSet.has(String(player.playerId)))
    : [...filteredAndSortedPlayers.filter((player) => !draftedIdSet.has(String(player.playerId))), ...filteredAndSortedPlayers.filter((player) => draftedIdSet.has(String(player.playerId)))];
  const pageCount = Math.max(1, Math.ceil(orderedPlayers.length / pageSize));
  const currentPage = Math.min(pageIndex, pageCount - 1);
  const displayPlayers = orderedPlayers.slice(currentPage * pageSize, (currentPage + 1) * pageSize);

  if (isLoading) {
    return (
      <div className={styles.projectionsContainer}>
        <div className={styles.controlsBar}>
          <h2 className={styles.panelTitle}>
            Available <span className={styles.panelTitleAccent}>Players</span>
          </h2>
        </div>
        <div className={styles.loadingState} role="status">
          <div className={styles.loadingSpinner} aria-hidden="true"></div>
          <p>Loading player projections…</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.projectionsContainer}>
        <div className={styles.controlsBar}>
          <h2 className={styles.panelTitle}>
            Available <span className={styles.panelTitleAccent}>Players</span>
          </h2>
        </div>
        <div className={styles.errorState} role="alert">
          <p>Unable to load projections.</p>
          <p>{error}</p>
          <p>Refresh data to try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`${styles.projectionsContainer} ${controls.scope}`}>
      {/* Primary Controls Bar */}
      <div className={styles.controlsBar}>
        <div className={styles.controlsBarTitle}>
          <h2 className={styles.panelTitle} title="Available Players">
            Available <span className={styles.panelTitleAccent}>Players</span>
          </h2>
          <details className={styles.tableTools}>
            <summary data-control-size="icon" aria-label="Player table options" title="Player table options">⋯</summary>
            <div className={styles.settingsAndTooltips}>
            {/* Full-season Prorate Toggle */}
            <div
              className={styles.stackedControl}
              style={{ alignItems: "flex-end" }}
            >
              <span className={styles.controlLabelMini}>
                {NHL_REGULAR_SEASON_GAMES}G Prorate
              </span>
              <div className={styles.toggleButtonsGroup}>
                <button
                  type="button"
                  className={`${styles.controlToggleBtn} ${prorate84 ? styles.controlToggleBtnActive : ""}`}
                  onClick={() => {
                    setProrate84((v) => {
                      const next = !v;
                      try {
                        if (typeof window !== "undefined") {
                          window.localStorage.setItem(
                            "projections.prorate84",
                            String(next),
                          );
                          window.dispatchEvent(
                            new CustomEvent("projections:prorate84", {
                              detail: { value: next },
                            }),
                          );
                        }
                      } catch {}
                      return next;
                    });
                  }}
                  aria-pressed={prorate84}
                  aria-label={`Toggle ${NHL_REGULAR_SEASON_GAMES}-game prorated skater stats`}
                  title={`Display skater counting stats and projected fantasy points on an ${NHL_REGULAR_SEASON_GAMES}-game pace (asterisk indicates a prorated stat)`}
                >
                  {prorate84 ? "On" : "Off"}
                </button>
              </div>
            </div>
            <div
              className={styles.stackedControl}
              style={{ alignItems: "flex-end" }}
            >
              <span className={styles.controlLabelMini}>Settings</span>
              <div className={styles.toggleButtonsGroup}>
                <button
                  type="button"
                  className={`${styles.controlToggleBtn} ${settingsOpen ? styles.controlToggleBtnActive : ""}`}
                  onClick={() => setSettingsOpen(true)}
                  aria-haspopup="dialog"
                  aria-expanded={settingsOpen}
                  aria-controls="draft-settings-drawer"
                  aria-label="Open settings drawer"
                >
                  Open
                </button>
              </div>
            </div>
            <div
              className={styles.stackedControl}
              style={{ width: "auto", alignItems: "flex-end" }}
            >
              <div className={styles.infoTooltip}>
                <button
                  type="button"
                  className={`${styles.infoButton} ${dataNotices.length > 0 ? styles.infoButtonNotice : ""}`}
                  data-control-size="icon"
                  aria-describedby="projections-help"
                  aria-label={
                    dataNotices.length > 0 ? "Data notices and legend" : "Legend"
                  }
                >
                  i
                </button>
                <div
                  id="projections-help"
                  role="tooltip"
                  className={styles.tooltipContent}
                >
                  {dataNotices.length > 0 && (
                    <div className={styles.dataNotice}>
                      <div className={styles.tooltipTitle}>Data notices</div>
                      {dataNotices.map((notice) => (
                        <p key={notice}>{notice}</p>
                      ))}
                    </div>
                  )}
                  <div className={styles.tooltipTitle}>Legend</div>
                  <div className={styles.tooltipBody}>
                    <ul>
                      {leagueType === "categories" && (
                        <li>
                          <strong>Score</strong>: percentile-weighted composite
                          (0–100) across your selected categories, weighted by
                          your category weights and by metric scarcity.
                        </li>
                      )}
                      <li>VORP: Value over replacement.</li>
                      <li>VONA: Over next available.</li>
                      <li>VBD: Blended draft value.</li>
                      <li>Bands: Percentile tiers.</li>
                      <li>AVL%: Likely available at your next pick.</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </details>
        <div className={styles.primaryControls}>
          <div className={`${styles.stackedControl} ${styles.searchStack}`}>
            <span className={styles.controlLabelMini}>Search</span>
            <input
              type="text"
              placeholder="Search players..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={styles.searchInput}
              aria-label="Search players"
            />
          </div>
          <div className={styles.stackedControlsRow}>
            <div className={`${styles.stackedControl} ${styles.compactPrimaryControl}`}>
              <span className={styles.controlLabelMini}>Position</span>
              <select
                id="position-filter"
                value={activePositionFilter}
                onChange={(e) => setPositionFilter(e.target.value)}
                className={styles.inlineSelect}
                aria-label="Position filter"
              >
                <option value="ALL">ALL</option>
                <option value="SKATER">Skater</option>
                <option value="FORWARDS">Forwards</option>
                {availablePositions.map((position) => (
                  <option key={position} value={position}>
                    {position}
                  </option>
                ))}
                {draftProEligible && (
                  <optgroup label={canFilterMultiplePositions ? "Draft Pro · Eligibility" : "Connect a Fantrax league for dual eligibility"} disabled={!canFilterMultiplePositions}>
                    <option value="ELIGIBLE_DUAL">Dual eligible</option>
                    <option value="ELIGIBLE_C_LW">C/LW</option>
                    <option value="ELIGIBLE_C_RW">C/RW</option>
                    <option value="ELIGIBLE_LW_RW">LW/RW</option>
                    <option value="ELIGIBLE_TRI">Tri eligible · C/LW/RW</option>
                  </optgroup>
                )}
              </select>
            </div>
            <div className={`${styles.stackedControl} ${styles.compactPrimaryControl}`}>
              <span className={styles.controlLabelMini}>Favorites</span>
              <div className={styles.toggleButtonsGroup}>
                <button
                  type="button"
                  className={`${styles.controlToggleBtn} ${
                    favoritesOnly ? styles.controlToggleBtnActive : ""
                  }`}
                  onClick={() => setFavoritesOnly((v) => !v)}
                  aria-pressed={favoritesOnly}
                  aria-label="Toggle favorites only"
                >
                  Only
                </button>
              </div>
            </div>
            <div className={`${styles.stackedControl} ${styles.compactPrimaryControl}`}>
              <span className={styles.controlLabelMini}>View</span>
              <div className={styles.toggleButtonsGroup}>
                <button
                  type="button"
                  className={`${styles.controlToggleBtn} ${
                    statColumnsMode ? styles.controlToggleBtnActive : ""
                  }`}
                  onClick={() => setStatColumnsMode((v) => !v)}
                  aria-pressed={statColumnsMode}
                  aria-label="Toggle stat columns"
                  title={
                    statColumnsMode
                      ? "Showing stats with VORP, VONA, and VBD. Switch to the compact metrics view."
                      : "Showing projected fantasy points, VORP, VONA, and VBD. Switch to stats while keeping VORP, VONA, and VBD."
                  }
                >
                  {statColumnsMode ? "Stats" : "Metrics"}
                </button>
              </div>
            </div>
            <div className={`${styles.stackedControl} ${styles.compactPrimaryControl}`}>
              <span className={styles.controlLabelMini}>Drafted</span>
              <div className={styles.toggleButtonsGroup}>
                <button
                  type="button"
                  className={`${styles.controlToggleBtn} ${
                    hideDrafted ? styles.controlToggleBtnActive : ""
                  }`}
                  onClick={() => setHideDrafted((v) => !v)}
                  aria-pressed={hideDrafted}
                  aria-label="Toggle hide drafted"
                >
                  Hide
                </button>
              </div>
            </div>
            <div className={styles.stackedControl}>
              <span className={styles.controlLabelMini}>
                Compare ({selectedIds.size})
              </span>
              <div className={styles.toggleButtonsGroup}>
                <button
                  type="button"
                  className={`${styles.controlToggleBtn} ${styles.compareLaunchButton}`}
                  onClick={() => setCompareOpen(true)}
                  disabled={selectedIds.size < 2}
                  aria-label="Open compare players"
                  title={
                    selectedIds.size < 2
                      ? "Select 2 players in the table"
                      : "Compare selected players"
                  }
                >
                  {`Compare`}
                </button>
                {onOpenRosterImpact && (
                  <button
                    type="button"
                    className={styles.controlToggleBtn}
                    onClick={() => onOpenRosterImpact(Array.from(selectedIds))}
                    aria-label="Open roster impact scenarios"
                    title={selectedIds.size === 2
                      ? "Compare the selected players against your current roster"
                      : "Open saved roster-impact scenarios; select two available players to compare"}
                  >
                    Roster impact
                  </button>
                )}
                {selectedIds.size > 0 && (
                  <button
                    type="button"
                    className={styles.controlToggleBtn}
                    onClick={resetComparison}
                    aria-label="Clear comparison selection"
                  >
                    Clear
                  </button>
                )}
              </div>
              {compareSelectionMessage && (
                <span role="status" className={styles.controlHint}>
                  {compareSelectionMessage}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      </div>

      {/* Mini Run Forecast Row */}
      {expectedRuns && (
        <div className={styles.miniRunForecast}>
          <div className={styles.miniRunDescriptor}>
            Projected Next {expectedRuns.N} Picks by Position
          </div>
          <div className={styles.miniRunItems}>
            {" "}
            {/* new wrapper */}
            {getRosterPositions(forwardGrouping).map((pos) => {
              const val = Math.max(
                0,
                Math.round((expectedRuns.byPos?.[pos] ?? 0) * 10) / 10,
              );
              const max = Math.max(1, expectedRuns.N || 1);
              const pct = Math.min(100, Math.round((val / max) * 100));
              return (
                <div
                  key={pos}
                  className={styles.miniRunItem}
                  title={`${pos} ${val} / ${expectedRuns.N}`}
                >
                  <span className={styles.miniRunLabel}>{pos}</span>
                  <span className={styles.miniRunBar}>
                    <span
                      className={styles.miniRunFill}
                      style={{ width: pct + "%" }}
                    />
                  </span>
                  <span className={styles.miniRunVal}>{val.toFixed(1)}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Settings Drawer Overlay */}
      {settingsOpen && (
        <div
          className={styles.drawerOverlay}
          role="presentation"
          onClick={() => setSettingsOpen(false)}
        />
      )}
      {settingsOpen && (
        <aside
          id="draft-settings-drawer"
          className={styles.settingsDrawer}
          role="dialog"
          aria-label="Draft advanced settings"
        >
          <div className={styles.drawerHeader}>
            <h3>Advanced Settings</h3>
            <button
              type="button"
              onClick={() => setSettingsOpen(false)}
              className={styles.drawerClose}
              data-control-size="icon"
              aria-label="Close settings"
            >
              ×
            </button>
          </div>
          <div className={styles.drawerContent}>
            <section className={styles.drawerSection}>
              <h4>Value Band Scope</h4>
              <select
                value={bandScope}
                onChange={(e) => setBandScope(e.target.value as any)}
                className={styles.drawerSelect}
                aria-label="Value band scope"
              >
                <option value="position">Per Position</option>
                <option value="overall">Overall</option>
              </select>
            </section>
            <section className={styles.drawerSection}>
              <h4>VORP Baseline</h4>
              <select
                value={baselineMode}
                onChange={(e) =>
                  onBaselineModeChange &&
                  onBaselineModeChange(e.target.value as any)
                }
                className={styles.drawerSelect}
                aria-label="VORP baseline mode"
              >
                <option value="remaining">Remaining (AVAIL)</option>
                <option value="full">Full Pool (ALL)</option>
              </select>
            </section>
            <section className={styles.drawerSection}>
              <h4>Risk Model</h4>
              <div className={styles.sliderRow}>
                <label htmlFor="risk-sd" className={styles.sliderLabel}>
                  SD (picks): {riskSd}
                </label>
                <input
                  id="risk-sd"
                  type="range"
                  min={2}
                  max={40}
                  step={1}
                  value={riskSd}
                  onChange={(e) => onRiskSdChange?.(parseInt(e.target.value, 10))}
                  className={styles.rangeInput}
                />
              </div>
            </section>
            <section className={styles.drawerSection}>
              <h4>Diagnostics</h4>
              <label className={styles.toggle}>
                <input
                  type="checkbox"
                  className={styles.toggleInput}
                  checked={showDiagnostics}
                  onChange={(e) => setShowDiagnostics(e.target.checked)}
                  aria-label="Show diagnostics"
                />
                <span className={styles.toggleText}>Show Excluded</span>
              </label>
              <div className={styles.drawerNote} style={{ marginTop: 8 }}>
                <button
                  onClick={runCrosscheck}
                  disabled={crosscheckRunning}
                  className={styles.collapseButton}
                  title="Cross-check source coverage"
                  aria-busy={crosscheckRunning}
                >
                  {crosscheckRunning ? "Checking…" : "Cross-check Sources"}
                </button>
                {crosscheckError && (
                  <div className={styles.errorText} style={{ marginTop: 6 }}>
                    {crosscheckError}
                  </div>
                )}
                {crosscheckMissing.length > 0 && (
                  <div style={{ marginTop: 6 }}>
                    <strong>Missing from UI but present in sources:</strong>
                    <div style={{ fontSize: 12, marginTop: 4 }}>
                      {crosscheckMissing.slice(0, 25).map((m) => (
                        <div key={m.player_id}>
                          {m.name || "Unknown"} (ID {m.player_id}) —{" "}
                          {m.sourceIds.join(", ")}
                        </div>
                      ))}
                      {crosscheckMissing.length > 25 && (
                        <div>…and {crosscheckMissing.length - 25} more</div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </section>
            {replacementByPos && (
              <section className={styles.drawerSection}>
                <h4>Replacement Baselines</h4>
                <ul className={styles.baselineList}>
                  {Object.entries(replacementByPos).map(([pos, vals]) => (
                    <li key={pos}>
                      <strong>{pos}</strong>: VORP {vals.vorp.toFixed(1)} | VOLS{" "}
                      {vals.vols.toFixed(1)}
                    </li>
                  ))}
                </ul>
              </section>
            )}
            <section className={styles.drawerSection}>
              <h4>Value Colors</h4>
              <p className={styles.drawerNote}>
                Green = top 30%, Yellow = middle 40%, Red = bottom 30% within
                selected scope.
              </p>
            </section>
          </div>
        </aside>
      )}

      {/* Players Table */}
      <div className={styles.tableContainer}>
        <table
          className={`${styles.playersTable} ${statColumnsMode ? styles.statColumnsTable : ""}`}
          style={{
            "--distributed-column-count": Math.max(
              statColumns.length + 6,
              1,
            ),
          } as React.CSSProperties}
        >
          <colgroup>
            <col className={styles.colFav} />
            <col className={styles.colName} />
            <col className={styles.colPos} />
            <col className={styles.colTeam} />
            <col className={styles.colFP} />
            {!statColumnsMode && leagueType === "categories" && (
              <col className={styles.colScore} />
            )}
            {statColumnsMode && (
              <>
                {statColumns.map((k) => (
                  <col key={`col-${k}`} className={styles.colStat} />
                ))}
              </>
            )}
            <col className={styles.colVorp} />
            <col className={styles.colVorp} />
            <col className={styles.colVorp} />
            <col className={styles.colValueDelta} />
            <col className={styles.colAdp} />
            <col className={styles.colSchedule} />
            <col className={styles.colSchedule} />
            <col className={styles.colNextPick} />
            <col className={styles.colAction} />
            <col className={styles.colCompare} />
          </colgroup>
          <thead>
            <tr>
              <th className={styles.colFav} scope="col" title="Favorite">
                Fav
              </th>
              <th
                className={`${styles.sortableHeader} ${styles.colName}`}
                aria-sort={getAriaSort("fullName")}
                scope="col"
              >
                <button
                  type="button"
                  className={styles.sortButton}
                  onClick={() => handleSort("fullName")}
                >
                  Player
                </button>
              </th>
              <th
                className={`${styles.sortableHeader} ${styles.colPos}`}
                aria-sort={getAriaSort("displayPosition")}
                scope="col"
              >
                <button
                  type="button"
                  className={styles.sortButton}
                  onClick={() => handleSort("displayPosition")}
                >
                  Pos
                </button>
              </th>
              <th
                className={`${styles.sortableHeader} ${styles.colTeam}`}
                aria-sort={getAriaSort("displayTeam")}
                scope="col"
              >
                <button
                  type="button"
                  className={styles.sortButton}
                  onClick={() => handleSort("displayTeam")}
                >
                  Team
                </button>
              </th>
              <th
                className={`${styles.sortableHeader} ${styles.colFP}`}
                aria-sort={getAriaSort("fantasyPoints")}
                scope="col"
              >
                <button
                  type="button"
                  className={`${styles.sortButton} ${styles.stackedSortButton}`}
                  onClick={() =>
                    handleSort("fantasyPoints")
                  }
                  title="Projected Fantasy Points"
                >
                  <span className={styles.stackedSortLabel}><span>Proj</span><span>FPts</span></span>
                </button>
              </th>
              {!statColumnsMode ? (
                <>
                  {leagueType === "categories" && (
                    <th
                      className={`${styles.sortableHeader} ${styles.colScore}`}
                      aria-sort={getAriaSort("score")}
                      scope="col"
                    >
                      <button type="button" className={styles.sortButton} onClick={() => handleSort("score")} title="Percentile-weighted category score">
                        Score
                      </button>
                    </th>
                  )}
                  <th
                    className={`${styles.sortableHeader} ${styles.colVorp}`}
                    aria-sort={getAriaSort("vorp")}
                    scope="col"
                  >
                    <button
                      type="button"
                      className={styles.sortButton}
                      onClick={() => handleSort("vorp")}
                      title="Value Over Replacement Player"
                    >
                      VORP
                    </button>
                  </th>
                  <th
                    className={`${styles.sortableHeader} ${styles.colVorp}`}
                    aria-sort={getAriaSort("vona")}
                    scope="col"
                  >
                    <button
                      type="button"
                      className={styles.sortButton}
                      onClick={() => handleSort("vona")}
                      title="Value Over Next Available"
                    >
                      VONA
                    </button>
                  </th>
                  <th
                    className={`${styles.sortableHeader} ${styles.colVorp}`}
                    aria-sort={getAriaSort("vbd")}
                    scope="col"
                  >
                    <button
                      type="button"
                      className={styles.sortButton}
                      onClick={() => handleSort("vbd")}
                      title="Value Based Drafting (blend)"
                    >
                      VBD
                    </button>
                  </th>
                  <th
                    className={`${styles.sortableHeader} ${styles.colValueDelta}`}
                    aria-sort={getAriaSort("valueDelta")}
                    scope="col"
                  >
                    <button type="button" className={`${styles.sortButton} ${styles.stackedSortButton}`} onClick={() => handleSort("valueDelta")} title={`${adpSource === "fantrax" ? "Fantrax" : "Yahoo"} ADP minus full-pool scoring rank; positive values indicate draft value`}>
                      <span className={styles.stackedSortLabel}><span>Value</span><span>Δ</span></span>
                    </button>
                  </th>
                </>
              ) : (
                <>
                  {statColumns.map((key) => (
                    <th
                      key={`h-${key}`}
                      className={`${styles.sortableHeader} ${styles.statHeader}`}
                      aria-sort={
                        statSortKey === key
                          ? sortDirection === "asc"
                            ? "ascending"
                            : "descending"
                          : "none"
                      }
                      scope="col"
                    >
                      <button
                        type="button"
                        className={styles.sortButton}
                        onClick={() => handleStatHeaderSort(key)}
                        title={`Projected ${statDefByKey.get(key)?.displayName || key}`}
                      >
                        {statDefByKey.get(key)?.displayName || key}
                      </button>
                    </th>
                  ))}
                  <th
                    className={`${styles.sortableHeader} ${styles.colVorp}`}
                    aria-sort={getAriaSort("vorp")}
                    scope="col"
                  >
                    <button
                      type="button"
                      className={styles.sortButton}
                      onClick={() => handleSort("vorp")}
                      title="Value Over Replacement Player"
                    >
                      VORP
                    </button>
                  </th>
                  <th
                    className={`${styles.sortableHeader} ${styles.colVorp}`}
                    aria-sort={getAriaSort("vona")}
                    scope="col"
                  >
                    <button
                      type="button"
                      className={styles.sortButton}
                      onClick={() => handleSort("vona")}
                      title="Value Over Next Available"
                    >
                      VONA
                    </button>
                  </th>
                  <th
                    className={`${styles.sortableHeader} ${styles.colVorp}`}
                    aria-sort={getAriaSort("vbd")}
                    scope="col"
                  >
                    <button
                      type="button"
                      className={styles.sortButton}
                      onClick={() => handleSort("vbd")}
                      title="Value Based Drafting (blend)"
                    >
                      VBD
                    </button>
                  </th>
                  <th
                    className={`${styles.sortableHeader} ${styles.colValueDelta}`}
                    aria-sort={getAriaSort("valueDelta")}
                    scope="col"
                  >
                    <button type="button" className={`${styles.sortButton} ${styles.stackedSortButton}`} onClick={() => handleSort("valueDelta")} title={`${adpSource === "fantrax" ? "Fantrax" : "Yahoo"} ADP minus full-pool scoring rank; positive values indicate draft value`}>
                      <span className={styles.stackedSortLabel}><span>Value</span><span>Δ</span></span>
                    </button>
                  </th>
                </>
              )}
              <th
                className={`${styles.sortableHeader} ${styles.colAdp}`}
                aria-sort={getAriaSort("yahooAvgPick")}
                scope="col"
              >
                <button
                  type="button"
                  className={styles.sortButton}
                  onClick={() => handleSort("yahooAvgPick")}
                >
                  ADP
                </button>
              </th>
              {(["off", "b2b"] as const).map((metric) => <th key={metric} scope="col" className={`${styles.sortableHeader} ${styles.colSchedule}`} aria-sort={getAriaSort(metric)}>
                <button type="button" className={styles.sortButton} onClick={() => handleSort(metric)} title={metric === "off" ? "Off-Nights: NHL opportunities on dates with at most 8 games" : "Back-to-Backs: consecutive-day NHL pairs, counted on the second day"}>{metric.toUpperCase()}</button>
              </th>)}
              <th
                className={`${styles.sortableHeader} ${styles.colNextPick}`}
                aria-sort={getAriaSort("risk")}
                scope="col"
              >
                <button
                  type="button"
                  className={styles.sortButton}
                  onClick={() => handleSort("risk")}
                  title="Probability of remaining available at your next pick (ADP-based)"
                >
                  AVL%
                </button>
              </th>
              <th className={styles.colAction} scope="col">
                Action
              </th>
              <th
                className={styles.colCompare}
                scope="col"
                title="Select players via right-side checkboxes; need 2+ to enable compare"
              >
                <span
                  aria-label="Compare column header"
                  title="Select players (checkboxes) then click Open to compare. AVL%: green high, yellow medium, red low probability of remaining available at your next pick."
                >
                  COMP.
                </span>
              </th>
            </tr>
          </thead>
          <tbody>
            {(() => {
              return displayPlayers.flatMap((player, rowIndex) => {
                const key = String(player.playerId);
                const m = vorpMap.get(key);
                const vorp = m?.vorp ?? 0;
                const vona = m?.vona ?? 0;
                const vbdBase = m?.vbd ?? 0;
                const bestPos = m?.bestPos;
                const vbdDisplay = vbdBase;
                const vbdBand = percentileBands.vbdBandById.get(key);
                const fpBand = percentileBands.valBandById.get(key);
                const vbdClasses = [styles.vorp, styles.valueNumeric];
                if (vbdBand) vbdClasses.push(styles.valueBand, styles[vbdBand]);
                const fpClasses = [styles.fantasyPoints, styles.valueNumeric];
                if (fpBand) fpClasses.push(styles.valueBand, styles[fpBand]);
                const risk = riskMap.get(key);
                const riskPct =
                  typeof risk === "number" ? Math.round((1 - risk) * 100) : null;
                const riskClass =
                  riskPct == null
                    ? undefined
                    : riskPct >= 70
                      ? styles.riskLow
                      : riskPct >= 30
                        ? styles.riskMed
                        : styles.riskHigh;
                const dust = dustInsights?.get(key);
                const metricColumnsCount = leagueType === "categories" ? 6 : 5;
                const detailColSpan =
                  1 + // favorite star
                  1 + // name
                  1 + // pos
                  1 + // team
                  (statColumnsMode
                    ? statColumns.length + 5 // FP/Score, VORP, VONA, VBD, value delta
                    : metricColumnsCount) +
                  1 + // ADP
                  2 + // OFF and B2B
                  1 + // Next Pick
                  1 + // Action
                  1; // Compare

                const mainRow = (
                  <tr
                    key={player.playerId}
                    onDragOver={
                      favoritesOnly
                        ? (event) => {
                            event.preventDefault();
                            event.dataTransfer.dropEffect = "move";
                          }
                        : undefined
                    }
                    onDrop={
                      favoritesOnly
                        ? (event) => {
                            event.preventDefault();
                            if (draggedFavorite)
                              moveFavorite(draggedFavorite, key);
                            setDraggedFavorite(null);
                          }
                        : undefined
                    }
                    data-player-id={key}
                    data-next-pick={
                      picksBeforeTurn != null &&
                      currentPage * pageSize + rowIndex === picksBeforeTurn
                    }
                    data-stripe={rowIndex % 2}
                    data-expanded={!!expanded[key]}
                    data-selected={selectedIds.has(key)}
                    className={`${styles.playerRow} ${draftedIdSet.has(key) ? styles.draftedRow : ""} ${
                      favoriteIds.has(key) ? styles.favoritedRow : ""
                    }`}
                  >
                    <td className={styles.colFav}>
                      <button
                        type="button"
                        className={`${styles.favoriteButton} ${favoriteIds.has(key) ? styles.favorited : ""}`}
                        data-control-size="icon"
                        aria-pressed={favoriteIds.has(key)}
                        onClick={() => toggleFavorite(key)}
                        aria-label={
                          favoriteIds.has(key)
                            ? `Unfavorite ${player.fullName}`
                            : `Favorite ${player.fullName}`
                        }
                        title={
                          favoriteIds.has(key)
                            ? "Unfavorite player"
                            : "Favorite player"
                        }
                      >
                        {favoriteIds.has(key) ? "★" : "☆"}
                      </button>
                    </td>
                    <td className={styles.playerName}>
                      {picksBeforeTurn != null &&
                        currentPage * pageSize + rowIndex ===
                          picksBeforeTurn && (
                          <span
                            className={styles.pickLabel}
                            title="Estimated slot in the displayed order; availability is not guaranteed"
                          >
                            Your next pick · estimate
                          </span>
                        )}
                      <div
                        className={`${styles.nameContainer} ${favoritesOnly ? styles.queueName : ""}`}
                      >
                        {favoritesOnly && (
                          <span className={styles.queueControls}>
                            <button
                              type="button"
                              draggable
                              className={styles.queueHandle}
                              aria-label={`Reorder ${player.fullName}; use arrow up or down`}
                              title="Drag to reorder; or use Up/Down arrow keys"
                              onDragStart={(event) => {
                                setDraggedFavorite(key);
                                event.dataTransfer.effectAllowed = "move";
                                event.dataTransfer.setData("text/plain", key);
                              }}
                              onDragEnd={() => setDraggedFavorite(null)}
                              onKeyDown={(event) => {
                                const delta =
                                  event.key === "ArrowUp"
                                    ? -1
                                    : event.key === "ArrowDown"
                                      ? 1
                                      : 0;
                                if (!delta) return;
                                event.preventDefault();
                                const target =
                                  favoriteOrder[
                                    favoriteOrder.indexOf(key) + delta
                                  ];
                                if (target) moveFavorite(key, target);
                              }}
                            >
                              ☰ {favoriteOrder.indexOf(key) + 1}
                            </button>
                            <button
                              type="button"
                              className={styles.queueMove}
                              aria-label={`Move ${player.fullName} up in queue`}
                              disabled={favoriteOrder.indexOf(key) === 0}
                              onClick={() =>
                                moveFavorite(
                                  key,
                                  favoriteOrder[favoriteOrder.indexOf(key) - 1]
                                )
                              }
                            >
                              ↑
                            </button>
                            <button
                              type="button"
                              className={styles.queueMove}
                              aria-label={`Move ${player.fullName} down in queue`}
                              disabled={
                                favoriteOrder.indexOf(key) ===
                                favoriteOrder.length - 1
                              }
                              onClick={() =>
                                moveFavorite(
                                  key,
                                  favoriteOrder[favoriteOrder.indexOf(key) + 1]
                                )
                              }
                            >
                              ↓
                            </button>
                          </span>
                        )}

                        <button
                          className={styles.expandToggle}
                          data-control-size="icon"
                          onClick={() => toggleExpand(player)}
                          title={
                            expanded[key]
                              ? "Hide last season"
                              : "Show last season"
                          }
                          aria-expanded={!!expanded[key]}
                          aria-label={
                            expanded[key]
                              ? `Collapse details for ${player.fullName}`
                              : `Expand details for ${player.fullName}`
                          }
                        >
                          {expanded[key] ? "−" : "+"}
                        </button>
                        <span
                          className={styles.fullName}
                          title={player.fullName}
                        >
                          {player.fullName}
                        </span>
                        {sourceRankImpacts[player.playerId] && (
                          <span
                            aria-label={`Projection source rank ${
                              sourceRankImpacts[player.playerId].delta > 0
                                ? "improved"
                                : "declined"
                            } by ${Math.abs(sourceRankImpacts[player.playerId].delta)}`}
                            title={`Projection-source change moved this player from rank ${sourceRankImpacts[player.playerId].previousRank} to ${sourceRankImpacts[player.playerId].currentRank} within the ${player.displayPosition === "G" ? "goalie" : "skater"} pool.`}
                            style={{
                              marginLeft: 6,
                              color:
                                sourceRankImpacts[player.playerId].delta > 0
                                  ? "#6ee7a8"
                                  : "#ff9a9a",
                              fontSize: 11,
                              whiteSpace: "nowrap"
                            }}
                          >
                            {sourceRankImpacts[player.playerId].delta > 0
                              ? "↑"
                              : "↓"}
                            {Math.abs(sourceRankImpacts[player.playerId].delta)}
                          </span>
                        )}
                      </div>
                      {dust && (
                        <div className={styles.dustInsight}>
                          <span
                            className={`${styles.dustBadge} ${styles[`dustRisk${dust.risk[0].toUpperCase()}${dust.risk.slice(1)}`]}`}
                            aria-label={`${player.fullName}: DUST plus ${dust.marginalDustGames}, ${dust.risk} schedule-conflict risk. ${dust.activeGamesAdded} Active Games Added across ${dust.candidateScheduledGames} scheduled games.`}
                            title={`DUST (Daily Unstartable Schedule Tax): ${dust.marginalDustGames} additional Bench Games and ${dust.activeGamesAdded} Active Games Added across ${dust.candidateScheduledGames} scheduled games (${Math.round(dust.dustRate * 100)}% DUST rate)`}
                          >
                            DUST +{dust.marginalDustGames}
                          </span>
                          {dust.alternative && (
                            <span
                              className={styles.dustAlternative}
                              title={`${dust.alternative.playerName} reduces DUST by ${dust.alternative.dustReduction} with a ${dust.alternative.valueDifference.toFixed(1)} ${leagueType === "categories" ? "score" : "projected-points"} difference.`}
                            >
                              Alt: {dust.alternative.playerName} ·{" "}
                              {dust.alternative.valueDifference >= 0
                                ? "+"
                                : "−"}
                              {Math.abs(
                                dust.alternative.valueDifference
                              ).toFixed(1)}{" "}
                              {leagueType === "categories" ? "score" : "FP"} · −
                              {dust.alternative.dustReduction} DUST
                            </span>
                          )}
                        </div>
                      )}
                    </td>
                    <td
                      className={styles.position}
                      data-label="Pos"
                      title={(() => {
                        const disp = getDisplayPos(player) || "-";
                        const elig = Array.isArray(
                          (player as any).eligiblePositions
                        )
                          ? ((player as any).eligiblePositions as string[])
                          : [];
                        return elig.length
                          ? `${disp} (Eligible: ${elig.join("/")})`
                          : disp;
                      })()}
                    >
                      {getDisplayPos(player) || "-"}
                    </td>
                    <td
                      className={styles.team}
                      data-label="Team"
                      title={player.displayTeam || undefined}
                    >
                      {canonicalScheduleTeam(player.displayTeam) || "-"}
                    </td>
                    <td
                      className={fpClasses.join(" ")}
                      data-label="Projected FPTs"
                    >
                      {typeof player.fantasyPoints.projected === "number"
                        ? player.fantasyPoints.projected.toFixed(1)
                        : "-"}
                    </td>
                    {!statColumnsMode ? (
                      <>
                        {leagueType === "categories" && (
                          <td
                            className={`${styles.score} ${styles.valueNumeric}`}
                            data-label="Score"
                          >
                            {typeof m?.value === "number"
                              ? m.value.toFixed(1)
                              : "-"}
                          </td>
                        )}
                        <td
                          className={styles.vorp}
                          data-label="VORP"
                          title={bestPos ? `Best Pos: ${bestPos}` : undefined}
                        >
                          {typeof vorp === "number" ? vorp.toFixed(1) : "-"}
                        </td>
                        <td
                          className={styles.vorp}
                          data-label="VONA"
                          title="Value Over Next Available"
                        >
                          {typeof vona === "number" ? vona.toFixed(1) : "-"}
                        </td>
                        <td
                          className={vbdClasses.join(" ")}
                          data-label="VBD"
                          title="Value Based Drafting"
                        >
                          {typeof vbdDisplay === "number"
                            ? vbdDisplay.toFixed(1)
                            : "-"}
                        </td>
                      </>
                    ) : (
                      <>
                        {isGoaliePlayer(player) &&
                        positionFilter !== "G" &&
                        statColumns.length > 0 &&
                        goalieStatColumns.length > 0 ? (
                          <td
                            className={`${styles.statCol} ${styles.inlineGoalieStatsCell}`}
                            colSpan={statColumns.length}
                            data-label="Goalie stats"
                            aria-label="Goalie projected statistics"
                          >
                            <span
                              className={styles.inlineGoalieStats}
                              style={
                                {
                                  "--goalie-stat-count":
                                    goalieStatColumns.length,
                                  "--goalie-label-width": `${Math.max(2, ...goalieStatColumns.map((key) => (statDefByKey.get(key)?.displayName || key).length))}ch`
                                } as React.CSSProperties
                              }
                            >
                              {goalieStatColumns.map((goalieKey) => {
                                const value = getProratedStat(
                                  player,
                                  goalieKey,
                                  prorate84
                                );
                                const label =
                                  statDefByKey.get(goalieKey)?.displayName ||
                                  goalieKey;
                                const formatted = formatStatValue(
                                  goalieKey,
                                  value
                                );
                                return (
                                  <span
                                    key={`goalie-${goalieKey}-${key}`}
                                    className={styles.inlineGoalieStat}
                                    title={`Projected ${label}: ${
                                      formatted === "-"
                                        ? "Not supplied"
                                        : formatted
                                    }`}
                                  >
                                    <span
                                      className={styles.inlineGoalieStatLabel}
                                    >
                                      {label}
                                    </span>
                                    <span
                                      className={styles.inlineGoalieStatValue}
                                    >
                                      {formatted}
                                    </span>
                                  </span>
                                );
                              })}
                            </span>
                          </td>
                        ) : (
                          statColumns.map((k) => {
                            const val = getProratedStat(player, k, prorate84);
                            const isProrated =
                              prorate84 && canProrateStat(player, k);
                            return (
                              <td
                                key={`c-${k}-${key}`}
                                className={styles.statCol}
                                data-label={
                                  statDefByKey.get(k)?.displayName || k
                                }
                                title={
                                  val == null
                                    ? "Not supplied"
                                    : isProrated
                                      ? `${val} (${NHL_REGULAR_SEASON_GAMES}-game pace)`
                                      : String(val)
                                }
                              >
                                {formatStatValue(k, val)}
                                {isProrated && (
                                  <sup
                                    className={styles.proratedMarker}
                                    aria-label={`${NHL_REGULAR_SEASON_GAMES}-game prorated`}
                                  >
                                    *
                                  </sup>
                                )}
                              </td>
                            );
                          })
                        )}
                        <td
                          className={styles.vorp}
                          data-label="VORP"
                          title={bestPos ? `Best Pos: ${bestPos}` : undefined}
                        >
                          {typeof vorp === "number" ? vorp.toFixed(1) : "-"}
                        </td>
                        <td
                          className={styles.vorp}
                          data-label="VONA"
                          title="Value Over Next Available"
                        >
                          {typeof vona === "number" ? vona.toFixed(1) : "-"}
                        </td>
                        <td
                          className={vbdClasses.join(" ")}
                          data-label="VBD"
                          title="Value Based Drafting"
                        >
                          {typeof vbdDisplay === "number"
                            ? vbdDisplay.toFixed(1)
                            : "-"}
                        </td>
                      </>
                    )}
                    {(() => {
                      const leagueRank = leagueRankByPlayerId.get(key);
                      const selectedAdp =
                        typeof player.yahooAvgPick === "number" &&
                        player.yahooAvgPick > 0
                          ? player.yahooAvgPick
                          : null;
                      const valueDelta =
                        selectedAdp != null && leagueRank != null
                          ? Math.round(selectedAdp - leagueRank)
                          : null;
                      return (
                        <td
                          className={`${styles.valueDelta} ${valueDelta == null ? "" : valueDelta > 0 ? styles.valueDeltaPositive : valueDelta < 0 ? styles.valueDeltaNegative : ""}`}
                          data-label="Value Δ"
                          title={
                            selectedAdp == null || leagueRank == null
                              ? `${adpSource === "fantrax" ? "Fantrax" : "Yahoo"} ADP or full-pool scoring rank is unavailable`
                              : `${adpSource === "fantrax" ? "Fantrax" : "Yahoo"} ADP ${selectedAdp.toFixed(1)} minus full-pool scoring rank ${leagueRank}`
                          }
                        >
                          {valueDelta == null
                            ? "-"
                            : `${valueDelta > 0 ? "+" : ""}${valueDelta}`}
                        </td>
                      );
                    })()}
                    <td className={styles.adp} data-label="ADP">
                      {typeof player.yahooAvgPick === "number" &&
                      player.yahooAvgPick > 0
                        ? player.yahooAvgPick.toFixed(1)
                        : "-"}
                    </td>
                    {(["off", "b2b"] as const).map((metric) => {
                      const offNightRank =
                        metric === "off"
                          ? offNightRankById.get(key)
                          : undefined;
                      return (
                        <td
                          key={metric}
                          className={styles.colSchedule}
                          data-label={metric.toUpperCase()}
                          style={
                            offNightRank
                              ? { color: offNightRank.color }
                              : undefined
                          }
                          title={
                            offNightRank
                              ? `Off-night opportunities; rank quartile ${offNightRank.quartile} of 4 (highest to lowest)`
                              : "Scheduled NHL opportunities; not projected appearances"
                          }
                        >
                          {scheduleMetrics?.get(key)?.[metric] ?? "—"}
                        </td>
                      );
                    })}
                    <td
                      className={`${styles.nextPick} ${riskClass ? riskClass : ""}`}
                      data-label="AVL%"
                      title={
                        riskPct == null
                          ? undefined
                          : `${riskPct}% likely available at your next pick`
                      }
                    >
                      {riskPct == null ? "-" : `${riskPct}%`}
                    </td>
                    <td className={styles.colAction}>
                      <button
                        className={styles.draftButton}
                        data-control-variant="primary"
                        onClick={() => handleDraftClick(player.playerId)}
                        disabled={!canDraft || draftedIdSet.has(key)}
                        title={
                          !canDraft
                            ? draftUnavailableReason
                            : draftedIdSet.has(key)
                              ? "Player already drafted"
                              : "Draft this player"
                        }
                      >
                        {draftedIdSet.has(key) ? "Drafted" : "Draft"}
                      </button>
                    </td>
                    <td className={`${styles.compareCell}`}>
                      <input
                        type="checkbox"
                        className={styles.compareCheckbox}
                        data-control-variant="gold"
                        checked={selectedIds.has(key)}
                        onChange={() => toggleSelected(key)}
                        aria-label={`Select ${player.fullName} for comparison`}
                      />
                    </td>
                  </tr>
                );

                const detailRow = expanded[key] ? (
                  <tr
                    key={`${player.playerId}-details`}
                    data-stripe={rowIndex % 2}
                    className={styles.expandRow}
                  >
                    <td colSpan={detailColSpan}>
                      {seasonLoading[key] && (
                        <div style={{ padding: "8px 12px", opacity: 0.8 }}>
                          Loading last season totals...
                        </div>
                      )}
                      {!seasonLoading[key] && seasonError[key] && (
                        <div style={{ padding: "8px 12px", color: "#c66" }}>
                          {seasonError[key]}
                        </div>
                      )}
                      {!seasonLoading[key] &&
                        !seasonError[key] &&
                        seasonTotals[key] == null && (
                          <div style={{ padding: "8px 12px", opacity: 0.8 }}>
                            No last season totals available.
                          </div>
                        )}
                      {!seasonLoading[key] &&
                        !seasonError[key] &&
                        seasonTotals[key] && (
                          <div style={{ padding: "10px 12px" }}>
                            <div
                              style={{
                                fontSize: 12,
                                opacity: 0.8,
                                marginBottom: 6,
                              }}
                            >
                              Last Season: {seasonTotals[key]?.seasonLabel}
                            </div>
                            {seasonTotals[key]?.type === "skater" ? (
                              <div
                                style={{
                                  display: "grid",
                                  gridTemplateColumns:
                                    "repeat(auto-fit, minmax(110px, 1fr))",
                                  gap: 8,
                                }}
                              >
                                <StatPill
                                  label="GP"
                                  value={seasonTotals[key]!.data.games_played}
                                />
                                <StatPill
                                  label="G"
                                  value={seasonTotals[key]!.data.goals}
                                />
                                <StatPill
                                  label="A"
                                  value={seasonTotals[key]!.data.assists}
                                />
                                <StatPill
                                  label="P"
                                  value={seasonTotals[key]!.data.points}
                                />
                                <StatPill
                                  label="SOG"
                                  value={seasonTotals[key]!.data.shots}
                                />
                                <StatPill
                                  label="HIT"
                                  value={seasonTotals[key]!.data.hits}
                                />
                                <StatPill
                                  label="BLK"
                                  value={seasonTotals[key]!.data.blocked_shots}
                                />
                                <StatPill
                                  label="PPP"
                                  value={seasonTotals[key]!.data.pp_points}
                                />
                                <StatPill
                                  label="TOI/G"
                                  value={
                                    seasonTotals[
                                      key
                                    ]!.data.toi_per_game?.toFixed?.(2) ??
                                    seasonTotals[key]!.data.toi_per_game
                                  }
                                />
                                <StatPill
                                  label="+/-"
                                  value={seasonTotals[key]!.data.plus_minus}
                                />
                                <StatPill
                                  label="S%"
                                  value={
                                    seasonTotals[key]!.data.shooting_percentage
                                  }
                                />
                                <StatPill
                                  label="GWG"
                                  value={seasonTotals[key]!.data.gw_goals}
                                />
                              </div>
                            ) : (
                              <div
                                style={{
                                  display: "grid",
                                  gridTemplateColumns:
                                    "repeat(auto-fit, minmax(130px, 1fr))",
                                  gap: 8,
                                }}
                              >
                                <StatPill
                                  label="GP"
                                  value={seasonTotals[key]!.data.games_played}
                                />
                                <StatPill
                                  label="W-L-OT"
                                  value={`${seasonTotals[key]!.data.wins ?? 0}-${seasonTotals[key]!.data.losses ?? 0}-${seasonTotals[key]!.data.ot_losses ?? 0}`}
                                />
                                <StatPill
                                  label="SV%"
                                  value={seasonTotals[key]!.data.save_pct}
                                />
                                <StatPill
                                  label="GAA"
                                  value={
                                    seasonTotals[key]!.data.goals_against_avg
                                  }
                                />
                                <StatPill
                                  label="SO"
                                  value={seasonTotals[key]!.data.shutouts}
                                />
                                <StatPill
                                  label="SVS"
                                  value={seasonTotals[key]!.data.saves}
                                />
                              </div>
                            )}
                          </div>
                        )}
                    </td>
                  </tr>
                ) : null;

                return [mainRow, detailRow];
              });
            })()}
          </tbody>
        </table>

        {(() => {
          const anyPlayers = hideDrafted
            ? filteredAndSortedPlayers.some(
                (p) => !draftedIdSet.has(String(p.playerId)),
              )
            : filteredAndSortedPlayers.length > 0;
          return !anyPlayers ? (
            <div className={styles.emptyState}>
              <p>{emptyStateMessage}</p>
            </div>
          ) : null;
        })()}
      </div>

      <nav className={styles.pagination} aria-label="Available players pagination">
        <button type="button" disabled={currentPage === 0} onClick={() => setPageIndex(0)}>First</button>
        <label>Rows <select aria-label="Available players per page" value={pageSize} onChange={(event) => setPageSize(Number(event.target.value))}>{[15, 25, 50, 100].map((size) => <option key={size}>{size}</option>)}</select></label>
        {onRefresh && <button type="button" className={styles.refreshButton} onClick={onRefresh} title="Force refresh projections from database">Refresh Data</button>}
        <span className={styles.pageCount}>{orderedPlayers.length ? currentPage * pageSize + 1 : 0}–{Math.min((currentPage + 1) * pageSize, orderedPlayers.length)} of {orderedPlayers.length}</span>
        <button type="button" disabled={currentPage === 0} onClick={() => setPageIndex(currentPage - 1)}>Prev</button>
        <span>{currentPage + 1} / {pageCount}</span>
        <button type="button" disabled={currentPage === pageCount - 1} onClick={() => setPageIndex(currentPage + 1)}>Next</button>
      </nav>
      {showDiagnostics && (
        <div
          className={styles.diagnostics}
          style={{
            margin: "8px 0 0",
            padding: "8px 10px",
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 6,
            fontSize: 12,
          }}
        >
          <div style={{ marginBottom: 4 }}>
            Excluded: <strong>{diagnostics.excluded}</strong> of{" "}
            <strong>{diagnostics.total}</strong> (shown {diagnostics.shown})
          </div>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            {Object.keys(diagnostics.reasons).length === 0 ? (
              <span style={{ opacity: 0.7 }}>No exclusions at present.</span>
            ) : (
              Object.entries(diagnostics.reasons).map(([k, v]) => (
                <span key={k} style={{ opacity: 0.9 }}>
                  {k}: {v}
                </span>
              ))
            )}
          </div>
          {yahooMappingDiagnostics && (
            <div style={{ marginTop: 6, display: "grid", gap: 3 }}>
              {(["skater", "goalie"] as const).map((playerType) => {
                const mapping = yahooMappingDiagnostics[playerType];
                if (!mapping) return null;
                return (
                  <div key={playerType}>
                    Yahoo {playerType}s: selected {mapping.selectedNhlIds} /{" "}
                    {mapping.projectedNhlIds}; unresolved{" "}
                    {mapping.unresolvedNhlIds}; unmapped{" "}
                    {mapping.unmappedNhlIds}; conflicting IDs{" "}
                    {mapping.conflictingYahooIdNhlIds}; current-game missing{" "}
                    {mapping.currentGameMissingNhlIds}
                    {mapping.unresolvedNhlIdSamples.length > 0 && (
                      <span>
                        ; review IDs {mapping.unresolvedNhlIdSamples.join(", ")}
                        {mapping.unresolvedNhlIds >
                        mapping.unresolvedNhlIdSamples.length
                          ? ` … +${mapping.unresolvedNhlIds - mapping.unresolvedNhlIdSamples.length}`
                          : ""}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
          {inclusionDiagnostics && (
            <div style={{ marginTop: 8, display: "grid", gap: 6 }}>
              {(["skater", "goalie"] as const).map((playerType) => {
                const report = inclusionDiagnostics[playerType];
                if (!report) return null;
                return (
                  <div key={playerType}>
                    <strong>Projection {playerType} inclusion:</strong> raw rows{" "}
                    {report.rawRows}; valid-ID rows {report.validIdRows}; unique
                    IDs {report.uniqueSourcePlayerIds}; processed{" "}
                    {report.processedPlayers}; invalid IDs{" "}
                    {report.invalidIdRows}; duplicate rows{" "}
                    {report.duplicateIdRows}; valid IDs missing from pool{" "}
                    {report.sourceIdsMissingFromProcessed}.
                    {report.invalidIdentitySamples.length > 0 && (
                      <details style={{ marginTop: 3 }}>
                        <summary>
                          Identities requiring upstream mapping review (
                          {report.invalidIdentitySamples.length}
                          {report.invalidIdRows >
                          report.invalidIdentitySamples.length
                            ? ` sampled of ${report.invalidIdRows}`
                            : ""}
                          )
                        </summary>
                        {report.invalidIdentitySamples.map((issue, index) => (
                          <div key={`${issue.sourceId}-${index}`}>
                            {issue.name || "Unnamed row"} — {issue.sourceId}{" "}
                            (raw ID {String(issue.rawId ?? "null")})
                          </div>
                        ))}
                        <div style={{ opacity: 0.75 }}>
                          A-DRAFT displays these rows; B-YAHOO owns
                          authoritative mapping and manual-review persistence.
                        </div>
                      </details>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      <ComparePlayersModal
        open={compareOpen}
        onClose={() => setCompareOpen(false)}
        selectedIds={Array.from(selectedIds)}
        allPlayers={allPlayers || players}
        leagueType={leagueType}
      />
    </div>
  );
};

// Simple pill component for compact stat display
const StatPill = ({ label, value }: { label: string; value: any }) => (
  <div
    style={{
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 8,
      padding: "6px 8px",
      borderRadius: 6,
      background: "rgba(255,255,255,0.04)",
      border: "1px solid rgba(255,255,255,0.06)",
      fontSize: 12,
    }}
    title={`${label}: ${value ?? "-"}`}
    aria-label={`${label} ${value ?? "-"}`}
  >
    <span style={{ opacity: 0.65 }}>{label}</span>
    <span style={{ fontVariantNumeric: "tabular-nums" }}>
      {value == null
        ? "-"
        : typeof value === "number"
          ? Number(value).toFixed(0)
          : String(value)}
    </span>
  </div>
);

export default ProjectionsTable;
