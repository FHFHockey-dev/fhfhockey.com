import { totalRosterScheduleMetrics, type PlayerScheduleMetrics } from "lib/draftDashboard/scheduleMetrics";
import { useMemo, useState, type CSSProperties } from "react";
import type { TeamDraftStats } from "./DraftDashboard";
import type { PlayerVorpMetrics } from "hooks/useVORPCalculations";
import { STATS_MASTER_LIST } from "lib/projectionsConfig/statsMasterList";
import {
  categoryRankBand,
  rankTeamCategories,
} from "lib/draftDashboard/categoryStandings";
import styles from "./LeagueStandings.module.scss";

interface LeagueStandingsProps {
  scheduleMetrics?: PlayerScheduleMetrics;
  schedulePeriod?: string;
  teams: TeamDraftStats[];
  categories: Record<string, number>;
  leagueType: "points" | "categories";
  myTeamId: string;
  vorpMetrics: Map<string, PlayerVorpMetrics>;
  onUpdateTeamName: (teamId: string, name: string) => void;
  canEdit: boolean;
  isLoading: boolean;
  error: string | null;
}

export default function LeagueStandings({
  scheduleMetrics,
  schedulePeriod = "Season · Yahoo 477",
  teams,
  categories,
  leagueType,
  myTeamId,
  vorpMetrics,
  onUpdateTeamName,
  canEdit,
  isLoading,
  error,
}: LeagueStandingsProps) {
  const [view, setView] = useState("value");
  const scheduleTotals = useMemo(() => new Map(teams.map((team) => [team.teamId, totalRosterScheduleMetrics([...Object.values(team.rosterSlots).flat(), ...team.bench].map((player) => String(player.playerId)), scheduleMetrics)])), [teams, scheduleMetrics]);
  const [sort, setSort] = useState({ key: "value", ascending: false });
  const [editing, setEditing] = useState<string | null>(null);
  const ranks = useMemo(
    () => rankTeamCategories(teams, categories, leagueType),
    [teams, categories, leagueType],
  );
  const values = useMemo(
    () =>
      Object.fromEntries(
        teams.map((team) => {
          if (leagueType === "points")
            return [team.teamId, team.projectedPoints];
          const scores = [
            ...Object.values(team.rosterSlots).flat(),
            ...team.bench,
          ]
            .map((player) => vorpMetrics.get(player.playerId)?.value)
            .filter(
              (value): value is number =>
                typeof value === "number" && Number.isFinite(value),
            );
          return [
            team.teamId,
            scores.length
              ? scores.reduce((sum, score) => sum + score, 0) / scores.length
              : 0,
          ];
        }),
      ),
    [teams, leagueType, vorpMetrics],
  );
  const standingOrder = [...teams].sort(
    (a, b) => values[b.teamId] - values[a.teamId],
  );
  const sorted = [...teams].sort((a, b) => {
    const value = (team: TeamDraftStats) =>
      sort.key === "value"
        ? values[team.teamId]
        : sort.key === "off" || sort.key === "b2b"
          ? (scheduleTotals.get(team.teamId)?.[sort.key] ?? null)
        : sort.key === "vorp"
          ? (team.teamVorp ?? 0)
          : (team.categoryTotals[sort.key] ?? null);
    const av = value(a), bv = value(b);
    if (av == null) return bv == null ? 0 : 1;
    if (bv == null) return -1;
    return (sort.ascending ? 1 : -1) * (av - bv);
  });
  const changeSort = (key: string) =>
    setSort((current) => ({
      key,
      ascending: current.key === key ? !current.ascending : false,
    }));
  return (
    <section className={styles.standings} aria-label="League Standings" style={{ "--standings-rows": Math.max(1, teams.length + 1) } as CSSProperties}>
      <header>
        <h2>League Standings</h2>
        <label>
          View{" "}
          <select
            aria-label="Standings summary"
            value={view}
            onChange={(event) => { setView(event.target.value); setSort({ key: event.target.value, ascending: false }); }}
          >
            <option value="value">
              {leagueType === "categories" ? "Score" : "Projected points"}
            </option>
            <option value="vorp">Team VORP</option>
          </select>
        </label>
      </header>
      {view === "vorp" && <p className={styles.schedulePeriod}>{schedulePeriod} · NHL opportunities, including bench players</p>}
      <div className={styles.tableViewport}>
        <table aria-label="League scoring category standings">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Team</th>
              {view === "vorp" && (["off", "b2b"] as const).map((key) => <th scope="col" key={key} aria-sort={sort.key === key ? sort.ascending ? "ascending" : "descending" : "none"}><button type="button" onClick={() => changeSort(key)} title={key === "off" ? "Player games on NHL dates with at most 8 games" : "Consecutive-day pairs, counted on the second day"}>{key === "off" ? "Off-Nights" : "Back-to-Backs"}</button></th>)}
              {view !== "vorp" && Object.keys(categories).map((key) => (
                <th
                  scope="col"
                  key={key}
                  aria-sort={
                    sort.key === key
                      ? sort.ascending
                        ? "ascending"
                        : "descending"
                      : "none"
                  }
                >
                  <button
                    type="button"
                    title={key}
                    onClick={() => changeSort(key)}
                  >
                    {STATS_MASTER_LIST.find((stat) => stat.key === key)
                      ?.displayName || key}
                  </button>
                </th>
              ))}
              <th
                scope="col"
                aria-sort={
                  sort.key === "vorp"
                    ? sort.ascending
                      ? "ascending"
                      : "descending"
                    : "none"
                }
              >
                <button type="button" onClick={() => changeSort("vorp")}>
                  VORP
                </button>
              </th>
              <th
                scope="col"
                aria-sort={
                  sort.key === "value"
                    ? sort.ascending
                      ? "ascending"
                      : "descending"
                    : "none"
                }
              >
                <button type="button" onClick={() => changeSort("value")}>
                  {leagueType === "categories" ? "Score" : "Proj FP"}
                </button>
              </th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((team) => (
              <tr key={team.teamId} data-my-team={team.teamId === myTeamId}>
                <td>
                  {standingOrder.findIndex(
                    (item) => item.teamId === team.teamId,
                  ) + 1}
                </td>
                <th scope="row">
                  {editing === team.teamId ? (
                    <input
                      autoFocus
                      aria-label="Team name"
                      defaultValue={team.teamName}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") event.currentTarget.blur();
                        if (event.key === "Escape") setEditing(null);
                      }}
                      onBlur={(event) => {
                        const name = event.currentTarget.value.trim();
                        if (name) onUpdateTeamName(team.teamId, name);
                        setEditing(null);
                      }}
                    />
                  ) : (
                    <button
                      type="button"
                      disabled={!canEdit}
                      onClick={() => setEditing(team.teamId)}
                      title={`${team.teamName}${team.teamId === myTeamId ? " (You)" : ""}`}
                    >
                      {team.teamName}
                      {team.teamId === myTeamId ? " (You)" : ""}
                    </button>
                  )}
                </th>
                {view === "vorp" && (["off", "b2b"] as const).map((key) => <td key={key}>{scheduleTotals.get(team.teamId)?.[key] ?? "—"}</td>)}
                {view !== "vorp" && Object.keys(categories).map((key) => {
                  const rank = ranks[team.teamId][key];
                  const definition = STATS_MASTER_LIST.find(
                    (stat) => stat.key === key,
                  );
                  const value = team.categoryTotals[key] ?? (rank == null ? null : 0);
                  const estimated = team.categoryAggregateQuality?.[key] === "estimated";
                  return (
                    <td
                      key={key}
                      data-category={key}
                      data-rank={rank}
                      data-band={rank == null ? undefined : categoryRankBand(rank, teams.length)}
                      title={`${definition?.displayName || key}: ${rank == null ? "unranked" : `rank ${rank} of ${teams.length}`}${estimated ? " · Estimated" : ""}`}
                    >
                      {value == null ? <span aria-label="Unavailable team rate">N/A</span> : <>
                        {value.toFixed(definition?.decimalPlaces ?? 0)}
                        {estimated && <sup aria-label="Estimated team rate based on projected workload" title="Estimated from projected workload">≈</sup>}
                      </>}
                    </td>
                  );
                })}
                <td>{(team.teamVorp ?? 0).toFixed(1)}</td>
                <td>{values[team.teamId].toFixed(1)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <footer>
        {isLoading
          ? "Updating projections…"
          : error
            ? "Projection data unavailable"
            : `${teams.length} teams · ${Object.keys(categories).length} scoring categories`}
        <span title="Category ranks: best to worst">
          {" "}
          <i data-band="green" /> Best <i data-band="yellow" />{" "}
          <i data-band="orange" /> <i data-band="red" /> Lowest
        </span>
      </footer>
    </section>
  );
}
