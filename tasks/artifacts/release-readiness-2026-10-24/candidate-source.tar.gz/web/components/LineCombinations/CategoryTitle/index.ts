export { default } from "./CategoryTitle";
