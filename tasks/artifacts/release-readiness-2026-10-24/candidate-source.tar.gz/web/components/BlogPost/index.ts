export { default } from "./BlogPost";
