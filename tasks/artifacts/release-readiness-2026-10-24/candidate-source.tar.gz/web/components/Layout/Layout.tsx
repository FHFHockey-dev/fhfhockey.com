import React from "react";
import { useRouter } from "next/router";
import Link from "next/link";

import Header from "./Header";
import SocialMedias from "components/SocialMedias";
import styles from "./Layout.module.scss";
import { SUPPORT_URL } from "./NavbarItems/NavbarItemsData";

type LayoutProps = {
  children: React.ReactNode;
};

function Layout({ children }: LayoutProps) {
  const router = useRouter();
  const isShiftChart = router.pathname === "/shiftChart";
  const isWigo = router.pathname === "/wigoCharts";
  const isRosterOptimizer = router.pathname === "/roster-schedule-optimizer";
  const hideFooter = router.pathname === "/draft-dashboard" || isRosterOptimizer || isWigo;
  return (
    <div className={`${styles.container} ${isShiftChart ? styles.shiftChartLayout : ""} ${router.pathname === "/draft-dashboard" ? styles.draftLayout : ""} ${isRosterOptimizer ? styles.rosterOptimizerLayout : ""} ${isWigo ? styles.wigoLayout : ""}`}>
      <Header />
      {children}
      {!hideFooter && <Footer />}
    </div>
  );
}

function FooterLogo() {
  return (
    <svg
      width="81"
      height="24"
      viewBox="0 0 81 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <g clipPath="url(#footerLogoClip)">
        <path
          d="M1.02051 7.44365C1.02051 2.47482 3.49155 0 8.4528 0H18.3753V3.31894H8.4528C5.69442 3.31894 4.31523 4.70024 4.31523 7.46283V24H1.02051V7.44365ZM5.15807 11.5875V7.44365C5.15807 5.23741 6.26908 4.1247 8.47195 4.1247H18.3944V7.44365H9.27648C8.72097 7.44365 8.4528 7.71223 8.4528 8.26858H15.8851V11.5875H5.15807ZM5.15807 12.4125H15.8851V15.7314H8.4528V24H5.13892V12.4125H5.15807Z"
          fill="currentColor"
        />
        <path
          d="M20.8652 0H24.1791V24H20.8652V0ZM25.0028 0H28.3167V8.26858H30.7877V0H34.1016V11.5875H25.0028V0ZM34.1016 12.4125V24H30.7877V15.7314H28.3167V24H25.0028V12.4125H34.1016ZM34.9253 0H38.2392V24H34.9253V0Z"
          fill="currentColor"
        />
        <path
          d="M42.1276 7.44365C42.1276 2.47482 44.5986 0 49.5598 0H59.4823V3.31894H49.5598C46.8015 3.31894 45.4223 4.70024 45.4223 7.46283V24H42.1084V7.44365H42.1276ZM46.2651 11.5875V7.44365C46.2651 5.23741 47.3761 4.1247 49.579 4.1247H59.5015V7.44365H50.4027C49.8472 7.44365 49.579 7.71223 49.579 8.26858H57.0113V11.5875H46.2651ZM46.2651 12.4125H57.0113V15.7314H49.579V24H46.2651V12.4125Z"
          fill="white"
        />
        <path
          d="M61.9922 0H65.3061V24H61.9922V0ZM66.1298 0H69.4436V8.26858H71.9147V0H75.2286V11.5875H66.1298V0ZM75.2286 12.4125V24H71.9147V15.7314H69.4436V24H66.1298V12.4125H75.2286ZM76.0522 0H79.3661V24H76.0522V0Z"
          fill="white"
        />
      </g>
      <defs>
        <clipPath id="footerLogoClip">
          <rect width="80.3478" height="24" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
}

export function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.footerInner}>
        <div className={styles.footerBrand}>
          <Link href="/" aria-label="FHFH home"><FooterLogo /></Link>
          <small>Five Hole Fantasy Hockey</small>
          <small>© {new Date().getFullYear()} FHFHockey</small>
        </div>
        <nav aria-label="Footer navigation">
          <Link href="/underlying-stats">Underlying Stats</Link>
          <Link href="/game-grid">Game Grid</Link>
          <Link href="/stats">Stats</Link>
          <Link href="/blog">Blog</Link>
          <Link href="/podfeed">Podcast</Link>
          <Link href="/privacy">Privacy</Link>
        </nav>
        <div className={styles.footerCommunity}>
          <a href={SUPPORT_URL} target="_blank" rel="noopener noreferrer">Support FHFH</a>
          <SocialMedias className={styles.footerSocials} />
        </div>
      </div>
    </footer>
  );
}

export default Layout;
