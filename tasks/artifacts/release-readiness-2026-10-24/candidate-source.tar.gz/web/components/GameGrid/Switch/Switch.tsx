import React from "react";
import styles from "./Switch.module.scss";

interface SwitchProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  onClick?: () => void;
  checked?: boolean;
  disabled?: boolean;
  "aria-label"?: string;
  className?: string;
}

function Switch({
  checked = false,
  disabled = false,
  onClick,
  "aria-label": ariaLabel,
  className,
  ...rest
}: SwitchProps) {
  const handleClick = (e: React.MouseEvent) => {
    if (!disabled && onClick) {
      e.preventDefault();
      onClick();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      if (e.repeat) return;
      if (!disabled && onClick) {
        onClick();
      }
    }
  };

  return (
    <button
      type="button"
      className={`${styles.switch} ${checked ? styles.checked : styles.unchecked} ${
        disabled ? styles.disabled : ""
      } ${className || ""}`}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      disabled={disabled}
      aria-label={ariaLabel || `Toggle ${checked ? "on" : "off"}`}
      role="switch"
      aria-checked={checked}
      tabIndex={disabled ? -1 : 0}
      {...rest}
    >
      <span className={styles.arrow} />
    </button>
  );
}

export default Switch;
