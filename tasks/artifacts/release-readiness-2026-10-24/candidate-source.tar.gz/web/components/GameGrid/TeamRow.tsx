// components/GameGrid/TeamRow.tsx

import Image from "next/image";
import Link from "next/link";
import { formatWinOdds, calculateBlendedWinOdds } from "./utils/calcWinOdds";
import { formatWeekScore } from "./utils/calcWeekScore";
import { useTeam } from "./contexts/GameGridContext";
import {
  DAYS,
  EXTENDED_DAY_ABBREVIATION,
  EXTENDED_DAYS,
  GameData,
  WeekData,
} from "lib/NHL/types";
import Tooltip from "./PDHC/Tooltip";
import PoissonHeatmap from "./PDHC/PoissonHeatMap";
import styles from "./GameGrid.module.scss";
import detailStyles from "./TeamDetails.module.scss";
import clsx from "clsx";
import { ReactNode, useEffect, useRef, useState } from "react";
import { teamsInfo } from "lib/teamsInfo";

export type MatchUpCellData = {
  home: boolean;
  away: boolean;
  /**
   * URL, the opponent's team logo.
   */
  logo: string;
  opponentName: string;
  win: boolean;
  loss: boolean;
  /**
   * The game score. e.g., 5-2
   */
  score: string;
  /**
   * The win odds of a game. A number between -5 and 5.
   * e.g., 0.51, -1.06
   */
  winOdds: number;
  /**
   * if the total # of games played that day was <=8
   * to signify what I call an "Off-Night"
   */
  offNight: boolean;
};

type TeamRowProps = {
  teamId: number;
  totalGamesPlayed: number;
  totalOffNights: number;
  weekScore: number;
  extended: boolean;
  excludedDays: EXTENDED_DAY_ABBREVIATION[];
  hidePreseason?: boolean;
  rowHighlightClass?: string;
  games: number[];
  rank: number;
  expanded?: boolean;
  onToggle?: () => void;
  details?: ReactNode;
} & WeekData;

function getGamesPlayedIntensity(totalGamesPlayed: number): string {
  if (totalGamesPlayed <= 1) return "low";
  if (totalGamesPlayed === 2) return "medium-low";
  if (totalGamesPlayed === 3) return "medium-high";
  return "high";
}

function getOffNightsIntensity(totalOffNights: number): string {
  if (totalOffNights === 0) return "low";
  if (totalOffNights === 1) return "medium-low";
  if (totalOffNights === 2) return "medium-high";
  return "high";
}

// Simple hook to detect mobile (<=480px)
function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth <= 480);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);
  return isMobile;
}

function TeamRow(props: TeamRowProps) {
  const team = useTeam(props.teamId);
  const days = props.extended ? EXTENDED_DAYS : DAYS;
  const isMobile = useIsMobile();
  const triggerRef = useRef<HTMLButtonElement>(null);
  const detailId = `game-grid-team-details-${props.teamId}`;

  // Handle cases where team data might not be loaded yet
  if (!team) {
    return (
      <tr className={`${styles.teamRow} ${props.rowHighlightClass || ""}`}></tr>
    );
  }

  const identity = (
    <>
          <span
            className={styles.desktopTeamAbbreviation}
            style={
              {
                "--team-primary-color":
                  teamsInfo[team.abbreviation]?.primaryColor ?? undefined,
                "--team-secondary-color":
                  teamsInfo[team.abbreviation]?.secondaryColor ?? undefined,
                "--team-accent-color":
                  teamsInfo[team.abbreviation]?.accent ?? undefined,
                "--team-light-color":
                  teamsInfo[team.abbreviation]?.lightColor ?? undefined,
                "--team-dark-color":
                  teamsInfo[team.abbreviation]?.darkColor ?? undefined,
                "--team-jersey-color":
                  teamsInfo[team.abbreviation]?.jersey ?? undefined,
              } as React.CSSProperties
            }
          >
            {team.abbreviation}
          </span>
          <span className={clsx(styles.mobileTeamLogo, props.onToggle && detailStyles.rowTeamLogo)}>
            <span className={styles.firstColumnLogo}>
              <Image
                alt=""
                src={team.logo}
                title={team.name}
                fill
                sizes="40px"
                className={styles.teamLogo24}
                style={{ objectFit: "contain" }}
              />
            </span>
          </span>
    </>
  );

  return (
    <>
    <tr className={clsx(styles.teamRow, props.rowHighlightClass)}>
      {/* First column: show abbreviation on desktop, logo on mobile */}
      <td className={clsx(styles.firstColumnContent, props.onToggle && detailStyles.identityCell)}>
        <div className={props.onToggle ? detailStyles.teamIdentity : undefined}>
          {props.onToggle && (
            <button
              type="button"
              ref={triggerRef}
              id={`game-grid-team-trigger-${props.teamId}`}
              className={detailStyles.teamDisclosure}
              aria-label={`${props.expanded ? "Hide" : "Show"} ${team.name} upcoming category forecasts`}
              aria-expanded={props.expanded ?? false}
              aria-controls={detailId}
              onClick={props.onToggle}
            >
              {identity}
              <span aria-hidden="true">{props.expanded ? "−" : "+"}</span>
            </button>
          )}
          <Link
            href={`/stats/team/${team.abbreviation}`}
            aria-label={`Open ${team.name} Team HQ`}
            className={props.onToggle ? detailStyles.teamHqLink : styles.teamSurfaceLink}
          >
            {props.onToggle ? "HQ" : identity}
          </Link>
        </div>
      </td>
      {/* Days */}
      {days.map((day, index) => {
        const matchUp = props[day];
        const hasMatchUp = matchUp !== undefined;
        const isPreseason = !!matchUp && matchUp.gameType === 1;
        const isPostseason = !!matchUp && matchUp.gameType === 3;
        const excluded = props.excludedDays.includes(day as EXTENDED_DAY_ABBREVIATION);
        const numGamesThatDay = props.games[index] || 0;
        // Determine cell classes for inner border styling
        let dayIntensityClass = "";
        // if (hasMatchUp) {
        if (numGamesThatDay >= 9) {
          dayIntensityClass = styles["heavy-day"]; // Red border for heavy day matchup
        } else if (numGamesThatDay === 7) {
          dayIntensityClass = styles["medium-heavy-day"]; // Red border for heavy day matchup
        } else if (numGamesThatDay === 8) {
          dayIntensityClass = styles["medium-heavy-day"]; // Red border for heavy day matchup
        } else if (numGamesThatDay < 7) {
          dayIntensityClass = styles["off-night-day"]; // Green border for off-night matchup
        }

        let offNightTypeClass = "";
        // if (hasMatchUp) {
        //   offNightTypeClass =
        //     matchUp.homeTeam.id === props.teamId
        //       ? styles["off-night-home"]
        //       : styles["off-night-away"];
        // }

        // if (numGamesThatDay <= 8) {
        //   offNightTypeClass = styles["off-night-day"];
        // }

        const cellClasses = clsx(
          styles.cellInnerBorder,
          dayIntensityClass,
          offNightTypeClass,
          isPreseason ? styles.preseason : undefined,
          isPostseason ? styles.postseason : undefined,
        );

        return (
          <td key={day} className={cellClasses}>
            {/* Excluded Day Overlay */}
            {excluded && !isMobile && (
              <div className={styles.excludedOverlay}></div>
            )}

            {hasMatchUp && !(isPreseason && props.hidePreseason) ? (
              <MatchUpCell
                key={day}
                gameId={matchUp.id}
                home={matchUp.homeTeam.id === props.teamId}
                homeTeam={matchUp.homeTeam}
                awayTeam={matchUp.awayTeam}
                excluded={excluded}
              />
            ) : isMobile ? (
              ""
            ) : (
              "-"
            )}
          </td>
        );
      })}

      {!props.extended && (
        <>
          {/* Total Games Played - Use data-attribute for styling */}
          <td data-intensity={getGamesPlayedIntensity(props.totalGamesPlayed)}>
            {props.totalGamesPlayed}
          </td>
          {/* Total Off-Nights - Use data-attribute for styling */}
          <td data-intensity={getOffNightsIntensity(props.totalOffNights)}>
            {props.totalOffNights}
          </td>
          {/* Week Score - Apply rank color class */}
          <td
            className={clsx(
              styles.weekScoreCell,
              styles[`rank-color-${props.rank}`],
            )}
          >
            {props.weekScore === -100 ? "-" : formatWeekScore(props.weekScore)}
          </td>
        </>
      )}
    </tr>
    {props.expanded && props.details && (
      <tr className={detailStyles.detailRow}>
        <td className={detailStyles.detailCell} colSpan={days.length + (props.extended ? 1 : 4)}>
          <div id={detailId}>
            <div className={detailStyles.detailControls}>
              <button type="button" className={detailStyles.closeButton}
                aria-label={`Close ${team.name} game previews`}
                onClick={() => { triggerRef.current?.focus(); props.onToggle?.(); }}>
                Close preview
              </button>
            </div>
            {props.details}
          </div>
        </td>
      </tr>
    )}
    </>
  );
}

type MatchUpCellProps = {
  gameId: number; // Add gameId here
  home: boolean;
  homeTeam: GameData["homeTeam"];
  awayTeam: GameData["awayTeam"];
  excluded?: boolean;
};

export function MatchUpCell({
  home,
  homeTeam,
  awayTeam,
  gameId,
  excluded,
}: MatchUpCellProps) {
  const us = home ? homeTeam : awayTeam;
  const opponent = home ? awayTeam : homeTeam;

  // Always call hooks at the top
  const usTeam = useTeam(us.id);
  const opponentTeam = useTeam(opponent.id);
  const isMobile = useIsMobile();

  // Handle cases where team data might not be found
  if (!usTeam || !opponentTeam) {
    console.error(`Team data not found for team IDs: ${us.id}, ${opponent.id}`);
    return <div>Data unavailable</div>;
  }

  const opponentColors = teamsInfo[opponentTeam.abbreviation];
  const matchupCellStyle = {
    "--opponent-primary-color": opponentColors?.primaryColor,
    "--opponent-secondary-color": opponentColors?.secondaryColor,
    "--opponent-accent-color": opponentColors?.accent,
    "--opponent-light-color": opponentColors?.lightColor,
    "--opponent-dark-color": opponentColors?.darkColor,
    "--opponent-jersey-color": opponentColors?.jersey,
  } as React.CSSProperties;

  // Proceed with rendering
  const hasResult = us.score !== undefined && opponent.score !== undefined;
  let text = "";
  let stat = "";

  if (hasResult) {
    const usScore = us.score!;
    const opponentScore = opponent.score!;
    const win = usScore > opponentScore;
    text = win ? "WIN" : "LOSS";
    stat = `${usScore}-${opponentScore}`;
  } else {
    // Calculate blended win odds
    const blendedWinOdds = calculateBlendedWinOdds(us.winOdds, us.apiWinOdds);
    stat = blendedWinOdds !== null ? formatWinOdds(blendedWinOdds) : "-";
  }

  // Define tooltipContent within MatchUpCell
  const tooltipContent = (
    <div>
      <PoissonHeatmap
        homeTeamId={home ? us.id : opponent.id}
        awayTeamId={home ? opponent.id : us.id}
        gameId={gameId} // Pass gameId to PoissonHeatmap
      />
    </div>
  );

  return (
    <Tooltip content={tooltipContent}>
      <div className={styles.matchupCell} style={matchupCellStyle}>
        {isMobile ? (
          <div
            className={clsx(
              styles.logoWithIconWrapper,
              styles.mobileMatchupLogoWrapper,
            )}
          >
            <span
              className={clsx(
                styles.cornerBadge,
                home ? styles.homeBadge : styles.awayBadge,
              )}
              aria-label={home ? "Home game" : "Away game"}
            >
              {home ? "H" : "A"}
            </span>
            <Image
              className={clsx(
                styles.mobileLogoSize,
                styles.compactMobileLogo,
                home ? styles["home-shadow"] : styles["away-shadow"],
                excluded ? styles.excludedStateMobile : undefined,
              )}
              objectFit="contain"
              alt={`${opponentTeam.name} logo`}
              width={20}
              height={20}
              src={opponentTeam.logo}
              title={opponentTeam.name}
            />
          </div>
        ) : (
          <span className={styles.matchupDesktopCluster}>
            <span
              className={clsx(
                styles.matchupOpponentLogo,
                excluded ? styles.excludedStateDesktop : undefined,
              )}
            >
              <Image
                alt={`${opponentTeam.name} logo`}
                src={opponentTeam.logo}
                title={opponentTeam.name}
                fill
                sizes="44px"
                className={clsx(
                  styles.opponentLogoDesktop,
                  home ? styles["home-shadow"] : styles["away-shadow"],
                )}
                style={{ objectFit: "contain" }}
              />
            </span>
            <span
              className={clsx(
                styles.matchupHomeAwayIcon,
                home ? styles.homeAwayBadgeHome : styles.homeAwayBadgeAway,
                excluded ? styles.excludedGrayscale : undefined,
              )}
            >
              <Image
                src={
                  home ? "/pictures/homeIcon3.png" : "/pictures/awayIcon3.png"
                }
                alt={home ? "Home" : "Away"}
                fill
                sizes="24px"
                className={styles.matchupHomeAwayIconImg}
                style={{ objectFit: "contain" }}
              />
            </span>
          </span>
        )}
      </div>
    </Tooltip>
  );
}

export default TeamRow;
