// C:\Users\timbr\OneDrive\Desktop\fhfhockey.com-3\web\components\LinemateMatrix\index.tsx

import { memo, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import useResizeObserver from "hooks/useResizeObserver";
import classNames from "classnames";
import Fetch from "lib/cors-fetch";
import { Shift, getAvg, getPairwiseTOI } from "./utilities";
import getPowerPlayBlocks, {
  Block,
  formatTime
} from "utils/getPowerPlayBlocks";
import groupBy from "utils/groupBy";

import styles from "./index.module.scss";
import Tooltip from "components/Tooltip";
import Select from "components/Select";
import Image from "next/image";
import { setDifference } from "utils/setDifference";

// C:\Users\timbr\Desktop\FHF\fhfhockey.com-3\web\components\LinemateMatrix\index.tsx

export async function fetchGamecenterJson<T>(
  gameId: number,
  resource: "boxscore" | "play-by-play"
): Promise<T> {
  const response = await Fetch(
    `https://api-web.nhle.com/v1/gamecenter/${gameId}/${resource}`
  );

  const contentType = response.headers.get("content-type") ?? "";

  if (!response.ok) {
    let detail = "";
    if (contentType.includes("application/json")) {
      const body = await response.json().catch(() => null);
      if (body && typeof body === "object" && "message" in body) {
        detail = `: ${String(body.message)}`;
      }
    }
    throw new Error(`Gamecenter ${resource} HTTP ${response.status}${detail}`);
  }

  if (!contentType.includes("application/json")) {
    throw new Error(`Unexpected content type: ${contentType}`);
  }

  return response.json() as Promise<T>;
}

async function getRostersMap(gameId: number, _teamId?: number) {
  const rostersMap: Record<number, PlayerData> = {};

  let boxscore;
  try {
    boxscore = await fetchGamecenterJson<any>(gameId, "boxscore");
  } catch (e: any) {
    throw new Error(
      `Failed to fetch or parse boxscore for game ${gameId}: ${e.message}`
    );
  }

  // Check gameScheduleState
  if (boxscore.gameScheduleState !== "OK") {
    throw new Error(
      `Skipping game ${gameId} because gameScheduleState is ${boxscore.gameScheduleState}`
    );
  }

  // Existing gameState check
  if (!["OFF", "FINAL"].includes(boxscore.gameState)) {
    throw new Error(
      `The gameState for the game ${gameId} is ` + boxscore.gameState
    );
  }

  const playerByGameStats = boxscore.playerByGameStats;
  const transform = (teamId: number) => (item: any) => ({
    id: item.playerId,
    teamId: teamId,
    sweaterNumber: item.sweaterNumber,
    position: item.position,
    name: item.name.default
  });

  const players: PlayerData[] = [];
  let teams: { id: number; name: string }[] = [
    boxscore.homeTeam,
    boxscore.awayTeam
  ].map((team) => ({
    id: team.id,
    name: team.commonName.default
  }));

  if (_teamId) {
    teams = teams.filter((team) => team.id === _teamId);
    if (_teamId === boxscore.homeTeam.id) {
      const homeTeamPlayers = [
        ...playerByGameStats.homeTeam.forwards,
        ...playerByGameStats.homeTeam.defense
      ].map(transform(boxscore.homeTeam.id));
      players.push(...homeTeamPlayers);
    } else if (_teamId === boxscore.awayTeam.id) {
      const awayTeamPlayers = [
        ...playerByGameStats.awayTeam.forwards,
        ...playerByGameStats.awayTeam.defense
      ].map(transform(boxscore.awayTeam.id));
      players.push(...awayTeamPlayers);
    }
  } else {
    const homeTeamPlayers = [
      ...playerByGameStats.homeTeam.forwards,
      ...playerByGameStats.homeTeam.defense
    ].map(transform(boxscore.homeTeam.id));
    const awayTeamPlayers = [
      ...playerByGameStats.awayTeam.forwards,
      ...playerByGameStats.awayTeam.defense
    ].map(transform(boxscore.awayTeam.id));
    players.push(...homeTeamPlayers, ...awayTeamPlayers);
  }

  players.forEach((p) => {
    rostersMap[p.id] = p;
  });

  return {
    rostersMap,
    teams
  };
}

function processShifts(
  shifts: Shift[],
  rosters: Record<number, PlayerData[]>,
  ppBlocks: Block[] | undefined
) {
  const teamIds = Object.keys(rosters).map(Number);
  const result: Record<number, { toi: number; p1: number; p2: number }[]> = {};
  teamIds.forEach((teamId) => {
    const teamRosters = [...(rosters[teamId] ?? [])];
    const teamShifts = shifts.filter((shift) => shift.teamId === teamId);
    for (let i = 0; i < teamRosters.length; i++) {
      for (let j = i; j < teamRosters.length; j++) {
        if (result[teamId] === undefined) result[teamId] = [];
        const p1 = teamRosters[i].id;
        const p2 = teamRosters[j].id;
        result[teamId].push({
          toi: getPairwiseTOI(teamShifts, p1, p2, ppBlocks),
          p1,
          p2
        });
      }
    }
  });
  return result;
}

export type PlayerData = {
  id: number;
  teamId: number;
  position: string;
  sweaterNumber: number;
  name: string;
  fullName?: string;
};

export type TOIData = {
  toi: number;
  p1: PlayerData;
  p2: PlayerData;
};

export async function fetchTOIRawData(id: number) {
  const [{ data: shiftsData }, { rostersMap, teams }, { plays }] =
    await Promise.all([
      Fetch(
        `https://api.nhle.com/stats/rest/en/shiftcharts?cayenneExp=gameId=${id}`
      ).then((res) => res.json()),
      getRostersMap(id),
      fetchGamecenterJson<{ plays: any }>(id, "play-by-play")
    ]);

  return [{ data: shiftsData }, { rostersMap, teams }, { plays }] as const;
}

export async function simpleGetTOIData(id: number) {
  const rawData = await fetchTOIRawData(id);
  // @ts-ignore
  return getTOIData(rawData, "line-combination");
}

export function getTOIData(
  rawData: [
    {
      data: any;
    },
    {
      rostersMap: Record<number, PlayerData>;
      teams: {
        id: number;
        name: string;
      }[];
    },
    {
      plays: any;
    }
  ],
  mode: Mode
) {
  const [{ data: shiftsData }, { rostersMap, teams }, { plays }] = rawData;

  let rosters = groupBy(Object.values(rostersMap), (player) => player.teamId);
  const shiftRows = Array.isArray(shiftsData) ? shiftsData : [];

  const data: Record<number, TOIData[]> = {};
  let ppBlocks: Block[] = [];
  if (mode === "pp-toi") {
    ppBlocks = getPowerPlayBlocks(plays);
  }
  const pairwiseTOIForTwoTeams = processShifts(
    shiftRows,
    rosters,
    mode !== "pp-toi" ? undefined : ppBlocks
  );
  const teamIds = Object.keys(pairwiseTOIForTwoTeams).map(Number);
  // populate player info
  teamIds.forEach((teamId) => {
    if (data[teamId] === undefined) data[teamId] = [];
    pairwiseTOIForTwoTeams[teamId].forEach((item) => {
      // skip for goalies
      if (!rostersMap[item.p1] || !rostersMap[item.p2]) {
        console.log(
          "skip for goalie",
          item,
          rostersMap[item.p1],
          rostersMap[item.p2]
        );
        return;
      }
      data[teamId].push({
        toi: item.toi,
        p1: rostersMap[item.p1],
        p2: rostersMap[item.p2]
      });
    });
  });

  return { toi: data, rosters, teams };
}
function useTOI(id: number, mode: Mode) {
  const [toi, setTOI] = useState<Record<number, TOIData[]>>({});
  const [rosters, setRosters] = useState<Record<number, PlayerData[]>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [teams, setTeams] = useState<[Team, Team] | null>(null);
  const [rawData, setRawData] = useState<
    | [
        {
          data: any;
        },
        {
          rostersMap: Record<number, PlayerData>;
          teams: {
            id: number;
            name: string;
          }[];
        },
        {
          plays: any;
        }
      ]
    | null
  >(null);

  useEffect(() => {
    let mounted = true;
    if (!id || rawData === null) {
      return;
    }
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const { toi, rosters, teams } = getTOIData(rawData, mode);
        if (mounted) {
          setTOI(toi);
          setRosters(rosters);
          setTeams(teams as any);
        }
      } catch (e: any) {
        console.error(e);
        if (mounted) {
          setError(e?.message ?? "Failed to build linemate matrix.");
        }
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [id, rawData, mode]);

  useEffect(() => {
    let mounted = true;
    if (!id) {
      setTOI({});
      setRosters({});
      setTeams(null);
      setRawData(null);
      setError("Select a completed game to load linemate data.");
      return;
    }
    (async () => {
      setLoading(true);
      setError(null);
      setRawData(null);
      setTOI({});
      setRosters({});
      setTeams(null);
      try {
        const rawData = await fetchTOIRawData(id);

        if (mounted) {
          // @ts-ignore
          setRawData(rawData);
        }
      } catch (e: any) {
        console.error(e);
        if (mounted) {
          setError(e?.message ?? "Failed to load linemate matrix data.");
        }
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [id]);
  return [toi, rosters, teams, loading, error] as const;
}

type Team = { id: number; name: string; logo?: string };
type Props = {
  id: number;
  mode: Mode;
  onModeChanged?: (newMode: Mode) => void;
};

export const OPTIONS = [
  { label: "Line Combination", value: "line-combination" },
  {
    label: "Power Play TOI",
    value: "pp-toi"
  },
  {
    label: "Total TOI",
    value: "total-toi"
  },

  { label: "Sweater Number", value: "number" }
] as const;
export default function LinemateMatrix({
  id,
  mode,
  onModeChanged = () => {}
}: Props) {
  const [activeMode, setActiveMode] = useState<Mode>(mode);

  useEffect(() => {
    setActiveMode(mode);
  }, [mode]);

  const [toiData, rosters, gameInfo, loading, error] = useTOI(id, activeMode);
  const handleModeChange = (newMode: Mode) => {
    setActiveMode(newMode);
    onModeChanged(newMode);
  };

  return <LinemateMatrixView toiData={toiData} rosters={rosters} gameInfo={gameInfo}
    loading={loading} error={error} mode={activeMode} onModeChanged={handleModeChange} />;
}

type MatrixViewProps = {
  toiData: Record<number, TOIData[]>;
  rosters: Record<number, PlayerData[]>;
  gameInfo: readonly Team[] | null;
  loading?: boolean;
  error?: string | null;
  mode: Mode;
  onModeChanged: (mode: Mode) => void;
  compact?: boolean;
};

export const LinemateMatrixView = memo(function LinemateMatrixView({
  toiData, rosters, gameInfo, loading = false, error = null,
  mode: activeMode, onModeChanged: handleModeChange, compact = false
}: MatrixViewProps) {

  if (!gameInfo) {
    return (
      <div className={styles.shell}>
        <div className={styles.selectWrapper}>
          <Select
            ariaLabel="Linemate matrix mode"
            options={OPTIONS}
            option={activeMode}
            onOptionChange={handleModeChange}
          />
        </div>
        <div className={styles.status} role={error ? "alert" : "status"}>
          {error ?? (loading ? "Loading linemate matrix..." : "No linemate data loaded.")}
        </div>
      </div>
    );
  }
  const [homeTeam, awayTeam] = gameInfo;
  return (
    <div className={classNames(styles.shell, { [styles.compact]: compact })}>
      <div className={styles.selectWrapper}>
        <Select
          ariaLabel="Linemate matrix mode"
          options={OPTIONS}
          option={activeMode}
          onOptionChange={handleModeChange}
        />
      </div>
      {compact && <p className={styles.fullGameLabel}>Full-game shared ice time · brighter = more TOI</p>}
      {loading && (
        <div className={styles.status} role="status">
          Updating linemate matrix...
        </div>
      )}
      {error && (
        <div className={styles.statusError} role="alert">
          {error}
        </div>
      )}
      <div className={styles.gridWrapper}>
        <LinemateMatrixInternal
          key={homeTeam.id}
          teamId={homeTeam.id}
          teamName={homeTeam.name}
          roster={rosters[homeTeam.id]}
          toiData={toiData[homeTeam.id]}
          mode={activeMode}
          compact={compact}
          logo={homeTeam.logo}
        />

        <LinemateMatrixInternal
          key={awayTeam.id}
          teamId={awayTeam.id}
          teamName={awayTeam.name}
          roster={rosters[awayTeam.id]}
          toiData={toiData[awayTeam.id]}
          mode={activeMode}
          compact={compact}
          logo={awayTeam.logo}
        />
      </div>
    </div>
  );
});

type PlayerType = "forwards" | "defensemen";
export const NUM_PLAYERS_PER_LINE = {
  forwards: 3,
  defensemen: 2
} as const;
export function sortByLineCombination(
  data: Record<string, TOIData>,
  players: PlayerData[]
): PlayerData[] {
  // TJ: I think that would be the three fwds w most shared toi, then 2nd, 3rd, 4th etc
  if (players.length === 0) return [];
  const getTOI = (playerId1: number, playerId2: number) =>
    data[getKey(playerId1, playerId2)]?.toi ?? 0;
  const groups = groupBy(players, (player) =>
    isForward(player.position) ? "forwards" : "defensemen"
  );
  const result: PlayerData[] = [];
  ["forwards", "defensemen"].forEach((playerType) => {
    const players = [...(groups[playerType] ?? [])];
    const numPlayersPerLine = NUM_PLAYERS_PER_LINE[playerType as PlayerType];
    const numLines = Math.ceil(players.length / numPlayersPerLine);
    for (let line = 0; line < numLines; line++) {
      const pivotPlayer = players
        .sort((a, b) => getTOI(b.id, b.id) - getTOI(a.id, a.id))
        .shift();
      if (!pivotPlayer) break;
      result.push(pivotPlayer);
      for (let i = 0; i < numPlayersPerLine - 1; i++) {
        const p = players
          .sort(
            (a, b) =>
              getTOI(pivotPlayer!.id, b.id) -
              getTOI(pivotPlayer!.id, a.id)
          )
          .shift();
        if (!p) break;
        result.push(p);
      }
    }
  });
  return result;
}

export function sortByPPTOI(data: Record<string, TOIData>): PlayerData[] {
  const getTOI = (playerId1: number, playerId2: number) =>
    data[getKey(playerId1, playerId2)]?.toi ?? 0;

  const sortPlayerSet = (playerIds: Set<number>) =>
    [...playerIds].sort((a, b) => getTOI(b, b) - getTOI(a, a));

  // Filter valid players
  const filteredPlayers = Object.values(data)
    .filter((item) => item.p1.id === item.p2.id && item.toi > 0)
    .sort((a, b) => b.toi - a.toi)
    .map((item) => item.p1.id);

  const allPlayers = new Set(filteredPlayers);
  if (allPlayers.size === 0) return [];

  const sortBySharedTOI = (pivotId: number, playerIds: number[]) =>
    [...playerIds].sort((a, b) => getTOI(pivotId, b) - getTOI(pivotId, a));

  const selectTopPlayers = (
    pivotId: number,
    playerIds: Set<number>,
    limit: number
  ): Set<number> => {
    const sortedPlayers = sortBySharedTOI(pivotId, [...playerIds]);
    return new Set(sortedPlayers.slice(0, limit));
  };

  // Step 1: Determine PP1 players
  const pp1Pivot = filteredPlayers[0]; // has been sorted by toi
  const pp1PlayerIds = selectTopPlayers(pp1Pivot, allPlayers, 5);

  // Step 2: Determine PP2 players
  const remainingPlayers = setDifference(allPlayers, pp1PlayerIds);
  // Find the player with the highest individual TOI as the PP2 pivot
  const pp2Pivot = sortPlayerSet(remainingPlayers)[0];

  const pp2PlayerIds =
    pp2Pivot == null ? new Set<number>() : selectTopPlayers(pp2Pivot, remainingPlayers, 5);

  // Step 3: Sort the remaining players

  const sortedPP1Players = sortPlayerSet(pp1PlayerIds);
  const sortedPP2Players = sortPlayerSet(pp2PlayerIds);
  const sortedRemainingPlayers = sortPlayerSet(
    setDifference(remainingPlayers, pp2PlayerIds)
  );

  return [
    ...sortedPP1Players,
    ...sortedPP2Players,
    ...sortedRemainingPlayers
  ]
    .map((playerId) => data[getKey(playerId, playerId)]?.p1)
    .filter((player): player is PlayerData => player != null);
}

export type Mode = "number" | "total-toi" | "pp-toi" | "line-combination";
type LinemateMatrixInternalProps = {
  teamId: number;
  teamName: string;
  toiData: TOIData[];
  roster: PlayerData[];
  mode: Mode;
  compact?: boolean;
  logo?: string;
};

export const getKey = (p1: number, p2: number) => `${[p1, p2].sort()}`;
export function LinemateMatrixInternal({
  teamId,
  teamName,
  roster = [],
  toiData = [],
  mode,
  compact = false,
  logo
}: LinemateMatrixInternalProps) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const viewport = useResizeObserver(viewportRef);
  const [selectedCell, setSelectedCell] = useState({ row: -1, col: -1 });
  const [positionFilter, setPositionFilter] = useState<"All" | "F" | "D">("All");
  const table = useMemo(() => {
    const table: Record<string, TOIData> = {};
    toiData.forEach((item) => {
      const key = getKey(item.p1.id, item.p2.id);
      table[key] = item;
    });

    return table;
  }, [toiData]);

  const orderedRoster = useMemo(() => {
    if (mode === "number") {
      const rosterSortedByNumber = [...roster].sort(
        (a, b) => a.sweaterNumber - b.sweaterNumber
      );
      return rosterSortedByNumber;
    } else if (mode === "total-toi") {
      return Object.values(table)
        .filter((item) => item.p1.id === item.p2.id)
        .sort((a, b) => b.toi - a.toi)
        .map((item) => item.p1);
    } else if (mode === "line-combination") {
      return sortByLineCombination(table, roster);
    } else if (mode === "pp-toi") {
      return sortByPPTOI(table);
    } else {
      console.error("not implemented");
      return [];
    }
  }, [table, mode, roster]);
  const sortedRoster = useMemo(() => orderedRoster.filter(player =>
    !compact || positionFilter === "All" ||
    (positionFilter === "F" ? isForward(player.position) : isDefense(player.position))
  ), [orderedRoster, positionFilter, compact]);
  const avgSharedToi = useMemo(() => {
    if (sortedRoster.length === 0) return 0;
    let sum = 0;
    sortedRoster.forEach((player) => {
      sum += table[getKey(player.id, player.id)]?.toi ?? 0;
    });
    return sum / sortedRoster.length;
  }, [table, sortedRoster]);

  return (
    <section id={`linemate-matrix-${teamId}`} className={styles.container}>
      {compact ? <div className={styles.teamHeading}>
        {logo && <Image src={logo} alt="" width={40} height={40} unoptimized />}
        <h4>{teamName}</h4>
        {compact && <div className={styles.positionFilters} role="group" aria-label={`${teamName} positions`}>
          {(["All", "F", "D"] as const).map(filter => <button key={filter} type="button"
            aria-pressed={positionFilter === filter}
            aria-label={filter === "F" ? "Forwards" : filter === "D" ? "Defense" : "All skaters"}
            onClick={() => { setPositionFilter(filter); setSelectedCell({ row: -1, col: -1 }); }}>{filter}</button>)}
        </div>}
      </div> : <h4>{teamName}</h4>}
      {sortedRoster.length === 0 ? (
        <div className={styles.emptyState}>No skater TOI available.</div>
      ) : null}
      <div ref={viewportRef} className={styles.matrixViewport}>
      <div
        data-matrix-size={sortedRoster.length}
        onKeyDown={compact ? (event) => {
          const cells = Array.from(event.currentTarget.querySelectorAll<HTMLElement>("[data-matrix-cell]"));
          const index = cells.indexOf(document.activeElement as HTMLElement);
          const delta = { ArrowRight: 1, ArrowLeft: -1, ArrowDown: sortedRoster.length, ArrowUp: -sortedRoster.length }[event.key];
          if (index >= 0 && delta !== undefined) {
            event.preventDefault();
            cells[Math.max(0, Math.min(cells.length - 1, index + delta))]?.focus();
          }
        } : undefined}
        className={classNames(styles.grid, "content")}
        style={{
          gridTemplateRows: `var(--player-info-size) repeat( ${sortedRoster.length}, 1fr)`,
          gridTemplateColumns: `var(--player-info-size) repeat(${sortedRoster.length}, 1fr)`,
          "--players": sortedRoster.length,
          "--cell-size": `${Math.floor(Math.max(1, Math.min((viewport.width - 88) / Math.max(1, sortedRoster.length), (viewport.height - 76) / Math.max(1, sortedRoster.length))) * 64) / 64}px`
        } as CSSProperties}
      >
        {sortedRoster.length > 0 &&
          new Array(sortedRoster.length + 1).fill(0).map((_, row) => {
            // Render the top row aka. player names
            if (row === 0) {
              return [
                <div key="left-up"></div>,
                ...sortedRoster.map((player, col) => (
                  <div
                    key={player.id}
                    title={player.fullName ?? player.name}
                    className={classNames(styles.topPlayerName, {
                      [styles.active]: col === selectedCell.col - 1
                    })}
                  >
                    <div className={styles.inner}>
                      {/* {player.sweaterNumber}
                      <>&nbsp;</> */}
                      {player.name}
                    </div>
                  </div>
                ))
              ];
            } else {
              return new Array(sortedRoster.length + 1)
                .fill(0)
                .map((_, col) => {
                  const p1 = sortedRoster[col - 1];
                  const p2 = sortedRoster[row - 1];

                  // Render the first column aka. player names
                  if (col === 0) {
                    return (
                      <div
                        key={p2.id}
                        title={p2.fullName ?? p2.name}
                        className={classNames(styles.leftPlayerName, {
                          [styles.active]: selectedCell.row === row
                        })}
                      >
                        {/* {p2.sweaterNumber}
                        <>&nbsp;</> */}
                        {p2.name}
                      </div>
                    );
                  } else {
                    // Render the colored cells
                    if (col !== 0 && row !== 0) {
                      const p1 = sortedRoster[col - 1];
                      const p2 = sortedRoster[row - 1];
                      const isHighlight = p1.id === p2.id; // Check if it's the same player

                      return (
                        <Cell
                          key={`${p1.id}-${p2.id}`}
                          compact={compact}
                          focusable={row === 1 && col === 1}
                          teamAvgToi={avgSharedToi}
                          sharedToi={table[getKey(p1.id, p2.id)]?.toi ?? 0}
                          p1={p1}
                          p2={p2}
                          highlight={isHighlight}
                          onPointerEnter={() => setSelectedCell({ row, col })}
                          onPointerLeave={() =>
                            setSelectedCell({ row: -1, col: -1 })
                          }
                        />
                      );
                    }
                  }
                });
            }
          })}
      </div>

      </div>

      {/* PPTOI mode only */}
      {mode === "pp-toi" && (
        <div className={styles.comparisonBar}>
          <PPTOIComparasion
            AVG_PPTOI1={getAvg(sortedRoster.slice(0, 5), table)}
            AVG_PPTOI2={getAvg(sortedRoster.slice(5, 10), table)}
          />
        </div>
      )}
    </section>
  );
}

type CellProps = {
  compact?: boolean;
  focusable?: boolean;
  teamAvgToi: number;
  sharedToi: number;

  p1: PlayerData;
  p2: PlayerData;

  onPointerEnter?: () => void;
  onPointerLeave?: () => void;

  highlight: boolean; // New prop to indicate if the cell should be highlighted
};

const RED = "#D65108";
const BLUE = "#0267C1";
const PURPLE = "#EFA00B";
const FORWARDS_POSITIONS = ["L", "R", "C"];
const DEFENSE_POSITIONS = ["D"];

export function isForward(position: string) {
  return FORWARDS_POSITIONS.includes(position);
}

export function isDefense(position: string) {
  return DEFENSE_POSITIONS.includes(position);
}

function isMixing(p1Pos: string, p2Pos: string) {
  return (
    (isForward(p1Pos) && isDefense(p2Pos)) ||
    (isForward(p2Pos) && isDefense(p1Pos))
  );
}

/**
 * Forward pairs are blue, defense pairs orange, and mixed pairs gold.
 */
function getColor(p1Pos: string, p2Pos: string) {
  if (isForward(p1Pos) && isForward(p2Pos)) return BLUE;
  if (isDefense(p1Pos) && isDefense(p2Pos)) return RED;
  if (isMixing(p1Pos, p2Pos)) return PURPLE; // the check can be omitted
  return "#6b7280";
}

function Cell({
  compact = false,
  focusable = false,
  teamAvgToi,
  sharedToi,
  p1,
  p2,
  highlight,
  onPointerEnter = () => {},
  onPointerLeave = () => {}
}: CellProps) {
  const [point, setPoint] = useState<{ left: number; top: number } | null>(null);
  useEffect(() => {
    if (!point) return;
    const dismiss = (event: KeyboardEvent) => {
      if (event.key === "Escape") setPoint(null);
    };
    window.addEventListener("keydown", dismiss);
    return () => window.removeEventListener("keydown", dismiss);
  }, [point]);
  const label = `${p1.fullName ?? p1.name} × ${p2.fullName ?? p2.name}: ${formatTime(sharedToi)} shared TOI`;
  const opacity =
    teamAvgToi > 0 && Number.isFinite(teamAvgToi)
      ? Math.max(0, Math.min(1, sharedToi / teamAvgToi))
      : 0;
  const color = getColor(p1.position, p2.position);

  if (compact) {
    const show = (element: HTMLElement) => {
      const rect = element.getBoundingClientRect();
      setPoint({ left: Math.max(8, Math.min(window.innerWidth - 268, rect.left - 120)), top: Math.max(8, rect.top - 66) });
      onPointerEnter();
    };
    const hide = () => { setPoint(null); onPointerLeave(); };
    return <div data-matrix-cell={`${p1.id}-${p2.id}`} tabIndex={focusable ? 0 : -1}
      aria-label={label} className={classNames(styles.cell, { [styles.highlight]: highlight })}
      onPointerEnter={e => show(e.currentTarget)} onPointerLeave={hide}
      onFocus={e => show(e.currentTarget)} onBlur={hide}
      onKeyDown={e => { if (e.key === "Escape") hide(); }}>
      <div className={styles.content} style={{ opacity, backgroundColor: color }} />
      {point && createPortal(<div role="tooltip" className={styles.matrixTooltip} style={point}>{label}</div>, document.body)}
    </div>;
  }
  return (
    <div
      className={classNames(styles.cell, { [styles.highlight]: highlight })}
      onPointerEnter={onPointerEnter}
      onPointerLeave={onPointerLeave}
    >
      <Tooltip
        onHoverText={formatTime(sharedToi)}
        style={{ width: "100%", height: "100%" }}
      >
        <div
          className={styles.content}
          style={{
            opacity: opacity,
            backgroundColor: color
          }}
        ></div>
      </Tooltip>
    </div>
  );
}

type PPTOIComparasionProps = {
  /**
   *  Average PPTOI in seconds
   */
  AVG_PPTOI1: number;
  /**
   * Average PPTOI in seconds
   */
  AVG_PPTOI2: number;
};

const PP1_COLOR = "#0167C1";
const PP2_COLOR = "#D55008";

function PPTOIComparasion({ AVG_PPTOI1, AVG_PPTOI2 }: PPTOIComparasionProps) {
  const total = AVG_PPTOI1 + AVG_PPTOI2;
  const pp1Percent = total > 0 ? (AVG_PPTOI1 / total) * 100 : 0;
  const pp2Percent = total > 0 ? (AVG_PPTOI2 / total) * 100 : 0;
  return (
    <div className={styles.comparisonBar}>
      {/* average PPTOI comparasion*/}
      <div className={styles.comparisonBarContent}>
        <div className={styles.comparisonBarLeft}>
          <div style={{ color: PP1_COLOR }}>{formatTime(AVG_PPTOI1)} PPTOI</div>
        </div>
        <div className={styles.comparisonBarRight}>
          <div style={{ color: PP2_COLOR }}>{formatTime(AVG_PPTOI2)} PPTOI</div>
        </div>
      </div>

      {/* comparasion bar */}

      <div className={styles.comparisonBarBar}>
        {/* Left Section */}
        <div className={styles.comparisonBarLeftSection}>
          <div>PP1</div>
          <div>{pp1Percent.toFixed(1)}%</div>
        </div>

        <div className={styles.comparisonBarRightSection}>
          <div>PP2</div>
          <div>{pp2Percent.toFixed(1)}%</div>
        </div>
      </div>
    </div>
  );
}
