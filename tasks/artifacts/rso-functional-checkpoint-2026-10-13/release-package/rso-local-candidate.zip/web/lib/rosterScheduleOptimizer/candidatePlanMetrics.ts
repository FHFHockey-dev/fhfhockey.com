import { contributionLedger } from "./contributionLedger";
import { normalizeEligibility } from "./eligibility";
import { candidateAcquisitionSteps, evaluatePlan } from "./planning";
import { expandActiveSlots } from "./slots";
import type { PlanEvaluation, PlanIntent, PlanningSnapshot, PlanStep } from "./planningTypes";

export type CandidatePlan = {
  objective: "agp" | "outcome"; steps: PlanStep[];
  netAGP: number | null; netPoints: number | null;
  dropped: Array<{ playerId: string; lostAGP: number | null; lostPoints: number | null }>;
  displacedPlayerIds: string[];
};
export type CandidateComparison = { playerId: string; plans: CandidatePlan[]; complete: boolean };
export type CandidatePlanOptions = { maxCandidates?: number; maxEvaluations?: number; maxProposalsPerCandidate?: number };

const number = (value: number | null) => value ?? -Infinity;
const dropped = (plan: CandidatePlan) => plan.steps.some(step => step.dropPlayerId);
export function compareCandidatePlans(a: CandidatePlan, b: CandidatePlan, sort: "points" | "schedule") {
  const primary = sort === "points" ? number(b.netPoints) - number(a.netPoints) : number(b.netAGP) - number(a.netAGP);
  if (primary && !Number.isNaN(primary)) return primary;
  const secondary = sort === "points" ? number(b.netAGP) - number(a.netAGP) : number(b.netPoints) - number(a.netPoints);
  if (secondary && !Number.isNaN(secondary)) return secondary;
  return Number(dropped(a)) - Number(dropped(b)) || a.steps.length - b.steps.length
    || a.steps.map(step => step.id).join("|").localeCompare(b.steps.map(step => step.id).join("|"));
}
export function candidatePlanForSort(plans: CandidatePlan[], sort: "points" | "schedule") {
  return [...plans].sort((a, b) => compareCandidatePlans(a, b, sort))[0];
}

/** One acquisition with its necessary reserve/drop, not an unbounded sequence search. */
export function candidatePlanMetrics(snapshot: PlanningSnapshot, intent: PlanIntent, options: CandidatePlanOptions = {}) {
  const bounded = (value: number | undefined, fallback: number, cap: number) =>
    Number.isFinite(value) ? Math.max(0, Math.min(cap, Math.floor(value!))) : fallback;
  const maxCandidates = bounded(options.maxCandidates, 40, 40);
  const maxEvaluations = Math.max(2, bounded(options.maxEvaluations, 160, 240));
  const maxProposals = bounded(options.maxProposalsPerCandidate, 12, 24);
  const originalIntent = { ...intent, steps: [] };
  const agpBaseline = evaluatePlan(snapshot, originalIntent, "agp", [], false);
  const outcomeBaseline = evaluatePlan(snapshot, originalIntent, "outcome", [], false);
  const baseline = snapshot.rules.scoring.mode === "points" && outcomeBaseline.comparisonEligible
    ? outcomeBaseline : agpBaseline;
  const baselineLedger = contributionLedger(snapshot, baseline, originalIntent);
  const capacity = expandActiveSlots(snapshot.rules.rosterSlots);
  const vacant = snapshot.roster.filter(row => !["IR", "IR+", "NA"].includes(row.position)).length
    < capacity.activeSlots.length + capacity.benchCapacity;
  const owned = new Set(snapshot.roster.map(row => row.playerId));
  const eligible = [...new Map(snapshot.players.map(player => [player.id, player])).values()].filter(player =>
    !owned.has(player.id) && !intent.excludedPlayerIds.includes(player.id) && player.eligibilityVerified === true
    && normalizeEligibility(player.eligiblePositions).valid
    && normalizeEligibility(player.eligiblePositions).playerClass === player.playerClass
    && ["free_agent", "manager_available", "waivers"].includes(player.availability)
    && snapshot.games.some(game => game.status === "scheduled" && game.teamAbbreviation === player.teamAbbreviation
      && game.date >= snapshot.context.startDate && game.date <= snapshot.context.endDate))
    .sort((a, b) => a.id.localeCompare(b.id));
  const selected = eligible.slice(0, maxCandidates);
  const comparisons: CandidateComparison[] = selected.map(player => ({ playerId: player.id, plans: [], complete: false }));
  const iterators = selected.map(player => candidateAcquisitionSteps(snapshot, originalIntent, player));
  const proposals = selected.map(() => 0);
  const finished = selected.map(() => false);
  let evaluated = 2;
  const objectives = outcomeBaseline.comparisonEligible ? ["agp", "outcome"] as const : ["agp"] as const;
  const scheduleKnown = baseline.legal && !snapshot.rules.unsupported.length && snapshot.evidence.schedule?.completeness === "complete";
  const retain = (index: number, evaluation: PlanEvaluation) => {
    if (!evaluation.legal || !evaluation.budgetVerified) return;
    const pointsKnown = scheduleKnown && snapshot.rules.scoring.mode === "points" && baseline.comparisonEligible && evaluation.comparisonEligible
      && baseline.projectedValue != null && evaluation.projectedValue != null
      && Number.isFinite(baseline.projectedValue) && Number.isFinite(evaluation.projectedValue)
      && Number.isFinite(evaluation.projectedValue - baseline.projectedValue);
    const plan: CandidatePlan = { objective: evaluation.objective, steps: evaluation.steps,
      netAGP: scheduleKnown ? evaluation.activeGames - baseline.activeGames : null,
      netPoints: pointsKnown ? evaluation.projectedValue! - baseline.projectedValue! : null,
      dropped: [], displacedPlayerIds: [...new Set(baseline.assignments.filter(row => !evaluation.assignments.some(next =>
        next.date === row.date && next.gameId === row.gameId && next.playerId === row.playerId && next.slotId === row.slotId)).map(row => row.playerId))].sort() };
    const rows = comparisons[index].plans;
    const dominates = (a: CandidatePlan, b: CandidatePlan) => a.netAGP != null && b.netAGP != null
      && a.netPoints != null && b.netPoints != null && a.netAGP >= b.netAGP && a.netPoints >= b.netPoints
      && (a.netAGP > b.netAGP || a.netPoints > b.netPoints || compareCandidatePlans(a, b, "points") <= 0);
    if (rows.some(row => dominates(row, plan))) return;
    const after = contributionLedger(snapshot, evaluation, originalIntent);
    plan.dropped = evaluation.steps.flatMap(step => step.dropPlayerId ? [step.dropPlayerId] : []).map(playerId => {
      const before = baselineLedger.get(playerId), retained = after.get(playerId);
      return { playerId, lostAGP: before?.activeGames != null && retained?.activeGames != null ? before.activeGames - retained.activeGames : null,
        lostPoints: before?.projectedPoints != null && retained?.projectedPoints != null ? before.projectedPoints - retained.projectedPoints : null };
    });
    comparisons[index].plans = [...rows.filter(row => !dominates(plan, row)), plan];
  };
  // Round-robin work lets every selected candidate reach its first legal swap before expanding.
  while (evaluated + objectives.length <= maxEvaluations && finished.some(value => !value)) {
    for (let index = 0; index < selected.length; index++) {
      if (finished[index] || evaluated + objectives.length > maxEvaluations) continue;
      let next = iterators[index].next();
      // A full roster cannot use an add-only proposal. Reserve prerequisites still compete before drops.
      while (!next.done && !vacant && next.value.length === 1 && !next.value[0].dropPlayerId) {
        proposals[index]++;
        if (proposals[index] >= maxProposals) break;
        next = iterators[index].next();
      }
      if (next.done) { finished[index] = true; comparisons[index].complete = true; continue; }
      if (proposals[index] >= maxProposals) { finished[index] = true; continue; }
      proposals[index]++;
      for (const objective of objectives) {
        retain(index, evaluatePlan(snapshot, originalIntent, objective, next.value, false)); evaluated++;
      }
      if (proposals[index] >= maxProposals) finished[index] = true;
    }
  }
  const representative = comparisons.map(row => ({ playerId: row.playerId, plan: candidatePlanForSort(row.plans, "points") }));
  const activePoints = representative.map(({ playerId, plan }): [string, number | null] => [playerId, plan?.netPoints ?? null]);
  return { candidates: comparisons, points: activePoints, activePoints,
    activeGames: representative.map(({ playerId, plan }): [string, number | null] => [playerId, plan?.netAGP ?? null]),
    baseline: { objective: baseline.objective, activeGames: baseline.activeGames,
      projectedPoints: snapshot.rules.scoring.mode === "points" && baseline.comparisonEligible ? baseline.projectedValue : null },
    search: { evaluated, maxEvaluations, candidates: selected.length, eligibleCandidates: eligible.length, maxCandidates,
      maxProposalsPerCandidate: maxProposals, complete: selected.length === eligible.length && comparisons.every(row => row.complete) } };
}
