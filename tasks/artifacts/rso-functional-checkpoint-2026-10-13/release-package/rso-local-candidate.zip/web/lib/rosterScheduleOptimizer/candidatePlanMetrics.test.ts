import { describe, expect, it } from "vitest";
import { candidatePlanMetrics as candidateMetrics, candidatePlanForSort } from "./candidatePlanMetrics";
import { defaultIntent, defaultWorkspace } from "./workspace";
import type { GameForecast, PlanningSnapshot } from "./planningTypes";

function fixture(): PlanningSnapshot {
  const workspace = defaultWorkspace(new Date("2026-10-04T12:00:00Z"));
  const players = ["a", "b", "c"].map((id, index) => ({ id, nhlId: index + 1, nhlTeamId: index + 1,
    rosterRevision: `roster-${id}`, name: id, teamAbbreviation: id.toUpperCase(), eligiblePositions: ["C"],
    eligibilityVerified: true, playerClass: "skater" as const, availability: id === "c" ? "free_agent" as const : "rostered" as const,
    canDrop: true, ownership: null, holdValue: null, reserveEligibility: [] }));
  const games = players.map(row => { const date = row.id === "c" ? "2026-10-05" : "2026-10-06";
    return { id: row.id, date, startsAt: `${date}T20:00:00Z`, scheduleRevision: `schedule-${row.id}`,
      teamAbbreviation: row.teamAbbreviation, opponent: "X", home: true, status: "scheduled" as const }; });
  const snapshot: PlanningSnapshot = { id: "net-candidate-fixture", context: { ...workspace.context, startDate: "2026-10-05", endDate: "2026-10-06", timeZone: "UTC" },
    players, roster: [{ playerId: "a", position: "active" }, { playerId: "b", position: "bench" }], games, forecasts: [],
    rules: { ...workspace.rules, rosterSlots: { C: 1, BN: 1 }, acquisitionTiming: "same_day", acquisitionCost: 1,
      periods: [{ id: "week", start: "2026-10-04T00:00:00Z", end: "2026-10-08T00:00:00Z", remaining: 1, source: "manager" }],
      scoring: { mode: "points", weights: { GOALS: 1 }, categories: [] } }, lockedAssignments: [], realized: {}, opponent: null,
    evidence: { schedule: { source: "Local fixture", asOf: workspace.context.asOf, seasonId: workspace.context.seasonId, completeness: "complete", limitations: [] } } };
  snapshot.forecasts = players.map(row => {
    const game = games.find(game => game.id === row.id)!;
    return { playerId: row.id, gameId: game.id, stats: { GOALS: row.id === "a" ? 10 : row.id === "b" ? 1 : 2 },
      conditioning: "unconditional", sourceKind: "detailed", sourceWatermark: "fixture-only", cutoffAt: snapshot.context.asOf,
      issuedAt: snapshot.context.asOf, expiresAt: game.startsAt, revisionId: `revision-${row.id}`, modelVersion: "fixture",
      startProbability: null, confirmedStart: false, allowedUses: { assignment: true, totals: true, comparison: true, conditionalTieBreak: false }, limitations: [],
      issuedContext: { version: "forge-issued-context-v1", playerId: row.id, gameId: game.id, nhlPlayerId: row.nhlId, teamId: row.nhlTeamId,
        seasonId: snapshot.context.seasonId, scheduledAt: game.startsAt, scheduleRevision: game.scheduleRevision, rosterRevision: row.rosterRevision,
        observedAt: snapshot.context.asOf, scheduleSourceUpdatedAt: snapshot.context.asOf, scheduleFetchedAt: snapshot.context.asOf,
        identityUpdatedAt: snapshot.context.asOf, membershipCreatedAt: ["2026-09-01T00:00:00Z"] } } as GameForecast;
  });
  return snapshot;
}

describe("complete timed candidate metrics", () => {
  it("includes lost drop contribution and the remaining roster's reshuffling, rather than crediting an extra place", () => {
    const snapshot = fixture();
    const intent = { ...defaultIntent(), protectedPlayerIds: ["b"] };
    const before = JSON.stringify({ snapshot, intent });
    const metrics = candidateMetrics(snapshot, intent);
    expect(new Map(metrics.activePoints).get("c")).toBe(-7);
    const plan = metrics.candidates[0].plans[0];
    expect(plan).toMatchObject({ netAGP: 1, netPoints: -7, dropped: [{ playerId: "a", lostAGP: 1, lostPoints: 10 }] });
    expect(plan.displacedPlayerIds).toContain("a");
    expect(JSON.stringify({ snapshot, intent })).toBe(before);
  });

  it("uses a real vacancy before an equivalent forced drop", () => {
    const snapshot = fixture(); snapshot.rules.rosterSlots.BN = 2;
    const metrics = candidateMetrics(snapshot, defaultIntent());
    const plan = candidatePlanForSort(metrics.candidates[0].plans, "points")!;
    expect(plan).toMatchObject({ netAGP: 1, netPoints: 2, dropped: [] });
    expect(plan.steps).toHaveLength(1);
    expect(plan.steps[0].dropPlayerId).toBeUndefined();
  });

  it("does not credit a candidate duplicating crowded bench dates as a net gain", () => {
    const snapshot = fixture();
    moveGame(snapshot, "c", "2026-10-06");
    const plan = candidatePlanForSort(candidateMetrics(snapshot, { ...defaultIntent(), protectedPlayerIds: ["a"] }).candidates[0].plans, "points")!;
    expect(plan).toMatchObject({ netAGP: 0, netPoints: 0 });
  });

  it("reassigns dual eligibility and includes the dropped player's actual lost starts", () => {
    const snapshot = fixture();
    moveGame(snapshot, "c", "2026-10-06");
    snapshot.players[0].eligiblePositions = ["C", "LW"];
    snapshot.players[2].eligiblePositions = ["LW"];
    snapshot.rules.rosterSlots = { C: 1, LW: 1, BN: 0 };
    snapshot.forecasts.find(row => row.playerId === "c")!.stats.GOALS = 20;
    const plan = candidatePlanForSort(candidateMetrics(snapshot, { ...defaultIntent(), protectedPlayerIds: ["a"] }).candidates[0].plans, "points")!;
    expect(plan).toMatchObject({ netAGP: 0, netPoints: 19, dropped: [{ playerId: "b", lostAGP: 1, lostPoints: 1 }] });
    expect(plan.displacedPlayerIds).toEqual(["a", "b"]);
  });

  it("respects next-day timing instead of claiming today's game", () => {
    const snapshot = fixture(); snapshot.context.asOf = "2026-10-05T12:00:00Z"; snapshot.rules.acquisitionTiming = "next_day";
    expect(candidateMetrics(snapshot, defaultIntent()).candidates[0].plans).toEqual([]);
  });

  it("keeps legal reserve prerequisites ahead of equivalent drops", () => {
    const snapshot = fixture(); snapshot.players[0].reserveEligibility = ["IR"];
    snapshot.rules.rosterSlots.IR = 1;
    const plan = candidatePlanForSort(candidateMetrics(snapshot, { ...defaultIntent(), protectedPlayerIds: ["b"] }).candidates[0].plans, "points")!;
    expect(plan.steps.map(row => row.type)).toEqual(["reserve", "add"]);
    expect(plan.dropped).toEqual([]);
    expect(plan).toMatchObject({ netAGP: 1, netPoints: -7 });
  });

  it.each(["no budget", "unknown allowance", "unknown timing", "protected", "locked", "excluded", "invalid eligibility"])("withholds dependent plans for %s", problem => {
    const snapshot = fixture(); const intent = defaultIntent();
    if (problem === "no budget") snapshot.rules.periods[0].remaining = 0;
    if (problem === "unknown allowance") snapshot.rules.periods[0].remaining = null;
    if (problem === "unknown timing") snapshot.rules.acquisitionTiming = "unknown";
    if (problem === "protected") intent.protectedPlayerIds = ["a", "b"];
    if (problem === "locked") { intent.protectedPlayerIds = ["b"]; snapshot.lockedAssignments = [{ date: "2026-10-06", playerId: "a", slotId: "C#1" }]; }
    if (problem === "excluded") intent.excludedPlayerIds = ["c"];
    if (problem === "invalid eligibility") snapshot.players[2].eligiblePositions = ["UNSUPPORTED"];
    expect(candidateMetrics(snapshot, intent).candidates.every(row => !row.plans.length)).toBe(true);
  });

  it.each(["conditional", "missing", "unsupported", "partial schedule", "categories"])("does not fabricate net points for %s", problem => {
    const snapshot = fixture();
    if (problem === "conditional") snapshot.forecasts.find(row => row.playerId === "c")!.conditioning = "conditional_playing" as GameForecast["conditioning"];
    if (problem === "missing") snapshot.forecasts = snapshot.forecasts.filter(row => row.playerId !== "c");
    if (problem === "unsupported") snapshot.rules.unsupported = ["Unverified league rule"];
    if (problem === "partial schedule") snapshot.evidence.schedule!.completeness = "partial";
    if (problem === "categories") snapshot.rules.scoring = { mode: "categories", weights: {}, categories: [{ key: "GOALS", direction: "higher" }] };
    const metrics = candidateMetrics(snapshot, defaultIntent());
    expect(metrics.candidates[0].plans.length).toBeGreaterThan(0);
    expect(metrics.candidates[0].plans.every(row => row.netPoints === null)).toBe(true);
    if (problem === "unsupported" || problem === "partial schedule") expect(metrics.candidates[0].plans.every(row => row.netAGP === null)).toBe(true);
  });

  it("retains AGP-versus-points tradeoffs as separate actual plan pairs", () => {
    const snapshot = fixture(); snapshot.rules.rosterSlots.BN = 2;
    snapshot.forecasts.find(row => row.playerId === "c")!.stats.GOALS = -2;
    const plans = candidateMetrics(snapshot, defaultIntent()).candidates[0].plans;
    expect(candidatePlanForSort(plans, "points")).toMatchObject({ netAGP: 0, netPoints: 0 });
    expect(candidatePlanForSort(plans, "schedule")).toMatchObject({ netAGP: 1, netPoints: -2 });
  });

  it("caps a 1000-candidate catalogue and remains deterministic without a broad sequence search", () => {
    const snapshot = fixture();
    for (let i = 0; i < 999; i++) snapshot.players.push({ ...snapshot.players[2], id: `candidate-${String(i).padStart(4, "0")}`, nhlId: 1000 + i });
    const options = { maxCandidates: 4, maxEvaluations: 18, maxProposalsPerCandidate: 3 };
    const result = candidateMetrics(snapshot, defaultIntent(), options);
    expect(result.search).toMatchObject({ candidates: 4, eligibleCandidates: 1000, complete: false });
    expect(result.search.evaluated).toBeLessThanOrEqual(18);
    const reversed = { ...snapshot, players: [...snapshot.players].reverse(), games: [...snapshot.games].reverse(), forecasts: [...snapshot.forecasts].reverse() };
    expect(candidateMetrics(reversed, defaultIntent(), options)).toEqual(result);
  });
});

function moveGame(snapshot: PlanningSnapshot, id: string, date: string) {
  const game = snapshot.games.find(row => row.id === id)!;
  game.date = date; game.startsAt = `${date}T20:00:00Z`;
  const forecast = snapshot.forecasts.find(row => row.gameId === id)!;
  forecast.expiresAt = game.startsAt; forecast.issuedContext!.scheduledAt = game.startsAt;
}
