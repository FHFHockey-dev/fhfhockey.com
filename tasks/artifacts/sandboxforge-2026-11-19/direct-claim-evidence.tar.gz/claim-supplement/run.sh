#!/bin/bash
set -euo pipefail
cd /workspace/scratch/forge-preflight
sha=f886ddac731ae825a12fab915848d2b5fd7d9b8c
test "$(git -C checkout-v4 rev-parse HEAD)" = "$sha"
for file in checkout-v4/supabase/migrations/*.sql checkout-v4/supabase/tests/*.py; do
  test "$(git hash-object "$file")" = "$(git -C checkout-v4 rev-parse "$sha:${file#checkout-v4/}")"
done
tar -cf - checkout-v4/supabase/migrations checkout-v4/supabase/tests/forge_{hosted_control,pregame_publication}.py claim-supplement/claim.py |
env -i PATH=/usr/local/bin:/usr/bin:/bin docker -H unix:///var/run/docker.sock run -i --rm --pull=never --network=none --read-only --cap-drop=ALL --security-opt=no-new-privileges --user postgres --tmpfs /tmp:rw,mode=1777 --entrypoint /usr/bin/env sha256:4203f88e88cc028b6bb78804c6d62ec6b117c31ce7be048b21621a4cc62067ff -i PATH=/usr/bin:/bin FORGE_TEST_PG_BIN=/usr/lib/postgresql/15/bin LC_ALL=C TZ=UTC sh -ec 'cd /tmp; tar -xf -; exec python3 -I claim-supplement/claim.py'
