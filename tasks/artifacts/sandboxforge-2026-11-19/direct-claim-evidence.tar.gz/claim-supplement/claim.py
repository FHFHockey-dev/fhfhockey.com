import json
import socket
import sys
from pathlib import Path

sys.path.insert(0, "/tmp/checkout-v4/supabase/tests")
import forge_hosted_control as h

rpc = """select outcome, claim_id from public.forge_pregame_hosted_claim_v2(
    %s,%s,%s,%s,%s::smallint,%s::smallint,%s,%s,%s,%s)"""
lookup = "select claim_id from public.forge_pregame_capture_lookup_v1(%s,%s)"
state = "select count(*), (array_agg(id))[1] from forge_pregame_capture.claims"

assert [name for _, name in socket.if_nameindex()] == ["lo"]
with h.publication_db() as connect, connect() as owner:
    h.setup(owner)
    h.arm(owner)
    h.ready(owner)
    assert h.tick(owner) == "capture"
    dispatch = h.stage_id(owner, "capture")
    with connect("service_role") as first, connect("service_role") as retry:
        identities = [h.row(c, "select pg_backend_pid(), current_user") for c in (first, retry)]
        assert identities[0][0] != identities[1][0]
        assert all(role == "service_role" for _, role in identities)
        admitted = h.capture_begin(first, dispatch)
        assert admitted["status"] == "started"
        game, policy = admitted["game_id"], admitted["policy_id"]
        binding = (dispatch, game, policy, admitted["slate_date"], 10, 6, h.CALENDAR,
                   admitted["scheduled_start"], 160000, h.SHA)
        assert h.row(owner, state) == (0, None)
        assert first.autocommit and retry.autocommit
        with first.cursor() as cursor:
            cursor.execute(rpc, binding)
            # Discard the entire first result. Only the independent observer records its effect.
        before_retry, committed_id = h.row(owner, state)
        assert before_retry == 1 and committed_id
        disposition, duplicate_id = h.row(retry, rpc, binding)
        assert (disposition, duplicate_id) == ("duplicate", None)
        recovered, = h.row(retry, lookup, (game, policy))
        after_lookup, final_id = h.row(owner, state)
        linked, = h.row(owner, "select claim_id from forge_pregame_capture.hosted_runs where game_id=%s", (game,))
        assert after_lookup == 1 and recovered == committed_id == final_id == linked
        print(json.dumps(dict(passed=True, mode="sequential", dispatch=dispatch, game=game, policy=policy,
                              backend_pids=[pid for pid, _ in identities], roles=[role for _, role in identities],
                              first_reply="discarded without fetching", committed_claim=committed_id,
                              second_outcome=disposition, second_claim_id=duplicate_id,
                              lookup_claim=recovered, hosted_run_claim=linked,
                              claim_counts=[0, before_retry, after_lookup]), indent=2))
