const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const {gunzipSync} = require('node:zlib');
const {performance} = require('node:perf_hooks');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
assert.deepEqual(fs.readdirSync('/sys/class/net'), ['lo']);
assert.equal(fs.readFileSync('/proc/net/route','utf8').trim().split('\n').length, 1);
const raw = fs.readFileSync('/tmp/original.gz');
assert.equal(raw.length,187301);
assert.equal(hash(raw),'3a76caf5e5ad1485d3638ae13b8a2a432dd7578703ea09a188608029ff4d4a9b');
const {packet,rawSha256,canonicalSha256} = require('./lib/projections/pregameCapture/packet').decodePacket(raw);
const json = gunzipSync(raw);
assert.equal(hash(json),canonicalSha256);
assert.equal(canonicalSha256,'bf9041ca164e2cef73ee984237560caab82181892ad2b62e85fa0b34c0822d56');
assert.equal(packet.binding.codeVersion,'83750b4abd672399113659b96c279a1ddaeb425b');
assert.equal(packet.binding.gameId,2026020336);
assert.equal(packet.binding.homeAbbrev,'NYI');
assert.equal(packet.binding.awayAbbrev,'CBJ');
assert.equal(packet.reads.length,187);
const fields=['FORGE_SKATER_MODEL_MODE','NHL_XG_TEAM_AGGREGATE_MODEL_VERSION',
  'NHL_XG_TEAM_AGGREGATE_FEATURE_VERSION','NHL_XG_TEAM_AGGREGATE_WINDOW_GAMES','NHL_XG_MODEL_VERSION',
  'START_CHART_GAME_REVISIONS','STARTER_BOARD_COMPUTE_ENABLED','STARTER_BOARD_SEASON_BOOTSTRAP_ENABLED'].sort();
assert.deepEqual(Object.keys(packet.modelEnvironment).sort(),fields);
assert.equal(packet.modelEnvironment.STARTER_BOARD_COMPUTE_ENABLED,'false');
for(const field of fields){
  const value=packet.modelEnvironment[field];
  if(value===null) delete process.env[field];
  else {assert.equal(typeof value,'string'); process.env[field]=value;}
}
process.env.STARTER_BOARD_CANARY_GAME_IDS=String(packet.binding.gameId);
const RealDate=Date, anchor=Date.parse(packet.statedCutoff)+1000, zero=performance.now();
assert(anchor<Date.parse(packet.binding.scheduledStart));
global.Date=class extends RealDate {
  constructor(...args){super(...(args.length ? args : [global.Date.now()]));}
  static now(){return anchor+Math.floor(performance.now()-zero);}
};
global.fetch=()=>{throw Error('live_fetch_forbidden');};
const modelPath=require.resolve('./lib/projections/run-forge-projections');
assert(!require.cache[modelPath]);
const model=require(modelPath);
assert.equal(typeof model.computeForgePregamePublication,'undefined');
assert.equal(typeof model.replayForgeSnapshot,'function');
const actual=model.projectionModelEnvironment();
assert.deepEqual(actual,packet.modelEnvironment);
const {projectionInputHash}=require('./lib/projections/inputCapture');
const expected=projectionInputHash(packet.modelEnvironment);
assert.equal(projectionInputHash(actual),expected);
assert.equal(process.argv[2],'/tmp/native.json');
fs.writeFileSync(process.argv[2],json,{mode:0o600,flag:'wx'});
assert.equal(hash(fs.readFileSync(process.argv[2])),canonicalSha256);
fs.writeFileSync('/tmp/harness.json',JSON.stringify({bindingMatchesRelease:true,game:packet.binding.gameId,
  rawBytes:raw.length,rawSha256,canonicalSha256,cliArgumentSha256:canonicalSha256,recordedReads:packet.reads.length,
  fieldCount:fields.length,modelEnvironmentKeys:fields,currentModelEnvironmentHash:projectionInputHash(actual),
  recordedModelEnvironmentHash:expected,computeSetting:actual.STARTER_BOARD_COMPUTE_ENABLED,
  fakeClockAnchor:new RealDate(anchor).toISOString(),fakeClockAdvances:true,
  observationPayloadPresent:Object.hasOwn(packet,'payload'),observationPayloadHashPresent:Object.hasOwn(packet,'payload_hash'),
  node:process.version,linuxKernel:os.release(),architecture:os.arch(),uid:process.getuid(),interfaces:['lo'],ipv4Routes:0}));
