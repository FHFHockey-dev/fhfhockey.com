import json,os,subprocess
from pathlib import Path
argv=['node','-r','ts-node/register/transpile-only','-r','./preload.cjs','scripts/replay-forge-snapshot.ts','/tmp/native.json']
p=subprocess.run(argv,capture_output=True,env={**os.environ,'NODE_V8_COVERAGE':'/tmp/coverage'})
expected=b'Expected a source observation containing payload and payload_hash.\n'
if (p.returncode,p.stdout,p.stderr)!=(1,b'',expected):
 import hashlib
 raise RuntimeError(f'unexpected CLI disposition: {p.returncode}, stderr SHA256 {hashlib.sha256(p.stderr).hexdigest()}, harness completed={Path("/tmp/harness.json").exists()}')
counts={}
for file in Path('/tmp/coverage').glob('*.json'):
 for mod in json.loads(file.read_text())['result']:
  if mod['url'].endswith(('/scripts/replay-forge-snapshot.ts','/lib/projections/run-forge-projections.ts','/lib/projections/inputCapture.ts')):
   for f in mod['functions']:
    name=f['functionName']
    if name in ('main','projectionModelEnvironment','replayForgeSnapshot','replayProjectionInputs','runProjectionCalculations'):
     counts[name]=f['ranges'][0]['count']
assert counts['replayForgeSnapshot']==counts['replayProjectionInputs']==counts['runProjectionCalculations']==0,counts
assert counts['main']==1 and counts['projectionModelEnvironment']==1,counts
print(json.dumps(dict(harness=json.loads(Path('/tmp/harness.json').read_text()),cli=dict(argv=argv,exit=p.returncode,stdout='',stderr=p.stderr.decode(),gate='source-observation format',source='web/scripts/replay-forge-snapshot.ts:10',condition='!observation.payload || typeof observation.payload_hash !== "string"',coverageCalls=counts),model=dict(environmentGateReached=False,computeGateReached=False,queryGateReached=False,readsConsumed=0,queriesMissed=0,projectionWrites=0,forecasts=0)),indent=2))
