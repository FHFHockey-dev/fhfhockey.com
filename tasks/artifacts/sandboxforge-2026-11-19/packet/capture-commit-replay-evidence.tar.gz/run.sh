#!/bin/bash
set -euo pipefail
umask 077
base=/workspace/scratch/forge-preflight
cd "$base/original-release"
test "$(git -C checkout rev-parse HEAD)" = 83750b4abd672399113659b96c279a1ddaeb425b
test "$(git -C checkout rev-parse 'HEAD^{tree}')" = 79074035caf33d6993a6e4efc9bdd5e555f8ea1c
while IFS= read -r p; do
  test "$(git -C checkout hash-object "$p")" = "$(git -C checkout rev-parse "HEAD:$p")"
done < transfer/source-paths.txt
tar -cf - -C checkout -T "$PWD/transfer/source-paths.txt" -C "$PWD" invoke.py preload.cjs -C "$base/historical-replay" original.gz |
env -i PATH=/usr/local/bin:/usr/bin:/bin docker -H unix:///var/run/docker.sock run -i --rm --pull=never --network=none --read-only --cap-drop=ALL --security-opt=no-new-privileges --user postgres --tmpfs /tmp:rw,mode=1777 --entrypoint /usr/bin/env sha256:4203f88e88cc028b6bb78804c6d62ec6b117c31ce7be048b21621a4cc62067ff -i PATH=/opt/node/bin:/usr/bin:/bin HOME=/tmp LC_ALL=C TZ=UTC NODE_PATH=. TS_NODE_COMPILER_OPTIONS='{"module":"commonjs","moduleResolution":"node"}' NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:1 NEXT_PUBLIC_SUPABASE_PUBLIC_KEY=offline-fixture SUPABASE_SERVICE_ROLE_KEY=offline-fixture sh -ec 'umask 077; cd /tmp; tar -xf -; mv preload.cjs web/; cd web; cmp package-lock.json /deps/package-lock.json; ln -s /deps/node_modules node_modules; test "$(node -v)" = v22.23.4; test "$(npm -v)" = 10.9.9; exec python3 -I /tmp/invoke.py'
