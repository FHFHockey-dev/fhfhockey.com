'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const os = require('node:os');
const {performance} = require('node:perf_hooks');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const evidence = JSON.parse(fs.readFileSync('/tmp/attestation.json'));
const emit = (status, detail, code) => {
  fs.writeSync(1, JSON.stringify({...evidence, status, ...detail}, null, 2) + '\n');
  process.exit(code);
};
async function run() {
  assert.deepEqual(fs.readdirSync('/sys/class/net'), ['lo']);
  assert.equal(fs.readFileSync('/proc/net/route','utf8').trim().split('\n').length, 1);
  evidence.runtime = {kernel:os.release(), arch:os.arch(), node:process.version, uid:process.getuid(),
    interfaces:['lo'], ipv4Routes:0, dockerNetwork:'none'};
  const raw = fs.readFileSync('/tmp/original.gz');
  assert.equal(raw.length,187301);
  assert.equal(sha(raw),'3a76caf5e5ad1485d3638ae13b8a2a432dd7578703ea09a188608029ff4d4a9b');
  const {packet, canonicalSha256, rawSha256} = require('./lib/projections/pregameCapture/packet').decodePacket(raw);
  assert.equal(canonicalSha256,'bf9041ca164e2cef73ee984237560caab82181892ad2b62e85fa0b34c0822d56');
  assert.equal(packet.binding.gameId,2026020336);
  assert.equal(packet.binding.codeVersion,'83750b4abd672399113659b96c279a1ddaeb425b');
  assert.equal(packet.reads.length,187);
  Object.assign(evidence,{gameId:packet.binding.gameId, captureLabel:packet.binding.codeVersion,
    input:{rawSha256, canonicalSha256, bytes:raw.length, recordedReads:packet.reads.length}});
  const flags=packet.modelEnvironment;
  const keys=Object.keys(flags).sort();
  assert.equal(keys.length,8);
  for (const key of keys) {
    assert.match(key,/^(FORGE_|START_CHART_|STARTER_BOARD_|NHL_XG_)[A-Z0-9_]+$/);
    if(flags[key]===null) delete process.env[key];
    else {assert.equal(typeof flags[key],'string'); process.env[key]=flags[key];}
  }
  process.env.STARTER_BOARD_CANARY_GAME_IDS=String(packet.binding.gameId);
  const realDate=Date;
  const epoch=realDate.parse(packet.statedCutoff)+1000, zero=performance.now();
  assert(epoch<realDate.parse(packet.binding.scheduledStart));
  class ReplayDate extends realDate {
    constructor(...args){super(...(args.length ? args : [ReplayDate.now()]));}
    static now(){return epoch+Math.floor(performance.now()-zero);}
  }
  globalThis.Date=ReplayDate;
  globalThis.fetch=()=>{emit('unexpected_network_attempt',{},2);};
  evidence.clock={anchor:new realDate(epoch).toISOString(), statedCutoff:packet.statedCutoff,
    start:packet.binding.scheduledStart, elapsedTimeAdvances:true};
  const source='lib/projections/inputCapture.ts';
  const marker='const message = `Unrecorded projection input: ${method} ${String(args[0])}`;';
  const original=fs.readFileSync(source,'utf8');
  assert.equal(original.split(marker).length,2);
  const injected=original.replace(marker,marker+'\n        globalThis.__observeForgeMiss(request,hash,context);');
  fs.writeFileSync(source,injected);
  evidence.observer={originalSha256:sha(original),instrumentedSha256:sha(injected),markerMatches:1};
  globalThis.__observeForgeMiss=(request,hash,context)=>{
    assert.equal(context.mode,'replay'); assert.equal(context.rejectUnrecordedReads,true);
    const shapes=context.reads.filter(r=>r.request[0].method===request[0].method &&
      r.request[0].args[0]===request[0].args[0]).map(r=>r.request.map(o=>({method:o.method,
        field:typeof o.args[0]==='string'?o.args[0]:null})));
    emit('first_unmatched_read',{request,requestHash:hash,consumed:context.consumed.size,
      compatibleRecordedShapes:[...new Set(shapes.map(s=>JSON.stringify(s)))].map(s=>JSON.parse(s))},21);
  };
  const model=require('./lib/projections/run-forge-projections');
  const {projectionInputHash}=require('./lib/projections/inputCapture');
  const runtime=model.projectionModelEnvironment(), expectedKeys=Object.keys(runtime).sort();
  const missing=expectedKeys.filter(k=>!Object.hasOwn(flags,k));
  assert(keys.every(k=>runtime[k]===flags[k]));
  evidence.environment={restoredKeys:keys,requiredKeys:expectedKeys,missingKeys:missing,
    recordedHash:projectionInputHash(flags),candidateHash:projectionInputHash(runtime)};
  let result;
  try {result=await model.computeForgePregamePublication(packet,{codeVersion:packet.binding.codeVersion});}
  catch(error){
    if(missing.length && error.message==='FORGE pregame packet code or model environment mismatch.') {
      emit('blocked_missing_model_metadata',{error:error.message,matchedReads:0,unmatchedRequest:null,
        calculationStarted:false,projectionWrites:0},20);
    }
    throw error;
  }
  const werenski=result.rows.players.find(r=>Number(r.player_id)===8478460);
  const projected={};
  if(werenski) for(const [key,value] of Object.entries(werenski))
    if(key.startsWith('projected_') && typeof value==='number') projected[key]=value;
  emit('calculated',{counts:Object.fromEntries(Object.entries(result.rows).map(([k,v])=>[k,v.length])),
    outputHash:result.outputHash,werenskiProjectedFields:projected},0);
}
run().catch(error=>emit('driver_error',{errorClass:error.name,errorFingerprint:sha(String(error.message)),
  location:(String(error.stack).split('\n').find(s=>s.includes(' at ')&&s.includes('/tmp/'))||'').trim()},2));
