#!/bin/bash
set -euo pipefail
umask 077
cd /workspace/scratch/forge-preflight
dir=historical-replay
image=sha256:4203f88e88cc028b6bb78804c6d62ec6b117c31ce7be048b21621a4cc62067ff
export IMAGE_ID="$image"
python3 -I - <<'PY'
from pathlib import Path
import subprocess as sp,hashlib,json,os
root=Path('checkout-v4')
def git(*args):return sp.check_output(['git','-C',str(root),*args],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
head=git('rev-parse','HEAD'); tree=git('rev-parse','HEAD^{tree}')
assert head=='f886ddac731ae825a12fab915848d2b5fd7d9b8c' and tree=='09ef9bf0662e14cd80fa60cee25c70a988e5c748'
paths=[s for s in Path('transfer-v2/source-paths.txt').read_text().splitlines() if s.startswith('web/') and '/__fixtures__/tsa/' not in s]
for s in paths:
 assert all(not p.startswith('.env') for p in Path(s).parts)
 assert git('hash-object',s)==git('rev-parse','HEAD:'+s),s
out=Path('historical-replay')
(out/'source-files.txt').write_text(''.join(s+'\n' for s in paths))
key=['lib/projections/run-forge-projections.ts','lib/projections/inputCapture.ts','lib/projections/pregameCapture/packet.ts','lib/projections/queries/skater-queries.ts','package-lock.json']
att=dict(candidate=head,tree=tree,verifiedWebFiles=len(paths),sourceHashes={s:sha(root/'web'/s) for s in key},image=os.environ['IMAGE_ID'])
(out/'attestation.json').write_text(json.dumps(att))
PY
tar -cf - -C checkout-v4 -T "$PWD/$dir/source-files.txt" -C "$PWD/$dir" driver.cjs attestation.json original.gz |
env -i PATH=/usr/local/bin:/usr/bin:/bin docker -H unix:///var/run/docker.sock run -i --rm --pull=never --network=none --read-only --cap-drop=ALL --security-opt=no-new-privileges --user postgres --tmpfs /tmp:rw,mode=1777 --entrypoint /usr/bin/env "$image" -i PATH=/opt/node/bin:/usr/bin:/bin HOME=/tmp LANG=C.UTF-8 TZ=UTC NODE_PATH=. TS_NODE_COMPILER_OPTIONS='{"module":"commonjs","moduleResolution":"node"}' STARTER_BOARD_COMPUTE_ENABLED=true NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:1 SUPABASE_SERVICE_ROLE_KEY=offline-fixture NEXT_PUBLIC_SUPABASE_PUBLIC_KEY=offline-fixture sh -ec 'umask 077; cd /tmp; tar -xf -; mv driver.cjs web/; cd web; ln -s /deps/node_modules node_modules; cmp package-lock.json /deps/package-lock.json; exec node -r ts-node/register/transpile-only driver.cjs'
