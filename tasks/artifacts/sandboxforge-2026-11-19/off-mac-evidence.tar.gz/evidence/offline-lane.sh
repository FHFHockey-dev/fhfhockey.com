#!/usr/bin/env bash
set -eu
umask 077
lane=$1
start=$2
cd /tmp
mkdir inputs result home
tar -xf - -C inputs
cd inputs/checkout-v4
mkdir web/node_modules
ln -s /deps/node_modules/* /deps/node_modules/.bin web/node_modules/
export FORGE_TEST_ARCHIVE_SHA=f886ddac731ae825a12fab915848d2b5fd7d9b8c
export FORGE_TEST_PG_BIN=/usr/lib/postgresql/15/bin
set +e
(
set -ex
test "$(ls /sys/class/net)" = lo
test "$(wc -l < /proc/net/route)" = 1
test "$(git rev-parse HEAD)" = "$FORGE_TEST_ARCHIVE_SHA"
node -v
npm -v
python3 -I -c 'import psycopg2; print(psycopg2.__version__)'
postgres --version
/tmp/inputs/postgrest --version
case "$lane" in
 synthetic) python3 -I tasks/artifacts/forge-offline-2026-11-18/rehearsal/bootstrap.py --start "$start" --check-postgrest /tmp/inputs/postgrest ;;
 controls) python3 -I supabase/tests/forge_hosted_control.py --with-route ;;
 daily) POSTGREST_BIN=/tmp/inputs/postgrest PG_BIN_DIR="$FORGE_TEST_PG_BIN" bash /tmp/inputs/daily-transfer/daily/run-postgrest.sh "$PWD" /tmp/result/daily ;;
 packet) mkdir -p tasks/artifacts/sandboxforge-2026-11-19 && cp -R /tmp/inputs/transfer-v2/aux/packet tasks/artifacts/sandboxforge-2026-11-19/packet
 web/node_modules/.bin/esbuild tasks/artifacts/sandboxforge-2026-11-19/packet/offline.ts --tsconfig=web/tsconfig.json --platform=node --target=node22 --bundle --log-level=warning --outfile=/tmp/offline.cjs
 node /tmp/offline.cjs reconstruct-fragment ;;
esac
) > /tmp/result/lane.log 2>&1
status=$?
echo "$status" > /tmp/result/exit-code
tar -cf - -C /tmp/result .
exit "$status"
