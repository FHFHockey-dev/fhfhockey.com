import csv,hashlib,io,pathlib,zipfile,shutil,subprocess,json
p=pathlib.Path
z=zipfile.ZipFile('full.zip')
m=list(csv.DictReader(io.StringIO(z.read('PATH-MANIFEST.tsv').decode()),delimiter='\t'))
assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())=={r['path'] for r in m}|{'PATH-MANIFEST.tsv'}
for r in m:
 n=r['path']; b=z.read(n)
 assert not p(n).is_absolute() and '..' not in p(n).parts and all(not s.startswith(('.env','.git/')) for s in p(n).parts)
 assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==int(r['bytes']),n
base=p('checkout-v2'); dst=p('checkout-v4'); shutil.copytree(base,dst)
tsa=p('web/lib/projections/pregameCapture/__fixtures__/tsa')
fresh={'ca.crt','tsa.crt','tsa.key','plain.crt','plain.key'}
compared=0
for line in p('transfer-v2/source-paths.txt').read_text().splitlines():
 path=p(line)
 if path.parent==tsa and path.name in fresh:
  (dst/path).unlink()
 elif line in z.NameToInfo:
  assert z.read(line)==(base/path).read_bytes(),line
  compared+=1
oracle=p('web/lib/projections/pregameCapture/__fixtures__/world/oracle')
for n in z.namelist():
 if str(oracle)+'/' in n:
  t=dst/n; t.parent.mkdir(parents=True,exist_ok=True); t.write_bytes(z.read(n))
def git_hash(kind,body):
 return hashlib.sha1(kind+b' '+str(len(body)).encode()+b'\0'+body).digest()
def tree(t):
 entries=[]
 for f in sorted(t.iterdir(),key=lambda f:f.name+('/' if f.is_dir() else '')):
  mode,h=(b'40000',tree(f)) if f.is_dir() else (b'100644',git_hash(b'blob',f.read_bytes()))
  entries.append(mode+b' '+f.name.encode()+b'\0'+h)
 return git_hash(b'tree',b''.join(entries))
actual=tree(dst/oracle).hex()
expect=subprocess.check_output(['git','-C',str(base),'rev-parse',f'HEAD:{oracle}'],text=True).strip()
assert actual==expect,(actual,expect)
(dst/'generate-sandbox-test-tsa.sh').write_bytes(z.read('generate-sandbox-test-tsa.sh'))
print(json.dumps(dict(manifest_members=len(m),compared_candidate_files=compared,oracle_tree=actual,fixture_files_replaced=sorted(fresh))))
