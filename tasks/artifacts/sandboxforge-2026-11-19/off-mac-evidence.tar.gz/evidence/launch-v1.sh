#!/usr/bin/env bash
set -eu
cd /workspace/scratch/forge-preflight
lane=$1
attempt=$2
out=results/$lane-$attempt
mkdir -p results
mkdir "$out"
set +e
set -o pipefail
tar -cf - checkout-v2 postgrest offline-lane.sh daily-transfer/daily transfer-v2/aux/packet |
env -i PATH=/usr/bin:/usr/local/bin:/bin docker -H unix:///var/run/docker.sock run -i --rm --pull=never --network=none --read-only --cap-drop=ALL --security-opt=no-new-privileges --user postgres --tmpfs /tmp:rw,exec,mode=1777,size=2g --entrypoint /usr/bin/env forge-local-preflight:runtime -i PATH=/opt/node/bin:/usr/lib/postgresql/15/bin:/usr/local/bin:/usr/bin:/bin HOME=/tmp/home LANG=C.UTF-8 TZ=UTC /bin/bash -c "$(cat offline-lane.sh)" bash "$lane" "$(cat start.txt)" > "$out/outputs.tar" 2>"$out/container.log"
rc=$?
if test -s "$out/outputs.tar"; then tar -xf "$out/outputs.tar" -C "$out"; fi
exit "$rc"
