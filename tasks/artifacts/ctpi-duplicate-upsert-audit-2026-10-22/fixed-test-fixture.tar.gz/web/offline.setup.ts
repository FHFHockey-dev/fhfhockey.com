import { vi } from "vitest"; vi.stubGlobal("fetch", async () => { throw new Error("CTPI_OFFLINE_NETWORK_BLOCKED"); });
