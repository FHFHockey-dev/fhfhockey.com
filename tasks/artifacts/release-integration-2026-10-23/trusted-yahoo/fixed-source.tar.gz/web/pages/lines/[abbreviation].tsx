import dynamic from "next/dynamic";
import ProjectedLineups from "components/LineCombinations/ProjectedLineups";
// C:\Users\timbr\OneDrive\Desktop\fhfhockey.com-3\web\pages\lines\[abbreviation].tsx

import React, { useMemo, useRef } from "react";
import { useRouter } from "next/router";
import { NextSeo } from "next-seo";
import type { GetStaticPaths, GetStaticProps } from "next";
import { toPng } from "html-to-image";

import PageTitle from "components/PageTitle";
import Container from "components/Layout/Container";
import TeamSelect from "components/TeamSelect";
import TimeAgo from "components/TimeAgo";
import Select from "components/Select";
import CategoryTitle from "components/LineCombinations/CategoryTitle";
import Line from "components/LineCombinations/Line";
import { mapTeamAbbreviation } from "lib/NHL/utils/utils";
import PowerPlayCombos from "components/PowerPlayCombos";

import { LineChange } from "components/LineCombinations/PlayerCard/SkaterCard";
import Custom404 from "pages/404";
import TeamColorProvider, { useTeamColor } from "contexts/TeamColorContext";

import styles from "./[abbreviation].module.scss";
import useScreenSize from "hooks/useScreenSize";
import { getTeamLogo, getTeams, getCurrentSeason } from "lib/NHL/server";
import { Team } from "lib/NHL/types";
import {
  getLineCombinations,
  type LineCombinations
} from "components/LineCombinations/utilities";
import { getLinesSurfaceLinks } from "lib/navigation/siteSurfaceLinks";
import LineShareBars from "components/LineCombinations/LineShareBars";
import SurfaceWorkflowLinks from "components/SurfaceWorkflowLinks";

export type PlayerBasic = {
  playerId: number;
  playerName: string;
  position: string;
  sweaterNumber: number;
  lineChange: LineChange;
};

export type SkaterStats = PlayerBasic & {
  Goals: number;
  Assists: number;
  PTS: number;
  PPP: number;
  Shots: number;
  Hits: number;
  Blocks: number;
  PlusMinus: number;
  TOISeconds?: number;
};

export type GoalieStats = PlayerBasic & {
  last10Games: {
    Record: string;
    SV: number;
    SVPercentage: number;
    GAA: number;
  };

  season: {
    Record: string;
    GP: number;
    SVPercentage: number;
    GAA: number;
  };
};

const ObservedLinemateMatrix = dynamic(() => import("components/LinemateMatrix"), { ssr: false });

type Props = {
  teamName: string;
  /**
   * An array of team info.
   */
  teams: Team[];

  lineCombinations: LineCombinations | null;
  lastUpdated: string;
};

export default function TeamLC({
  teamName,
  teams,
  lineCombinations,
  lastUpdated
}: Props) {
  const router = useRouter();
  const { abbreviation } = router.query;
  const mappedAbbreviation = mapTeamAbbreviation(abbreviation as string); // Map abbreviation
  const sourceTeamMeta = useMemo(
    () => teams.find((team) => lineCombinations ? team.id === lineCombinations.game.teamId : team.abbreviation === mappedAbbreviation),
    [teams, lineCombinations, mappedAbbreviation]
  );

  const onTeamChange = (newAbbreviation: string) => {
    const mappedNewAbbreviation = mapTeamAbbreviation(newAbbreviation);
    router.push(`/lines/${mappedNewAbbreviation}`);
  };
  const onGameChange = (gameId: number) => { void router.push({ pathname: router.pathname, query: { abbreviation, gameId } }, undefined, { shallow: true }); };

  // download the line combo
  const size = useScreenSize();
  const lineComboRef = useRef<HTMLDivElement>(null);
  const downloadImage = () => {
    if (lineComboRef.current === null) return;
    console.log("downloading...");

    toPng(lineComboRef.current, { backgroundColor: "#202020" })
      .then((dataUrl) => {
        const link = document.createElement("a");
        link.download = `${teamName}-${new Date(
          lastUpdated
        ).toLocaleDateString()}-${size.screen}.png`;
        link.href = dataUrl;
        link.click();
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // NOTE: workaround for weird vercel client side bug
  if (!teams || !sourceTeamMeta) return <Custom404 />;
  if (!lineCombinations) return <Container className={styles.container}>
    <h1>{teamName} line combinations</h1>
    <ProjectedLineups teamId={sourceTeamMeta.id} onGameChange={onGameChange} gameId={typeof router.query.gameId === "string" && /^[1-9]\d*$/.test(router.query.gameId) ? Number(router.query.gameId) : undefined} />
    <section aria-label="Observed shared ice time"><h2>Observed shared ice time</h2><p>No observed lineup data is available yet.</p></section>
  </Container>;

  return (
    <TeamColorProvider teamName={teamName}>
      <TeamSelect
        className={styles.teamSelect}
        teams={teams}
        team={abbreviation as string}
        onTeamChange={onTeamChange}
      />

      <Container className={styles.container}>
        <NextSeo
          title={`FHFH | ${abbreviation} Line Combinations`}
          description={`${abbreviation} Line Combinations`}
        />
        <div className={styles.top}>
          <PageTitle className={styles.title}>
            NHL LINE <PageTitle.Highlight>COMBINATIONS</PageTitle.Highlight>
          </PageTitle>
          <Select
            ariaLabel="Team"
            className={styles.select}
            option={abbreviation as string}
            options={teams.map((team) => ({
              label: team.abbreviation,
              value: team.abbreviation
            }))}
            onOptionChange={onTeamChange}
          />
        </div>

        <ProjectedLineups teamId={sourceTeamMeta?.id} onGameChange={onGameChange} gameId={typeof router.query.gameId === "string" && /^[1-9]\d*$/.test(router.query.gameId) ? Number(router.query.gameId) : undefined} />
        <section aria-label="Observed shared ice time">
          <h2>Observed shared ice time</h2>
          <ObservedLinemateMatrix id={lineCombinations.game.id} mode="line-combination" />
        </section>
        <h2>Previous lineup and player statistics</h2>
        <div ref={lineComboRef}>
          <Header
            sourceUrl={
              `/shiftChart?gameId=${lineCombinations.game.id}` +
              "&linemate-matrix-mode=line-combination#linemate-matrix"
            }
            teamName={teamName}
            teamAbbreviation={mappedAbbreviation}
            lastUpdated={lastUpdated || new Date(2022, 10, 1).toString()}
            onTeamLogoClick={downloadImage}
          />
          <Container className={styles.mainContent}>
            <section className={styles.forwards}>
              <CategoryTitle type="large" className={styles.categoryTitle}>
                FORWARDS
              </CategoryTitle>
              <Line
                className={styles.line}
                title="LINE 1"
                columns={3}
                players={lineCombinations.forwards.line1}
              />
              <Line
                className={styles.line}
                title="LINE 2"
                columns={3}
                players={lineCombinations.forwards.line2}
              />
              <Line
                className={styles.line}
                title="LINE 3"
                columns={3}
                players={lineCombinations.forwards.line3}
              />
              <Line
                className={styles.line}
                title="LINE 4"
                columns={3}
                players={lineCombinations.forwards.line4}
              />
            </section>

            <LineShareBars
              lines={[
                { label: "L1", players: lineCombinations.forwards.line1 },
                { label: "L2", players: lineCombinations.forwards.line2 },
                { label: "L3", players: lineCombinations.forwards.line3 },
                { label: "L4", players: lineCombinations.forwards.line4 }
              ]}
            />

            {/* mobile only */}
            <section className={styles.defense}>
              <CategoryTitle type="large">DEFENSE</CategoryTitle>
              <Line
                className={styles.line}
                columns={2}
                players={lineCombinations.defensemen.line1}
              />
              <Line
                className={styles.line}
                columns={2}
                players={lineCombinations.defensemen.line2}
              />
              <Line
                className={styles.line}
                columns={2}
                players={lineCombinations.defensemen.line3}
              />
            </section>

            {/* mobile only */}
            <section className={styles.goalies}>
              <CategoryTitle type="large">GOALIES</CategoryTitle>
              <Line
                className={styles.line}
                columns={2}
                type="goalies"
                players={[
                  ...lineCombinations.goalies.line1,
                  ...lineCombinations.goalies.line2
                ]}
              />
            </section>

            <section className={styles.defenseAndGoalies}>
              <CategoryTitle type="large" className={styles.categoryTitle}>
                DEFENSE & GOALIES
              </CategoryTitle>
              <Line
                className={styles.line}
                title="1ST PAIR"
                columns={2}
                players={lineCombinations.defensemen.line1}
              />
              <Line
                className={styles.line}
                title="2ND PAIR"
                columns={2}
                players={lineCombinations.defensemen.line2}
              />
              <Line
                className={styles.line}
                title="3RD PAIR"
                columns={2}
                players={lineCombinations.defensemen.line3}
              />

              <Line
                className={styles.line}
                title="GOALIES"
                columns={2}
                type="goalies"
                players={[
                  ...lineCombinations.goalies.line1,
                  ...lineCombinations.goalies.line2
                ]}
              />
            </section>
          </Container>
          {lineCombinations.game.teamId ? (
            <div className={styles.powerPlay}>
              <PowerPlayCombos
                teamId={lineCombinations.game.teamId}
                gameId={lineCombinations.game.id}
                seasonId={lineCombinations.game.seasonId}
                teamAbbreviation={sourceTeamMeta?.abbreviation}
              />
            </div>
          ) : null}
          <SurfaceWorkflowLinks
            eyebrow="Deployment workflow"
            title={`Use ${mappedAbbreviation} lines in context`}
            description="Carry the current combinations into Team HQ, matchup, schedule, and trend decisions."
            links={getLinesSurfaceLinks(mappedAbbreviation)}
          />
        </div>
      </Container>
    </TeamColorProvider>
  );
}

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const abbreviation = params!.abbreviation as string;
  const mappedAbbreviation = mapTeamAbbreviation(abbreviation); // Map abbreviation

  const teams = await getTeams();
  const team = teams.find((team) => team.abbreviation === mappedAbbreviation);

  if (!team) {
    console.warn(`Team not found for abbreviation: ${mappedAbbreviation}`);
    return { notFound: true };
  }

  try {
    const lineCombinations = await getLineCombinations(team.id);
    return {
      props: {
        teamName: team.name,
        lastUpdated: lineCombinations.game.startTime,
        lineCombinations,
        teams
      },
      revalidate: 60 // In seconds
    };
  } catch (error) {
    // If UTA doesn't have enough current-season data yet, try last season with prior team ID
    if (team.abbreviation === "UTA") {
      try {
        const { lastSeasonId } = await getCurrentSeason();
        const utahLastSeasonTeamId = 59;
        const lineCombinations = await getLineCombinations(
          utahLastSeasonTeamId,
          lastSeasonId
        );
        return {
          props: {
            teamName: team.name,
            lastUpdated: lineCombinations.game.startTime,
            lineCombinations,
            teams
          },
          revalidate: 60
        };
      } catch (fallbackError) {
        console.error(
          `Failed fallback for UTA (last season/team 59):`,
          fallbackError
        );
      }
    }
    console.error(
      `Failed to get line combinations for team ${mappedAbbreviation}:`,
      error
    );

    // Instead of returning notFound immediately, check if this is a data availability issue
    const errorMessage = error?.toString() || "";
    if (errorMessage.includes("Cannot find at least 2 games")) {
      // Return notFound but allow ISR to retry later as more data becomes available
      console.warn(
        `Insufficient line combination data for ${mappedAbbreviation} at build time. Will retry on-demand.`
      );
    }
    return { props: { teamName: team.name, teams, lineCombinations: null, lastUpdated: null }, revalidate: 60 };
  }
};

export const getStaticPaths: GetStaticPaths = async () => {
  const teams = await getTeams();
  const paths = teams.map((team) => ({
    params: { abbreviation: team.abbreviation }
  }));

  return {
    paths,
    fallback: "blocking" // Allow pages to be generated on-demand if they fail at build time
  };
};

type HeaderProps = {
  teamName: string;
  teamAbbreviation: string;
  lastUpdated: string;
  sourceUrl: string;
  onTeamLogoClick: () => void;
};

export function Header({
  teamName,
  teamAbbreviation,
  lastUpdated,
  sourceUrl,
  onTeamLogoClick
}: HeaderProps) {
  const names = teamName.split(" ");
  const abbreviation = teamAbbreviation;
  const color = useTeamColor();

  return (
    <div
      className={styles.header}
      style={{
        backgroundColor: color.primary,
        color: color.secondary
      }}
    >
      <div className={styles.left}>
        <h2 className={styles.teamName}>
          {names.slice(0, -1).join(" ")}{" "}
          <span className={styles.highlight}>{names.at(-1)}</span>
        </h2>
        <div className={styles.time}>
          <a href={sourceUrl} target="_blank" rel="noreferrer">
            Updated: <TimeAgo date={lastUpdated} />
          </a>
        </div>
      </div>
      <button
        type="button"
        className={styles.right}
        onClick={onTeamLogoClick}
        aria-label={`Download ${teamName} line combinations image`}
      >
        <span className={styles.large}>
          <img
            alt={teamName}
            src={getTeamLogo(teamAbbreviation)}
            style={{
              width: 120,
              height: 72,
              objectFit: "contain"
            }}
          />
        </span>

        <span className={styles.small}>
          <img
            alt={teamName}
            src={getTeamLogo(teamAbbreviation)}
            style={{
              width: 60,
              height: 35,
              objectFit: "contain"
            }}
          />
        </span>
      </button>
    </div>
  );
}
