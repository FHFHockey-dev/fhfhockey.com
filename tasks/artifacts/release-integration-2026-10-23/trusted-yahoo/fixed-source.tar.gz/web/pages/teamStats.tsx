// C:\Users\timbr\OneDrive\Desktop\fhfhockey.com-1\web\pages\teamStats.tsx

import React from "react";
import Link from "next/link";
import useTeams from "../hooks/useTeams";
import styles from "../styles/teamStats.module.scss";
import { teamsInfo } from "lib/teamsInfo"; // ensure unified path
import LegacySurfaceNotice from "components/LegacySurfaceNotice/LegacySurfaceNotice";

interface CustomStyle extends React.CSSProperties {
  "--primary-color"?: string;
  "--secondary-color"?: string;
  "--accent-color"?: string;
  "--alt-color"?: string;
  "--jersey"?: string;
}

const TeamStats = () => {
  const teams = useTeams();

  // Sort teams alphabetically by name
  const sortedTeams = teams
    ?.slice()
    .sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className={styles.teamStatsContainer}>
      <LegacySurfaceNotice
        replacementHref="/underlying-stats/teamStats"
        replacementLabel="Underlying Team Stats"
      >
        This retained directory supports old bookmarks. Underlying Team Stats
        is the current team-analysis surface.
      </LegacySurfaceNotice>
      <h1 className={styles.pageHeader}>
        <span className={styles.spanColorBlue}>Team</span> Stats
      </h1>
      <div className={styles.teamsGrid}>
        {sortedTeams && sortedTeams.length > 0 ? (
          sortedTeams.map((team) => {
            const teamInfo = teamsInfo[team.abbreviation];
            return (
              <Link
                href={`/teamStats/${team.abbreviation}`}
                key={team.id}
                className={styles.teamCard}
                style={
                  {
                    "--primary-color": teamInfo?.primaryColor || ("" as string),
                    "--secondary-color":
                      teamInfo?.secondaryColor || ("" as string),
                    "--jersey": teamInfo?.jersey || "black",
                    "--accent-color": teamInfo?.accent || ("" as string),
                    "--alt-color": teamInfo?.alt || "black"
                  } as CustomStyle
                }
              >
                <div className="center-stripe"></div>
                <div className={styles.teamLogoContainer}>
                  <img
                    src={`/teamLogos/${team.abbreviation.replace(
                      /\s+/g,
                      " "
                    )}.png`}
                    alt={team.name}
                    className={styles.teamLogo}
                  />
                </div>
                <div className={styles.teamAbbrev}>{team.abbreviation}</div>
              </Link>
            );
          })
        ) : (
          <p className={styles.loading}>Loading...</p>
        )}
      </div>
    </div>
  );
};

export default TeamStats;
