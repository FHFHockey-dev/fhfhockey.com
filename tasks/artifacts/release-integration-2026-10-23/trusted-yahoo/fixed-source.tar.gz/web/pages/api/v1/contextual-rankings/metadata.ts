import {
  buildContextualRankingsMetadataSurface,
} from "lib/rankings/rankingMetadata";
import type { NextApiRequest, NextApiResponse } from "next";

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({
      success: false,
      error: "Method not allowed",
    });
  }

  return res.status(200).json(buildContextualRankingsMetadataSurface());
}
