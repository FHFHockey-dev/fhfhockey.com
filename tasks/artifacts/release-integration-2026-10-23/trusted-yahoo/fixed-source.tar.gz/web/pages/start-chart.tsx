import { summarizeTeamForm } from "lib/projections/startChartTeamForm";
import {
  type KeyboardEvent as ReactKeyboardEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Head from "next/head";
import { buildPlayerHeadshotSources, getLocalTeamLogoPath, fallbackTeamLogo } from "lib/images";
import Link from "next/link";
import { useRouter } from "next/router";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ReferenceLine,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import ResizeObserverPolyfill from "resize-observer-polyfill";
import useSWR from "swr";

import SurfaceWorkflowLinks from "components/SurfaceWorkflowLinks";
import StarterBoardYahoo from "components/StarterBoardYahoo";
import StarterBoardValidation from "components/StarterBoardValidation";
import StarterBoardPlayerDetails from "components/StarterBoardPlayerDetails";
import { START_CHART_SURFACE_LINKS } from "lib/navigation/siteSurfaceLinks";
import {
  normalizeStartChartResponse,
  selectStartChartExpectationBasis,
  scoreStartChartPayload,
  type StartChartExpectationBasis,
  type StartChartGoalie,
  type StartChartPlayer,
  type StartChartResponse,
} from "lib/projections/startChartContract";
import {
  formatStartChartFantasyScoringContract,
  START_CHART_FANTASY_SCORING_CONTRACT,
  type StartChartPosition,
} from "lib/projections/startChartFantasyScoring";
import { teamsInfo } from "lib/teamsInfo";
import { BOARD_CATEGORIES, DEFAULT_BOARD_SCORING, boardSkaterForecast, parseBoardScoringRequest, type BoardScoringRequest } from "lib/projections/starterBoardScoring";

import styles from "./start-chart.module.scss";

const POSITION_ORDER = ["LW", "RW", "C", "D", "G"] as const;
const INITIAL_POSITION_LIMIT = 5;
const FORECAST_EXCLUSION_LABELS: Record<string, string> = {
  serving_disabled: "Published forecasts disabled",
  canary_excluded: "Game outside the forecast serving scope",
  no_issued_revision: "No issued game forecast",
  unreleased_source: "Forecast source not released",
  identity_conflict: "Player, roster or schedule evidence does not match",
  missing_target: "Some category values unavailable",
  missing_participation: "Participation evidence unavailable",
  stale_source: "Forecast source expired",
  future_input: "Source evidence is later than the comparison time",
  invalid_cutoff: "Forecast cutoff could not be verified",
  outside_horizon: "Game outside the supported forecast window",
  use_not_approved: "Forecast use not approved",
  unsupported_conditioning: "Unconditional forecast unavailable",
  incomplete_refresh: "Source coverage could not be verified",
  discovery_timeout: "Forecast read timed out",
  discovery_failed: "Forecast read failed",
  eligibility_unverified: "Player eligibility unverified",
  game_mismatch: "Game schedule evidence does not match",
  no_usable_target: "No supported category values",
  conflicting_forecast: "Conflicting forecast evidence",
  incompatible_overlap: "Forecast sources overlap incompatibly",
  incompatible_component_basis: "Forecast components use incompatible values",
};

function BoardImage({ sources, className, label }: { sources: string[]; className: string; label: string }) {
  const [index, setIndex] = useState(0);
  return index < sources.length ? (
    // Official headshots use a validated CMS host; keep the fallback sequence local.
    // eslint-disable-next-line @next/next/no-img-element
    <img src={sources[index]} alt={label} width={48} height={48} className={className}
      referrerPolicy="no-referrer" onError={() => setIndex((current) => current + 1)} />
  ) : <span className={className} role="img" aria-label={`${label} unavailable`} />;
}

const logoSources = (team: string | null | undefined) => Array.from(new Set([getLocalTeamLogoPath(team), fallbackTeamLogo]));
const publicationTime = (value?: string | null) => value && Number.isFinite(Date.parse(value))
  ? new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZoneName: "short" }).format(new Date(value))
  : "Time unavailable";

const shiftDate = (date: string, days: number): string => {
  const parsed = new Date(`${date}T12:00:00Z`);
  parsed.setUTCDate(parsed.getUTCDate() + days);
  return parsed.toISOString().slice(0, 10);
};

const describeTeamForm = (value: number | null | undefined): string => {
  if (value == null || !Number.isFinite(value)) return "Unavailable";
  if (value > 50) return "Above league average";
  if (value < 50) return "Below league average";
  return "League average";
};

const useMeasuredChart = (enabled: boolean) => {
  const ref = useRef<HTMLDivElement | null>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    if (!enabled) return;
    const element = ref.current;
    if (!element) return;
    let frame = 0;
    const measure = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const { width, height } = element.getBoundingClientRect();
        const next = {
          width: Math.max(0, Math.floor(width)),
          height: Math.max(0, Math.floor(height)),
        };
        setSize((current) =>
          current.width === next.width && current.height === next.height
            ? current
            : next,
        );
      });
    };
    const Observer = window.ResizeObserver ?? ResizeObserverPolyfill;
    const observer = new Observer(measure);
    observer.observe(element);
    window.addEventListener("resize", measure);
    measure();
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [enabled]);

  return { ref, size };
};

const isCalendarDate = (value: unknown): value is string => {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }
  const parsed = new Date(`${value}T00:00:00Z`);
  return (
    !Number.isNaN(parsed.getTime()) &&
    parsed.toISOString().slice(0, 10) === value
  );
};

const easternDate = (now = new Date()): string => {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  return ["year", "month", "day"]
    .map((type) => parts.find((part) => part.type === type)?.value)
    .join("-");
};

const fetcher = async (url: string): Promise<StartChartResponse> => {
  const response = await fetch(url);
  const text = await response.text();
  let payload: unknown = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch {
    throw new Error("Start Chart returned an unreadable response");
  }
  if (!response.ok) {
    const error = payload as any;
    throw new Error(
      error?.error?.message ??
        (typeof error?.error === "string" ? error.error : null) ??
        "Start Chart request failed",
    );
  }
  return normalizeStartChartResponse(payload);
};

const formatNumber = (
  value: number | null | undefined,
  digits = 1,
): string =>
  value == null || !Number.isFinite(value) ? "—" : value.toFixed(digits);

const formatPercent = (
  value: number | null | undefined,
  fractional = true,
): string => {
  if (value == null || !Number.isFinite(value)) return "—";
  return `${(fractional ? value * 100 : value).toFixed(0)}%`;
};

const formatGameTime = (value: string | null | undefined): string => {
  if (!value) return "Time TBD";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return "Time TBD";
  return new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    hour: "numeric",
    minute: "2-digit",
    timeZoneName: "short",
  }).format(parsed);
};

const getColorDistance = (hex1: string, hex2: string): number => {
  const channels = (hex: string) => [
    parseInt(hex.slice(1, 3), 16),
    parseInt(hex.slice(3, 5), 16),
    parseInt(hex.slice(5, 7), 16),
  ];
  const [r1, g1, b1] = channels(hex1);
  const [r2, g2, b2] = channels(hex2);
  return Math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2);
};

const adjustBrightness = (hex: string, percent: number): string => {
  const numeric = parseInt(hex.replace("#", ""), 16);
  const amount = Math.round(2.55 * percent);
  const channel = (value: number) => Math.max(0, Math.min(255, value + amount));
  return `#${(
    0x1000000 +
    channel(numeric >> 16) * 0x10000 +
    channel((numeric >> 8) & 0xff) * 0x100 +
    channel(numeric & 0xff)
  )
    .toString(16)
    .slice(1)}`;
};

const buildContextHref = (
  href: string,
  context: {
    date: string;
    resolvedDate: string | null;
    position: StartChartPosition;
    team: string | null;
    mode: string;
  },
): string => {
  const url = new URL(href, "https://fhfh.local");
  const appliedDate = context.resolvedDate ?? context.date;
  if (url.pathname === "/game-grid/7-Day-Forecast") {
    url.searchParams.set("startDate", appliedDate);
    url.searchParams.set("endDate", shiftDate(appliedDate, 6));
    return `${url.pathname}${url.search}`;
  }
  if (url.pathname === "/trends") {
    url.searchParams.set("date", appliedDate);
    return `${url.pathname}${url.search}`;
  }
  if (url.pathname === "/splits") {
    if (context.team) url.searchParams.set("team", context.team);
    return `${url.pathname}${url.search}`;
  }
  if (url.pathname === "/lines") {
    return context.team ? `/lines/${encodeURIComponent(context.team)}` : href;
  }
  if (url.pathname === "/variance/goalies") return href;
  url.searchParams.set("date", context.date);
  if (context.resolvedDate) {
    url.searchParams.set("resolvedDate", context.resolvedDate);
  }
  if (url.pathname.startsWith("/forge/team/")) {
    return `${url.pathname}${url.search}`;
  }
  if (url.pathname.startsWith("/forge/player/")) {
    url.searchParams.set("mode", context.mode);
    return `${url.pathname}${url.search}`;
  }
  url.searchParams.set("position", context.position);
  if (context.team) url.searchParams.set("team", context.team);
  url.searchParams.set("mode", context.mode);
  return `${url.pathname}${url.search}`;
};

const TeamEndpointDot = (props: any) => {
  const { cx, cy, dataKey, payload, lastDate } = props;
  if (!lastDate || payload?.date !== lastDate || cx == null || cy == null) {
    return null;
  }
  return (
    <image
      x={cx - 10}
      y={cy - 10}
      width={20}
      height={20}
      href={`/teamLogos/${dataKey}.png`}
    />
  );
};

const RenderGoalie = ({ goalies }: { goalies?: StartChartGoalie[] }) => {
  const likely = [...(goalies ?? [])].sort((left, right) =>
    Number(right.confirmed_status) - Number(left.confirmed_status) ||
    (right.start_probability ?? -1) - (left.start_probability ?? -1))[0];
  if (!likely) return <span className={styles.goalieUnavailable}>Goalie TBD</span>;
  return <span className={styles.goalieSummary} title={likely.name}>
    {likely.name} · {likely.confirmed_status ? "Confirmed" : likely.start_probability == null ? "Probability unavailable" : `Projected ${formatPercent(likely.start_probability)}`}
  </span>;
};

const ContextChips = ({
  player,
  position,
  opponentGoalie,
}: {
  player: StartChartPlayer;
  position: StartChartPosition;
  opponentGoalie: StartChartGoalie | null;
}) => {
  const opponentGoalieStatus = opponentGoalie
    ? opponentGoalie.confirmed_status
      ? "confirmed"
      : opponentGoalie.start_probability != null
        ? `projected ${formatPercent(opponentGoalie.start_probability)}`
        : "status unavailable"
    : null;
  const chips = [
    position === "G"
      ? null
      : `Role ${player.context?.es_role ?? "unavailable"}`,
    position === "G"
      ? null
      : player.context?.unit_tier
        ? `${player.context.unit_tier}${
            player.context.pp_share != null
              ? ` · ${formatPercent(player.context.pp_share)}`
              : ""
          }`
        : "PP role unavailable",
    player.context?.role_probability != null
      ? `Role scenario weight ${formatPercent(player.context.role_probability)}`
      : null,
    player.context?.role_continuity != null
      ? `Continuity ${formatPercent(player.context.role_continuity)}`
      : null,
    player.context?.opponent_defense_edge != null
      ? `DEF edge ${player.context.opponent_defense_edge >= 0 ? "+" : ""}${player.context.opponent_defense_edge.toFixed(2)}`
      : null,
    player.context?.goalie_goal_rate_multiplier != null
      ? `Goal rate ×${player.context.goalie_goal_rate_multiplier.toFixed(2)}`
      : null,
    player.context?.goalie_starter_certainty != null
      ? `Goalie ${formatPercent(player.context.goalie_starter_certainty)}`
      : null,
    opponentGoalie
      ? `Opp G ${opponentGoalie.name} · ${opponentGoalieStatus}`
      : "Opp G unavailable",
    player.context?.rest_delta != null
      ? `Rest ${player.context.rest_delta >= 0 ? "+" : ""}${player.context.rest_delta}`
      : null,
    player.context?.trend_effect && player.context.trend_effect !== "none"
      ? `Trend ${player.context.trend_effect.replaceAll("_", " ")}`
      : null,
    ...(player.context?.flags ?? []).map((flag) => flag.replaceAll("_", " ")),
  ].filter((value): value is string => Boolean(value));
  if (chips.length === 0) return null;
  return (
    <ul className={styles.contextChips} aria-label="Projection context">
      {chips.map((chip) => (
        <li key={chip}>{chip}</li>
      ))}
    </ul>
  );
};

export default function StartChartPage() {
  const router = useRouter();
  const [date, setDate] = useState("");
  const [search, setSearch] = useState("");
  const [ownershipMax, setOwnershipMax] = useState(100);
  const [selectedGameId, setSelectedGameId] = useState<number | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<string | null>(null);
  const [scoring, setScoring] = useState<BoardScoringRequest>(() => parseBoardScoringRequest({}));
  const [scoringTouched, setScoringTouched] = useState(false);
  const [expectationBasis, setExpectationBasis] = useState<StartChartExpectationBasis | null>(null);
  const selectedCategoryRef = useRef<string | null>(null);
  const [scoringError, setScoringError] = useState<string | null>(null);
  const [activePosition, setActivePosition] =
    useState<StartChartPosition>("C");
  const [positionLimits, setPositionLimits] = useState<
    Record<StartChartPosition, number>
  >({ C: INITIAL_POSITION_LIMIT, LW: INITIAL_POSITION_LIMIT, RW: INITIAL_POSITION_LIMIT, D: INITIAL_POSITION_LIMIT, G: INITIAL_POSITION_LIMIT });

  const queryDate = Array.isArray(router.query.date)
    ? router.query.date[0]
    : router.query.date;
  const queryPosition = Array.isArray(router.query.position)
    ? router.query.position[0]
    : router.query.position;
  const queryTeam = Array.isArray(router.query.team)
    ? router.query.team[0]
    : router.query.team;
  const queryMode = Array.isArray(router.query.mode)
    ? router.query.mode[0]
    : router.query.mode;
  const normalizedQueryPosition = queryPosition?.toUpperCase();
  const validQueryPosition = POSITION_ORDER.includes(
    normalizedQueryPosition as StartChartPosition,
  )
    ? (normalizedQueryPosition as StartChartPosition)
    : null;

  useEffect(() => {
    if (!router.isReady) return;
    const today = easternDate();
    const resolvedDate = isCalendarDate(queryDate) && queryDate >= today ? queryDate : today;
    setDate(resolvedDate);
    if (validQueryPosition) setActivePosition(validQueryPosition);
    setSelectedTeam(queryTeam?.toUpperCase() ?? null);

    if (queryDate !== resolvedDate) {
      void router.replace(
        {
          pathname: router.pathname,
          query: { ...router.query, date: resolvedDate },
        },
        undefined,
        { shallow: true },
      );
    }
  }, [
    queryDate,
    queryTeam,
    router,
    router.isReady,
    router.pathname,
    validQueryPosition,
  ]);

  const { data: publishedData, error, isLoading, mutate } = useSWR<StartChartResponse>(
    // The server selects the forecast source, the same request the dashboard cards make.
    date ? `/api/v1/start-chart?date=${encodeURIComponent(date)}` : null,
    fetcher,
    { refreshInterval: 30_000, dedupingInterval: 5_000, revalidateOnFocus: true },
  );
  const [expiryClock, setExpiryClock] = useState(() => Date.now());
  const sourceExpiresAt = Date.parse(publishedData?.gameExpectations?.expiresAt ?? "");
  useEffect(() => {
    if (!Number.isFinite(sourceExpiresAt) || sourceExpiresAt <= Date.now()) return;
    const timer = window.setTimeout(() => setExpiryClock(Date.now()), Math.min(sourceExpiresAt - Date.now(), 2_147_483_647));
    return () => window.clearTimeout(timer);
  }, [sourceExpiresAt, expiryClock]);
  const forecastsExpired = Number.isFinite(sourceExpiresAt) && sourceExpiresAt <= Date.now();
  const data = useMemo(() => {
    if (publishedData && forecastsExpired) return { ...publishedData, players: [],
      games: publishedData.games.map(game => ({ ...game, homeGoalies: [], awayGoalies: [] })) };
    if (!publishedData || (!scoringTouched && publishedData.contractVersion !== 2)) return publishedData;
    const board = publishedData.gameExpectations
      ? selectStartChartExpectationBasis(publishedData, expectationBasis ?? publishedData.gameExpectations.basis) : publishedData;
    return { ...board, ...scoreStartChartPayload({ ...board,
      players: board.players.map((player) => ({ ...player,
        forecast: player.forecast ?? (player.positions.includes("G") ? null : boardSkaterForecast(player, null)),
      })),
    }, scoring) } as StartChartResponse;
  }, [publishedData, scoring, scoringTouched, expectationBasis, forecastsExpired]);
  const { ref: chartGraphicRef, size: chartSize } = useMeasuredChart(
    (data?.ctpi?.length ?? 0) > 0,
  );

  const updateQuery = (values: Record<string, string | null>) => {
    const query = Object.fromEntries(
      Object.entries(router.query).filter(
        (entry): entry is [string, string | string[]] => entry[1] !== undefined,
      ),
    );
    for (const [key, value] of Object.entries(values)) {
      if (value) query[key] = value;
      else delete query[key];
    }
    void router.replace({ pathname: router.pathname, query }, undefined, {
      shallow: true,
    });
  };

  const selectDate = (nextDate: string) => {
    if (!isCalendarDate(nextDate) || nextDate < easternDate()) return;
    setDate(nextDate);
    setSelectedGameId(null);
    updateQuery({ date: nextDate, resolvedDate: null });
  };

  const selectPosition = (position: StartChartPosition, focus = false) => {
    setActivePosition(position);
    updateQuery({ position });
    if (focus) {
      requestAnimationFrame(() =>
        document.getElementById(`start-chart-tab-${position}`)?.focus(),
      );
    }
  };

  const handleTabKeyDown = (
    event: ReactKeyboardEvent<HTMLButtonElement>,
    position: StartChartPosition,
  ) => {
    const index = POSITION_ORDER.indexOf(position);
    const direction =
      event.key === "ArrowRight" || event.key === "ArrowDown"
        ? 1
        : event.key === "ArrowLeft" || event.key === "ArrowUp"
          ? -1
          : 0;
    if (direction === 0) return;
    event.preventDefault();
    const next = POSITION_ORDER[(index + direction + POSITION_ORDER.length) % POSITION_ORDER.length];
    selectPosition(next, true);
  };

  useEffect(() => {
    setPositionLimits({ C: INITIAL_POSITION_LIMIT, LW: INITIAL_POSITION_LIMIT, RW: INITIAL_POSITION_LIMIT, D: INITIAL_POSITION_LIMIT, G: INITIAL_POSITION_LIMIT });
  }, [date, search, ownershipMax, selectedGameId, selectedTeam, scoring]);

  const allowedGameTeamIds = useMemo(() => {
    if (!selectedGameId) return null;
    const game = data?.games.find((candidate) => candidate.id === selectedGameId);
    return game ? new Set([game.homeTeamId, game.awayTeamId]) : null;
  }, [data?.games, selectedGameId]);

  const gamesById = useMemo(
    () => new Map((data?.games ?? []).map((game) => [game.id, game] as const)),
    [data?.games],
  );

  const scopedPlayers = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase();
    return (data?.players ?? []).filter((player) => {
      const passesSearch =
        !normalizedSearch || player.name.toLowerCase().includes(normalizedSearch);
      const passesGame = allowedGameTeamIds
        ? player.team_id != null && allowedGameTeamIds.has(player.team_id)
        : true;
      const passesTeam = selectedTeam
        ? player.team_abbrev === selectedTeam || String(player.team_id) === selectedTeam
        : true;
      return passesSearch && passesGame && passesTeam;
    });
  }, [allowedGameTeamIds, data?.players, search, selectedTeam]);

  const unknownOwnershipExcluded = useMemo(
    () =>
      ownershipMax < 100
        ? scopedPlayers.filter(
            (player) =>
              (player.ownership ?? player.percent_ownership) == null,
          ).length
        : 0,
    [ownershipMax, scopedPlayers],
  );

  const filteredPlayers = useMemo(
    () =>
      scopedPlayers.filter((player) => {
        const ownership = player.ownership ?? player.percent_ownership;
        return (
          ownershipMax === 100 ||
          (ownership != null && ownership <= ownershipMax)
        );
      }),
    [ownershipMax, scopedPlayers],
  );

  const playersByPosition = useMemo(() => {
    const result = new Map<StartChartPosition, StartChartPlayer[]>(
      POSITION_ORDER.map((position) => [position, []]),
    );
    for (const player of filteredPlayers) {
      const score = player.boardScore ? player.boardScore.sortValue
        : player.positions.includes("G") ? player.start_probability : player.proj_fantasy_points;
      const rankedPlayer = typeof score === "number" && Number.isFinite(score)
        ? player
        : { ...player, position_ranks: {} };
      for (const position of player.positions) {
        if (!POSITION_ORDER.includes(position as StartChartPosition)) continue;
        result.get(position as StartChartPosition)?.push(rankedPlayer);
      }
    }
    for (const position of POSITION_ORDER) {
      result.get(position)?.sort(
        (left, right) =>
          (left.position_ranks[position] ?? Number.MAX_SAFE_INTEGER) -
            (right.position_ranks[position] ?? Number.MAX_SAFE_INTEGER) ||
          left.player_id - right.player_id ||
          left.game_id - right.game_id ||
          left.row_key.localeCompare(right.row_key),
      );
    }
    return result;
  }, [filteredPlayers]);

  useEffect(() => {
    if (validQueryPosition || !data?.players.length) return;
    const firstAvailable = POSITION_ORDER.find(
      (position) => (playersByPosition.get(position)?.length ?? 0) > 0,
    );
    if (firstAvailable && firstAvailable !== activePosition) {
      setActivePosition(firstAvailable);
    }
  }, [activePosition, data?.players.length, playersByPosition, validQueryPosition]);

  const teamsPlaying = useMemo(() => {
    const teams = new Set<string>();
    for (const game of data?.games ?? []) {
      const home = game.homeAbbrev ?? findTeamAbbrev(game.homeTeamId);
      const away = game.awayAbbrev ?? findTeamAbbrev(game.awayTeamId);
      if (home) teams.add(home);
      if (away) teams.add(away);
    }
    return Array.from(teams);
  }, [data?.games]);

  const teamColors = useMemo(() => {
    const colors: Record<string, string> = {};
    const used: string[] = [];
    for (const abbreviation of teamsPlaying) {
      const team = Object.values(teamsInfo).find(
        (candidate) => candidate.abbrev === abbreviation,
      );
      if (!team) continue;
      let color = team.primaryColor;
      if (used.some((candidate) => getColorDistance(candidate, color) < 50)) {
        color = team.secondaryColor;
      }
      if (used.some((candidate) => getColorDistance(candidate, color) < 50)) {
        color = adjustBrightness(team.primaryColor, 40);
      }
      if (used.some((candidate) => getColorDistance(candidate, color) < 50)) {
        color = adjustBrightness(team.primaryColor, -40);
      }
      colors[abbreviation] = color;
      used.push(color);
    }
    return colors;
  }, [teamsPlaying]);

  const latestTeamFormByTeam = useMemo(() => {
    const latest = new Map<string, { date: string; value: number }>();
    for (const row of data?.ctpi ?? []) {
      for (const team of teamsPlaying) {
        const value = row[team];
        const previous = latest.get(team);
        if (
          typeof value === "number" &&
          Number.isFinite(value) &&
          (!previous || row.date > previous.date)
        ) {
          latest.set(team, { date: row.date, value });
        }
      }
    }
    return latest;
  }, [data?.ctpi, teamsPlaying]);

  const yAxisDomain = useMemo<[number, number]>(() => {
    const values = (data?.ctpi ?? []).flatMap((row) =>
      teamsPlaying.flatMap((team) =>
        typeof row[team] === "number" ? [row[team] as number] : [],
      ),
    );
    if (values.length === 0) return [0, 100];
    return [
      Math.max(0, Math.floor(Math.min(50, ...values) - 5)),
      Math.min(100, Math.ceil(Math.max(50, ...values) + 5)),
    ];
  }, [data?.ctpi, teamsPlaying]);

  const workflowContext = {
    date: date || easternDate(),
    resolvedDate: data?.resolvedDate ?? data?.dateUsed ?? null,
    position: activePosition,
    team: selectedTeam,
    mode: queryMode ?? "tonight",
  };
  const workflowLinks = START_CHART_SURFACE_LINKS.map((link) => ({
    ...link,
    href: buildContextHref(link.href, workflowContext),
    description: `${link.description} ${link.href === "/forge/command-center"
      ? "Date, position, team and mode are retained."
      : link.href === "/game-grid/7-Day-Forecast"
        ? "Opens seven days from the applied slate; team and position filters reset."
        : link.href === "/trends"
          ? "Retains the applied date; other filters reset."
          : link.href === "/splits" || link.href === "/lines"
            ? "Retains the selected team; date, position and mode reset."
            : "Opens the destination's default view."}`,
  }));
  const fantasyScoringDescription = formatStartChartFantasyScoringContract(
    data?.fantasyScoringContract ?? START_CHART_FANTASY_SCORING_CONTRACT,
  );
  const [formCount, setFormCount] = useState(10);
  const goalForm = summarizeTeamForm(data?.recentGoals, formCount);
  const hasGoalForm = goalForm.some((team) => team.games > 0);
  const { ref: goalChartRef, size: goalChartSize } = useMeasuredChart(hasGoalForm);
  const isFallback = data?.serving?.mode === "fallback" || data?.fallbackApplied;
  const fallbackStatus = data && data.resolvedDate > data.requestedDate
    ? "Upcoming slate"
    : "Adjusted slate";
  const isPartial = data?.serving?.mode === "partial";
  const isDegraded = forecastsExpired || data?.sourceStatus?.overall === "degraded";
  const servingMessage = data?.serving?.message;
  const statusMessages = Array.from(
    new Set(
      [
        servingMessage,
        data?.sourceStatus?.projection?.state !== "ready"
          ? data?.sourceStatus?.projection?.message
          : null,
        data?.sourceStatus?.goalies?.state !== "ready"
          ? data?.sourceStatus?.goalies?.message
          : null,
      ].filter((message): message is string => Boolean(message)),
    ),
  );

  return (
    <div className={styles.page}>
      <Head>
        <title>Starter Board | FHFH</title>
      </Head>

      <header className={`${styles.pageHeader} ${isFallback ? styles.fallbackHeader : ""}`}>
        <div className={styles.headerIntro}>
          <p className={styles.eyebrow}>FORGE Daily</p>
          <h1>Starter Board</h1>
          <p className={styles.subtitle}>
            One-game projections, matchup context, and starter probabilities.
          </p>
        </div>
        <div className={styles.dateCommand}>
          <button type="button" aria-label="Previous day" disabled={!date || date <= easternDate()} onClick={() => selectDate(shiftDate(date, -1))}>‹</button>
          <label htmlFor="start-chart-date" className={styles.dateTile}>
            <span aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M7 3v4M17 3v4M3 10h18" /></svg></span>
            <strong>{date ? new Intl.DateTimeFormat("en-US", { timeZone: "UTC", weekday: "short", month: "short", day: "numeric", year: "numeric" }).format(new Date(`${date}T12:00:00Z`)) : "Choose date"}</strong>
            <small>{data ? `${data.games.length} games · ${teamsPlaying.length} teams` : error ? "Slate unavailable" : "Slate loading"}</small>
            <input aria-label="Date" id="start-chart-date" type="date" min={date ? easternDate() : undefined} value={date} onChange={(event) => selectDate(event.target.value)} />
          </label>
          <button type="button" aria-label="Next day" disabled={!date} onClick={() => selectDate(shiftDate(date, 1))}>›</button>
        </div>
        <dl className={styles.provenanceSummary}>
          <div><dt>Model</dt><dd title={data?.sourceStatus.projection.modelVersion ?? undefined}>{data?.sourceStatus.projection.modelVersion ?? "Unavailable"}</dd></div>
          <div><dt>Scoring</dt><dd title={fantasyScoringDescription}>{scoringTouched ? scoring.mode === "categories" ? "Category comparison" : "Selected points weights" : data?.fantasyScoringContract?.label ?? "Unavailable"}</dd></div>
          <div><dt>Run</dt><dd title={data?.projectionRunId ?? undefined}>{publicationTime(data?.sourceStatus.projection.updatedAt)}</dd></div>
          <div><dt>Input</dt><dd title={data?.sourceStatus.projection.inputVersion ?? undefined}>{data?.sourceStatus.projection.inputVersion ?? "Unverified"}</dd></div>
        </dl>
        <div className={`${styles.headerStatus} ${isFallback || isPartial || isDegraded ? styles.statusAmber : ""}`} role="status" aria-label="Starter Board status">
          <strong><span aria-hidden="true">{isFallback || isPartial || isDegraded ? "◷" : "◉"}</span> {error ? "Unavailable" : forecastsExpired ? "Forecasts expired" : !data ? "Loading" : data.serving.mode === "no_games" ? "No scheduled games" : isFallback ? fallbackStatus : isPartial || isDegraded || data.newsStatus?.freshnessBreachedGames || data.newsStatus?.unresolvedConflicts ? "Review coverage" : data.newsStatus?.available === false ? "News unavailable" : data.newsStatus?.pendingGames ? "Refreshing" : data.newsStatus?.available && data.serving.mode === "exact" && data.requestedDate === data.resolvedDate && data.resolvedDate === easternDate() && data.sourceStatus.projection.updatedAt ? "Up to date" : "Published slate"}</strong>
          <span>Page refresh · 30 seconds</span>
        </div>
        <details className={styles.mobileProvenance}>
          <summary>Run details</summary>
          <p>Requested {data?.requestedDate ?? date} · Resolved {data?.resolvedDate ?? "Unavailable"}</p>
          <p>Model {data?.sourceStatus?.projection?.modelVersion ?? "Unavailable"} · Scoring {scoringTouched ? scoring.mode : data?.fantasyScoringContract?.label ?? "Unavailable"}</p>
          <p>Run {data?.projectionRunId ?? "Unavailable"} · Input {data?.sourceStatus?.projection?.inputVersion ?? "Unverified"}</p>
        </details>
      </header>

      <nav className={styles.mobileNav} aria-label="Board panels">
        <a href="#slate-games">Games</a><a href="#board-filters">Filters</a><a href="#board-yahoo">Yahoo</a>
        <button type="button" onClick={() => { document.querySelectorAll<HTMLDetailsElement>("#board-filters > details, #board-settings").forEach((element) => { element.open = true; }); document.getElementById("board-settings")?.scrollIntoView({ block: "start" }); }}>Settings</button>
      </nav>
      <section id="slate-games" className={styles.gamesPanel} aria-label="Games on this slate">
        <div className={styles.gamesHeading}>
          <div><h2>{data?.resolvedDate === easternDate() ? "Today’s Games" : "Selected Slate Games"}</h2>
            <p>{data ? `${data.games.length} games · ${teamsPlaying.length} teams · ${data.resolvedDate}` : error ? "Games unavailable" : "Slate loading"}</p></div>
          <div className={styles.gamesActions}>
            {selectedGameId != null ? <button type="button" onClick={() => setSelectedGameId(null)}>Clear game filter</button> : null}
            <Link href="/game-grid/7-Day-Forecast">View Full Schedule{data?.resolvedDate && data.resolvedDate !== easternDate() ? " · current" : ""}</Link>
            {data?.resolvedDate && <Link href={`/game-grid/7-Day-Forecast?startDate=${encodeURIComponent(data.resolvedDate)}&endDate=${encodeURIComponent(shiftDate(data.resolvedDate, 6))}`}>7-day schedule from {data.resolvedDate}</Link>}
          </div>
        </div>
        {(data?.games?.length ?? 0) > 0 ? <div className={styles.gameStrip}>
          {data!.games.map((game) => {
            const home = teamFor(game.homeTeamId);
            const away = teamFor(game.awayTeamId);
            const homeAbbrev = game.homeAbbrev ?? home?.abbrev;
            const awayAbbrev = game.awayAbbrev ?? away?.abbrev;
            const isSelected = selectedGameId === game.id;
            return <button type="button" key={game.id}
              className={`${styles.gameCard} ${isSelected ? styles.selected : ""}`}
              onClick={() => setSelectedGameId(isSelected ? null : game.id)}
              aria-pressed={isSelected}
              aria-label={`${awayAbbrev ?? "Away"} at ${homeAbbrev ?? "Home"}; ${isSelected ? "remove" : "apply"} game filter`}>
              <span className={styles.gameTime}>{formatGameTime(game.startTime)}{isSelected ? " · Selected" : ""}</span>
              <span className={styles.gameMatchup}>
                {awayAbbrev ? <BoardImage sources={logoSources(awayAbbrev)} label={`${awayAbbrev} logo`} className={styles.teamLogo} /> : null}
                <strong>{awayAbbrev ?? "TBD"}</strong><span>@</span>
                {homeAbbrev ? <BoardImage sources={logoSources(homeAbbrev)} label={`${homeAbbrev} logo`} className={styles.teamLogo} /> : null}
                <strong>{homeAbbrev ?? "TBD"}</strong>
              </span>
              <span className={styles.gameGoalies}><RenderGoalie goalies={game.awayGoalies} /><RenderGoalie goalies={game.homeGoalies} /></span>
            </button>;
          })}
        </div> : <p className={styles.gamesEmpty}>{error ? "Games unavailable while the board request failed." : isLoading || !data ? "Loading games…" : "No games available for this slate."}</p>}
      </section>

      {data?.contractVersion === 2 ? <div className={styles.statusBanner} aria-label="Slate news freshness"
        data-board-revisions={JSON.stringify((data.gameRevisions ?? []).map((revision) => revision.revisionId))}>
        <strong>{data.gameExpectations ? "Daily game expectations" : data.newsStatus?.available === false ? "News freshness unavailable" : data.newsStatus?.pendingGames ? `${data.newsStatus.pendingGames} games refreshing` : data.gameRevisions?.length ? "Latest published projections" : "No admitted game forecasts"}</strong>
        <span>{data.gameExpectations ? `Read ${data.gameExpectations.readAsOf} · original source clocks in player details`
          : data.sourceStatus.projection.updatedAt ? `Published ${data.sourceStatus.projection.updatedAt}` : "Publication pending"} · refreshes every 30 seconds</span>
        {data.gameExpectations ? <span>Conditional values apply if playing or starting. Unknown participation and missing categories remain unavailable.</span> : null}
        {data.newsStatus?.freshnessBreachedGames ? <span role="status">Five-minute update target exceeded for {data.newsStatus.freshnessBreachedGames} games. {data.gameRevisions?.length
          ? "Showing the last successful projections."
          : data.newsStatus.pendingGames ? "No admitted forecasts are available while updates are pending."
          : "No admitted forecasts are available."}</span> : null}
        {data.newsStatus?.unresolvedConflicts ? <span>{data.newsStatus.unresolvedConflicts} unresolved news conflicts</span> : null}
      </div> : null}

      {isFallback || isPartial || isDegraded ? (
        <section
          className={`${styles.statusBanner} ${
            isPartial || isDegraded ? styles.statusWarning : ""
          }`}
          role="status"
        >
          <strong>
            {isFallback
              ? `Showing ${data?.resolvedDate ?? data?.dateUsed}, not ${data?.requestedDate}.`
              : "This slate has incomplete source coverage."}
          </strong>
          <span>
            {statusMessages.join(" ") ||
              data?.sourceStatus?.degradedReasons?.join(", ") ||
              "Review source details before acting on the board."}
          </span>
        </section>
      ) : null}

      <section id="board-filters" className={styles.filters} aria-label="Starter Board controls">
        {data?.gameExpectations ? <div className={styles.filterGroup}>
          <label htmlFor="start-chart-expectation-basis">Comparison basis</label>
          <select id="start-chart-expectation-basis" className={styles.selectInput}
            value={data.gameExpectations.basis} onChange={event => setExpectationBasis(event.target.value as StartChartExpectationBasis)}>
            <option value="expected">Expected game values</option>
            <option value="per_appearance">If playing</option>
            <option value="per_start">If starting (goalies)</option>
          </select>
        </div> : null}
        <div className={styles.filterGroup}>
          <label htmlFor="start-chart-search">Player</label>
          <input
            id="start-chart-search"
            className={styles.search}
            placeholder="Player name…"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>
      <div
        className={styles.positionTabs}
        role="tablist"
        aria-label="Starter Board positions"
      >
        {POSITION_ORDER.map((position) => (
          <button
            id={`start-chart-tab-${position}`}
            key={position}
            type="button"
            role="tab"
            aria-selected={activePosition === position}
            aria-controls={`start-chart-panel-${position}`}
            tabIndex={activePosition === position ? 0 : -1}
            onClick={() => selectPosition(position)}
            onKeyDown={(event) => handleTabKeyDown(event, position)}
          >
            {position}
            <span>{data ? playersByPosition.get(position)?.length ?? 0 : "—"}</span>
          </button>
        ))}
      </div>
        <div className={styles.filterGroup}>
          <label htmlFor="start-chart-mode">Compare</label>
          <select
            id="start-chart-mode"
            className={styles.selectInput}
            value={scoring.mode}
            onChange={(event) => {
              const mode = event.target.value as "points" | "categories";
              const categories = ["SHOTS_ON_GOAL", ...BOARD_CATEGORIES.filter(category => category !== "SHOTS_ON_GOAL")];
              const category = mode === "categories" ? selectedCategoryRef.current ?? categories.find(key =>
                (playersByPosition.get(activePosition) ?? []).some(player => {
                  const forecast = player.forecast;
                  const value = (forecast?.expected ?? forecast?.conditional ?? forecast?.legacy)?.[key];
                  return typeof value === "number" && Number.isFinite(value);
                })) ?? "SHOTS_ON_GOAL" : null;
              selectedCategoryRef.current = category ?? selectedCategoryRef.current;
              setScoringTouched(true);
              setScoring({ ...scoring, mode, category });
            }}
          >
            <option value="points">Fantasy points</option>
            <option value="categories">Individual category</option>
          </select>
        </div>
        {scoring.mode === "categories" ? <div className={styles.filterGroup}>
          <label htmlFor="start-chart-category">Category</label>
          <select id="start-chart-category" className={styles.selectInput} value={scoring.category ?? "SHOTS_ON_GOAL"}
            onChange={(event) => { selectedCategoryRef.current = event.target.value; setScoringTouched(true); setScoring({ ...scoring, category: event.target.value }); }}>
            {BOARD_CATEGORIES.map((category) => <option key={category} value={category}>{category.replaceAll("_", " ")}</option>)}
          </select>
        </div> : null}
        <div className={styles.desktopFilters}>
          <label>Slate team <select className={styles.selectInput} value={selectedTeam ?? ""} onChange={(event) => { const team = event.target.value || null; setSelectedTeam(team); updateQuery({ team }); }}>
            <option value="">All teams</option>{teamsPlaying.map((team) => <option key={team} value={team}>{team}</option>)}
          </select></label>
          <label>Ownership cap <input aria-label="Ownership cap" type="range" min={0} max={100} value={ownershipMax} onChange={(event) => setOwnershipMax(Number(event.target.value))} /><span>{ownershipMax === 100 ? "All" : `${ownershipMax}%`}</span></label>
          <label>Goalie ranking <select className={styles.selectInput} value={!scoringTouched && data?.contractVersion !== 2 ? "start_probability" : scoring.goalieSort} disabled={scoring.mode === "categories"} onChange={(event) => { setScoringTouched(true); setScoring({ ...scoring, goalieSort: event.target.value as "fantasy" | "start_probability" }); }}><option value="fantasy">Expected points</option><option value="start_probability">Start probability</option></select></label>
        </div>
        <details className={styles.moreFilters}>
          <summary>More Filters</summary>
          <div className={styles.moreFiltersContent}>
            <div className={styles.filterGroup}>
              <label htmlFor="start-chart-team">Team</label>
              <select
                id="start-chart-team"
                className={styles.selectInput}
                value={selectedTeam ?? ""}
                onChange={(event) => {
                  const team = event.target.value || null;
                  setSelectedTeam(team);
                  updateQuery({ team });
                }}
              >
                <option value="">All slate teams</option>
                {teamsPlaying.map((team) => (
                  <option key={team} value={team}>
                    {team}
                  </option>
                ))}
              </select>
            </div>
            <div className={styles.filterGroup}>
              <label htmlFor="start-chart-ownership">
                {ownershipMax === 100 ? "All ownership" : `Ownership ≤ ${ownershipMax}%`}
              </label>
              <input
                id="start-chart-ownership"
                className={styles.rangeInput}
                type="range"
                min={0}
                max={100}
                value={ownershipMax}
                onChange={(event) => setOwnershipMax(Number(event.target.value))}
              />
            </div>
            <div className={styles.filterGroup}>
              <label htmlFor="start-chart-goalie-sort">Goalie order</label>
              <select id="start-chart-goalie-sort" className={styles.selectInput} value={!scoringTouched && data?.contractVersion !== 2 ? "start_probability" : scoring.goalieSort}
                disabled={scoring.mode === "categories"}
                onChange={(event) => { setScoringTouched(true); setScoring({ ...scoring, goalieSort: event.target.value as "fantasy" | "start_probability" }); }}>
                <option value="fantasy">Expected fantasy points</option>
                <option value="start_probability">Starting probability</option>
              </select>
            </div>
            <details id="board-settings" className={styles.scoringEditor}>
              <summary>Scoring profile · customize points</summary>
              <form onSubmit={(event) => {
                event.preventDefault();
                const values = new FormData(event.currentTarget);
                const profile = Object.fromEntries((["skater", "goalie"] as const).map((population) => [population,
                  Object.fromEntries(Object.keys(DEFAULT_BOARD_SCORING[population]).map((key) => [key, Number(values.get(`${population}.${key}`))])),
                ]));
                try { setScoring(parseBoardScoringRequest({ ...scoring, profile })); setScoringTouched(true); setScoringError(null); }
                catch (error) { setScoringError(error instanceof Error ? error.message : String(error)); }
              }}>
                {(["skater", "goalie"] as const).map((population) => <fieldset key={population}>
                  <legend>{population === "skater" ? "Skaters" : "Goalies"}</legend>
                  {Object.entries(DEFAULT_BOARD_SCORING[population]).map(([key, weight]) => <label key={key}>
                    {key.replaceAll("_", " ")}
                    <input name={`${population}.${key}`} type="number" step="any" min={-100} max={100} required defaultValue={weight} />
                  </label>)}
                </fieldset>)}
                <button type="submit" className={styles.loadMore}>Apply scoring</button>
                {scoringError ? <p role="alert">{scoringError}</p> : null}
              </form>
            </details>
            {unknownOwnershipExcluded > 0 ? (
              <p className={styles.controlNote} role="status">
                {unknownOwnershipExcluded} player
                {unknownOwnershipExcluded === 1 ? " was" : "s were"} excluded because
                ownership is unavailable; unknown values are never treated as 0%.
              </p>
            ) : null}
            <p className={styles.controlNote}>
              Compare streaming candidates using points or one category. Skater forecasts marked “if playing” exclude participation risk.
              Unavailable statistics are shown as —. Goalie expected points assume no relief appearance when not starting.
            </p>
            <details className={styles.legendContainer}>
              <summary className={styles.legendIcon} aria-label="Explain metrics">
                i
              </summary>
              <div className={styles.legendTooltip}>
                <div className={styles.legendItem}>
                  <strong>Fantasy points</strong>
                  {fantasyScoringDescription}.
                </div>
                <div className={styles.legendItem}>
                  <strong>DEF ease</strong>
                  Slate-relative opponent defense grade. Higher opponent xGA/60 is
                  easier; missing as-of ratings display as unavailable.
                </div>
                <div className={styles.legendItem}>
                  <strong>NHL PTS uncertainty</strong>
                  Low/high values bound projected goals plus assists, not fantasy
                  points or guarantees.
                </div>
              </div>
            </details>
          </div>
        </details>
      </section>



      <section
        className={styles.columns}
        aria-label="Starter Board rankings by position"
        aria-busy={isLoading || !date}
      >
        {error ? (
          <div className={styles.requestState} role="alert">
            <strong>Starter Board is unavailable.</strong>
            <span>{error.message}</span>
            <button type="button" onClick={() => void mutate()}>
              Retry
            </button>
          </div>
        ) : null}
        {forecastsExpired ? <div className={styles.requestState} role="status" aria-label="Forecast validity">
          <strong>Forecast values expired.</strong>
          <span>Values and ranks are withheld until fresh inputs arrive. The board checks for updates every 30 seconds.</span>
          {!error ? <button type="button" onClick={() => void mutate()}>Refresh forecasts</button> : null}
        </div> : null}
        {!error && data?.publishedForecastsEnabled === false ? (
          <div className={styles.requestState} role="status">
            <strong>Published game forecasts are disabled.</strong>
            <span>Review source coverage before using any projections shown below. Reloading does not enable forecast serving.</span>
          </div>
        ) : null}
        {!error && data?.serving?.mode === "no_games" ? (
          <div className={styles.requestState} role="status">
            <strong>No games found.</strong>
            <span>{data.serving.message}</span>
          </div>
        ) : null}
        {!error && data?.forecastAdmission && Object.keys(data.forecastAdmission.exclusionCounts).length ? (
          <div className={styles.requestState} role="status" aria-label="Forecast exclusions">
            <strong>Some forecast values are unavailable.</strong>
            <ul>{Object.entries(data.forecastAdmission.exclusionCounts).map(([reason, count]) => (
              <li key={reason}>{FORECAST_EXCLUSION_LABELS[reason] ?? "Forecast evidence could not be verified"}: {count}</li>
            ))}</ul>
            <span>Missing values do not disable comparisons for categories with a supported value.</span>
          </div>
        ) : null}
        {!error && !forecastsExpired && data?.games?.length && data.players.length === 0 ? (
          <div className={styles.requestState} role="status">
            <strong>No player projections found.</strong>
            <span>{data.forecastAdmission && Object.keys(data.forecastAdmission.exclusionCounts).length
              ? "Scheduled forecasts were withheld. Review the forecast exclusions above."
              : <>
              {data.games.length} game{data.games.length === 1 ? " is" : "s are"}
              scheduled, but canonical projection rows are not ready.
              </>}</span>
          </div>
        ) : null}

        {POSITION_ORDER.map((position) => {
          const fullList = playersByPosition.get(position) ?? [];
          const visibleList = fullList.slice(0, positionLimits[position]);
          const headingId = `start-chart-position-${position}`;
          const isActive = activePosition === position;
          return (
            <section
              id={`start-chart-panel-${position}`}
              role="tabpanel"
              aria-labelledby={`start-chart-tab-${position}`}
              className={`${styles.column} ${styles[`pos${position}`]} ${
                isActive ? "" : styles.columnInactive
              }`}
              key={position}
            >
              <div className={styles.columnHeader}>
                <h2 id={headingId}>{position}</h2>
              {visibleList.length < fullList.length ? (
                <button
                  type="button"
                  className={styles.columnViewAll}
                  onClick={() =>
                    setPositionLimits((current) => ({
                      ...current,
                      [position]: fullList.length,
                    }))
                  }
                >
                  View all {position} ({fullList.length})
                </button>
              ) : null}
                {visibleList.length === fullList.length ? <span className={styles.pill}>{data ? fullList.length : "—"}</span> : null}
              </div>
              {error ? (
                <div className={styles.emptyState}>Projections unavailable.</div>
              ) : forecastsExpired ? (
                <div className={styles.emptyState}>Awaiting refreshed forecast inputs.</div>
              ) : isLoading || !date ? (
                <div className={styles.emptyState} role="status">
                  Loading projections…
                </div>
              ) : fullList.length === 0 ? (
                <div className={styles.emptyState}>
                  No players match this position and filter set.
                </div>
              ) : (
                <ol className={styles.cardList}>
                  {visibleList.map((player) => {
                    const confirmedOut = position !== "G" && player.forecast?.participationProbability === 0
                      && player.forecast.probabilityStatus === "confirmed_evidence"
                      && player.forecast.evidence.some(item => item.dimension === "availability" && item.value === "out");
                    const game = gamesById.get(player.game_id);
                    const opponentGoalie = game
                      ? player.team_id === game.homeTeamId
                        ? (game.awayGoalies[0] ?? null)
                        : (game.homeGoalies[0] ?? null)
                      : null;
                    const playerHref = buildContextHref(
                      `/forge/player/${player.player_id}`,
                      {
                        ...workflowContext,
                        team: player.team_abbrev,
                        position,
                      },
                    );
                    const teamHref = player.team_abbrev
                      ? buildContextHref(`/forge/team/${player.team_abbrev}`, {
                          ...workflowContext,
                          team: player.team_abbrev,
                          position,
                        })
                      : null;
                    const opponentHref = player.opponent_abbrev
                      ? buildContextHref(
                          `/forge/team/${player.opponent_abbrev}`,
                          {
                            ...workflowContext,
                            team: player.opponent_abbrev,
                            position,
                          },
                        )
                      : null;
                    const usesStartBasis = position === "G" && data?.gameExpectations?.basis !== "per_appearance";
                    const conditionalLabel = usesStartBasis ? "if starting" : "if playing";
                    const startMetadata = player.gameExpectation?.startParticipation;
                    const participationModel = usesStartBasis && startMetadata && startMetadata.probability === player.forecast?.participationProbability
                      ? startMetadata?.model : Object.values(player.gameExpectation?.targets ?? {}).find(target =>
                      target.participation?.model?.probabilityStatus === "uncalibrated_model"
                      && target.participation.revisionId === target.participationRevisionId
                      && target.participation.basis === (usesStartBasis ? "start" : "appearance")
                      && target.participation.probability === player.forecast?.participationProbability)?.participation?.model;
                    return (
                      <li className={styles.card} key={`${position}-${player.row_key}`}>
                        <div className={styles.playerIdentity}>
                          <span className={styles.playerRank}>{player.position_ranks[position] ?? "—"}</span>
                          <BoardImage sources={buildPlayerHeadshotSources(`https://assets.nhle.com/mugs/nhl/latest/${player.player_id}.png`, player.player_id)} label={`${player.name} headshot`} className={styles.playerHeadshot} />
                          <BoardImage sources={logoSources(player.team_abbrev)} label={`${player.team_abbrev ?? "Team"} logo`} className={styles.playerLogo} />
                        </div>
                        <div className={styles.header}>
                          <Link
                            href={playerHref}
                            className={styles.name}
                            title={`${player.name} research retains the slate date and mode; team and position filters reset.`}
                          >
                            {player.name}
                          </Link>
                          <div className={styles.primaryProjection}>
                            <strong>{formatNumber(scoring.mode === "categories" ? player.boardScore?.categoryValue : player.proj_fantasy_points, 2)}</strong>
                            <span>{scoring.mode === "categories" ? `${scoring.category?.replaceAll("_", " ") ?? "Category"}${player.forecast?.conditioning === "conditional_playing" ? ` ${conditionalLabel}` : ""}` : player.forecast?.conditioning === "conditional_playing" ? `FP ${conditionalLabel}` : position === "G" ? "Expected FP" : "FP"}</span>
                            {data?.contractVersion === 2 && (scoring.mode === "categories" ? player.boardScore?.categoryValue == null : player.proj_fantasy_points == null) ? (
                              <span>{scoring.mode === "categories"
                                ? `${scoring.category?.replaceAll("_", " ") ?? "Category"} unavailable for this player.`
                                : player.boardScore?.missingCategories.length
                                  ? `Point total unavailable: missing ${player.boardScore.missingCategories.map(key => key.replaceAll("_", " ")).join(", ")}. Compare an available category.`
                                  : "Point total unavailable for this player."}</span>
                            ) : null}
                          </div>
                          <div className={styles.meta}>
                            <span>
                              {teamHref ? (
                                <Link href={teamHref} title="Team research retains the slate date; mode and position filters reset.">{player.team_abbrev}</Link>
                              ) : (
                                "Team TBD"
                              )}{" "}
                              vs{" "}
                              {opponentHref ? (
                                <Link href={opponentHref} title="Team research retains the slate date; mode and position filters reset.">
                                  {player.opponent_abbrev}
                                </Link>
                              ) : (
                                "Opponent TBD"
                              )}
                              {game ? ` · ${formatGameTime(game.startTime)}` : ""}
                            </span>
                          </div>
                        </div>
                        <div className={styles.cardSignals}>
                          <span className={styles.positionBadge}>{position}</span>
                          {position !== "G" || player.percent_ownership != null ? <span>Own {formatPercent(player.percent_ownership, false)}</span> : null}
                          {position !== "G" ? <span>{player.games_remaining_week == null ? "Games —" : `${player.games_remaining_week} GM`}</span> : null}
                          {position === "G" ? <span title="Goalie start probability">{formatPercent(player.start_probability)} {player.confirmed_status ? "confirmed" : player.start_probability == null ? "start unknown" : "projected"}</span>
                            : player.context?.unit_tier ? <span className={styles.positionBadge} title={player.context.pp_share != null ? `PP share ${formatPercent(player.context.pp_share)}` : undefined}>{player.context.unit_tier}</span> : null}
                          {confirmedOut ? <span>Confirmed out</span> : null}
                          {player.boardScore?.comparisonAllowed === false ? <span>Primary rank unavailable{player.forecast?.conditioning === "conditional_playing" ? " · conditional values are secondary context only" : ""}</span> : null}
                        </div>
                        <StarterBoardPlayerDetails
                          className={styles.playerDetails}
                          playerId={player.player_id}
                          positions={player.positions}
                          date={data?.resolvedDate ?? data?.dateUsed ?? date}
                        >
                        <div className={styles.statsContainer}>
                          {position === "G" ? (
                            <>
                              <Metric label="Start" value={formatPercent(player.start_probability)} />
                              <Metric label="GSAA/60" value={formatNumber(player.projected_gsaa, 2)} />
                              <Metric
                                label="Status"
                                value={
                                  player.confirmed_status
                                    ? "Confirmed"
                                    : player.start_probability == null
                                      ? "Unavailable"
                                      : "Projected"
                                }
                              />
                            </>
                          ) : (
                            <>
                              <Metric
                                label="G / A / S"
                                value={`${formatNumber(player.proj_goals)} / ${formatNumber(
                                  player.proj_assists,
                                )} / ${formatNumber(player.proj_shots)}`}
                              />
                              <Metric
                                label="DEF ease"
                                value={formatNumber(player.matchup_grade, 0)}
                              />
                            </>
                          )}
                        </div>

                        {player.forecast ? <div className={styles.uncertainty}>
                          {usesStartBasis ? `${participationModel ? "Start model estimate" : "Start"} ${formatPercent(player.forecast.participationProbability)}`
                            : confirmedOut ? "Confirmed out"
                            : player.forecast.participationProbability == null ? "Participation unknown"
                            : `${participationModel ? "Participation model estimate" : !player.gameExpectation && player.forecast.probabilityStatus === "uncalibrated_model" ? "Modeled participation" : "Participation"} ${formatPercent(player.forecast.participationProbability)}`}
                          {player.boardScore?.change != null ? ` · ${player.boardScore.change >= 0 ? "+" : ""}${formatNumber(player.boardScore.change, 2)} since prior revision` : ""}
                        </div> : null}
                          {player.forecast ? <>
                            <p>{player.forecast.participationProbability == null
                              ? player.forecast.conditioning === "unconditional"
                                ? "Participation detail unavailable. Game expectations use the admitted source."
                                : "Participation probability unavailable. This is not an unconditional expectation."
                              : `${usesStartBasis ? "Starting" : "Participation"} probability ${formatPercent(player.forecast.participationProbability)} · ${participationModel ? "model estimate · calibration unavailable" : player.gameExpectation ? "calibration unavailable" : player.forecast.probabilityStatus.replaceAll("_", " ")}`}</p>
                            {player.forecast.previous?.changedInputs.length ? <p>Changed inputs: {player.forecast.previous.changedInputs.join(", ").replaceAll("_", " ")}</p> : null}
                            <p>{player.forecast.ppRole ? `${player.forecast.ppRole} · ` : ""}Fantasy intervals are unavailable pending calibration.</p>
                            {player.forecast.seasonBootstrap ? <p>
                              Season-opening prior: {player.forecast.seasonBootstrap.historyGames} previous-season games;
                              {" "}{player.forecast.seasonBootstrap.currentSeasonGames} current-season appearances.
                              {" "}Public fantasy prior {formatPercent(player.forecast.seasonBootstrap.fantasyWeight)}
                              {" "}({player.forecast.seasonBootstrap.sourceIds.join(", ") || "unavailable"}).
                              {" "}Starting weights are uncalibrated; missing categories use the available inputs.
                            </p> : null}
                            {player.forecast.conflicts.length ? <p role="status">Unresolved news: {player.forecast.conflicts.join(", ")}</p> : null}
                            {player.forecast.evidence.map((item, index) => <p key={index}>
                              {item.dimension.toUpperCase()}: {item.value} · published <time dateTime={item.publishedAt}>{item.publishedAt}</time> · received <time dateTime={item.receivedAt}>{item.receivedAt}</time>
                            </p>)}
                            {position === "G" ? <dl className={styles.secondaryStats}>
                              <StatTerm label={player.forecast.conditioning === "conditional_playing" ? `Saves ${conditionalLabel}` : "Expected saves"} value={formatNumber((player.forecast.expected ?? player.forecast.conditional)?.SAVES_GOALIE)} />
                              <StatTerm label={player.forecast.conditioning === "conditional_playing" ? `GA ${conditionalLabel}` : "Expected GA"} value={formatNumber((player.forecast.expected ?? player.forecast.conditional)?.GOALS_AGAINST_GOALIE)} />
                              <StatTerm label="Win" value={formatPercent((player.forecast.expected ?? player.forecast.conditional)?.WINS_GOALIE)} />
                              <StatTerm label="Shutout" value={formatPercent((player.forecast.expected ?? player.forecast.conditional)?.SHUTOUTS_GOALIE)} />
                            </dl> : null}
                          </> : null}
                        {player.gameExpectation ? <details>
                          <summary>Category sources and freshness</summary>
                          <p>Power-play role: {player.gameExpectation.powerPlayRole?.status === "not_applicable"
                            ? "Not applicable (goalie)." : "Unavailable. Current role evidence is unavailable."}</p>
                          {player.gameExpectation.limitations.map((limitation, index) => <p key={index}>{limitation}</p>)}
                          {Object.entries(player.gameExpectation.targets).map(([key, target]) => <p key={key}>
                            {key.replaceAll("_", " ")}: {target.basis?.replaceAll("_", " ") ?? "unavailable"} · {target.unit}.
                            {" "}Valid from cutoff {target.cutoffAt ?? "unavailable"}; composite issuance {target.issuedAt ?? "unavailable"}; expires {target.expiresAt ?? "unavailable"}.
                            {" "}Sources: {target.sourceIds.join(", ") || "unavailable"}.
                            {target.sources.map(source => <span key={source.sourceId}>
                              {" "}Original {source.kind} cutoff {source.cutoffAt}; issued {source.issuedAt}; expires {source.expiresAt}.
                            </span>)}
                            {target.participation ? <span> Participation {target.participation.basis} {formatPercent(target.participation.probability)} · issued {target.participation.issuedAt}.</span> : null}
                            {target.participation?.model ? <span> Participation model estimate · calibration unavailable.
                              {" "}Event: positive minutes; sample size {target.participation.model.sampleSize ?? "unavailable"}.
                              {target.participation.model.limitations.map((limitation, index) => <span key={index}> {limitation}</span>)}
                            </span> : null}
                            {target.reasons.length ? ` ${target.reasons.join(", ").replaceAll("_", " ")}.` : ""}
                            {target.limitations.map((limitation, index) => <span key={index}> {limitation}</span>)}
                          </p>)}
                        </details> : null}
                        {position !== "G" ? (
                          <dl className={styles.secondaryStats}>
                            <StatTerm label="PPP" value={formatNumber(player.proj_pp_points)} />
                            <StatTerm label="HIT" value={formatNumber(player.proj_hits)} />
                            <StatTerm label="BLK" value={formatNumber(player.proj_blocks)} />
                            <StatTerm label="PIM" value={formatNumber(player.proj_pim)} />
                            <StatTerm
                              label="TOI"
                              value={
                                player.proj_toi_minutes == null
                                  ? "—"
                                  : `${player.proj_toi_minutes.toFixed(1)}m`
                              }
                            />
                          </dl>
                        ) : null}

                        {player.context?.projection_low != null ||
                        player.context?.projection_high != null ? (
                          <div className={styles.uncertainty}>
                            NHL PTS range {formatNumber(player.context.projection_low, 2)}–
                            {formatNumber(player.context.projection_high, 2)}
                          </div>
                        ) : null}
                        <ContextChips
                          player={player}
                          position={position}
                          opponentGoalie={opponentGoalie}
                        />
                        <div className={styles.cardFooter}>
                          <span>
                            Own {formatPercent(player.percent_ownership, false)}
                            {player.ownership_as_of_date
                              ? ` · ${player.ownership_as_of_date}`
                              : ""}
                          </span>
                          <span>
                            {player.games_remaining_week == null
                              ? "Weekly volume unavailable"
                              : `${player.games_remaining_week} ${
                                  player.games_remaining_week === 1 ? "game" : "games"
                                } left this week`}
                          </span>
                        </div>
                        </StarterBoardPlayerDetails>
                      </li>
                    );
                  })}
                </ol>
              )}

            </section>
          );
        })}
      </section>

      <section className={`${styles.chartPanel} ${styles.goalFormPanel}`} aria-label="Recent goals for and against">
        <div className={styles.chartHeader}>
          <div><h2 className={styles.chartTitle}>Recent Team Form</h2><p>Goals For / Goals Against per game · completed games before {data?.resolvedDate ?? date}</p></div>
          {hasGoalForm ? <label>Window <select aria-label="Team form window" value={formCount} onChange={(event) => setFormCount(Number(event.target.value))}><option value={10}>Last 10 Games</option><option value={5}>Last 5 Games</option></select></label> : null}
        </div>
        {hasGoalForm ? <>
          <div ref={goalChartRef} className={styles.goalChart} role="img" aria-label={`Goals per game: ${goalForm.map((team) => `${team.team}, ${team.games} games, GF ${formatNumber(team.goalsFor, 2)}, GA ${formatNumber(team.goalsAgainst, 2)}`).join("; ")}`}>
            {goalChartSize.width > 0 ? <BarChart width={goalChartSize.width} height={goalChartSize.height} data={goalForm} margin={{ top: 5, right: 10, bottom: 0, left: -20 }}>
              <CartesianGrid stroke="currentColor" opacity={0.15} vertical={false} /><XAxis dataKey="team" tick={{ fill: "currentColor", fontSize: 11 }} /><YAxis tick={{ fill: "currentColor", fontSize: 10 }} />
              <Tooltip formatter={(value: number) => value.toFixed(2)} /><Legend /><Bar dataKey="goalsFor" name="Goals For" fill="var(--gf-color)" barSize={18} isAnimationActive={false} /><Bar dataKey="goalsAgainst" name="Goals Against" fill="var(--ga-color)" barSize={18} isAnimationActive={false} />
            </BarChart> : null}
          </div>
          <p className={styles.formProvenance}>{goalForm.map((team) => `${team.team}: ${team.games ? `${team.games} games, through ${data?.recentGoals?.teams.find((row) => row.team === team.team)?.games[0]?.date}` : "unavailable"}`).join(" · ")} · NHL final scores (including shootouts) · Season {data?.recentGoals?.seasonId}. Regular season + playoffs; no prior-season games.</p>
        </> : <p className={styles.formProvenance} role="status">Goals history unavailable: final NHL scores do not cover the preceding scheduled games for this slate. Only completed games in this season qualify; no older games are substituted.</p>}
      </section>
      <details className={styles.ctpiDisclosure}>
        <summary>CTPI · all-around team form and provenance</summary>
      <section
        className={`${styles.chartPanel} ${!data?.ctpi?.length ? styles.chartUnavailable : ""}`}
        aria-labelledby="team-form-heading"
        aria-describedby="team-form-description"
      >
        <div className={styles.chartHeader}>
          <div>
            <p className={styles.chartEyebrow}>Team context</p>
            <h2 id="team-form-heading" className={styles.chartTitle}>
              CTPI Team Form
            </h2>
            <p>
              How each team has been playing lately, compared with the league.
              It combines recent offense, defense, goaltending, and special
              teams in one score.
            </p>
          </div>
          <span className={styles.meta}>
            Data through {data?.sourceStatus?.ctpi?.throughDate ?? "Unavailable"}
          </span>
        </div>
        <div id="team-form-description" className={styles.chartGuide}>
          <span>
            <strong>50</strong> is league average
          </span>
          <span>
            <strong>Higher</strong> means stronger recent all-around form
          </span>
          <span>
            <strong>Lower</strong> means weaker recent all-around form
          </span>
          <span>Context only — not a game prediction or ranking input</span>
        </div>
        {(data?.ctpi?.length ?? 0) > 0 &&
        data?.sourceStatus?.ctpi?.state !== "ready" &&
        data?.sourceStatus?.ctpi?.message ? (
          <p className={styles.chartNotice} role="status">
            {data.sourceStatus.ctpi.message}
          </p>
        ) : null}
        {(data?.ctpi?.length ?? 0) > 0 ? (
          <>
            <div
              ref={chartGraphicRef}
              className={styles.chartGraphic}
              role="img"
              aria-label={`Recent team form for ${teamsPlaying.join(", ")}. Daily snapshots from the last 30 days compare recent offense, defense, goaltending, and special teams with the league. 50 is league average and higher is stronger.`}
            >
              {chartSize.width > 0 && chartSize.height > 0 ? (
                <LineChart
                  width={chartSize.width}
                  height={chartSize.height}
                  data={data?.ctpi ?? []}
                  margin={{ right: 20 }}
                >
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#9ea7b3" }}
                    padding={{ right: 20 }}
                  />
                  <YAxis
                    domain={yAxisDomain}
                    width={30}
                    tick={{ fill: "#9ea7b3" }}
                  />
                  <ReferenceLine
                    y={50}
                    stroke="#9ea7b3"
                    strokeDasharray="4 4"
                    label={{
                      value: "League avg",
                      position: "insideTopRight",
                      fill: "#cbd2dc",
                      fontSize: 10,
                    }}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "rgba(0,0,0,0.9)",
                      border: "1px solid #596272",
                      color: "#fff",
                    }}
                    labelStyle={{ color: "#fff" }}
                  />
                  {teamsPlaying.map((abbreviation) => (
                    <Line
                      key={abbreviation}
                      type="monotone"
                      dataKey={abbreviation}
                      stroke={teamColors[abbreviation] ?? "#fff"}
                      strokeWidth={2}
                      connectNulls
                      dot={(props: any) => {
                        const { key, ...dotProps } = props;
                        return (
                          <TeamEndpointDot
                            key={key}
                            {...dotProps}
                            dataKey={abbreviation}
                            lastDate={latestTeamFormByTeam.get(abbreviation)?.date}
                          />
                        );
                      }}
                      activeDot={{ r: 4 }}
                      name={abbreviation}
                    />
                  ))}
                </LineChart>
              ) : null}
            </div>
            <ul
              className={styles.chartLegend}
              aria-label="Latest team form by team"
            >
              {teamsPlaying.map((team) => (
                <li key={team}>
                  <span
                    className={styles.chartLegendSwatch}
                    style={{ backgroundColor: teamColors[team] }}
                    aria-hidden="true"
                  />
                  <strong>{team}</strong>
                  <span className={styles.chartLegendValue}>
                    {formatNumber(latestTeamFormByTeam.get(team)?.value, 0)}
                  </span>
                  <span className={styles.chartLegendReading}>
                    {describeTeamForm(latestTeamFormByTeam.get(team)?.value)}
                  </span>
                </li>
              ))}
            </ul>
          </>
        ) : (
          <div className={styles.chartEmpty} role="status">
            {data?.sourceStatus?.ctpi?.message ??
              "Recent team form is unavailable for this slate. Fantasy ranks are unchanged."}
          </div>
        )}
      </section>

      </details>

      <section id="board-yahoo" className={styles.personalization} aria-label="Yahoo today comparison"><StarterBoardYahoo /></section>

      {data?.validation ? <StarterBoardValidation validation={data.validation} className={styles.statusBanner} /> : null}

      {data?.sourceStatus ? (
        <details className={styles.sourceDetails}>
          <summary>Source coverage and provenance</summary>
          <p>Requested {data.requestedDate} · Resolved {data.resolvedDate} · Model {data.sourceStatus.projection.modelVersion ?? "Unavailable"} · Run {data.projectionRunId ?? "Unavailable"} · Published {publicationTime(data.sourceStatus.projection.updatedAt)}</p>
          <p>Polling every 30 seconds does not establish publication freshness. Pending or failed model-run status is unavailable unless supplied by a run receipt.</p>
          <dl>
            <SourceRow
              label="FORGE projections"
              state={data.sourceStatus.projection.state}
              value={`${data.sourceStatus.projection.date ?? "No date"} · ${
                data.sourceStatus.projection.inputVersion ?? "unverified provenance"
              }`}
            />
            <SourceRow
              label="Team ratings"
              state={data.sourceStatus.teamRatings.state}
              value={data.sourceStatus.teamRatings.resolvedDate ?? "Unavailable"}
            />
            <SourceRow
              label="Goalies"
              state={data.sourceStatus.goalies.state}
              value={`${data.sourceStatus.goalies.coveredTeams}/${data.sourceStatus.goalies.expectedTeams} teams · ${data.sourceStatus.goalies.freshTeams} fresh · ${data.sourceStatus.goalies.staleTeams} stale`}
            />
            <SourceRow
              label="Yahoo ownership"
              state={data.sourceStatus.ownership.state}
              value={`${data.sourceStatus.ownership.mappedPlayers} mapped · ${
                data.sourceStatus.ownership.unmappedPlayers
              } unmapped · ${data.sourceStatus.ownership.playersWithAsOf} with as-of · ${
                data.sourceStatus.ownership.playersMissingAsOf
              } without · ${
                data.sourceStatus.ownership.oldestAsOfDate &&
                data.sourceStatus.ownership.latestAsOfDate
                  ? `${data.sourceStatus.ownership.oldestAsOfDate}–${data.sourceStatus.ownership.latestAsOfDate}`
                  : "no as-of date"
              }`}
            />
            <SourceRow
              label="Team form history"
              state={data.sourceStatus.ctpi.state}
              value={data.sourceStatus.ctpi.throughDate ?? "Unavailable"}
            />
            <SourceRow
              label="Weekly volume"
              state={data.sourceStatus.gamesRemaining.state}
              value={
                data.sourceStatus.gamesRemaining.date ??
                data.sourceStatus.gamesRemaining.message ??
                "Unavailable"
              }
            />
          </dl>
        </details>
      ) : null}

      <SurfaceWorkflowLinks
        title="Continue in FORGE"
        description="Each link retains the supported context listed below. Player research links retain slate date and mode; team research links retain slate date. Other filters reset. League availability is not transferred."
        links={date ? workflowLinks : []}
      />
    </div>
  );
}

function findTeamAbbrev(teamId: number): string | null {
  return teamFor(teamId)?.abbrev ?? null;
}

function teamFor(teamId: number) {
  return Object.values(teamsInfo).find((team) => team.id === teamId);
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className={styles.statBox}>
      <div className={styles.statLabel}>{label}</div>
      <div className={styles.statValue}>{value}</div>
    </div>
  );
}

function StatTerm({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt>{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}

function SourceRow({
  label,
  state,
  value,
}: {
  label: string;
  state: string;
  value: string;
}) {
  return (
    <div>
      <dt>{label}</dt>
      <dd>
        <span data-state={state}>{state}</span> {value}
      </dd>
    </div>
  );
}
