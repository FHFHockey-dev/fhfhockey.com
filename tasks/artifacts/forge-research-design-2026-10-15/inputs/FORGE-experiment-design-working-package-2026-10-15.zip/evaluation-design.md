# FORGE: evaluation design, second research pass

October 15, 2026. Research specification only. No retained outcomes, protected data, source feeds, model execution, or external writes were used. This refines F05, F07, F17, F21 and F22 in the supplied amended plan and working checklist; it does not lift their execution gates.

## Recommendation and material changes

Keep the proposed three-mean first wave, but define its units as **three complete, selectable forecast pipelines**. Evaluate one target first, then carry one chosen challenger into prospective confirmation against the incumbent. Measure a forecast gain and a start/bench gain separately.

The useful additions beyond the existing plan are:

1. Count hidden searches: half-lives, feature alternatives, postprocessing, missing-input fallbacks, and outcome-driven retries belong in the candidate ledger.
2. Resolve a scope ambiguity: Section B/F07 lists four mean ablations, while the first experiment allows only baseline plus two challengers. Stage the fourth ablation later rather than silently expanding the first wave.
3. Preserve the estimand when handling dependence. Averaging daily mean errors equally is not the same as averaging all player-game errors; resampling must preserve the chosen numerator and denominator.
4. Evaluate recommendations on complete roster decision units, with a fixed tie-break and a pregame-defined actionable subset. Identical starters cancel from the paired utility difference.
5. Freeze pipeline recipes, while allowing fitted parameters to update only under the registered policy. A later observation may enter a later fit only after its label is genuinely available.
6. Predeclare when evidence will be inspected for promotion. A fixed-time interval cannot be repeatedly checked until it happens to favor the challenger.

These are proposed design choices, not findings that any particular FORGE implementation is defective. The existing plan's core cautions about chronology, exposure and small samples remain sound.

## 1. Finite experiment contract

### Scope and budget

Choose the first head from the separately approved coverage audit, using coverage and consumer relevance, not which preliminary result looks best. Retain the plan's distinction between unconditional scheduled opportunities and conditional-on-appearance targets. Do not switch between them mid-comparison.

Proposed first-wave budget:

- **M0:** the exact proposed comparison anchor: `season_rate` for skater counts, `g000` for the coherent goalie family, and `expanding` for W. Pin helper/version/population; prior selected v3 recipes remain preserved separately and are not interchangeable with these anchors.
- **M1:** pooled/shrunk rate × a fixed simple pregame exposure forecast, unless this duplicates M0. If it does, reconcile the menu before execution rather than inventing a replacement after seeing results.
- **M2:** M1 with exactly one predeclared change: enhanced exposure *or* one context block. Everything else stays fixed.
- **D1:** one mean-fixed distribution alternative against a named reference distribution, evaluated separately after the mean choice. It cannot enter the mean-model leaderboard as another mean candidate.

This is three mean pipelines in total, not three families with an unspecified tuning grid. A training-only, fully specified empirical-Bayes estimator can be part of one pipeline. If several shrinkage rules or half-lives are compared on selection losses, each selectable configuration counts against the budget. Pin preprocessing, reconciliation, clipping, fallback, random-seed policy, stopping conditions and software version. Deterministic refits at new origins are not new candidates; outcome-driven design edits are.

The additional exposure/rate ablation from F07 belongs in a later registered wave. An actual-minutes oracle is a diagnostic with no promotion rights. Neither the oracle nor an exploratory fourth forecast may supply a covert new selection option in this wave.

**Evidence:** Cawley and Talbot show that a finite, noisy selection criterion can itself be overfit and that tuning before repartitioning leaves evaluation optimistic. The evaluated object should include the selection procedure. Their examples are not temporal NHL experiments. Counting complete pipelines and the specific three-slot budget are our operational choices. [Cawley & Talbot, §§5.3–6](https://jmlr.csail.mit.edu/papers/volume11/cawley10a/cawley10a.pdf)

### Estimands and scores

For target k, each issued mean estimates the expected credited target under the declared population and information available at that forecast's origin. Score the **final consumer-visible forecast**, after any reconciliation.

For matched admitted cases i, define positive gain as:

ΔMSE = Σ wᵢ[(yᵢ − μ₀ᵢ)² − (yᵢ − μ꜀ᵢ)²] / Σ wᵢ.

Use player-opportunity-weighted MSE as the primary mean score, with wᵢ = 1, unless the product contract explicitly selects another population weighting before outcomes. Report RMSE, signed bias, player-balanced loss and count deviance secondarily. Do not change the winner because another descriptive score happens to look better. Report absolute paired improvement before percentage skill; percentage skill is undefined if baseline loss is zero and can be unstable near zero.

For a mean-fixed count-distribution comparison, predeclare the discrete ranked probability score, Σ over j ≥ 0 of [F(j) − 1{y ≤ j}]², with a certified tail-summation rule. Report zero/tail event checks alongside it. It measures distribution quality, not a change in the mean. For supported binary probability heads, predeclare Brier loss; calibration remains a separate diagnostic. Never substitute classification accuracy for probability quality. The ranked-score construction integrates proper binary scores over thresholds; our count version uses integer thresholds and lower-is-better orientation. [Gneiting & Raftery, §6.4](https://sites.stat.washington.edu/raftery/Research/PDF/Gneiting2007jasa.pdf)

**Evidence:** Squared error targets the mean; absolute error targets a median. Therefore MAE cannot be a competing primary criterion for selecting an expected-count predictor simply because its ranking is more favorable. [Gneiting, §1.3](https://arxiv.org/html/0912.0902#S1.SS3)

## 2. Train, select and confirm chronologically

Freeze a manifest containing the target, origin/cutoff definition, admissible source versions, label-availability rule, exact chronological boundaries, candidate recipes, weights and deterministic selection/tie rules. There is no defensible calendar split to invent before the coverage audit.

**Historical development:** rolling inner origins fit only on labels available before each origin. Selection chooses the lowest primary weighted MSE among M0/M1/M2 on later inner predictions, with earlier dates used for training. A deterministic tie favors M0, then the simpler challenger. If evaluating the selection procedure in historical outer periods, rerun that same inner procedure using only information preceding each outer origin; do not choose retrospectively whichever fixed candidate won the outer period.

**Exposure status:** all existing historical results keep their documented development/exposure status. Nested chronology does not restore an untouched reserve or authentic old source versions. A cleaner fold diagram is not a repair for previously exposed or late-captured information.

**Prospective confirmation:** before the permitted window, select one challenger from development and freeze its recipe against M0. Allow only the predeclared parameter-update/refit schedule, label-maturity rules and fallbacks. Do not use confirmation performance to change hyperparameters, features, eligibility, reconciliation or the chosen head. This tests the frozen challenger/update policy; it is distinct from testing an adaptive model-selection policy.

Use the timestamp of actual label availability, not just game date. For a next-10/20-game label, the whole label must have matured before it can train a forecast. Overlapping future horizons also induce overlapping evaluation errors; a random split or arbitrary fixed embargo is not a substitute for checking their actual outcome spans.

Preserve the current proposal's explicit fallback branches. A case with no individual target history may use the eligible pooled baseline when defined; missing required recent support despite individual history may not acquire a new fallback. Any remaining candidate omission makes it ineligible on the fixed baseline-covered comparison, with optional intersection diagnostics clearly secondary. A future always-issue fallback pipeline would be a distinct design change requiring approval. Report coverage, fallback use and losses; unresolved labels are not zeros.

## 3. Paired uncertainty with dependent, small samples

The historical realized difference is a descriptive fact for those cases. An interval that generalizes to other dates or players requires assumptions beyond arithmetic. State that population explicitly: initially, future dates for the admitted player/decision population, not all NHL players or all leagues.

**Proposed fixed-endpoint inference:** after the development-only diagnostic audit, use a paired calendar-block bootstrap over the entire panel for the frozen prospective comparison, provided the evaluator can defend weak dependence and approximate stability over that window. Draw the same blocks for both forecasts and retain every game, player and roster decision within a drawn date block. For a player-opportunity mean, resample date-level pairs (sum of paired loss differences, sum of weights), and recompute the ratio of totals. Do not take an unweighted average of daily mean losses unless an equal-date estimand was deliberately chosen.

Pin block-length selection and sensitivity settings on development data, before confirmation. Use block lengths compatible with the target's overlapping horizon. Do not choose a length because its final confidence interval excludes zero. Repeated-player dependence extending beyond the assumed blocks, strong trends, a few dominant dates or an unstable reference loss can invalidate the approximation. Date blocking does not magically solve every player/date dependence pattern.

**Small-window fallback:** show the paired estimate, date-by-date contributions, player/game concentration and leave-one-date/player sensitivity. Label these deletion exercises as diagnostics, not confidence intervals. Do not report a row-i.i.d. bootstrap, treat rolling folds as independent replicates, or call an arbitrary sign-flip test exact without its exchangeability/symmetry assumptions. If the required dependence assumptions or temporal support cannot be defended, the inferential result is **inconclusive**. More bootstrap draws do not create more independent dates.

**Evidence:** Politis and Romano's block resampling framework assumes weakly dependent stationary observations and highlights block-size selection as a substantive issue. It provides no guarantee for six NHL dates. [Politis & Romano, §§1–2, pp.1303–1304](https://users.ssc.wisc.edu/~behansen/718/Politis%20Romano.pdf)

**Evidence:** Few-cluster corrections can still understate uncertainty, and unequal cluster sizes worsen the problem; multiway clustering with few clusters has no automatic universal repair. [Cameron & Miller, §VI.A and §VI.E.3](https://cameron.econ.ucdavis.edu/research/Cameron_Miller_JHR_2015_February.pdf) Strong autocorrelation in paired losses can also distort the Diebold–Mariano comparison or sharply reduce its power. A standard test name alone does not validate this sample. [Coroneo & Iacone, §§2,6](https://arxiv.org/html/2409.12662v1)

## 4. Test actual start/bench utility

For each valid roster decision snapshot r, keep one common legal feasible set Sᵣ, one scoring rule, identical cutoff information, locks, eligibility and solver settings. Define a deterministic solver tie-break independent of future results. A change in tie-breaking alone must not masquerade as a forecast benefit.

For linear points leagues:

- A₀ᵣ and A꜀ᵣ are the baseline and challenger active-lineup indicators.
- zᵣ is the subsequently realized player fantasy-point vector under the pinned provider/rule version.
- Paired realized utility gain is ΔUᵣ = zᵣ · (A꜀ᵣ − A₀ᵣ).

This cancels every unchanged starter exactly. Preserve complete multi-position legal lineups; do not score independent player swaps that may not form a legal lineup. For the first head experiment, change only that head's admitted forecasts in the otherwise frozen category vector, so the utility comparison can be attributed to the intended intervention.

Primary decision summary: mean paired utility over **all admitted roster decision units**, including unchanged decisions with zero gain. Also predeclare an actionable subset using only roster, schedule, locks and eligibility: cases with meaningful competition for available active slots. Report its gain and denominator. “Days the challenger won” is never a valid subset. Disagreement rate and gain conditional on model disagreement are useful descriptions, but they do not replace the all-decision result.

Retain active games played, lineup validity, fallbacks, recommendation churn and per-date utility contributions. Separate points-league utility from category/matchup utility; the latter requires the pinned matchup state, opponent information and decision horizon. Several fantasy rosters can share the same NHL outcomes, so their results are not independent trials.

A hindsight optimum may quantify unrealized opportunity. Because it uses the same feasible set and realized outcomes for both systems, the difference in their hindsight regrets equals the paired utility difference above. It is unnecessary to claim hindsight is a reachable competitor.

The replay estimates the value of following the solver under the reconstructed constraints, not observed user adoption. A fantasy lineup choice ordinarily does not change NHL player outcomes; waiver availability and rival acquisitions are different. Without authentic acquisition availability, do not extend this start/bench result into a claim of achievable drop/add gains.

**Evidence:** Smart Predict, then Optimize formally evaluates the realized cost of the decision induced by a forecast; equal prediction error can produce different decision losses. The roster-day equations and replay controls above are our application of that principle. No published NHL lineup improvement is inferred. [Elmachtoub & Grigas, §§2–3](https://arxiv.org/html/1710.08005)

## 5. Stop, promote, or remain inconclusive

A remains a separately authorized validation-only operation and does not require predictive gain thresholds. Before the first new B comparison, bind the predictive decisions below; bind the utility margin only if B includes a utility claim. Any later prospective confirmation requires its own approved window, final margins, family of claims and fixed readout before its outcomes are inspected:

- practical mean-score gain δM, in squared target units;
- practical decision gain δU, in the selected league's points per decision unit, if claiming utility;
- confidence/error level and the family of claims it protects;
- permitted subgroup harm, fallback/coverage limits and operational latency/cost limits;
- the calendar endpoint and completed-label policy for the evaluation.

No universal numerical values are supplied by the reviewed literature. The current design is **not execution-ready while these fields are blank**. Develop the values from the user's consumer objective and costs before seeing the new comparison, rather than reverse-engineering them from observed improvements.

At the declared endpoint:

- **Reject on integrity:** leakage, a changed target/population, irreproducible forecasts, broken accounting, missing required pregame inputs or unsupported uncertainty claims. Repairing the design creates a new version; it does not turn old contaminated results into confirmation.
- **Predictive promotion candidate:** the predeclared uncertainty bound supports a gain beyond δM, and coverage, subgroup and operating gates pass. Improvement in a secondary score alone is insufficient.
- **Decision-value claim:** requires the separately predeclared utility evidence beyond δU. A better count forecast with unchanged legal starts has no demonstrated start/bench gain.
- **No useful gain:** a valid upper uncertainty bound falls below the practical gain required for this experiment, or operating costs defeat the benefit.
- **Inconclusive:** the interval spans practically useful and inadequate outcomes, or valid inference is unsupported. Keep M0 and state what evidence is missing. A future extension needs a separately frozen protocol; do not keep inspecting the same stream until a favorable ordinary interval appears.

Prefer one prospective head and one challenger in this wave. If later approving several heads from the same test, predeclare the family-wide error approach and test the final combined consumer vector; independent per-head wins do not establish combined lineup utility.

### Optional later improvement: honest repeated monitoring

Choe and Ramdas provide time-uniform confidence sequences for accumulated conditional expected score differences when the score differences are bounded. This can support repeated checking of a future binary Brier comparison without assuming stationary outcomes. It does not by itself cover raw count MSE, guarantee future superiority, or solve delayed/overlapping forecast feedback. [Choe & Ramdas, §§4.1–4.3.3,6](https://arxiv.org/html/2110.00115v4)

Proposed later use: participation probabilities, once the full opportunity population is authentic. Specify non-overlapping feedback batches, pregame-fixed weights, the score bound and the confidence sequence before launch. Obtain a separate derivation/review for delayed feedback. Do not clip legitimate count outcomes merely to borrow a bounded-score theorem. Keep this optional method out of the first count-mean promotion gate.

## Source review record

Primary research was opened on October 15, 2026. Sections actually read for this amendment:

- Cawley & Talbot (2010): full §5.3 and the relevant conclusion; tuning/selection is part of the evaluated procedure.
- Gneiting (2011; arXiv v2, 2010): full §1.3; mean versus median score contract.
- Gneiting & Raftery (2007): §6.4; construction of distribution scores from binary threshold scores.
- Politis & Romano (1994): full §§1–2, pp.1303–1304, read from the original PDF using OCR; stationary block construction and limitations. No claimed proof of finite-sample NHL validity.
- Cameron & Miller (2015): full §VI.A and §VI.E.3, plus relevant multiway implementation warnings; few-cluster inference.
- Coroneo & Iacone (arXiv v1, September 2024; journal publication 2025): §2 and full §6; paired-loss dependence requirements. The HTML's later rendering header is not the publication date.
- Elmachtoub & Grigas (arXiv 1710.08005): §2 setup and §3 loss definition; decision objective rather than forecast error alone.
- Choe & Ramdas (arXiv 2110.00115v4; published online 2023): §§4.1–4.3.3 and the unbounded-score/lag discussion in §6; sequential estimand and boundedness/feedback conditions. The HTML rendering date is not a new study date.

The numerical budget is an experiment-management proposal. None of these sources identifies a universally best NHL head model, sample-size cutoff, minimum percentage gain or guaranteed lineup benefit.
