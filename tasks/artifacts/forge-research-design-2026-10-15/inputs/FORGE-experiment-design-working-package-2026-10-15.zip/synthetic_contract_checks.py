"""Synthetic arithmetic checks only. No NHL data, model fitting, or evaluation labels."""
import unittest
from math import isclose

class ForecastContractChecks(unittest.TestCase):
    def test_linear_count_identity_survives_expectation(self):
        scenarios = [(0.5, 30, 27, 3), (0.5, 10, 8, 2)]
        for p, sa, sv, ga in scenarios:
            self.assertEqual(sa, sv + ga)
        means = [sum(row[0] * row[i] for row in scenarios) for i in (1,2,3)]
        self.assertAlmostEqual(means[0], means[1] + means[2])

    def test_expected_ratio_is_not_ratio_of_means(self):
        scenarios = [(0.5, 30, 27), (0.5, 10, 8)]
        expected_game_sv_pct = sum(p * sv / sa for p,sa,sv in scenarios)
        ratio_expected_counts = sum(p*sv for p,sa,sv in scenarios)/sum(p*sa for p,sa,sv in scenarios)
        self.assertAlmostEqual(expected_game_sv_pct, .85)
        self.assertAlmostEqual(ratio_expected_counts, .875)
        self.assertFalse(isclose(expected_game_sv_pct, ratio_expected_counts))

    def test_zero_denominator_is_not_zero_ratio(self):
        def ratio(n,d): return None if d == 0 else n/d
        self.assertIsNone(ratio(0,0))

    def test_participation_not_applied_twice(self):
        p_appearance, conditional_count = .5, 2
        unconditional_count = p_appearance * conditional_count
        self.assertEqual(unconditional_count, 1)
        self.assertNotEqual(p_appearance * unconditional_count, unconditional_count)

    def test_role_exposure_rate_covariance(self):
        # Equal scenarios: 10 min at .1/min, or 20 min at .2/min.
        paired_mean = .5*10*.1 + .5*20*.2
        product_of_means = (.5*10+.5*20)*(.5*.1+.5*.2)
        self.assertAlmostEqual(paired_mean, 2.5)
        self.assertAlmostEqual(product_of_means, 2.25)

    def test_better_each_metric_does_not_guarantee_better_points_mse(self):
        baseline_errors = (1., -1.)
        challenger_errors = (.5, .5)
        for b,c in zip(baseline_errors,challenger_errors):
            self.assertLess(c*c,b*b)
        self.assertGreater(sum(challenger_errors)**2,sum(baseline_errors)**2)

    def test_pp_allocation_preserves_full_roster_residual(self):
        team_clock, skaters = 4., 5
        allocations = {'modeled_a': .2, 'modeled_b': .1, 'other': .7}
        self.assertAlmostEqual(sum(allocations.values()),1)
        minutes = {k: team_clock*skaters*a for k,a in allocations.items()}
        self.assertAlmostEqual(sum(minutes.values()),20)
        self.assertAlmostEqual(sum(minutes.values())/team_clock,5)

    def test_error_decomposition_needs_cross_term(self):
        rate_residual, exposure_residual = 2., -1.
        self.assertEqual((rate_residual+exposure_residual)**2,
                         rate_residual**2+exposure_residual**2+2*rate_residual*exposure_residual)
        self.assertNotEqual((rate_residual+exposure_residual)**2,
                            rate_residual**2+exposure_residual**2)

if __name__ == '__main__':
    unittest.main(verbosity=2)
