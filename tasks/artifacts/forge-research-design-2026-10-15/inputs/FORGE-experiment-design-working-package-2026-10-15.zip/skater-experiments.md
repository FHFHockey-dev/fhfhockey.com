# FORGE round 2: finite skater opportunity and rate experiments

Research-to-experiment specification, 15 October 2026 UTC. Research only. This document does not report a new fit, source collection, protected-data review, implementation audit, or authorization to execute. It extends the amended plan and checklist rather than replacing F03–F06 or the existing experiment hold.

## Recommendation

Use the first admissible SOG/HIT/BLK head to answer one question: **does error improve more by forecasting opportunity better or by estimating production per unit of opportunity better?** Keep the direct-count comparator. Then test one opportunity-aware PP challenger, one assist-context challenger, and one PIM frequency/severity challenger only when their inputs qualify. Do not open all cards together.

The most useful additional source found in this pass is an older primary NHL assist study: it motivates a bounded historical teammate-shot feature before an elaborate primary/secondary assist architecture. Its evidence is not next-game, chronological validation. The PIM work below adds an important design guard: penalty severity can itself curtail TOI, so actual final-game minutes are especially problematic as a prospective PIM exposure.

## What is inherited, and what must be frozen first

Read and preserve:
- FORGE amended research plan, dated 2026-10-15: F03–F12, F14–F15 and the finite first-experiment budget.
- FORGE working checklist, dated 2026-10-15: no additional protected outcome access, new fit, scoring run, production mutation, or source acquisition is authorized by research.

Common contract for every card:

1. **Population.** A scheduled player-game opportunity, with an as-of team/eligibility binding. If a verified participation risk set cannot be reconstructed, conduct and label only an appearance-conditional benchmark. Do not fill unresolved source rows with zero. For an unconditional scheduled-opportunity claim, membership must not depend on eventual scoring, minutes or future survival. The current A/B proposal instead declares an explicitly positive-TOI, appearance-conditional population; its validity filter can use realized TOI to define that estimand, but cannot support participation or unconditional claims. Apply the same frozen filter to every candidate and review the PIM exception separately.
2. **Clocks.** Every feature needs event time, source publication/version time and retained-availability time. A source captured after the simulated cutoff remains retrospective-development evidence unless authentic earlier availability can be established. No new worker or new partition name restores blindness.
3. **Comparison.** Same admitted rows, labels, origin, missingness policy and output reconciliation for both methods. Preserve forecasts before labels are joined. Report exclusions by head and method; failure to issue a forecast is coverage loss, not a row silently removed from the comparison. Preserve the owner proposal's asymmetric fallback policy: a no-individual-history case may use its eligible pool, but missing required recent support with individual history does not gain a new fallback. A remaining omission makes that candidate ineligible on the fixed baseline-covered comparison; do not introduce blanket fallback filling without a separately approved design change.
4. **Chronology.** All prior rates, group priors, shrinkage, context coefficients and fallback rules are fit using earlier data. Selection happens only in earlier chronological development; a later block evaluates the chosen procedure. Training a second stage on predicted TOI requires rolling-origin out-of-fold TOI predictions, not fitted values from a model that saw those same outcomes. If source completeness/revisions require a lag or an embargo, freeze it in the manifest.
5. **Search limit.** The first wave is the frozen incumbent plus at most two additional mean specifications for one active head/component. These seven cards are a queue, not a Cartesian-product search. If the incumbent is not a direct-count comparator, the direct-count and exposure/rate models consume the two challenger slots; defer context. An actual-minute oracle is a labeled diagnostic, never an eligible winner. One later mean-fixed distribution comparison is a different objective.
6. **Scores.** Primary: paired MSE gain, baseline minus challenger, so positive values favor the challenger, with bias and RMSE in category units. Report player-game-weighted and player-balanced results, by date block, with coverage. Add conditional count deviance where defined. Use probability/distribution scores only for genuinely issued probabilities/distributions. Neither MAE nor correlation alone decides a mean forecast.
7. **Decision gate.** A is validation-only and does not depend on predictive thresholds. Before the first new B comparison, the evaluator must freeze practical predictive benefit/harm tolerances, coverage/failure rules, uncertainty method, endpoint and operating limits. A utility margin is required only if B includes a utility claim. Later prospective confirmation requires its own approved window, final margins and fixed readout before outcomes are inspected. Unfilled gates mean a research-ready card, not an execution-ready protocol. Keep date/game/player dependence visible. If evidence spans both useful benefit and material harm, conclude inconclusive and do not promote. No universal percent-improvement or sample-size threshold is asserted here.

### Shared opportunity notation and a useful error diagnostic

For appearance-conditional production, let M_s be minutes in a mutually exclusive strength/state s, and r_ks be the corresponding category rate. A simple exposure forecast is sum_s Mhat_s rhat_ks. If rates use per-60 units, divide by 60. EV must not silently mean only 5v5; retain a mapped residual for other official states. Add appearance probability only if Mhat is conditional on appearance. An already-unconditional exposure forecast must not be multiplied by participation again.

A forecast of E[M] times a forecast of E[rate] is generally an approximation to E[M × rate]. With role uncertainty, integrate paired scenario-specific opportunity and rate, rather than multiply independently averaged components. Neither a scenario label nor a single point exposure removes within-scenario dependence automatically.

After forecasts are locked, use actual minutes only in this exact diagnostic identity:

Y_k − sum_s Mhat_s rhat_ks = (Y_k − sum_s M_s rhat_ks) + sum_s (M_s − Mhat_s) rhat_ks.

Report the two terms and their cross-product. The squared total is not the sum of their squared terms unless the cross-term vanishes. The first term includes outcome noise as well as rate misspecification. This is not a causal attribution, and replacing Mhat by M need not improve each realized squared error. NHL team-level research explicitly distinguishes such postgame-manpower conditional calculations from available pregame predictions. [R1]

## Card K1: separate exposure and rate for the first supported SOG/HIT/BLK head

**Maps to:** F07 and F09; F10 remains a separate context choice. **Priority:** first after F03–F06 and separate execution approval.

**Question.** Does explicit opportunity modeling beat an otherwise defensible direct count forecast, and which single additional component is worth testing next?

**Baseline and challengers.**
- For this proposed broader comparison, pin the skater anchor to `season_rate` as defined in the owner proposal. Preserve prior selected v3 policies as separate artifacts, not interchangeable incumbents.
- B: reproduce that pinned anchor without changes. Preserve a direct-count comparator D: a training-only, shrunk player category mean per appearance, with its predeclared cold-start fallback. If B already equals D, reuse it.
- E: the same admitted historical labels, pooled strength-specific player rate, and a simple pregame strength-minute forecast. Begin with defensible position pooling; pin one prior-strength estimator; any comparison of alternative priors on selection losses is enumerated and charged to the finite ledger before B. Learn rates from historical counts and historical exposure, rather than an unweighted mean of game-level count/minute ratios.
- X: change **either** the minute model while holding E's rate fixed, **or** add one rate/context block while holding E's minute forecasts fixed. Pick the branch before its later evaluation, from coverage plus earlier development diagnostics. If D and E already use the two challenger slots, X is a later experiment.

**Inputs and qualification.** Category counts, historical TOI with matching strength definitions, position, game/date/team mapping and forecast origins. Stronger minute models require genuinely pregame role/status history. If strength detail is missing, one all-strength pooled-rate experiment may proceed with that explicit limitation; do not fabricate a PP/PK decomposition.

**Chronological leakage risks.** Current-game TOI, end-of-season team/opponent rates, current-game score state and future roster membership. Learning a rate on historical realized minutes is permitted; substituting target-game minutes into E or X is not. If the model uses a predicted-minute feature during fitting, use chronological out-of-fold predictions.

**Paired diagnostics.**
- D versus E: count loss/bias and forecast issuance coverage.
- For an opportunity branch: E versus X with identical rates, plus total/strength-minute errors. A lower minute MSE is not sufficient if count decisions worsen.
- For a rate branch: E versus X with identical minutes, plus residuals by predicted rate, position and exposure band formed pregame.
- Run the locked-rate actual-minute identity above as a diagnostic. Show whether aggregate gains are concentrated in one player, date, or rare event.
- SOG: map recorded SHOT and GOAL events to the intended SOG definition; do not import an attempts rate unchanged. BLK: map a shooting-team BLOCK to the defending player before using it. HIT: score official/provider credited hits, even if training ability estimates are later neutralized. [R2]

**Failure/stop.** Stop if definitions cannot reconcile, target exposure is unavailable at issuance, a model obtains an easier population, or the apparent gain requires actual future minutes. Do not promote a count head merely because its TOI component improved. Keep the simpler direct-count method if the exposure machinery does not earn its complexity under the frozen gate.

**What stays conditional.** All heads remain appearance-conditional without an authentic risk set. Strength-specific claims remain unavailable without strength labels; this need not block an all-strength count baseline.

## Card K2: respond to role changes and trades without erasing player ability

**Maps to:** F08 and F14. **Priority:** one later opportunity branch after K1, not a simultaneous rate overhaul.

**Question.** Can pregame role evidence change minute/deployment forecasts sooner than a static historical average, without chasing noisy recent production?

**Baseline and challenger.**
- B: K1's frozen rate model and simple minute policy, with the same participation treatment.
- C: hold every category rate fixed, but replace minutes/deployment with one predeclared adaptive policy: regularized recent usage plus time-stamped role evidence, with explicit unchanged/promoted/reduced/unknown scenarios. Use one fixed decay or one fully specified training-only estimator. If comparing a decay shortlist on selection losses, enumerate all values and charge each selectable configuration to that card's separately approved finite ledger before execution; inner chronological selection does not waive the budget. Do not add a state-space rate model in this card.
- At a trade, carry the player's shrunk rate history; update team, opportunity and context at the time they become known. A blanket ability reset is not part of C. At no-history/sparse-history origins, use a pooled prior with a separately issued workload prior or scenario, not zero talent. These groups are defined by information available at the origin, not official rookie status or eventual NHL survival.

**Inputs and qualification.** Prior realized usage, as-of position/team, trade/call-up/return dates and publication timestamps for role reports. Without archived pregame news, an explicitly usage-only adaptive comparison is possible; a claim that the model anticipated announced changes is not.

**Chronological leakage risks.** Defining “promoted” from the target game's actual PP minutes; retrieving today's edited line page as yesterday's knowledge; backdating trade eligibility; choosing the best decay after observing post-change production. A rookie prior cannot be fit with that rookie's later season or with future survivors only.

**Paired diagnostics.** Same count forecasts except minutes, so separately inspect minute errors and category loss. Freeze groups at issuance: no prior NHL exposure, sparse exposure, established history, known team change, known role report, unknown/stale report. For change episodes, show first scheduled game and games 2–5 after the **known** event; five is an operational diagnostic horizon, not a sufficiency claim. Include scheduled nonappearances when the risk set qualifies. Show stable-role controls and reversal/false-alarm costs, not just successful promotions. A retrospective actual-usage-change subgroup may be exploratory, but cannot select who receives C.

**Failure/stop.** Reject adaptation that only helps after future usage identifies the change, gains from a few selected success stories, or persistent false promotions erase benefit on stable cases. If minute adaptation helps but counts do not, promote no production head on that evidence alone. Poor rookie precision is a reason for a labeled fallback/uncertainty, not deleting rookies from the benchmark.

**Evidence status.** NHL aging research documents selection into observed careers, rather than validating a next-game rookie or trade adjustment. [R3] The event-driven minute policy is a FORGE hypothesis. The reviewed NHL evidence does not establish a universal half-life or trade reset.

**What stays conditional.** Availability probabilities require a complete opportunity set. News-driven role claims require historical source clocks. Cold-start estimates remain pooled/scenario-conditional where personal history is absent.

## Card K3: add one target-specific count context block

**Maps to:** F09/F10. **Priority:** only after K1; use one block, one head, one comparison.

**Question.** Does context improve the recorded count after player rates and predicted minutes are fixed?

**Baseline and challenger.** B is K1 E, with frozen minute forecasts. C adds exactly one regularized block selected for that head before later scoring:
- SOG: historical own-team/opponent shot environment with a pinned denominator.
- BLK: historical opponent attempt/blockable-shot environment and/or PK exposure, only if the block was specified as a single coherent exposure block. Opponent SOG alone is not the population of shots that can be blocked.
- HIT: a recent training-only recorded-count venue block is a plausible first choice. Keep any ability neutralization and destination-rink observation adjustment explicit.

Rink and opponent blocks should not be introduced together unless that combined block consumes the single declared challenger and is evaluated as such; it cannot then identify the gain attributable to either one. Prefer separate later ablations to claims of causal attribution.

**Inputs and qualification.** Training-only context histories, exact event-to-player orientation, home/away and arena identity. Estimate contemporary effects from admitted history. Do not copy 2007–13 rink coefficients. The old rink study supports the mechanism and illustrates BLOCK orientation; it does not certify current coefficients or next-game gains. [R2]

**Chronological leakage risks.** Realized target-game score differential, final-season opponent rates, arena labels inferred after relocations, or inferring player ability and venue with the full test season. A pregame score-state forecast is a separate model, not a substitute name for observed score state.

**Paired diagnostics.** Same minute predictions and same admitted rows; paired count loss and bias by home/away, arena, position, known team change and calendar block. For venue, compare both neutralized latent ability and the final re-inflated credited-count prediction, but accept only on the credited target. Show effect shrinkage for sparse/new venues and concentration by home-team schedule.

**Failure/stop.** Fail the head if neutralized ability looks better but credited-count forecasts or lineup inputs worsen; if venue effects only memorize team strength; or if orientation/era mappings fail. Sparse contexts revert to the baseline rather than generating extreme multipliers.

**What stays conditional.** Lack of venue/context features blocks C, not a truthful venue-blind count baseline. Any all-strength claim requires all-strength labels or a stated residual treatment.

## Card K4: goals from predicted shot volume and shrunk finishing

**Maps to:** F11. **Priority:** after an admissible SOG component; native shot quality is a later card only if needed.

**Question.** Does a coherent SOG-generation × finishing mean beat a direct goal-rate forecast before adding shot-location complexity?

**Baseline and challenger.** B is a direct pooled goals/exposure forecast on the admitted rows. C uses the same predicted opportunity, a frozen pregame SOG-volume component and a shrunk probability of goal per compatible SOG, with scenario-specific strength/deployment if available. The scalar product of separate means is an approximation when volume and finishing co-vary; state the conditional independence assumption or integrate the paired scenarios. Do not tune the SOG component again using the goal test block.

**Inputs and qualification.** Compatible goals/SOG histories, position/strength, predicted exposure and versioned SOG forecasts. A native historical shot-quality feature is not needed for C. If a future extension uses xG per unblocked attempt, it must use a compatible attempt-generation model or convert denominators explicitly; it cannot be multiplied directly by predicted SOG.

**Chronological leakage risks.** Target-game shot location, shot type, rebound, score, goalie-on-ice status or actual shot count. Historical shot features are usable only with training-time native model versions; a quality model trained on later goals can leak into older feature rows.

**Paired diagnostics.** B versus C on goal MSE/bias; evaluate SOG-volume performance separately. Run actual SOG with locked finishing as an oracle diagnostic only. Check finishing calibration on historical-origin held-out shots separately from next-game G forecast quality. Enforce nonnegative means and G ≤ SOG with compatible official definitions; evaluate the reconciled final predictor rather than the unconstrained pre-reconciliation winner. Report PP and non-PP component performance only if labels qualify.

**Failure/stop.** No goal promotion from improved shot-level classification alone, improved SOG alone, or an oracle-volume gain. Stop if extra model error cancels the potential decomposition benefit. Keep direct G if C does not win its frozen gate. The primary NHL weighted-shot study found no demonstrated skater predictive superiority over raw shots in its older split-half comparison; it provides no guarantee either way for this next-game experiment. [R4]

**What stays conditional.** No matching SOG/shot labels means no finishing decomposition. A direct G forecast may still qualify. PP/strength-specific finishing remains conditional on those labels and forecast opportunity.

## Card K5: assists, one historical teammate-shot signal before more decomposition

**Maps to:** F11. **Priority:** after basic exposure, before a full goal-involvement simulator.

**Question.** Does a single lagged playmaking-context signal improve A beyond a shrunk personal assist rate and forecast minutes?

**Baseline and challenger.** B is the strength-compatible shrunk assist-rate × predicted exposure forecast, with its direct-count comparator retained. C adds one historical teammate-shot contribution feature for the 5v5 component: a training-only, pooled measure of non-self on-ice shooting relative to an explicitly defined teammate/off-ice reference. Keep minute forecasts and all non-5v5 components identical. The exact feature formula and regularization must be pinned before execution; do not claim the existing pipeline implements PLAY or invent passing events. A simpler historical non-self on-ice shot rate is a different candidate and must be named as such, not presented as a reproduction of the source metric.

**Inputs and qualification.** Historical event shooters, on-ice IDs/shift mapping, strength and exposure; personal A labels; versioned team/teammate bindings. No passing-event assumption is needed. Qualify lineup/on-ice coverage first, especially at shift boundaries. If these inputs are unavailable, defer C and retain direct/shrunk A.

**Chronological leakage risks.** Season-wide WOWY values using later teammate production; selecting linemates from the target game; full-season player-pair weights; deriving the rookie's prior from later history; fitting the added feature to the same later block used to judge it. All context/reference estimates must end before issuance.

**Paired diagnostics.** A MSE/bias on identical player-games, separately for forwards/defense, sparse history and known team changes. Also score the covered 5v5 component without relabeling it as all-strength A. Verify the feature adds information beyond personal SOG and team pace rather than functioning as a noisy duplicate. Report sensitivity to source missingness and pair-weight instability. Do not enforce a hard “assists ≤ on-ice non-self goals” identity without auditing line changes and credit rules; on-ice activity is a predictive feature, not automatically an exact assist-opportunity ledger.

**Failure/stop.** Reject if coverage shrinks selectively, the feature requires future pairings, or apparent gain disappears after chronological construction. A 2013 NHL study compared a shot-based teammate-contribution addition with assists alone, separately by position, using half/full-season rate targets and 10-fold CV. Its 5v5, both-goalies-on-ice result motivates this card; it is not evidence of next-game all-strength improvement or of FORGE gains. [R5]

**Conditional alternative, not an extra automatic candidate.** Split primary and secondary assists only if reliable labels qualify and earlier diagnostics justify that use of the challenger budget. Compare **the sum** of separately pooled components with the same B, on the same rows, without also adding a new context block. Never infer that secondary assists have zero signal or erase them from the fantasy target. If only total A exists, total A remains a valid head; unsupported A1/A2 heads are unavailable.

## Card K6: power-play opportunity versus player deployment

**Maps to:** F08/F11. **Priority:** after basic exposure; supports PPP but is first judged on opportunity components.

**Question.** Can the model distinguish a team getting little PP time from a player losing deployment, and does that improve PPP after opportunity uncertainty is integrated?

**Baseline and challenger.** B is a direct player PP-minute forecast plus a frozen pooled PPP-per-PP-minute rate, with direct PPP retained as comparator. C holds the PPP rate fixed and decomposes player PP minutes into: forecast team PP clock time by compatible manpower state, plus conditional player allocation/deployment under PP1/PP2/no-PP/unknown scenarios. Estimate the scenarios using only available pregame evidence and earlier realized usage. Avoid a parallel rate enhancement in this card.

**Allocation contract.** For a fixed state s with n_s skaters and PP clock time T_s, available team skater-minutes are n_s T_s. Define allocation against that budget, including an “other/unmodeled skaters” residual. Then player M_i,s = n_s T_s a_i,s and allocations sum to one over the full roster/residual, not over the pilot subset. Player fractions of team PP **clock time** do not sum to one. Integrate the joint scenario expectation E[n_s T_s a_i,s], rather than assume that independently averaged opportunity and deployment multiply exactly. Define empty-net/extra-attacker and official PP status separately; extra skaters alone do not define the official PPP target.

**Inputs and qualification.** Team PP time/opportunities, actual manpower-aware histories, player PP TOI, PP G/A or verified PPP labels, roster/news clocks, and mapped official scoring states. A penalty/opportunity count is not a fixed multiple of two minutes: goal termination, simultaneous/stacked penalties and other states matter. This clock/deployment split can start without a full game simulator. [R1]

**Chronological leakage risks.** Actual target-game penalties or PP duration; assigning PP1 from target-game usage; using revised practice reports; and interpreting a game with no team PP opportunity as evidence the player lost their PP role. Historical nonzero-opportunity games inform deployment; zero-opportunity games still inform the team opportunity model, not an observed deployment share of zero.

**Paired diagnostics.**
- Team PP exposure: calibration/bias, zero-PP probability if issued and PP-time error.
- Player deployment: conditional allocation error on games with usable team opportunity; report uncertainty for very short opportunities, rather than unstable raw ratios.
- Final player exposure and PPP: paired minute and PPP count loss, across known PP1/PP2/no-PP/unknown reports and stale/fresh evidence groups fixed pregame.
- Two separate locked diagnostics: substitute actual team PP exposure with forecast allocation; substitute actual allocation with forecast team exposure when actual allocation is defined. A full-oracle diagnostic is separate. These locate sensitivity, not deployable gains or additive causal effects.
- Preserve PPP = PP G + PP A and PPP ≤ G + A for final compatible marginal means; if joint draws are promised, enforce compatible identities per draw. Keep an other-player residual in team reconciliation.

**Failure/stop.** No PPP promotion if team opportunity improves but player exposure/PPP deteriorates, if allocations exhaust the pilot roster incorrectly, or if sparse PP labels make gains indeterminate. If only a few nonzero PPP outcomes exist, report the full uncertainty and inconclusive result rather than tuning until a winner appears. Do not collapse unknown PP role to zero.

**What stays conditional.** With only total PPP labels, direct PPP can remain an appearance-conditional head; PP G/A or role-state claims cannot. Without authentic roster/role history, scenario-specific forecasts must be explicitly conditional and the news-value claim is untestable. Without a full participation risk set, unconditional scheduled-game PPP remains unsupported.

## Card K7: rare PIM, credited penalty frequency and severity

**Maps to:** F12; any dynamic extension waits for F14. **Priority:** after a penalty-accounting qualification, not a reaction to one 14-PIM result.

**Question.** Does separating occurrence from penalty severity improve the full PIM mean and tails without deleting legitimate extremes?

**Baseline and one challenger.** B is a pooled direct player PIM mean per admitted opportunity/appearance, with a pinned historical update policy. Choose **one** challenger after metadata qualification:
- If penalty-event severity/credit marks reconcile: a regularized marked-count model, forecasting counts of credited penalty classes and summing their credited-minute contributions. Learn player event rates with strong pooling; use a pooled class composition when individual marks are too sparse. Compound bundles must be counted consistently, rather than treating a five-minute major plus added misconduct as one unexplained independent minute count.
- If only player-game PIM totals qualify: one pooled hurdle mean, P(PIM>0) × E[PIM | PIM>0], with no invented event classes. This fallback replaces, rather than accompanies, the marked-count challenger. A shifted unit-count distribution on positive minutes is not assumed to reproduce hockey's marked/bundled support.

**Inputs and qualification.** Historical credited player PIM, penalty type/severity, assessed player versus serving player/team attribution, revisions and applicable season/provider definitions. Verify event sums against official/provider PIM, including bench/goalie-served penalties, multiple assessments, misconduct/ejection marks and simultaneous events. Team shorthanded time is not a PIM label. PIM includes assessed minutes even without an opposing power play. [R6] Do not derive the target solely from penalty-clock service.

**Exposure warning.** Freeze a pregame workload/history signal if useful. Do not make actual target-game TOI a required exposure. Severe penalties or ejections can reduce final TOI, producing dependence between the target and denominator. A legitimate PIM total can also accrue with little ordinary on-ice exposure, so “zero minutes implies zero PIM” is not a safe general modeling rule. Compare a per-game mean first; a marked Poisson-per-minute construction is a hypothesis, not a necessary starting point.

**Chronological leakage risks.** Current-game fighting, score, officiating decisions, final TOI, ejection and opponent-response information; retrospective aggressor classifications chosen from the outcome; using officials not announced by issuance. Neither opponent rivalry nor past fighting receives a hand-set multiplier from the sources.

**Paired diagnostics.** Full PIM MSE/bias remains primary. Separately inspect P(PIM>0) Brier/log loss and calibration, positive-minute mean error, predicted class frequencies/severity mix where genuine labels exist, and high-PIM tail mass/proper distribution score when distributions are issued. Freeze any numeric “tail” cut before later scoring from hockey label classes or earlier training, not the losing test observation. Show cumulative loss contribution by date/event bundle and leave-one-date influence sensitivity while retaining every valid observation in the primary result. Typical-game and tail summaries are diagnostics, not replacement targets.

**Failure/stop.** Stop marked modeling if event credits cannot reconcile. Stop a hurdle that improves zeros but misses the positive mean sufficiently to worsen the full target. Do not winsorize valid extremes, remove fighting games, promote on typical-game MAE alone, or claim a few rare events establish stable tail calibration. If very sparse marks preclude useful inference, keep the pooled direct head and label the tail distribution unvalidated.

**Evidence status.** Primary NHL penalty research distinguishes penalty classes and shows substantial era change in fighting, but tests deterrence/associations, not pregame individual fantasy PIM forecasts. [R7] Dynamic binary/positive count mixtures are a transferable idea from retail forecasting, not NHL validation and not an exact severity model. [R8]

**What stays conditional.** Without event marks, individual class/severity heads are unavailable but total-PIM/hurdle candidates may qualify. Without complete scheduled participation, their output remains appearance-conditional. Missing tail evidence prevents a calibrated-tail claim, not honest issuance of a pooled mean.

## Minimal sequencing and stopping decisions

1. Finish metadata/cohort/clock gates; reproduce the baseline. None of this document authorizes that execution.
2. Open K1 for one best-covered SOG/HIT/BLK head. If no exposure inputs qualify, keep direct-count benchmarking; do not manufacture exposure.
3. Choose exactly one evidence-led extension: K2 minutes **or** K3 rate/context. Reuse previously existing functionality if later code review verifies it; these cards do not assert it is absent.
4. Use admitted components to test K4, K5 or K6 independently. A component improvement does not promote every dependent head.
5. Open K7 only with its explicit label gate. Its challenger need not share the same exposure architecture as SOG.
6. Only after choosing means, compare one mean-fixed distribution alternative on zero/tail and proper scores. Dispersion-only improvement cannot change mean MSE or a linear-points decision with fixed means. Do not add another dispersion layer merely because pooled raw variance exceeds pooled raw mean.
7. Pass supported final outputs to the common legal-lineup replay. Keep counts, distribution quality and lineup utility separate. A failed/inconclusive card is a valid stopping result; it is not permission for another unlogged tuning sweep.

## Unsupported-output register

- **All G/A/PPP/SOG/HIT/BLK/PIM unconditional scheduled-game heads:** conditional on appearance until the opportunity risk set and participation treatment qualify. PIM additionally needs a label rule that does not infer eligibility from positive minutes alone.
- **Strength components:** unavailable when matching exposure/outcome labels do not exist. Do not label all-strength rates as 5v5 or PPP-specific rates.
- **Rookie-specific individualized talent:** unsupported with no individual history. A declared pooled prior is permissible; transfer coefficients from other leagues remain deferred without verified input histories and their own validation.
- **News-responsive role forecasts:** unsupported historically without authentic source availability. Usage-only adaptation remains a separate, testable policy.
- **A1/A2:** unavailable without verified primary/secondary credit. Total A need not be unavailable.
- **PP G, PP A, role-specific PPP:** conditional/unavailable according to their labels and role evidence; a direct total-PPP baseline can still be evaluated on its honest population.
- **Penalty-class and calibrated rare-tail heads:** unavailable/unvalidated without the event accounting and later evidence. Total PIM can remain a simpler supported estimand.
- **Full joint distributions or team-reconciled totals:** not established by accurate marginal means. Require compatible identities, full roster/residual accounting and dedicated joint validation if promised.

## Primary-source ledger: sections actually checked

All accesses 15 October 2026 UTC. These are evidence/idea boundaries, not statements about the current FORGE implementation. No externally authored fantasy projection was used.

**R1 — Buttrey, Washburn & Price (2011), Estimating NHL Scoring Rates.** [Author-hosted paper](https://faculty.nps.edu/awashburn/docs/EstimatingNHLScoringRates.pdf). Read §2.2–§3.1 on manpower intervals and §4.4/Table 4, printed pp.13–14, on evaluation. NHL team-level, 2008–09: actual future manpower duration is explicitly unavailable pregame. Supports an oracle guard and state-aware exposure, not player-level parameters, current rule details, or a universal rolling window. The K1/K6 decomposition tests are proposed FORGE experiments.

**R2 — Schuckers & Macdonald (2014), Accounting for Rink Effects in the NHL's Real Time Scoring System.** [Full text](https://arxiv.org/html/1412.1035). Read §§2–3 and §§4.1/4.3. Historical NHL evidence, 2007–13 non-empty-net 5v5 regulation: recording effects and event orientation matter. The paper's BLOCK is indexed to the shooting team. Current venue-aware credited-count forecasting is a new test, not reuse of old multipliers. The HTML's later display date does not update the study's data era.

**R3 — Schuckers, Lopez & Macdonald, Estimation of Player Aging Curves Using Regression and Imputation (v2, 2023; initial preprint 2021).** [Full text](https://arxiv.org/html/2110.14017). Read §1 and §§4–5. NHL application uses season-standardized points/game for forwards; simulation and NHL missingness support separating player effects from age/entry/exit selection. This is not a next-game rookie/trade model or a universal age prior. K2's sparse-history and survival-bias guards are experimental-design inferences.

**R4 — Macdonald, Lennon & Sturdivant (2012), Evaluating NHL Goalies, Skaters, and Teams Using Weighted Shots.** [Full text](https://arxiv.org/html/1205.1746). Read §§4–5.1, especially the skater split-half comparison. NHL 2008–11 context; its shot descriptions condition on realized events. That comparison did not establish weighted-shot superiority over shots for skaters. This neither rules out modern quality models nor establishes a next-game gain for K4. No coefficients or performance gains were transferred.

**R5 — Macdonald, Weld & Arney (2013), Quantifying Playmaking Ability in Hockey.** [Paper](https://arxiv.org/pdf/1307.6539). Read §§3.1, 3.4–3.5, 4.1 and Figure 4, PDF pp.8, 12–17. Primary NHL evidence for a shot-based teammate-contribution addition to personal assists. The analysis is 5v5 with both goalies, half/full-season rate comparisons, position separation, a playing-time cutoff and 10-fold CV. It does not establish chronological next-game all-strength performance, a current passing feed, a source-authorized threshold, or zero predictability of secondary assists. K5 is a smaller new forecasting test; current implementation/input feasibility is unknown.

**R6 — NHL Stats glossary.** [Official glossary](https://www.nhl.com/stats/es/glossary). PIM entry inspected. The English endpoint did not fetch in this pass. No exact season-specific rare-penalty minute schedule was imported; provider credit mapping remains a qualification gate.

**R7 — Michael R. Betz (2022), Tooth for a tooth: Does fighting serve as a deterrent to greater violence in the modern NHL.** [Primary paper](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0269889). Read §§2.1–2.2 and §3.1. NHL penalty types, offending player and timing are distinguished in the analysis; historical fighting frequency changes. The question is deterrence/association, not individual next-game PIM prediction. It does not validate opponent-rivalry multipliers, class probabilities or a compound forecast for FORGE.

**R8 — Berry & West (2018), Bayesian Forecasting of Many Count-Valued Time Series.** [Full text](https://arxiv.org/html/1805.05232). Read §§2.1–2.3 and §3.1. Binary/positive dynamic mixtures and predictive variation are documented in retail-sales forecasting. This is a transferable method family only. No retail hyperparameters, shifted-positive support, or claimed gains are adopted for hockey PIM.

### Source-access limitations

The official 2025–26 NHL rulebook was located, but full retrieval failed, including an explicit size-limit response. The current 2026–27 rulebook link also did not retrieve. Therefore this pass does not claim to have verified the complete season-specific penalty-credit mapping. That verification is a K7 entry condition. Search snippets and third-party rule summaries were not used as a substitute for an inspected authoritative mapping.
