# FORGE: from research to a finite, useful experiment

Scout · October 15, 2026 · Research/design amendment, not execution approval

## Recommendation in one minute

Finish the missing identity-review evidence and bounded numeric qualification first. Then run **one broader, finite count-head experiment**, with the incumbent plus at most two complete challenger pipelines. Use SOG as the provisional first head if the qualification receipt confirms sufficient usable coverage; choose a different head only from predeclared coverage and product relevance, never from preliminary winning scores. Preserve all seven skater targets and the goalie targets in the roadmap, but do not open their full search menu simultaneously.

This builds on yesterday's research. It does not replace the existing FORGE implementation, repeat its completed experiments, or declare a new model production-ready. The immediate goal is a decision about which change actually earns its complexity, followed by a qualified forecast packet for RSO and Start Chart.

## 1. What I personally checked

I read the exact owner-supplied, nonsecret evidence archive, SHA-256 `de4dec0ad04659074f9b032df1882d173a311f5cad2d90124b30f521f3b20489`, and compared it with yesterday's amendment. It contains already-open development reports, coverage metadata and the pending proposal. It supplies implementation paths/hashes but **no implementation source code**, so code behavior remains owner-reported until a source review is possible. I did not open new protected outcomes, run a real-data experiment, or change a model.

Current evidence, in order of authority:

- The new availability addendum supersedes historical claims that the original identity-review receipt is currently available. The exact independent receipt is missing; its retained hash is not a replacement. The original identity lookup archive remains preserved. A fresh, separately dated offline re-review proposal is being prepared by the existing owner/evaluator. No repeated database lookup is required by this design.
- The proposed broader archive has 927 identities: 830 skaters and 97 goalies, 484 represented games, 93 represented dates and 19,360 roster metadata entries. These are **structural counts**, not qualified numeric rows, a league census or a pregame participation population.
- Core skater keys occur on 17,424 entries; goalie primitive keys on 1,936. PPP has only 49 potentially paired game structures and 1,764 candidate skater-game contexts. Numeric validity and usable per-head counts await A.
- There are zero certified original-as-of historical rows. Historical work remains retrospective development. January 14, 2026 onward remains closed under the existing protocol; this document does not allocate it.
- v3 scored 370 core skater appearances, 22 PPP appearances and 26 goalie appearances. The January 8–13 continuation scored 55 core appearances, three PPP labels and two goalie appearances. Its issued TOI MSE improved 5.112%, while A, HIT and PIM worsened. That does not prove the minute improvement caused those regressions.
- The v4 goalie rate-only candidate slightly improved its combined score but failed a predeclared fold guard. The baseline was retained. We keep that result rather than relax its old rules.

These facts materially narrow which research ideas can run next. Rink, teammate-shot, authentic news/PP-role and participation experiments need inputs beyond basic all-strength boxscore key presence. They are queued ideas, not current admitted features.

## 2. Changes I recommend to the pending design

### A. Resolve the search-budget disagreement explicitly

The current proposal has 73 maximum recipe/head slots. Yesterday's narrower amendment proposed a baseline and at most two additional mean specifications for one first head, plus a separate mean-fixed distribution diagnostic. These are different experiments. Neither is silently approved by this research.

My recommendation is the narrower first wave, because it makes the result interpretable and limits winner selection from noisy samples. A candidate is a **complete selectable pipeline**: feature choices, half-life/shrinkage choices, fallback, reconciliation and selection rules all count. Eight recipe names across seven heads are still many comparisons even if executed in one pass.

If the team deliberately wants the 73-slot descriptive census, preregister it as broader exploratory development and keep its selections separate from confirmation. It is not automatically unsound; it is simply a larger search with different interpretation and cost. The later confirmation still needs a frozen candidate/policy and a fresh authorized period.

### B. Freeze recipes, not necessarily every fitted number

A defined empirical-Bayes estimator can fit parameters from allowed training history without becoming an unlimited search. Comparing several priors or recent-history weights on selection losses creates selectable variants and belongs in the ledger. A deterministic daily refit under the registered policy is different from changing the policy after seeing a loss.

Preserve the proposal's two-calendar-day lag unless a separately reviewed protocol changes it. For historical development, that lag does not create authentic source availability. Prospective updates must additionally respect actual receipt and label-maturity times.

### C. Review the blanket positive-TOI eligibility filter for PIM

The pending allocation requires positive skater TOI for all core targets. That is a legitimate narrow conditional population if clearly named, but it must not silently become the definition of all official appearances or fantasy PIM. Penalty credit can exist outside ordinary positive on-ice exposure. The validator should distinguish a missing TOI, a valid zero TOI, official appearance status and credited PIM before exclusion. This is a **proposed contract correction** for review before A, not permission to decode more values or expand spans. If current scope cannot establish those distinctions, retain the narrower population and disclose what it excludes.

### D. Do not carry the old numeric guards into a release claim

The proposed zero-segment-regression rule with `1e-12` tolerance is a deterministic research-selection rule. It is not a meaningful effect size, sampling uncertainty or a practical deployment criterion. With many small segments it can reject useful candidates due to noise; pooled improvements alone can also hide harmful subgroups. Preserve old experiment rules for old results. A is validation-only and does not require predictive thresholds. Before the first new B comparison, freeze its estimand, practical predictive gain/harm tolerances, endpoint, uncertainty method, failure policy and operating limits; add a utility margin only if B claims utility. Later prospective confirmation needs its own approved window and final gates before outcomes are inspected. If these decisions remain unset, the protocol is design-ready rather than execution-ready.

### E. Keep two ways of answering “better”

1. Per-target predictive quality, on a common admitted population.
2. Final fantasy-points and legal lineup utility, after assembling all selected components.

For fixed linear scoring weights, expected fantasy points equal the weighted sum of expected category counts. Squared fantasy-point error includes weighted cross-products between category errors; its expectation depends on cross-moments, including covariance and bias. A method can lower every individual category's MSE and still increase total-points MSE if previously offsetting errors align. This is a mathematical possibility, not an observed FORGE failure. Therefore selecting separate methods per target is sensible, followed by checking the final combined vector under representative scoring rules and the actual legal solver.

## 3. The experiment queue

The queue contains future choices, not a simultaneous authorization or Cartesian grid. D1 is one separately registered mean-fixed distribution comparison after mean selection; it has no mean-selection rights and is outside B unless B explicitly authorizes it.

### First: broader count benchmark and one explainable change

**Entry:** accepted current identity review; accepted A support receipt; exact baseline/recipes/code and evaluation protocol reviewed; separate B approval.

**Provisional head:** SOG, conditional on the admitted appearance population. Confirm selection from support and product use, without new outcome-based target shopping. HIT/BLK are alternatives when their verified coverage is materially better.

**M0:** reproduce the proposal's pinned `season_rate` expanding count baseline on the broadened, admitted population. Preserve prior selected v3 policies, such as BLK `recent_.5`, separately. Do not relabel it as the unavailable prior-season native baseline.

**M1:** one pooled count/exposure recipe using only admissible history. The owner must identify which existing inspected helper actually implements the intended rate and exposure semantics. A recipe's name, such as `role_aware`, is not evidence it uses authentic role reports.

**M2:** change exactly one component relative to M1: predicted workload or one supported rate/context feature. If preserving a distinct direct-count comparator already consumes the two challenger slots, defer this third idea rather than silently add a fourth mean candidate.

**Score:** paired squared count error on the final issued output, with bias, RMSE, coverage, fallback, per-player and per-date contribution. Keep MAE descriptive. Record all failures and preserve the proposal's exact fallback branches: eligible pooling for no individual history, no new fallback for missing required recent support with individual history, and comparison ineligibility for any remaining omission. An always-issue replacement policy would need its own explicit design change; do not give a method a smaller easier comparison population.

**Diagnostic:** with predictions frozen, decompose count residual into a locked-rate term and an exposure term. Keep the cross-term when decomposing squared error. The locked-rate residual includes outcome noise; this is not a causal decomposition. Actual future exposure is permitted only in this labeled diagnostic, never in the candidate.

**Decision:** retain M0 when evidence is inconclusive. A lower TOI error alone does not promote the count head. Reproduce a gain across the predeclared temporal procedure and check whether the gain changes start/bench decisions.

### Next: goalie workload before a more elaborate stopping model

The already-open reports motivate a workload question, not a fresh round of save-rate weights on the same 26 appearances. The new metadata could support a broader conditional goalie sample, but numeric validation has not occurred.

**G0:** the proposed broader comparison anchor `g000`, with its declared population and count/rate estimands. Preserve the prior v3 selected `g111` and v4 results separately; they are not interchangeable meanings of “incumbent.”

**G1:** hold the stopping component fixed and alter only workload using an admissible pregame exposure policy. Retain short appearances. Do not exclude an 8.4-minute start because it dominates error. Separate start-conditioned and all-positive-appearance claims where official starts qualify; without that evidence, do not invent start/relief labels or pStart.

**G2, later:** hold the chosen workload component fixed and change one regularized stopping component. Compare SA and minutes separately, then final SV/GA and downstream points. This is a staged question rather than an eight-tuple winner search by default.

**Coherence:** compatible SA = SV + GA holds for both realized counts and their expectations. Derive the final components coherently and score that final predictor. Expected SV/SA is generally different from expected SV divided by expected SA; likewise for GAA and minutes. The current proposal explicitly uses component-derived exposure rates, which is a valid declared estimand. It should not be renamed the expected random game ratio. If expected game ratios or category-win probabilities are later required, joint scenarios and zero-denominator handling need their own contract.

**Conditionality:** no verified pStart means no unconditional goalie recommendation presented as certain. W given official start does not qualify W for every scheduled opportunity. SO needs official credit and complete-game rules, not merely predicted or observed GA=0.

**Research leads:** shot-quality-adjusted stopping can be useful, but a historical 5v5 reliability result is not a next-game all-strength benchmark. A contemporary nonlinear reconciliation paper explicitly warns that its Gaussian-based method is unsuitable for intermittent/discrete nonlinear series. We should not import it wholesale for goals and ratio outputs. Prefer a simple coherent construction and validate any later reconciliation as part of the predictor. [P1–P3]

### Queued skater extensions after coverage allows them

- **PP opportunity:** team PP clock time and player deployment are separate. Model their paired scenarios; zero team opportunity is not an observed zero deployment preference. Allocate the full manpower-aware skater-minute budget with an other-player residual. This needs qualified PP exposure/role data, currently unsupported.
- **Assists:** test one historical teammate-shot/context signal before a full A1/A2 architecture. The primary playmaking study is a lead from 5v5 half/full-season comparisons; it does not prove next-game accuracy. On-ice/shift quality must qualify first.
- **PIM:** compare a direct pooled mean with one marked frequency/severity model if penalty credits reconcile, or one hurdle alternative if only totals qualify. Do not delete legitimate extremes or assume actual final TOI is independent of penalty severity.
- **Adaptation:** preserve player ability history through a team change, while updating role/workload context from known evidence. Native team differences are metadata flags, not verified trade/return narratives. Sparse-history bands are not rookie labels.
- **Venue:** estimate contemporary recorded-count effects from training data, then forecast the credited outcome at the destination rink. No historical arena multipliers are adopted.

Detailed experimental cards are in the accompanying skater specification. They are hypotheses with input gates, not claims of missing implementation or promised improvements.

## 4. Evaluation and customer-value contract

Use the same chronology, player-game opportunity population, fallback, scoring version and final-output transformation for every comparison. Report coverage alongside error. Fit and choose using earlier development; preserve exposed-history labels. A separate prospective period tests the frozen recipe/update policy with genuine source availability.

For uncertainty, paired calendar-block analysis can preserve all players/games within date blocks, but its assumptions must be justified. Resample loss sums and weight sums if the estimand is player-opportunity-weighted; do not silently turn it into an equal-date average. Six dates do not become many independent samples because 2,000 bootstrap draws were taken. Leave-one-player/date views are concentration diagnostics, not confidence intervals.

For start/bench replay, keep roster, eligibility, locks, scoring and solver ties identical. Compute realized utility from the **difference in active-lineup indicators**, so unchanged starters cancel. Include unchanged decisions as zero gain in the all-decision denominator, plus a predeclared crowded/actionable subset selected without outcomes. Keep AGP, legality, churn, forecast fallback and points separate. A partial historical availability frame supports a simulation, not an authentic achievable drop/add claim.

For category leagues, ratio/threshold/matchup outcomes need more than independent mean accuracy. RSO can still expose honest count forecasts while category-outcome modeling remains unqualified. No need to block every simpler supported head on a future full joint simulator.

A fixed-time confidence interval should not be checked daily until a winner appears. Later, bounded Brier-score comparisons may support an independently reviewed anytime-valid monitoring design; raw count MSE and delayed overlapping outcomes do not automatically satisfy that framework. Keep it outside the first wave. See the evaluation specification and primary sources there.

## 5. Concrete task amendment

These are proposed child tasks of the existing F-IDs, preserving original task status. “Done” below concerns this cloud design work only.

- [x] R2-01 Read the current nonsecret owner package, verify archive hash and reconcile superseding receipt status.
- [x] R2-02 Write finite skater/evaluation/goalie experiment cards and source limitations.
- [x] R2-03 Run eight synthetic arithmetic/contract checks; no NHL labels or model training.
- [ ] F02/F03: obtain a fresh separately dated identity-only re-review and retain its exact bytes durably. Never recreate the missing acceptance from a hash.
- [ ] F04: resolve the PIM/positive-TOI population contract before A; preserve exact span scope and exclusions.
- [ ] F03/F04: independently review and separately authorize A; return numeric-valid support counts/exclusions, not an assumed full 927-player population.
- [ ] F05: explicitly choose the narrow first wave or larger descriptive menu. Pin complete pipeline identities, estimands, scores, budget, label timing and failure rules.
- [ ] F05: freeze practical predictive gain/harm, endpoint, uncertainty, failure and operating limits before the first new B comparison; add utility gates if claimed. Independently freeze later prospective confirmation gates before its outcomes. They are product/evaluator decisions, not universal constants from research.
- [ ] F06/F07/F09: separately authorize and execute the first count-head comparison once on qualified data; report all candidates and coverage.
- [ ] F13: run the staged conditional goalie workload comparison only after qualified broader goalie support and its own finite scope.
- [ ] F08/F10/F11/F12/F14: admit one next card from verified prerequisites and development diagnostics. No automatic expansion of the original budget.
- [ ] F17: validate the assembled multi-target vector, fantasy-point error and legal lineup utility under pinned representative league rules.
- [ ] F19: add an accountability report with signed errors, per-target trends, coverage, method/version and development/prospective status. A histogram alone is insufficient.
- [ ] F21/F22: retain future original-issued forecasts and independent readback; qualify each head/population before public claims.

## 6. Source boundaries and reproducibility

**P1. Michael Schuckers, Statistical Evaluation of Ice Hockey Goaltending, May 3, 2016.** [Author-hosted PDF](https://myslu.stlawu.edu/~msch/sports/StatEvalofGoalies2016Schuckers.pdf), §§1.1–1.2 and tables 1.2–1.5 inspected. Historical 2009–13, mainly 5v5 non-empty-net analysis distinguishes workload, shot mix and stopping. It reports reliability correlations with variable small samples and a chosen shrinkage constant; these are not out-of-time next-game FORGE performance estimates. No coefficient, threshold or gain was imported.

**P2. Corani, Azzimonti and Rubattu, Probabilistic Reconciliation of Count Time Series, arXiv v3, March 15, 2023.** [Full text](https://arxiv.org/html/2207.09322v3), §§3–4 inspected. Coherent count distributions require admissible support; ordinary continuous reconciliation can produce invalid counts. Its virtual-evidence combination has independence assumptions. This supports treating coherence and dependence explicitly, not multiplying redundant model evidence or claiming its non-hockey experiments validate our forecasts.

**P3. Biswas et al., Nonlinear Probabilistic Forecast Reconciliation, arXiv v1, April 29, 2026.** [Full text](https://arxiv.org/html/2604.26668v1), §§3.2–4 inspected. Its UKF-based conditioning uses a Gaussian approximation; §3.3 explicitly excludes suitability for intermittent/discrete nonlinear series. The reported synthetic, demography and tourism results do not establish hockey gains. This is a reason to defer that algorithm here, not a recommendation to implement it now.

The companion evaluation and skater files cite additional primary sources and record actual sections read. All performance numbers about FORGE in this memo come from already-open owner reports, not public papers. Those reports retain historical timestamps and former reserve descriptions; CURRENT-ADDENDUM.md and current protocol controls govern present state.

The eight checks in `synthetic_contract_checks.py` prove only their constructed arithmetic examples: linear goalie coherence, expected ratios, zero denominators, single participation adjustment, paired role/rate averaging, cross-category point errors, manpower-aware PP allocation and the residual cross-term. Passing them does not certify application code or a predictive model.
