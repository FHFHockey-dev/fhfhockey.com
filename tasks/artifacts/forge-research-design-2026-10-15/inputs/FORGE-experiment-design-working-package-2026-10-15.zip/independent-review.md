# Independent review: FORGE round-two research amendment

Reviewed 15 October 2026 UTC. Research/artifact review only.

**Final status:** all findings below were resolved in the final reread at approximately 14:28 UTC. See the final resolution at the end; intermediate status and original findings are retained as review history.

## Bottom line

The main memo is a defensible **research recommendation**, not an execution or production-readiness claim. Its reported archive hash, structural counts, exposed-report results, missing-receipt status and A/B/reserve holds match the supplied current evidence. I found no fatal arithmetic error, fabricated FORGE performance result, imported hockey coefficient or actual approval expansion.

During review, the author corrected the population contradiction, comparison-anchor ambiguity and fallback mismatch. I reread those changes at approximately 14:24 UTC and consider findings 1–3 resolved, subject to one grammar correction noted below. The remaining material clarifications are findings 4–5: specify/count the prior/decay search and give practical gates one consistent milestone. These are contract issues even though the documents correctly say execution remains stopped. The changes below do not require opening outcomes, running models or changing the owner proposal in place.

### Current verification status

- **Resolved:** finding 1. The common skater contract now explicitly distinguishes an unconditional risk set from the current positive-TOI conditional estimand and preserves the PIM review.
- **Resolved:** finding 2. The memo/companions name `season_rate`, `g000` and `expanding` as proposed comparison anchors and preserve prior v3 choices separately.
- **Resolved with a wording fix:** finding 3. The documents now preserve the owner's asymmetric fallback/ineligibility policy. In `evaluation-design.md`, replace “No individual target history may use the eligible pooled baseline when defined” with “A case with no individual target history may use the eligible pooled baseline when defined.” The former can be misread as a prohibition.
- **Still open when last checked:** findings 4–5 and the lower-priority precision edits.

Findings 1–3 below preserve the original issue and exact remediation for review history; they are not a claim those original passages remain in the current memo.

## Prioritized findings and exact edits

### 1. High: the skater population contract contradicts the admitted conditional population

**Location:** `skater-experiments.md:19`, common contract item 1. Compare `owner-evidence/protocol/PROPOSAL.md:48` and `SCOUT-EXPERIMENT-DECISIONS.md`, section 2C.

The card permits an appearance-conditional benchmark, then says evaluation membership must not depend on eventual minutes. The proposed historical allocation explicitly conditions on subsequently validated **positive TOI**. The main memo correctly recognizes that as a legitimate narrower population, subject to the PIM correction. These cannot simultaneously be the literal admission rules. The prohibition should target outcome-based cherry-picking and future survival filters, rather than the prespecified condition defining the estimand.

**Replace the last sentence of item 1 with:**

> For the historical conditional benchmark, apply the same prespecified validated-appearance/positive-TOI rule to every method; that rule defines the conditional estimand and does not establish pregame participation. Do not condition admission on target magnitude, a posthoc minimum-TOI threshold beyond the declared appearance rule, or future minimum-games/survival criteria. Resolve the separate official-appearance/PIM/zero-TOI contract before A; retain the existing narrower rule unless a changed rule is explicitly approved within the exact span scope.

This does not endorse excluding valid zero-TOI PIM credits. It preserves the main memo's required review before changing that definition.

### 2. High before implementation: “incumbent” can select a different anchor and consume a different budget

**Locations:** memo section 3 M0 and G0; `evaluation-design.md:28`; `skater-experiments.md:23,46`.

The memo explicitly calls M0 the reconstructed expanding count baseline. The companions instead say exact incumbent. Those terms are not interchangeable across the supplied evidence:

- The proposed broader development anchors are `season_rate` and goalie `g000`.
- The exposed v3 report selected `recent_.5` for BLK and a .25 recent goalie family.
- The v4 comparison retains its baseline **for that private comparison only** and explicitly leaves v3 unchanged.
- The separate live v1 operation is not replaced by any of these results.

SOG's v3 selected method happens to be expanding, so the ambiguity can stay hidden until a head changes to BLK or the goalie card begins. Using a different incumbent also affects whether the direct-count comparator consumes a challenger slot.

**Add after memo M0, and use the same naming in both companions:**

> For this proposed broader development comparison, the anchor is the hash-pinned reconstructed `season_rate` pipeline on the admitted population. It is distinct from any v3-selected research method, the unavailable prior-season native baseline and the separately authorized live v1 predictor. If the owner instead chooses another incumbent comparator, name its exact pipeline and reconcile all comparator/challenger slots before B; no comparator is added implicitly.

**Replace memo G0 with:**

> G0: explicitly pin the reference tuple and its population. The pending broader proposal uses g000. A choice to compare against preserved v3 g111 or another consumer incumbent is a separate, declared design choice; v4's baseline-retention result did not replace v3 or authorize live use.

These edits identify the intended research anchor without asserting which pipeline currently serves production, something this evidence package cannot establish.

### 3. Medium: fallback semantics differ from the owner proposal and must be an explicit design delta

**Location:** `evaluation-design.md:65`; compare `owner-evidence/protocol/PROPOSAL.md:50,54` and memo section 3 Score.

The evaluation companion says a failed candidate uses its pinned operational fallback. The owner proposal is more restrictive: pooling is for absent individual history; missing required recent support remains missing; any remaining challenger omission makes it ineligible for the fixed-population comparison. A catch-all fallback could turn an ineligible recipe into an eligible composite pipeline. Such a composite can be legitimate, but it is a changed candidate definition and must be reviewed and budgeted explicitly. The main memo's general injunction to freeze fallback does not choose between these policies.

**Replace evaluation-design.md:65 with:**

> Pin the exact failure policy before B. If retaining the pending owner proposal, pooling is used only for absent individual target history; missing required recent support remains missing, and any remaining challenger omission makes that challenger ineligible on the fixed baseline-covered set. A composite pipeline that uses the baseline or another operational fallback for additional failure modes is an explicitly amended candidate, requiring review before B. Score every issued fallback under that approved policy, report coverage and fallback use, and never improve a score by dropping difficult rows. Unresolved labels are not zeros.

**Add to memo Score:**

> The B manifest must explicitly retain or amend the proposal's missing-recent-support and challenger-ineligibility rules; a general fallback statement does not supersede them.

This is an unresolved design choice, not evidence that research has already altered the operative gates.

### 4. Medium: an unspecified “bounded decay shortlist” reopens the search the memo says to count

**Locations:** `skater-experiments.md:47` (prior strength selection) and `:73` (decay shortlist); compare `evaluation-design.md:33` and memo section 2B.

The common finite-budget rule is strong, but K2 still allows a shortlist with no members or size. K1 likewise leaves prior-strength choice to earlier development. Chronological nesting prevents future-label leakage; it does not make selection among several prior/decay configurations disappear from the declared search ledger. These are later cards, so this is not an actual first-wave overrun. It is a material qualification to the claim that the cards already specify a finite runnable search.

**Replace the K2 shortlist sentence with:**

> Use one fixed decay or one fully specified training-only estimator. If comparing a decay shortlist on selection losses, enumerate its values and charge each selectable configuration to that card's separately approved finite ledger before execution; inner chronological selection does not waive the search budget.

**Replace K1's prior-strength clause with:**

> Pin one prior-strength estimator; any comparison of alternative priors on selection losses is separately enumerated and counted before B.

Do not add a numeric grid size in this review. The owner must choose it or retain a single estimator.

### 5. Medium: the deadline for freezing practical gates is internally inconsistent

**Locations:** memo section 2D (“before results”), memo F05 checklist (“before confirmation”); `skater-experiments.md:25` (“before execution”); `evaluation-design.md:105–113` (“before confirmation” but also “before seeing the new comparison”).

A reader cannot tell whether blank practical margins block A, the initial descriptive B experiment, or only prospective promotion/utility claims. This is not a mathematical flaw: either a deliberately stricter pre-B gate or a staged gate can be defensible. The intended rule needs one unambiguous milestone. A's support-count validation should not be confused with a predictive comparison or utility confirmation.

**Suggested consistent edit, preserving the stricter wording already present:**

> A remains a separately authorized validation-only operation and does not depend on predictive gain thresholds. Before the first new B comparison, freeze its estimand, practical predictive gain/harm tolerances, endpoint, uncertainty method, failure policy and operating limits. If B includes a utility claim, also freeze the utility margin and complete legal-decision contract. Any later prospective confirmation requires its own separately approved window, final margins, family of claims and fixed readout before its outcomes are inspected. No blank confirmation field silently supplies execution authority.

Use that same milestone language in the memo checklist and companions. If the owner instead intends exploratory B without practical promotion margins, say so explicitly, keep it descriptive, and require all promotion gates before prospective outcomes; do not leave both versions operative.

## Lower-priority precision edits

1. **Standardize the loss-difference sign.** `evaluation-design.md:43–45` defines positive gain as baseline loss minus challenger loss; `skater-experiments.md:24` defines challenger minus baseline. Both are mathematically valid, but a common code/report interface should have one sign. Replace the skater sentence with: “Primary: paired MSE gain, baseline minus challenger, so positive values favor the challenger.”
2. **Use cross-moments for the fantasy-points MSE explanation.** Memo section 2E says point-error variance includes cross-category terms, then reasons about MSE. The conclusion and synthetic counterexample are correct, but MSE includes bias as well as covariance. Replace the first two explanatory sentences with: “For fixed linear scoring weights, expected fantasy points are the weighted sum of expected category counts. Squared fantasy-point error includes weighted cross-products between category errors; its expectation depends on cross-moments, including covariance and bias.” No claimed observed failure should be added.
3. **Make D1's status visible in the short memo.** The memo acknowledges the separate mean-fixed diagnostic in section 2A, and the companions budget it separately. To avoid treating it as an automatic fourth mean candidate or as already allocated, add: “D1 is one separately registered, mean-fixed distribution comparison after the mean choice; it has no mean-selection rights and is not included in B unless B explicitly authorizes it.”

## Checks that passed

- Recomputed archive SHA-256: `de4dec0ad04659074f9b032df1882d173a311f5cad2d90124b30f521f3b20489`, matching the memo.
- The latest addendum supersedes the README's recovery instruction. The memo preserves that precedence, does not recreate acceptance from the retained hash, and does not claim the new identity review has run.
- Structural counts reconcile: 830 skaters + 97 goalies = 927 identities; 17,424 + 1,936 = 19,360 entries. PPP's 49 structures and 1,764 contexts remain potential support, not accepted labels. The 73-slot calculation is 7×8 + 6 + 8 + 3.
- v3 scored denominators, the continuation's 55/3/2 support, its 5.112% TOI improvement and A/HIT/PIM regressions match the exposed reports. The memo correctly avoids attributing the count regressions causally to TOI improvement.
- The v4 rate-only small improvement and failed fold guard are accurately summarized. No old threshold is retrospectively relaxed.
- No implementation source code is included. The memo correctly limits implementation assertions to owner reports/pins and requires later source/runtime review.
- All eight tests in `synthetic_contract_checks.py` passed when rerun. They test only constructed arithmetic. They do **not** test protected-date rejection, d−2 feature/selector isolation, native credit reconciliation, span safety, production fallback or actual consumer solver behavior. The memo accurately avoids such certification.
- The residual identity includes its cross-term; the ratio-of-expectations distinction is correct; linear goalie count coherence survives expectation; the PP budget includes a full-roster residual; and the multi-category MSE counterexample is valid.
- January 14 onward, A, B and the held blend remain closed/pending as described. No separate live-operation schedule is inferred from obsolete copied reports.

## Primary-source spot checks

I reopened the following primary sources to verify the high-risk summaries. These are spot checks, not a claim to have independently replicated every cited study or verified each author's earlier access history.

- [Schuckers, Statistical Evaluation of Ice Hockey Goaltending](https://myslu.stlawu.edu/~msch/sports/StatEvalofGoalies2016Schuckers.pdf): confirms the May 3, 2016 date, historical 2009–13 RTSS data, reliability/sample limits and chosen shrinkage parameter. The memo does not turn these into FORGE next-game gains.
- [Corani, Azzimonti and Rubattu, count reconciliation, v3](https://arxiv.org/html/2207.09322v3): sections 3–4 support discrete-support concerns. Section 4 discusses independent evidence assumptions, including the conditional independence of upper-level uncertain observations. The memo's caution is supported.
- [Biswas et al., nonlinear reconciliation, v1](https://arxiv.org/html/2604.26668v1): section 3.3 expressly limits the Gaussian UKF algorithm for nonlinear discrete/intermittent series. The memo correctly uses this as a reason to defer that algorithm, without implying all coherent count constructions are impossible.
- [Macdonald, Weld and Arney, playmaking](https://arxiv.org/pdf/1307.6539): sections 4.1/Figure 4 confirm position-separated 5v5 half/full-season rate comparisons, playing-time filtering and cross-validation. The memo accurately treats this as a research lead rather than chronological next-game validation.
- [Macdonald, Lennon and Sturdivant, weighted shots](https://arxiv.org/html/1205.1746): section 5.1 supports the companion's limited statement that its older skater comparison did not demonstrate weighted-shot superiority over shots. It does not establish that modern shot quality cannot help.
- [Choe and Ramdas, sequential forecasters](https://arxiv.org/html/2110.00115v4): the bounded-score, accumulated conditional-performance interpretation and lagged-feedback limitations match the evaluation companion. It is appropriately kept outside the initial raw-count MSE gate.

I did not inspect new raw outcome bodies, other outcome datasets, implementation code or protected runners. No real-data model, fit, benchmark or source acquisition was run. Only the supplied synthetic arithmetic script was executed.

## Final resolution — 15 October 2026, approximately 14:28 UTC

I verified the final memo and both companion specifications. Findings 1–5 and all three lower-priority precision edits are resolved: the conditional population and exact anchors are explicit; fallback preserves owner rules and the no-history wording is corrected; prior/decay alternatives must be enumerated and counted; A is exempt from predictive thresholds, B has pre-comparison predictive gates, utility gates apply only if claimed, and later prospective confirmation has separate gates. Loss-gain signs, cross-moment wording and D1's separate authorization are also clear.

No material review finding remains open for this **research amendment**. This resolution does not certify implementation, supply missing gate values, choose the unresolved experiment budget, approve identity re-review/A/B, allocate protected outcomes or establish production readiness. The archive-hash, synthetic-arithmetic and primary-source spot-check conclusions above remain unchanged. No additional substantive research or model work was performed for this final reread.
