import { requireProviderSyncAccess } from "lib/integrations/providerSyncAccessServer";
import YahooFantasy from "yahoo-fantasy";

import serviceRoleClient from "lib/supabase/server";
import type { Database, Json } from "lib/supabase/database-generated.types";

import {
  getYahooClientCredentials,
  getYahooLiveDraftSeasonConfig,
  YAHOO_GAME_CODE,
  YAHOO_PROVIDER,
} from "./config";
import { YahooLiveDraftError } from "./liveDraft";

type ConnectedAccountRow = Database["public"]["Tables"]["connected_accounts"]["Row"];
type ExternalLeagueRow = Database["public"]["Tables"]["external_leagues"]["Row"];
type ExternalTeamRow = Database["public"]["Tables"]["external_teams"]["Row"];
type UserProviderPreferencesRow =
  Database["public"]["Tables"]["user_provider_preferences"]["Row"];

type YahooDiscoverySummary = {
  leagueCount: number;
  teamCount: number;
  defaultExternalLeagueId: string | null;
  defaultExternalTeamId: string | null;
};

type YahooSyncOptions = {
  userId: string;
  connectedAccount: ConnectedAccountRow;
  accessToken: string;
  expiresAt?: string | null;
  refreshToken: string;
  tokenType?: string | null;
  providerUserId?: string | null;
  redirectUri: string;
};

export function selectYahooGamesForCanonicalSeason(
  games: Array<any>,
  canonicalGame: {
    code?: string | null;
    game_id?: number | null;
    game_key?: string | null;
    season?: number | null;
  } | null,
) {
  if (!canonicalGame || !Array.isArray(games)) {
    return [];
  }

  const canonicalGameKey = String(
    canonicalGame.game_key ?? canonicalGame.game_id ?? "",
  );
  return games.filter((game) => {
    return (
      canonicalGameKey.length > 0 &&
      String(game?.code ?? "") === String(canonicalGame.code ?? YAHOO_GAME_CODE) &&
      String(game?.season ?? "") === String(canonicalGame.season ?? "") &&
      String(game?.game_key ?? game?.game_id ?? "") === canonicalGameKey &&
      (canonicalGame.game_id == null ||
        String(game?.game_id ?? "") === String(canonicalGame.game_id))
    );
  });
}

export function flattenYahooLeagues(games: Array<any>) {
  return games.flatMap((game) =>
    Array.isArray(game?.leagues)
      ? game.leagues.map((league: any) => ({
          ...league,
          game_key: league.game_key || game.game_key || null,
          game_id: league.game_id || game.game_id || null,
          game_code: league.game_code || game.code || null,
          game_name: game.name || null,
        }))
      : []
  );
}

export function flattenYahooTeams(games: Array<any>) {
  return games.flatMap((game) =>
    Array.isArray(game?.teams)
      ? game.teams.map((team: any) => ({
          ...team,
          league_key:
            team.league_key ||
            (typeof team.team_key === "string"
              ? team.team_key.split(".t.")[0]
              : null),
          game_key: team.game_key || game.game_key || null,
          game_id: team.game_id || game.game_id || null,
          game_code: team.game_code || game.code || null,
          game_name: game.name || null,
        }))
      : []
  );
}

export function mergeYahooLeagueTeams(teams: Array<any>, standings: Array<any>) {
  const standingsByTeamKey = new Map(
    (Array.isArray(standings) ? standings : [])
      .filter((team) => team?.team_key)
      .map((team) => [String(team.team_key), team.standings || null])
  );
  const sourceTeams = Array.isArray(teams) && teams.length > 0 ? teams : standings;

  return (Array.isArray(sourceTeams) ? sourceTeams : [])
    .filter((team) => team?.team_key)
    .map((team) => ({
      ...team,
      standings: standingsByTeamKey.get(String(team.team_key)) || team.standings || null,
    }));
}

export function yahooDraftDiscoveryMetadata(
  league: any,
  settingsResponse: any,
) {
  const settings = settingsResponse?.settings || {};
  return {
    draft_status:
      settingsResponse?.draft_status ??
      settings?.draft_status ??
      league?.draft_status ??
      null,
    draft_type:
      settingsResponse?.draft_type ?? settings?.draft_type ?? league?.draft_type ?? null,
    is_auction_draft:
      settingsResponse?.is_auction_draft ??
      settings?.is_auction_draft ??
      league?.is_auction_draft ??
      null,
    draft_time:
      settingsResponse?.draft_time ?? settings?.draft_time ?? league?.draft_time ?? null,
    pick_time:
      settingsResponse?.pick_time ??
      settingsResponse?.draft_pick_time ??
      settings?.pick_time ??
      settings?.draft_pick_time ??
      league?.pick_time ??
      null,
    draft_order_type:
      settingsResponse?.draft_order_type ??
      settings?.draft_order_type ??
      settingsResponse?.is_snake_draft ??
      settings?.is_snake_draft ??
      null,
  };
}

export function yahooTeamDraftPosition(team: any) {
  const value = Number(team?.draft_position ?? team?.draft_order);
  return Number.isInteger(value) && value > 0 ? value : null;
}

function toJsonObject(value: Record<string, unknown>): Json {
  return value as Json;
}

function jsonObjectOrEmpty(value: Json) {
  return value && !Array.isArray(value) && typeof value === "object"
    ? (value as Record<string, unknown>)
    : {};
}

async function upsertConnectedAccountTokens(args: {
  connectedAccountId: string;
  userId: string;
  accessToken: string;
  expiresAt?: string | null;
  refreshToken: string;
  tokenType?: string | null;
  providerUserId?: string | null;
}) {
  const { error } = await (serviceRoleClient as any).rpc(
    "upsert_connected_account_tokens_secure",
    {
      p_connected_account_id: args.connectedAccountId,
      p_user_id: args.userId,
      p_provider: YAHOO_PROVIDER,
      p_access_token: args.accessToken,
      p_expires_at: args.expiresAt ?? undefined,
      p_last_refreshed_at: new Date().toISOString(),
      p_refresh_token: args.refreshToken,
      p_token_type: args.tokenType ?? null,
      p_scopes: [],
      p_provider_user_id: args.providerUserId ?? null,
      p_secret_metadata: {
        provider: YAHOO_PROVIDER,
      },
    }
  );

  if (error) {
    throw new Error(`Failed to store Yahoo provider tokens: ${error.message}`);
  }
}

async function upsertYahooPreferences(args: {
  userId: string;
  connectedAccountId: string;
  defaultLeagueId: string | null;
  defaultTeamId: string | null;
  activeContext: Json;
}) {
  const { error } = await serviceRoleClient.from("user_provider_preferences").upsert(
    {
      user_id: args.userId,
      provider: YAHOO_PROVIDER,
      connected_account_id: args.connectedAccountId,
      default_external_league_id: args.defaultLeagueId,
      default_external_team_id: args.defaultTeamId,
      refresh_on_login: false,
      active_context: args.activeContext,
    },
    {
      onConflict: "user_id,provider",
    }
  );

  if (error) {
    throw new Error(`Failed to store Yahoo provider preferences: ${error.message}`);
  }

  const { error: settingsError } = await serviceRoleClient.from("user_settings").upsert(
    {
      user_id: args.userId,
      active_context: args.activeContext,
    },
    {
      onConflict: "user_id",
    }
  );

  if (settingsError) {
    throw new Error(`Failed to persist Yahoo active context: ${settingsError.message}`);
  }
}

export async function syncYahooDiscovery({
  userId,
  connectedAccount,
  accessToken,
  expiresAt,
  refreshToken,
  tokenType,
  providerUserId,
  redirectUri,
}: YahooSyncOptions): Promise<YahooDiscoverySummary> {
  await requireProviderSyncAccess(userId);
  const { clientId, clientSecret } = getYahooClientCredentials();
  const configuredSeason = getYahooLiveDraftSeasonConfig();
  const yahoo = new YahooFantasy(
    clientId,
    clientSecret,
    async ({
      access_token,
      expires_in,
      refresh_token,
      token_type,
    }: {
      access_token: string;
      expires_in?: number;
      refresh_token: string;
      token_type?: string;
    }) => {
      await upsertConnectedAccountTokens({
        connectedAccountId: connectedAccount.id,
        userId,
        accessToken: access_token,
        expiresAt: Number.isFinite(Number(expires_in))
          ? new Date(Date.now() + Number(expires_in) * 1000).toISOString()
          : null,
        refreshToken: refresh_token,
        tokenType: token_type ?? null,
        providerUserId: providerUserId ?? null,
      });
    },
    redirectUri
  );

  yahoo.setUserToken(accessToken);
  yahoo.setRefreshToken(refreshToken);

  await upsertConnectedAccountTokens({
    connectedAccountId: connectedAccount.id,
    userId,
    accessToken,
    expiresAt,
    refreshToken,
    tokenType: tokenType ?? null,
    providerUserId: providerUserId ?? null,
  });

  const [userGamesResponse, canonicalGameResponse] = await Promise.all([
    yahoo.user.games(),
    serviceRoleClient
      .from("yahoo_game_keys")
      .select("game_id,game_key,code,season,last_updated")
      .eq("code", YAHOO_GAME_CODE)
      .eq("season", Number(configuredSeason.season))
      .maybeSingle(),
  ]);
  const nhlGames = Array.isArray(userGamesResponse?.games)
    ? userGamesResponse.games.filter((game: any) => game.code === YAHOO_GAME_CODE)
    : [];
  if (canonicalGameResponse.error || !canonicalGameResponse.data) {
    throw new YahooLiveDraftError(
      "Yahoo discovery could not resolve the configured canonical NHL season.",
      503,
      "yahoo_game_context_mismatch",
    );
  }
  const canonicalNhlGames = selectYahooGamesForCanonicalSeason(
    nhlGames,
    canonicalGameResponse.data,
  );
  if (canonicalNhlGames.length !== 1) {
    throw new YahooLiveDraftError(
      "Yahoo discovery and the canonical NHL season do not agree.",
      503,
      "yahoo_game_context_mismatch",
    );
  }
  const discoveryGameSource = "configured_yahoo_game_keys";
  const nhlGameKeys = canonicalNhlGames.map((game: any) =>
    String(game.game_key || game.game_id || YAHOO_GAME_CODE)
  );

  if (nhlGameKeys.length === 0) {
    const emptyContext = toJsonObject({
      provider: YAHOO_PROVIDER,
      source_type: "external-provider",
      external_league_id: null,
      external_team_id: null,
      external_league_key: null,
      external_team_key: null,
    });

    await upsertYahooPreferences({
      userId,
      connectedAccountId: connectedAccount.id,
      defaultLeagueId: null,
      defaultTeamId: null,
      activeContext: emptyContext,
    });

    const { error: accountError } = await serviceRoleClient
      .from("connected_accounts")
      .update({
        status: "connected",
        provider_user_id: providerUserId ?? null,
        account_label: "Yahoo Fantasy",
        last_synced_at: new Date().toISOString(),
        metadata: {
          ...jsonObjectOrEmpty(connectedAccount.metadata),
          provider_user_id: providerUserId ?? null,
          available_game_codes: [],
          discovery_game_source: discoveryGameSource,
          discovery: {
            league_count: 0,
            team_count: 0,
          },
        },
      })
      .eq("id", connectedAccount.id);

    if (accountError) {
      throw new Error(`Failed to update Yahoo account metadata: ${accountError.message}`);
    }

    return {
      leagueCount: 0,
      teamCount: 0,
      defaultExternalLeagueId: null,
      defaultExternalTeamId: null,
    };
  }

  const [leagueGamesResponse, teamGamesResponse] = await Promise.all([
    yahoo.user.game_leagues(nhlGameKeys),
    yahoo.user.game_teams(nhlGameKeys),
  ]);

  const discoveredTeams = flattenYahooTeams(teamGamesResponse?.teams || []);
  const ownedLeagueKeys = new Set(
    discoveredTeams
      .map((team) => String(team.league_key || ""))
      .filter((leagueKey) => leagueKey.length > 0)
  );
  const discoveredLeagues = flattenYahooLeagues(leagueGamesResponse?.games || []).filter(
    (league) =>
      ownedLeagueKeys.size === 0 || ownedLeagueKeys.has(String(league.league_key || ""))
  );

  const normalizedLeagues = [];
  const leagueTeamsByLeagueKey = new Map<string, Array<any>>();
  for (const league of discoveredLeagues) {
    const [settingsResponse, standingsResponse, teamsResponse] = await Promise.all([
      yahoo.league.settings(league.league_key),
      yahoo.league.standings(league.league_key),
      yahoo.league.teams(league.league_key),
    ]);
    const leagueTeams = mergeYahooLeagueTeams(
      teamsResponse?.teams || [],
      standingsResponse?.standings || []
    );
    leagueTeamsByLeagueKey.set(String(league.league_key), leagueTeams);
    const draftMetadata = yahooDraftDiscoveryMetadata(league, settingsResponse);
    normalizedLeagues.push({
      connected_account_id: connectedAccount.id,
      user_id: userId,
      provider: YAHOO_PROVIDER,
      external_league_key: league.league_key,
      league_name: league.name || null,
      season_key: String(league.season || league.game_key || ""),
      league_metadata: toJsonObject({
        ...league,
        settings_summary: {
          scoring_type: settingsResponse.scoring_type || league.scoring_type || null,
          num_teams: settingsResponse.num_teams || league.num_teams || null,
          draft_status: settingsResponse.draft_status || league.draft_status || null,
        },
        yahoo_live_draft: {
          discovery: draftMetadata,
          fetched_at: new Date().toISOString(),
        },
        standings: standingsResponse?.standings || [],
        team_count: leagueTeams.length,
      }),
      scoring_settings: toJsonObject({
        scoring_type: settingsResponse.scoring_type || league.scoring_type || null,
        stat_categories: settingsResponse.settings?.stat_categories || [],
        stat_modifiers: settingsResponse.settings?.stat_modifiers || [],
        draft_type: draftMetadata.draft_type,
        is_auction_draft: draftMetadata.is_auction_draft,
      }),
      roster_settings: toJsonObject({
        uses_playoff: settingsResponse.settings?.uses_playoff ?? settingsResponse.uses_playoff ?? null,
        playoff_start_week: settingsResponse.settings?.playoff_start_week ?? settingsResponse.playoff_start_week ?? null,
        end_week: settingsResponse.end_week ?? league.end_week ?? null,
        roster_positions: settingsResponse.settings?.roster_positions || [],
        weekly_deadline:
          settingsResponse.settings?.weekly_deadline ||
          settingsResponse.weekly_deadline ||
          league.weekly_deadline ||
          null,
        roster_type: settingsResponse.settings?.roster_type || null,
        draft_time: draftMetadata.draft_time,
        pick_time: draftMetadata.pick_time,
        draft_status: draftMetadata.draft_status,
        draft_order_type: draftMetadata.draft_order_type,
      }),
      imported_at: new Date().toISOString(),
    });
  }

  const leagueUpsertResponse = await serviceRoleClient
    .from("external_leagues")
    .upsert(normalizedLeagues, {
      onConflict: "connected_account_id,external_league_key",
    })
    .select("*");

  if (leagueUpsertResponse.error) {
    throw new Error(`Failed to persist Yahoo leagues: ${leagueUpsertResponse.error.message}`);
  }

  const leagueRows = (leagueUpsertResponse.data || []) as ExternalLeagueRow[];
  const leagueIdByKey = new Map(leagueRows.map((row) => [row.external_league_key, row]));

  const ownedTeamByKey = new Map(
    discoveredTeams
      .filter((team) => team?.team_key)
      .map((team) => [String(team.team_key), team])
  );
  const normalizedTeams = [];
  for (const [leagueKey, leagueTeams] of leagueTeamsByLeagueKey.entries()) {
    const matchingLeague = leagueIdByKey.get(leagueKey);
    if (!matchingLeague) {
      continue;
    }

    for (const leagueTeam of leagueTeams) {
      const ownedTeam = ownedTeamByKey.get(String(leagueTeam.team_key));
      const rosterResponse = ownedTeam
        ? await yahoo.team.roster(leagueTeam.team_key)
        : null;

      normalizedTeams.push({
        connected_account_id: connectedAccount.id,
        external_league_id: matchingLeague.id,
        user_id: userId,
        provider: YAHOO_PROVIDER,
        external_team_key: leagueTeam.team_key,
        team_name: leagueTeam.name || null,
        team_metadata: toJsonObject({
          ...leagueTeam,
          is_owned: Boolean(ownedTeam),
          draft_position: yahooTeamDraftPosition(leagueTeam),
          team_logo_url:
            Array.isArray(leagueTeam.team_logos) && leagueTeam.team_logos.length > 0
              ? leagueTeam.team_logos[0]?.url || null
              : null,
        }),
        roster_snapshot: toJsonObject({
          players: rosterResponse?.roster || [],
          visibility: ownedTeam ? "owned" : "not_fetched",
        }),
        imported_at: new Date().toISOString(),
      });
    }
  }

  const teamUpsertResponse = await serviceRoleClient
    .from("external_teams")
    .upsert(normalizedTeams, {
      onConflict: "external_league_id,external_team_key",
    })
    .select("*");

  if (teamUpsertResponse.error) {
    throw new Error(`Failed to persist Yahoo teams: ${teamUpsertResponse.error.message}`);
  }

  const teamRows = (teamUpsertResponse.data || []) as ExternalTeamRow[];
  const ownedTeamRows = teamRows.filter(
    (team) => jsonObjectOrEmpty(team.team_metadata).is_owned === true
  );

  const { data: existingPreferences, error: preferencesError } = await serviceRoleClient
    .from("user_provider_preferences")
    .select("*")
    .eq("user_id", userId)
    .eq("provider", YAHOO_PROVIDER)
    .maybeSingle();

  if (preferencesError) {
    throw new Error(`Failed to load Yahoo provider preferences: ${preferencesError.message}`);
  }

  const nextDefaultTeam =
    ownedTeamRows.find((team) => team.id === existingPreferences?.default_external_team_id) ||
    ownedTeamRows[0] ||
    null;
  const nextDefaultLeague =
    leagueRows.find((league) => league.id === existingPreferences?.default_external_league_id) ||
    (nextDefaultTeam
      ? leagueRows.find((league) => league.id === nextDefaultTeam.external_league_id) || null
      : leagueRows[0] || null);

  const activeContext = toJsonObject({
    provider: YAHOO_PROVIDER,
    source_type: "external-provider",
    external_league_id: nextDefaultLeague?.id || null,
    external_team_id: nextDefaultTeam?.id || null,
    external_league_key: nextDefaultLeague?.external_league_key || null,
    external_team_key: nextDefaultTeam?.external_team_key || null,
  });

  await upsertYahooPreferences({
    userId,
    connectedAccountId: connectedAccount.id,
    defaultLeagueId: nextDefaultLeague?.id || null,
    defaultTeamId: nextDefaultTeam?.id || null,
    activeContext,
  });

  if (normalizedTeams.length > 0) {
    const discoveredTeamKeys = normalizedTeams.map((team) => team.external_team_key);
    const teamFilter = `(${discoveredTeamKeys.map((key) => `"${key}"`).join(",")})`;
    await serviceRoleClient
      .from("external_teams")
      .delete()
      .eq("connected_account_id", connectedAccount.id)
      .not("external_team_key", "in", teamFilter);
  }

  if (normalizedLeagues.length > 0) {
    const discoveredLeagueKeys = normalizedLeagues.map((league) => league.external_league_key);
    const leagueFilter = `(${discoveredLeagueKeys.map((key) => `"${key}"`).join(",")})`;
    await serviceRoleClient
      .from("external_leagues")
      .delete()
      .eq("connected_account_id", connectedAccount.id)
      .not("external_league_key", "in", leagueFilter);
  }

  const accountLabel =
    nextDefaultTeam?.team_name ||
    nextDefaultLeague?.league_name ||
    "Yahoo Fantasy";

  const { error: accountError } = await serviceRoleClient
    .from("connected_accounts")
    .update({
      status: "connected",
      provider_user_id: providerUserId ?? null,
      account_label: accountLabel,
      last_synced_at: new Date().toISOString(),
      metadata: {
        ...jsonObjectOrEmpty(connectedAccount.metadata),
        provider_user_id: providerUserId ?? null,
        available_game_codes: canonicalNhlGames.map((game: any) => game.code),
        discovery_game_source: discoveryGameSource,
        discovery: {
          league_count: leagueRows.length,
          team_count: teamRows.length,
        },
      },
    })
    .eq("id", connectedAccount.id);

  if (accountError) {
    throw new Error(`Failed to update Yahoo account record: ${accountError.message}`);
  }

  return {
    leagueCount: leagueRows.length,
    teamCount: teamRows.length,
    defaultExternalLeagueId: nextDefaultLeague?.id || null,
    defaultExternalTeamId: nextDefaultTeam?.id || null,
  };
}
