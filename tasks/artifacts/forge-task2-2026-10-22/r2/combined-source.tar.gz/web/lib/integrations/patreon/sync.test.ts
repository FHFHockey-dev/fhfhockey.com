import { describe, expect, it, vi } from "vitest";

import { getPatreonSyncBlock, materializePatreonEntitlement } from "./sync";

describe("getPatreonSyncBlock", () => {
  const now = new Date("2026-07-14T15:00:00Z");

  it("blocks a live in-flight run and exposes cooldown timing", () => {
    const running = getPatreonSyncBlock(
      {
        status: "running",
        started_at: "2026-07-14T14:59:30Z",
        created_at: "2026-07-14T14:59:30Z",
        cooldown_until: null,
      },
      now,
    );
    expect(running?.statusCode).toBe(409);

    const cooldown = getPatreonSyncBlock(
      {
        status: "completed",
        started_at: "2026-07-14T14:58:00Z",
        created_at: "2026-07-14T14:58:00Z",
        cooldown_until: "2026-07-14T15:00:09.200Z",
      },
      now,
    );
    expect(cooldown?.statusCode).toBe(429);
    expect(cooldown?.retryAfterSeconds).toBe(10);
  });

  it("allows stale recovery and completed runs outside cooldown", () => {
    expect(
      getPatreonSyncBlock(
        {
          status: "running",
          started_at: "2026-07-14T14:30:00Z",
          created_at: "2026-07-14T14:30:00Z",
          cooldown_until: null,
        },
        now,
      ),
    ).toBeNull();
  });
});

describe("Patreon entitlement anti-sharing", () => {
  const account = {
    id: "account-1",
  } as any;
  const snapshot = {
    providerUserId: "patreon-user-1",
    memberId: "member-1",
    pledgeRelationshipStart: "2026-01-01T00:00:00Z",
    isEligibleSupporter: true,
    metadata: {},
  } as any;

  it("marks a paid generic Patreon supporter entitlement as a verified Draft Pro source", async () => {
    const query = {
      select: vi.fn(),
      eq: vi.fn(),
      neq: vi.fn().mockResolvedValue({ error: null }),
      maybeSingle: vi.fn().mockResolvedValue({ data: null, error: null }),
      insert: vi.fn().mockResolvedValue({ error: null }),
      update: vi.fn(),
    };
    query.select.mockReturnValue(query);
    query.eq.mockReturnValue(query);
    query.update.mockReturnValue(query);
    const client = { from: vi.fn(() => query) } as any;

    await materializePatreonEntitlement({
      userId: "user-1",
      account,
      snapshot,
      client,
      now: new Date("2026-07-14T15:00:00Z"),
    });

    expect(query.insert).toHaveBeenCalledWith(
      expect.objectContaining({
        user_id: "user-1",
        source_provider: "patreon",
        source_account_id: "account-1",
        source_reference: "member-1",
        entitlement_key: "patreon_supporter",
        entitlement_status: "active",
        effective_to: null,
        metadata: expect.objectContaining({
          provider_user_id: "patreon-user-1",
          verified_at: "2026-07-14T15:00:00.000Z",
          draft_pro_eligible: true,
        }),
      }),
    );
  });

  it("retains the paid benefit snapshot across expiry and reuses the owned row on renewal", async () => {
    let row: any = null;
    const query: any = {
      select: vi.fn(),
      eq: vi.fn(),
      neq: vi.fn(),
      maybeSingle: vi.fn(() => Promise.resolve({ data: row, error: null })),
      insert: vi.fn((value) => {
        row = { ...value, id: "entitlement-1", user_id: "user-1" };
        return query;
      }),
      update: vi.fn((value) => {
        // The post-write stale-member update excludes the current member; the
        // harness models that predicate instead of mutating the current row.
        if (value.metadata !== undefined || value.entitlement_status !== "inactive") {
          row = { ...row, ...value };
        }
        return query;
      }),
      then: (resolve: (value: { error: null }) => unknown) => resolve({ error: null }),
    };
    query.select.mockReturnValue(query);
    query.eq.mockReturnValue(query);
    query.neq.mockReturnValue(query);
    const client = { from: vi.fn(() => query) } as any;
    const base = {
      providerUserId: "patreon-user-1",
      memberId: "member-1",
      pledgeRelationshipStart: "2026-01-01T00:00:00Z",
      metadata: {},
      hasPaidMembership: true,
    } as any;

    await materializePatreonEntitlement({
      userId: "user-1", account, client,
      snapshot: { ...base, isEligibleSupporter: true, currentlyEntitledAmountCents: 500, tiers: [{ id: "tier-5", title: "Power Play", amountCents: 500 }] },
      now: new Date("2026-07-14T15:00:00Z"),
    });
    const originalId = row.id;
    const originalActivation = row.metadata.paid_activated_at;

    await materializePatreonEntitlement({
      userId: "user-1", account, client,
      snapshot: { ...base, isEligibleSupporter: false, currentlyEntitledAmountCents: 0, tiers: [] },
      now: new Date("2026-07-15T15:00:00Z"),
    });
    expect(row).toMatchObject({ id: originalId, source_reference: "member-1", entitlement_status: "inactive" });
    expect(row.metadata).toMatchObject({ paid_activated_at: originalActivation, last_verified_paid_benefit: { amount_cents: 500, tiers: [{ id: "tier-5" }] } });

    await materializePatreonEntitlement({
      userId: "user-1", account, client,
      snapshot: { ...base, isEligibleSupporter: true, currentlyEntitledAmountCents: 600, tiers: [{ id: "tier-6", title: "Center Ice", amountCents: 600 }] },
      now: new Date("2026-07-16T15:00:00Z"),
    });
    expect(row).toMatchObject({ id: originalId, source_reference: "member-1", entitlement_status: "active" });
    expect(row.metadata.paid_activated_at).toBe(originalActivation);
    expect(row.metadata.last_verified_paid_benefit.amount_cents).toBe(600);
  });

  it("invalidates a missing campaign membership without erasing paid history", async () => {
    const retained = {
      id: "entitlement-1",
      metadata: {
        draft_pro_eligible: true,
        last_verified_paid_benefit: { amount_cents: 500, tiers: [{ id: "tier-1" }] },
      },
    };
    let call = 0;
    const updates: any[] = [];
    const client = {
      from: vi.fn(() => {
        call += 1;
        const query: any = {
          select: vi.fn(() => query),
          eq: vi.fn(() => query),
          update: vi.fn((value) => { updates.push(value); return query; }),
          then: (resolve: (value: any) => unknown) => resolve(
            call === 1 ? { data: [retained], error: null } : { error: null },
          ),
        };
        return query;
      }),
    } as any;
    await materializePatreonEntitlement({
      userId: "user-1", account, client,
      snapshot: { ...snapshot, memberId: null, isEligibleSupporter: false, metadata: { patron_status: null } },
      now: new Date("2026-07-17T15:00:00Z"),
    });
    expect(updates).toHaveLength(1);
    expect(updates[0]).toMatchObject({ entitlement_status: "inactive", metadata: { draft_pro_eligible: false, last_verified_paid_benefit: { amount_cents: 500 } } });
  });

  it("rejects a member identity already owned by another site user", async () => {
    const query = {
      select: vi.fn(),
      eq: vi.fn(),
      maybeSingle: vi.fn().mockResolvedValue({
        data: { id: "entitlement-1", user_id: "user-2" },
        error: null,
      }),
    };
    query.select.mockReturnValue(query);
    query.eq.mockReturnValue(query);
    const client = { from: vi.fn(() => query) } as any;

    await expect(
      materializePatreonEntitlement({
        userId: "user-1",
        account,
        snapshot,
        client,
        now: new Date("2026-07-14T15:00:00Z"),
      }),
    ).rejects.toMatchObject({ statusCode: 409 });
    expect(query.eq).toHaveBeenCalledWith("source_provider", "patreon");
    expect(query.eq).toHaveBeenCalledWith("source_reference", "member-1");
  });

  it("translates a unique-index race into the same safe conflict", async () => {
    const query = {
      select: vi.fn(),
      eq: vi.fn(),
      maybeSingle: vi.fn().mockResolvedValue({ data: null, error: null }),
      insert: vi.fn().mockResolvedValue({
        error: { code: "23505", message: "duplicate" },
      }),
    };
    query.select.mockReturnValue(query);
    query.eq.mockReturnValue(query);
    const client = { from: vi.fn(() => query) } as any;

    await expect(
      materializePatreonEntitlement({
        userId: "user-1",
        account,
        snapshot,
        client,
        now: new Date("2026-07-14T15:00:00Z"),
      }),
    ).rejects.toMatchObject({ statusCode: 409 });
    expect(query.insert).toHaveBeenCalledWith(
      expect.objectContaining({
        user_id: "user-1",
        source_provider: "patreon",
        source_reference: "member-1",
      }),
    );
  });
});
