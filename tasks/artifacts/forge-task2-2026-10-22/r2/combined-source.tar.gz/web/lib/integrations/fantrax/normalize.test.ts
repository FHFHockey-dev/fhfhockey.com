import { describe, expect, it } from "vitest";

import categoryFixture from "./__fixtures__/nhl-categories.json";
import pointsFixture from "./__fixtures__/nhl-points.json";
import {
  normalizeFantraxDiscovery,
  normalizeFantraxLeagueInfo,
  relevantFantraxRawSettings,
} from "./normalize";

describe("Fantrax NHL settings normalization", () => {
  it("keeps defense-only hits and blocks and adds special teams points to PP and SH points", () => {
    const config = (code: string, points: number, position = "DEFAULT") => ({
      scoringCategory: { code }, points, position: { code: position },
    });
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "defense-bonus",
      payload: {
        ...pointsFixture,
        scoringSystem: {
          type: "HEAD_TO_HEAD_POINTS_BASED",
          scoringCategorySettings: [{
            group: { code: "HOCKEY_SKATING" },
            configs: [
              config("INDIVIDUAL_HITS", 0.3),
              config("INDIVIDUAL_HITS", 0.32, "DEFENSE"),
              config("INDIVIDUAL_BLOCKS", 0.3),
              config("INDIVIDUAL_BLOCKS", 0.32, "DEFENSE"),
              config("INDIVIDUAL_POWER_PLAY_POINTS", 0.5),
              config("INDIVIDUAL_SPECIAL_TEAMS_POINTS", 1),
            ],
          }],
        },
      },
    });
    expect(normalized.skaterScoringCategories).toMatchObject({
      HITS: 0.3, HITS_D: 0.32, BLOCKED_SHOTS: 0.3, BLOCKED_SHOTS_D: 0.32,
      PP_POINTS: 1.5, SH_POINTS: 1,
    });
    expect(normalized.diagnostics.unsupported.filter((item) => item.kind === "scoring")).toEqual([]);
  });

  it("maps documented scoring types and codes observed in Fantrax league responses", () => {
    const configs = [
      ["HOCKEY_SKATING", "INDIVIDUAL_ASSISTS", "ASSISTS", 2],
      ["HOCKEY_SKATING", "INDIVIDUAL_BLOCKS", "BLOCKED_SHOTS", 0.25],
      ["HOCKEY_SKATING", "INDIVIDUAL_GOALS", "GOALS", 3],
      ["HOCKEY_SKATING", "INDIVIDUAL_HITS", "HITS", 0.2],
      ["HOCKEY_SKATING", "INDIVIDUAL_SHOTS_ON_GOAL", "SHOTS_ON_GOAL", 0.2],
      ["HOCKEY_SKATING", "INDIVIDUAL_POWER_PLAY_POINTS", "PP_POINTS", 1],
      ["HOCKEY_GOALIE", "INDIVIDUAL_GOALS_AGAINST", "GOALS_AGAINST_GOALIE", -1],
      ["HOCKEY_GOALIE", "INDIVIDUAL_SAVES", "SAVES_GOALIE", 0.2],
      ["HOCKEY_GOALIE", "INDIVIDUAL_SHUTOUTS", "SHUTOUTS_GOALIE", 3],
      ["HOCKEY_GOALIE", "INDIVIDUAL_GOALIE_WINS", "WINS_GOALIE", 4],
      ["HOCKEY_GOALIE", "INDIVIDUAL_SHOTS_ON_GOAL_AGAINST", "SHOTS_AGAINST_GOALIE", 0.1],
    ] as const;
    for (const type of ["POINTS_BASED", "HEAD_TO_HEAD_POINTS_BASED"]) {
      const normalized = normalizeFantraxLeagueInfo({
        externalLeagueKey: "official-points",
        payload: {
          ...pointsFixture,
          scoringSystem: {
            type,
            scoringCategorySettings: ["HOCKEY_SKATING", "HOCKEY_GOALIE"].map((group) => ({
              group: { code: group },
              configs: configs.filter(([role]) => role === group).map(([, code, , points]) => ({
                scoringCategory: { code }, points,
              })),
            })),
          },
        },
      });
      expect(normalized.leagueType).toBe("points");
      expect(normalized.diagnostics.unsupported.filter((item) => item.kind === "scoring")).toEqual([]);
      for (const [role, , key, points] of configs) {
        expect(role === "HOCKEY_GOALIE" ? normalized.goalieScoringCategories[key] : normalized.skaterScoringCategories[key]).toBe(points);
      }
    }
    for (const type of ["ROTISSERIE", "HEAD_TO_HEAD_ROTI_SINGLE_WIN", "HEAD_TO_HEAD_ROTI_MULTI_WIN"]) {
      expect(normalizeFantraxLeagueInfo({
        externalLeagueKey: "official-categories",
        payload: { ...categoryFixture, scoringSystem: { ...categoryFixture.scoringSystem, type } },
      }).leagueType).toBe("categories");
    }
    const bracket = normalizeFantraxLeagueInfo({
      externalLeagueKey: "bracket",
      payload: { ...pointsFixture, scoringSystem: { ...pointsFixture.scoringSystem, type: "BRACKET" } },
    });
    expect(bracket.diagnostics.status).toBe("unsupported");
    expect(bracket.diagnostics.warnings).toEqual(expect.arrayContaining([expect.stringContaining("BRACKET")]));
  });

  it("maps the sanitized Dynasty Hockey Challenge multi-win category response", () => {
    const groups = [
      ["HOCKEY_SKATING", [
        ["INDIVIDUAL_ASSISTS", "ASSISTS"],
        ["INDIVIDUAL_GOALS", "GOALS"],
        ["INDIVIDUAL_HITS", "HITS"],
        ["INDIVIDUAL_PLUS_MINUS", "PLUS_MINUS"],
        ["INDIVIDUAL_SHOTS_ON_GOAL", "SHOTS_ON_GOAL"],
        ["INDIVIDUAL_POWER_PLAY_POINTS", "PP_POINTS"],
        ["INDIVIDUAL_TIME_ON_ICE_SKATERS_PER_GAME", "TIME_ON_ICE_PER_GAME"],
      ]],
      ["HOCKEY_GOALIE", [
        ["INDIVIDUAL_GOALIE_WINS", "WINS_GOALIE"],
        ["INDIVIDUAL_GOALS_AGAINST_AVERAGE", "GOALS_AGAINST_AVERAGE"],
        ["INDIVIDUAL_SAVE_PERCENTAGE", "SAVE_PERCENTAGE"],
      ]],
    ] as const;
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "sanitized-multi-win",
      payload: {
        ...categoryFixture,
        scoringSystem: {
          type: "HEAD_TO_HEAD_ROTI_MULTI_WIN",
          scoringCategorySettings: groups.map(([group, configs]) => ({
            group: { code: group },
            configs: configs.map(([code]) => ({
              position: { code: "DEFAULT" },
              scoringCategory: { code },
              weight: 1,
            })),
          })),
        },
      },
    });
    expect(normalized.leagueType).toBe("categories");
    expect(normalized.diagnostics.unsupported.filter((item) => item.kind === "scoring")).toEqual([]);
    for (const [, configs] of groups) {
      for (const [, key] of configs) expect(normalized.categoryWeights[key]).toBe(1);
    }
  });

  it("scopes duplicate scoring codes by skater and goalie position", () => {
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "points-league",
      payload: pointsFixture,
      ownedTeams: [
        {
          externalTeamKey: "team-a",
          name: "High Slot",
          division: "West",
          isOwned: true,
        },
      ],
      fetchedAt: new Date("2026-08-14T12:00:00.000Z"),
    });

    expect(normalized.leagueType).toBe("points");
    expect(normalized.skaterScoringCategories).toMatchObject({
      GOALS: 3,
      GAMES_PLAYED: 0.1,
    });
    expect(normalized.goalieScoringCategories).toMatchObject({
      GAMES_PLAYED: 0.5,
      WINS_GOALIE: 4,
    });
    expect(normalized.skaterScoringCategories.PENALTY_MINUTES).toBeUndefined();
    expect(normalized.rosterConfig).toMatchObject({
      C: 2,
      LW: 2,
      RW: 2,
      D: 4,
      G: 2,
      FWD: 1,
      bench: 4,
    });
    expect(normalized.teams.map((team) => team.externalTeamKey)).toEqual([
      "team-a",
      "team-b",
    ]);
    expect(normalized.teams[0].isOwned).toBe(true);
    expect(normalized.diagnostics.status).toBe("partial");
    expect(normalized.diagnostics.unsupported).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ code: "PIM", kind: "scoring" }),
        expect.objectContaining({ code: "W", label: "Team Goalie Wins" }),
        expect.objectContaining({ code: "IR", kind: "roster" }),
      ]),
    );
  });

  it("maps category weights and preserves an explicit finite zero", () => {
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "category-league",
      payload: categoryFixture,
      fetchedAt: new Date("2026-08-14T12:00:00.000Z"),
    });

    expect(normalized.diagnostics.status).toBe("supported");
    expect(normalized.leagueType).toBe("categories");
    expect(normalized.categoryWeights).toMatchObject({
      GOALS: 2,
      GAMES_PLAYED: 1,
      WINS_GOALIE: 1,
      SAVE_PERCENTAGE: 0,
    });
    expect(normalized.rosterConfig).toMatchObject({
      C: 2,
      LW: 2,
      RW: 2,
      D: 4,
      G: 2,
      utility: 1,
      bench: 4,
    });
    expect(normalized.draftOrderType).toBe("straight");
  });

  it("maps Fantrax Skt roster slots to UTIL", () => {
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "skt-league",
      payload: {
        ...categoryFixture,
        rosterInfo: {
          ...categoryFixture.rosterInfo,
          positionConstraints: categoryFixture.rosterInfo.positionConstraints.map((slot) =>
            slot.position.code === "UTILITY"
              ? { ...slot, position: { code: "Skt" } }
              : slot,
          ),
        },
      },
      fetchedAt: new Date("2026-08-14T12:00:00.000Z"),
    });

    expect(normalized.rosterConfig.utility).toBe(1);
    expect(normalized.diagnostics.unsupported).not.toEqual(
      expect.arrayContaining([expect.objectContaining({ code: "Skt" })]),
    );
  });

  it("maps projected v4/v5 categories without guessing unknown labels", () => {
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "v4-category-league",
      payload: {
        ...categoryFixture,
        scoringSystem: {
          ...categoryFixture.scoringSystem,
          scoringCategorySettings: [{
            configs: [
              { position: "SKATER", scoringCategory: { code: "GWG", name: "Game Winning Goals" }, weight: 2 },
              { position: "SKATER", scoringCategory: { code: "TKA", name: "Takeaways" }, weight: 1 },
              { position: "SKATER", scoringCategory: { code: "GVA", name: "Giveaways" }, weight: -1 },
              { position: "SKATER", scoringCategory: { code: "iCF", name: "Individual Shot Attempts" }, weight: 0.2 },
              { position: "SKATER", scoringCategory: { code: "ixG", name: "Individual Expected Goals" }, weight: 2.5 },
              { position: "GOALIE", scoringCategory: { code: "QS", name: "Quality Starts" }, weight: 3 },
              { position: "GOALIE", scoringCategory: { code: "GSAx", name: "Goals Saved Above Expected" }, weight: 4 },
              { position: "SKATER", scoringCategory: { code: "EDGE42", name: "Unknown EDGE score" }, weight: 1 },
            ],
          }],
        },
      },
      fetchedAt: new Date("2026-08-18T12:00:00.000Z"),
    });

    expect(normalized.categoryWeights).toMatchObject({
      GAME_WINNING_GOALS: 2,
      TAKEAWAYS: 1,
      GIVEAWAYS: -1,
      SHOT_ATTEMPTS: 0.2,
      EXPECTED_GOALS: 2.5,
      QUALITY_STARTS_GOALIE: 3,
      GOALS_SAVED_ABOVE_EXPECTED: 4,
    });
    expect(normalized.diagnostics.unsupported).toContainEqual(
      expect.objectContaining({ code: "EDGE42", kind: "scoring" }),
    );
  });

  it("omits both sides of a conflicting category mapping with exact diagnostics", () => {
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "conflicting-category-league",
      payload: {
        ...categoryFixture,
        scoringSystem: {
          ...categoryFixture.scoringSystem,
          scoringCategorySettings: [
            {
              configs: [
                {
                  position: "SKATER",
                  scoringCategory: { code: "G", name: "Goals" },
                  weight: 1,
                },
                {
                  position: "SKATER",
                  scoringCategory: {
                    code: "INDG",
                    name: "Individual Goals",
                  },
                  weight: 2,
                },
              ],
            },
          ],
        },
      },
    });

    expect(normalized.categoryWeights.GOALS).toBeUndefined();
    expect(
      normalized.diagnostics.unsupported
        .filter((item) => item.reason.includes("conflicting weights"))
        .map((item) => item.code),
    ).toEqual(["G", "INDG"]);
  });

  it("produces a stable source hash independent of object insertion order and fetch time", () => {
    const reversedTeams = Object.fromEntries(
      Object.entries(categoryFixture.teamInfo).reverse(),
    );
    const first = normalizeFantraxLeagueInfo({
      externalLeagueKey: "category-league",
      payload: categoryFixture,
      fetchedAt: new Date("2026-08-14T12:00:00.000Z"),
    });
    const second = normalizeFantraxLeagueInfo({
      externalLeagueKey: "category-league",
      payload: { ...categoryFixture, teamInfo: reversedTeams },
      fetchedAt: new Date("2026-08-15T12:00:00.000Z"),
    });

    expect(second.sourceHash).toBe(first.sourceHash);
    expect(second.fetchedAt).not.toBe(first.fetchedAt);
  });

  it("fails closed for a non-NHL league and never invents draft order", () => {
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "wrong-sport",
      payload: {
        ...categoryFixture,
        sportCode: "MLB",
        draftType: "AUCTION",
      },
    });

    expect(normalized.diagnostics.status).toBe("unsupported");
    expect(normalized.draftOrderType).toBe("unknown");
    expect(normalized).not.toHaveProperty("draftOrder");
  });

  it("diagnoses present-but-empty roster and team collections without inventing values", () => {
    const normalized = normalizeFantraxLeagueInfo({
      externalLeagueKey: "incomplete-league",
      payload: {
        ...categoryFixture,
        rosterInfo: { positionConstraints: {} },
        teamInfo: {},
      },
    });

    expect(normalized.diagnostics.status).toBe("partial");
    expect(normalized.rosterConfig).toEqual({});
    expect(normalized.teams).toEqual([]);
    expect(normalized.diagnostics.unsupported).toContainEqual(
      expect.objectContaining({ code: "NO_ROSTER_CONSTRAINTS" }),
    );
    expect(normalized.diagnostics.warnings).toContain(
      "Fantrax did not return any league team identities.",
    );
  });

  it("filters known non-NHL discovery rows and retains only scoped raw settings", () => {
    expect(
      normalizeFantraxDiscovery({
        nhl: { name: "NHL", sport: "NHL", teamId: "mine", teamName: "Mine" },
        mlb: { name: "MLB", sport: "MLB" },
      }),
    ).toEqual([
      expect.objectContaining({
        externalLeagueKey: "nhl",
        ownedTeams: [expect.objectContaining({ externalTeamKey: "mine" })],
      }),
    ]);

    const raw = relevantFantraxRawSettings(pointsFixture);
    expect(raw).toHaveProperty("scoringSystem");
    expect(raw).toHaveProperty("rosterInfo");
    expect(raw).toHaveProperty("teamInfo");
    expect(raw).not.toHaveProperty("playerInfo");
    expect(raw).not.toHaveProperty("matchups");
  });
});
