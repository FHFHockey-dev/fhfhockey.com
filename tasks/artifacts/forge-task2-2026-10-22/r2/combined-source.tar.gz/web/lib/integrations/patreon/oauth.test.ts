import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import {
  buildPatreonAuthorizationUrl,
  buildPatreonAccountRedirect,
  createPatreonOAuthState,
  fetchPatreonIdentity,
  normalizePatreonIdentity,
  refreshPatreonTokens,
  sanitizePatreonNextPath,
  verifyPatreonOAuthState,
} from "./oauth";

const request = {
  headers: {
    "x-forwarded-proto": "https",
    "x-forwarded-host": "fhfhockey.com",
  },
} as any;

const identityResponse: any = {
  data: {
    id: "patreon-user-1",
    type: "user",
    attributes: { full_name: "Five Hole Supporter", image_url: null },
    relationships: {
      memberships: {
        data: [
          { id: "member-other", type: "member" },
          { id: "member-fhfh", type: "member" },
        ],
      },
    },
  },
  included: [
    {
      id: "member-other",
      type: "member",
      attributes: {
        patron_status: "active_patron",
        currently_entitled_amount_cents: 9999,
      },
      relationships: {
        campaign: { data: { id: "other-campaign", type: "campaign" } },
      },
    },
    {
      id: "member-fhfh",
      type: "member",
      attributes: {
        patron_status: "active_patron",
        currently_entitled_amount_cents: 500,
        last_charge_status: "Paid",
        pledge_relationship_start: "2026-01-10T00:00:00Z",
      },
      relationships: {
        campaign: { data: { id: "fhfh-campaign", type: "campaign" } },
        currently_entitled_tiers: {
          data: [{ id: "tier-5", type: "tier" }],
        },
      },
    },
    {
      id: "tier-5",
      type: "tier",
      attributes: { title: "Power Play", amount_cents: 500 },
    },
  ],
};

describe("Patreon OAuth v2", () => {
  beforeEach(() => {
    vi.stubEnv("PATREON_CLIENT_ID", "client-id");
    vi.stubEnv("PATREON_CLIENT_SECRET", "client-secret");
    vi.stubEnv("PATREON_CAMPAIGN_ID", "fhfh-campaign");
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-07-14T15:00:00Z"));
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.unstubAllEnvs();
    vi.restoreAllMocks();
  });

  it("signs bounded account-only state and requests only identity scope", () => {
    const state = createPatreonOAuthState("user-1", "/account?section=patreon");
    expect(verifyPatreonOAuthState(state)).toEqual(
      expect.objectContaining({
        userId: "user-1",
        next: "/account?section=patreon",
      }),
    );
    expect(() => verifyPatreonOAuthState(`${state}tampered`)).toThrow(
      "signature is invalid",
    );
    expect(sanitizePatreonNextPath("https://attacker.invalid")).toBe(
      "/account?section=patreon",
    );
    expect(sanitizePatreonNextPath("/\\attacker.invalid")).toBe(
      "/account?section=patreon",
    );

    const authorizationUrl = new URL(
      buildPatreonAuthorizationUrl(
        request,
        "user-1",
        "/account?section=patreon",
      ),
    );
    expect(authorizationUrl.pathname).toBe("/oauth2/authorize");
    expect(authorizationUrl.searchParams.get("scope")).toBe("identity");
    expect(authorizationUrl.searchParams.get("redirect_uri")).toBe(
      "https://fhfhockey.com/api/v1/account/patreon/callback",
    );
  });

  it("rejects offsite paths and every ASCII control before URL normalization", () => {
    const unsafePaths = [
      "https://attacker.invalid/path",
      "//attacker.invalid/path",
      "/\\attacker.invalid/path",
      "/.//attacker.invalid/path",
      "/safe/..//attacker.invalid/path",
      "/%2e%2e//attacker.invalid/path",
      " /account",
      "javascript:alert(1)",
      ...Array.from({ length: 32 }, (_, index) =>
        `/${String.fromCharCode(index)}/attacker.invalid`,
      ),
      "/\u007f/account",
    ];
    for (const next of unsafePaths) {
      expect(sanitizePatreonNextPath(next)).toBe("/account?section=patreon");
      const redirect = new URL(
        buildPatreonAccountRedirect(next, "error", "Please reconnect."),
        "https://fhfhockey.com",
      );
      expect(redirect.origin).toBe("https://fhfhockey.com");
      expect(redirect.pathname).toBe("/account");
      expect(redirect.searchParams.get("section")).toBe("patreon");
    }
    expect(sanitizePatreonNextPath(undefined)).toBe("/account?section=patreon");
    expect(sanitizePatreonNextPath({} as any)).toBe("/account?section=patreon");
  });

  it("preserves internal paths, query parameters, and fragments through state and redirect", () => {
    for (const next of ["/", "/account?section=patreon", "/account?tab=links#patreon", "/tools/a%20b"]) {
      expect(sanitizePatreonNextPath(next)).toBe(next);
      expect(verifyPatreonOAuthState(createPatreonOAuthState("user-1", next)).next).toBe(next);
      const original = new URL(next, "https://fhfhockey.com");
      const redirect = new URL(
        buildPatreonAccountRedirect(next, "connected", "Patreon linked."),
        original.origin,
      );
      expect(redirect.origin).toBe(original.origin);
      expect(redirect.pathname).toBe(original.pathname);
      expect(redirect.hash).toBe(original.hash);
      for (const [key, value] of original.searchParams) {
        expect(redirect.searchParams.get(key)).toBe(value);
      }
      expect(redirect.searchParams.get("patreon_status")).toBe("connected");
      expect(redirect.searchParams.get("patreon_message")).toBe("Patreon linked.");
    }
    expect(sanitizePatreonNextPath(["/account#patreon", "//attacker.invalid"])).toBe("/account#patreon");
  });

  it("selects only the configured campaign membership and tier metadata", () => {
    const snapshot = normalizePatreonIdentity(
      identityResponse,
      "fhfh-campaign",
    );

    expect(snapshot).toEqual(
      expect.objectContaining({
        providerUserId: "patreon-user-1",
        memberId: "member-fhfh",
        patronStatus: "active_patron",
        currentlyEntitledAmountCents: 500,
        isEligibleSupporter: true,
        tiers: [{ id: "tier-5", title: "Power Play", amountCents: 500 }],
      }),
    );
    expect(snapshot.metadata).toEqual(
      expect.objectContaining({
        campaign_id: "fhfh-campaign",
        tier_feature_mapping: "not_configured",
      }),
    );
  });

  it("fails closed to no entitlement when the configured campaign is absent", () => {
    const snapshot = normalizePatreonIdentity(
      identityResponse,
      "missing-campaign",
    );
    expect(snapshot.memberId).toBeNull();
    expect(snapshot.isEligibleSupporter).toBe(false);
    expect(snapshot.tiers).toEqual([]);
  });

  it("uses current paid entitlement, not a next billing date, for Draft Pro eligibility", () => {
    const canceledButEntitled = structuredClone(identityResponse);
    canceledButEntitled.included[1].attributes.patron_status = "active_patron";
    expect(normalizePatreonIdentity(canceledButEntitled, "fhfh-campaign").isEligibleSupporter).toBe(true);

    const declinedWithFutureBilling = structuredClone(identityResponse);
    declinedWithFutureBilling.included[1].attributes.patron_status = "declined_patron";
    declinedWithFutureBilling.included[1].attributes.next_charge_date = "2030-01-01T00:00:00Z";
    expect(normalizePatreonIdentity(declinedWithFutureBilling, "fhfh-campaign").isEligibleSupporter).toBe(false);

    const declinedCharge = structuredClone(identityResponse);
    declinedCharge.included[1].attributes.last_charge_status = "Declined";
    expect(normalizePatreonIdentity(declinedCharge, "fhfh-campaign").isEligibleSupporter).toBe(false);

    const freeTier = structuredClone(identityResponse);
    freeTier.included[1].attributes.currently_entitled_amount_cents = 0;
    freeTier.included[2].attributes.amount_cents = 0;
    expect(normalizePatreonIdentity(freeTier, "fhfh-campaign").isEligibleSupporter).toBe(false);

    const freeTrial = structuredClone(identityResponse);
    freeTrial.included[1].attributes.is_free_trial = true;
    expect(normalizePatreonIdentity(freeTrial, "fhfh-campaign").isEligibleSupporter).toBe(false);
  });

  it("requests explicit v2 fields and accepts rotated refresh tokens", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(JSON.stringify(identityResponse), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }),
      )
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            access_token: "access-2",
            refresh_token: "refresh-2",
            expires_in: 3600,
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        ),
      );

    const snapshot = await fetchPatreonIdentity(
      "access-1",
      "fhfh-campaign",
      fetchMock,
    );
    expect(snapshot.memberId).toBe("member-fhfh");
    const identityUrl = new URL(fetchMock.mock.calls[0][0]);
    expect(identityUrl.searchParams.get("include")).toContain(
      "memberships.currently_entitled_tiers",
    );
    expect(identityUrl.searchParams.get("fields[member]")).toContain(
      "patron_status",
    );

    const tokens = await refreshPatreonTokens("refresh-1", fetchMock);
    expect(tokens.refresh_token).toBe("refresh-2");
    expect(String(fetchMock.mock.calls[1][1]?.body)).toContain(
      "grant_type=refresh_token",
    );
  });
});
