import { DraftProRequestError } from "lib/draft-pro/requestError";
import { beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ auth: vi.fn(), access: vi.fn(), capability: vi.fn(), from: vi.fn(), consume: vi.fn(), dust: vi.fn(), references: vi.fn() }));
vi.mock("lib/api/requireApiUser", () => ({ requireApiUser: mocks.auth })); vi.mock("lib/draft-pro/server", () => ({ loadDraftProAccess: mocks.access, requireDraftProServerCapability: mocks.capability })); vi.mock("lib/draft-pro/features", () => ({ getDraftProFeatureFlags: () => ({ scenarios: true }) })); vi.mock("lib/draft-pro/recommendationsRateLimit", () => ({ consumeRecommendationRequest: mocks.consume })); vi.mock("lib/draft-pro/scenariosServer", () => ({ evaluateScenarioDust: mocks.dust, validateScenarioReferences: mocks.references })); vi.mock("lib/supabase/server", () => ({ default: { from: mocks.from } }));
import handler from "../../../pages/api/v1/account/draft-pro/scenarios";
import itemHandler from "../../../pages/api/v1/account/draft-pro/scenarios/[id]";
const response = () => { const value: any = { statusCode: 0, setHeader: vi.fn() }; value.status = (code: number) => (value.statusCode = code, value); value.json = (body: unknown) => (value.body = body, value); return value; };
const source = { projection: { id: "public", version: "v1", origin: "server" }, schedule: { season: "20262027", gameKey: "500", startWeek: 1, endWeek: 2, lineupMode: "daily", rosterSlots: { C: 1 } } };
const player = { id: "p", name: "Player", role: "skater", eligiblePositions: ["C"], teamAbbreviation: "AAA", projectionSeason: "20262027", globalVorp: 2, rankValue: 2, projectedPoints: 50, categoryValues: { GOALS: 20 } };
const valid = { action: "analyze", scenario: { roster: [], candidateA: player, candidateB: { ...player, id: "q", name: "Other" }, leagueType: "points", source } };
function query(data: unknown = null) { const value: any = { data, error: null }; for (const method of ["select", "eq", "is", "order", "limit", "insert"]) value[method] = vi.fn(() => value); value.single = vi.fn(async () => ({ data, error: null })); value.maybeSingle = vi.fn(async () => ({ data, error: null })); return value; }
const unavailableDust = { state: "empty_roster", freshness: { oldestFetchedAt: null, latestFetchedAt: null }, window: { startWeek: null, endWeek: null, startDate: null, endDate: null }, baseline: null, insights: [], diagnostics: ["Add roster players."] };
describe("Draft Pro scenarios API", () => {
  beforeEach(() => { vi.resetAllMocks(); mocks.auth.mockResolvedValue({ id: "owner" }); mocks.access.mockResolvedValue({}); mocks.consume.mockReturnValue(true); mocks.references.mockResolvedValue(null); mocks.dust.mockResolvedValue(unavailableDust); mocks.from.mockReturnValue(query([])); });
  it("returns 401 before premium work", async () => { mocks.auth.mockImplementation(async (_req, _res, options) => { options.onUnauthorized("Authentication required."); return null; }); const res = response(); await handler({ method: "POST" } as any, res); expect(res.statusCode).toBe(401); expect(mocks.access).not.toHaveBeenCalled(); });
  it("returns owned names-only summaries without checking active capability", async () => { mocks.from.mockReturnValue(query([{ id: "s", name: "A vs B", updated_at: "2026-09-07T00:00:00Z" }])); const res = response(); await handler({ method: "GET" } as any, res); expect(res.statusCode).toBe(200); expect(res.body.data[0]).toEqual({ id: "s", name: "A vs B", updated_at: "2026-09-07T00:00:00Z" }); expect(mocks.access).not.toHaveBeenCalled(); });
  it("returns stable inactive 403 before calculation", async () => { mocks.capability.mockImplementation(() => { throw new DraftProRequestError(403, "No access", "no_active_grant"); }); const res = response(); await handler({ method: "POST", body: valid } as any, res); expect(res.statusCode).toBe(403); expect(res.body.error.code).toBe("no_active_grant"); expect(mocks.dust).not.toHaveBeenCalled(); });
  it("calculates on the server without accepting client output", async () => { const res = response(); await handler({ method: "POST", body: valid } as any, res); expect(res.statusCode).toBe(200); expect(res.body.data.fingerprint).toMatch(/^scenario-v1-/); expect(mocks.dust).toHaveBeenCalledWith(expect.objectContaining({ candidateA: expect.objectContaining({ id: "p" }) })); });
  it("rejects unowned draft/private references", async () => { mocks.references.mockResolvedValue("draft_not_found"); const res = response(); await handler({ method: "POST", body: { ...valid, action: "save", name: "Saved", draftId: "00000000-0000-4000-8000-000000000001" } } as any, res); expect(res.statusCode).toBe(404); expect(mocks.dust).not.toHaveBeenCalled(); });
  it("carries the owned draft through private-import analysis", async () => { const privateScenario = { ...valid.scenario, source: { ...source, projection: { id: "private", version: "v1", origin: "saved_private_import", privateImports: [{ id: "00000000-0000-4000-8000-000000000002", contentFingerprint: "scenario-v1-0123456789abcdef0123456789abcdef" }] } } }; const res = response(); await handler({ method: "POST", body: { action: "analyze", draftId: "00000000-0000-4000-8000-000000000001", scenario: privateScenario } } as any, res); expect(res.statusCode).toBe(200); expect(mocks.references).toHaveBeenCalledWith("owner", expect.anything(), "00000000-0000-4000-8000-000000000001"); });
  it("persists only the server calculation", async () => { const stored = query({ id: "s", name: "Saved", source_fingerprint: "server", result: {} }); mocks.from.mockReturnValue(stored); const res = response(); await handler({ method: "POST", body: { ...valid, action: "save", name: "Saved" } } as any, res); expect(res.statusCode).toBe(201); expect(stored.insert).toHaveBeenCalledWith(expect.objectContaining({ user_id: "owner", source_fingerprint: expect.stringMatching(/^scenario-v1-/), result: expect.objectContaining({ fingerprint: expect.stringMatching(/^scenario-v1-/) }) })); });
  it("does not open a cross-owner scenario payload", async () => { mocks.from.mockReturnValue(query(null)); const res = response(); await itemHandler({ method: "GET", query: { id: "00000000-0000-4000-8000-000000000001" } } as any, res); expect(res.statusCode).toBe(404); expect(mocks.from().eq).toHaveBeenCalledWith("user_id", "owner"); });

  it.each([403, 503])("sanitizes backend status %s on scenario list and detail", async (statusCode) => {
    const dependencyError = Object.assign(new Error("synthetic-private-scenario-detail"), { statusCode, code: "synthetic-backend-code" });
    for (const route of [handler, itemHandler]) {
      const stored = query();
      stored.error = dependencyError;
      stored.maybeSingle.mockResolvedValue({ data: null, error: dependencyError });
      mocks.from.mockReturnValue(stored);
      const res = response();
      await route({ method: "GET", query: { id: "00000000-0000-4000-8000-000000000001" } } as any, res);
      expect(res.statusCode).toBe(500);
      expect(res.body.error.code).toBe("scenarios_unavailable");
      expect(res.body.error.message).toBe(route === handler ? "Scenarios are unavailable. Your current comparison is unchanged." : "Scenarios are unavailable.");
      expect(JSON.stringify(res.body)).not.toContain("synthetic-private");
      expect(JSON.stringify(res.body)).not.toContain("synthetic-backend");
    }
  });

  it("does not treat a provider message prefix as scenario validation", async () => {
    mocks.dust.mockRejectedValueOnce(new Error("Candidates must synthetic-private-provider-detail"));
    const res = response();
    await handler({ method: "POST", body: valid } as any, res);
    expect(res.statusCode).toBe(500);
    expect(res.body).toEqual({ error: { code: "scenarios_unavailable", message: "Scenarios are unavailable. Your current comparison is unchanged." } });
  });

  it("preserves local distinct-candidate validation", async () => {
    const res = response();
    await handler({ method: "POST", body: { ...valid, scenario: { ...valid.scenario, candidateB: valid.scenario.candidateA } } } as any, res);
    expect(res.statusCode).toBe(400);
    expect(res.body).toEqual({ error: { code: "invalid_scenario", message: "Choose two distinct candidates." } });
  });

});
