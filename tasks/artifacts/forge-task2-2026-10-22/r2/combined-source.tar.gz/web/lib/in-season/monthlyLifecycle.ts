import { IN_SEASON_COMMERCE, monthlyFailureWindow, monthlySignupQuote, previewInitialMonthlyCharge, type VerifiedStripeMinimum } from "./commerce";
import { type InSeasonGrant, resolveInSeasonAccess } from "./access";
import { IN_SEASON_SANDBOX_CATALOG } from "./billingConfig";

const cutoff = Date.parse(IN_SEASON_COMMERCE.accessEndsAt);

export type MonthlyPeriod = { from: string; to: string; amountCents: number };
export type MonthlyBinding = {
  userId: string; attemptId: string; customerId: string;
  subscriptionId: string; periods: MonthlyPeriod[]; verifiedMinimum: VerifiedStripeMinimum;
  scheduleId?: string;
};
export const monthlyMetadata = (binding: Pick<MonthlyBinding, "userId" | "attemptId">) => ({
  in_season_user_id: binding.userId, in_season_attempt_id: binding.attemptId,
  in_season_plan: "monthly", in_season: IN_SEASON_COMMERCE.season,
});
const instant = (value: string) => {
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed)) throw new Error("Invalid monthly lifecycle timestamp.");
  return parsed;
};

/** Pure calendar contract and mandatory atomic creation field; sends nothing.
 * The charging/anchor adapter is not enabled by this plan. In particular, a
 * fixed UTC recurrence does not reproduce Eastern midnight across DST.
 */
export function buildSettledMonthlyPlan(input: { userId: string; attemptId: string; customerId: string; startsAt: Date; verifiedMinimum: VerifiedStripeMinimum | null }) {
  if (![input.userId, input.attemptId, input.customerId].every((value) => value.trim())) throw new Error("Monthly identity is required.");
  const quote = monthlySignupQuote(input.startsAt, IN_SEASON_SANDBOX_CATALOG.accountId, input.verifiedMinimum);
  if (!quote.available) throw new Error(quote.reason === "below_verified_minimum"
    ? "Monthly signup is unavailable because the first charge is below the verified payment minimum. No amount will be rounded up or carried forward."
    : "Monthly signup is unavailable until the applicable payment minimum and season dates are verified.");
  const periods: MonthlyPeriod[] = [];
  let start = new Date(Math.floor(input.startsAt.getTime() / 1000) * 1000);
  while (start.getTime() < cutoff) {
    if (periods.length === 12) throw new Error("Monthly coverage exceeds this season's supported planning window.");
    const to = previewInitialMonthlyCharge(start).nextAnchorAt;
    periods.push({ from: start.toISOString(), to, amountCents: periods.length ? IN_SEASON_COMMERCE.plans.monthly.amountCents : quote.charge.confirmedAmountCents });
    start = new Date(to);
  }
  // This must be included in the SAME subscription creation request, before
  // collecting payment. Setting it later in a webhook is not a safety boundary.
  return { periods, requiredSubscriptionCreationFields: { cancel_at: cutoff / 1000 },
    metadata: monthlyMetadata(input), idempotencyKey: `in-season-monthly-sandbox:${input.attemptId}` };
}

export type MonthlyEvent = {
  eventId: string; userId: string; subscriptionId: string;
} & ({ kind: "paid"; invoiceId: string; period: number; paymentIntentId: string; paidAt: string }
  | { kind: "failed"; invoiceId: string; period: number; failedAttempts?: number; failureId?: string; firstFailureAt: string | null }
  | { kind: "cancelled"; cancelledAt: string }
  | { kind: "billing_stopped"; stoppedAt: string }
  | { kind: "observed"; observedAt: string }
  | { kind: "refund"; invoiceId: string; period: number; paymentIntentId: string; refundId: string; amountCents: number; status: "pending" | "failed" | "succeeded"; observedAt: string; observedVersion?: number }
  | { kind: "dispute"; invoiceId: string; period: number; paymentIntentId: string; disputeId: string; openedAt: string; status: "open" | "won" | "lost" });

type InvoiceState = { period: number; paymentIntentId: string | null; paidAt: string | null; firstFailureAt: string | null; failedAttempts: number; failureIds?: string[];
  refunds: Record<string, { amountCents: number; status: "pending" | "failed" | "succeeded"; observedAt: string; observedVersion?: number }>;
  disputes: Record<string, { openedAt: string; status: "open" | "won" | "lost" }>;
};
export type MonthlyState = {
  binding: MonthlyBinding; version: number; cancelledAt: string | null; billingStoppedAt: string | null;
  invoices: Record<string, InvoiceState>; events: Record<string, string>;
};

export function createMonthlyState(binding: MonthlyBinding): MonthlyState {
  if (![binding.userId, binding.attemptId, binding.customerId, binding.subscriptionId].every((value) => value.trim())) throw new Error("Monthly binding is incomplete.");
  const expected = buildSettledMonthlyPlan({ ...binding, startsAt: new Date(binding.periods[0]?.from) }).periods;
  if (expected.length !== binding.periods.length || expected.some((period, index) => period.from !== binding.periods[index].from || period.to !== binding.periods[index].to || period.amountCents !== binding.periods[index].amountCents)) throw new Error("Monthly periods do not match the approved schedule.");
  return { binding: structuredClone(binding), version: 0, cancelledAt: null, billingStoppedAt: null, invoices: {}, events: {} };
}

/** Commutative facts: paid beats failed; cancellation only moves earlier.
 * The durable caller must atomically persist the returned version, event receipt
 * and projected grants, with unique subscription/customer/payment bindings.
 */
export function reduceMonthlyEvent(state: MonthlyState, event: MonthlyEvent, now: Date): MonthlyState {
  if (!Number.isFinite(now.getTime()) || !event.eventId || event.userId !== state.binding.userId || event.subscriptionId !== state.binding.subscriptionId) throw new Error("Monthly event ownership mismatch.");
  const fingerprint = JSON.stringify(event.kind === "paid"
    ? [event.kind, event.userId, event.subscriptionId, event.invoiceId, event.period, event.paymentIntentId, event.paidAt]
    : event.kind === "failed" ? [event.kind, event.userId, event.subscriptionId, event.invoiceId, event.period, ...(event.failureId === undefined ? [event.failedAttempts] : ["identity", event.failureId]), event.firstFailureAt]
      : event.kind === "cancelled" ? [event.kind, event.userId, event.subscriptionId, event.cancelledAt]
        : event.kind === "billing_stopped" ? [event.kind, event.userId, event.subscriptionId, event.stoppedAt]
          : event.kind === "observed" ? [event.kind, event.userId, event.subscriptionId, event.observedAt]
        : event.kind === "refund" ? [event.kind, event.userId, event.subscriptionId, event.invoiceId, event.period, event.paymentIntentId, event.refundId, event.amountCents, event.status, event.observedAt, ...(event.observedVersion === undefined ? [] : [event.observedVersion])]
          : [event.kind, event.userId, event.subscriptionId, event.invoiceId, event.period, event.paymentIntentId, event.disputeId, event.openedAt, event.status]);
  if (Object.hasOwn(state.events, event.eventId)) {
    if (state.events[event.eventId] !== fingerprint) throw new Error("Event ID was reused with different facts.");
    return state;
  }
  const result = structuredClone(state);
  if (event.kind === "observed") {
    if (instant(event.observedAt) > now.getTime()) throw new Error("Invalid billing observation time.");
  } else if (event.kind === "cancelled" || event.kind === "billing_stopped") {
    const at = instant(event.kind === "cancelled" ? event.cancelledAt : event.stoppedAt);
    if (at > now.getTime() || at < instant(state.binding.periods[0].from)) throw new Error("Invalid cancellation time.");
    if (event.kind === "cancelled") result.cancelledAt = new Date(Math.min(at, cutoff, state.cancelledAt ? instant(state.cancelledAt) : Infinity)).toISOString();
    result.billingStoppedAt = new Date(Math.min(at, state.billingStoppedAt ? instant(state.billingStoppedAt) : Infinity)).toISOString();
  } else {
    const period = state.binding.periods[event.period];
    if (!event.invoiceId || !Number.isInteger(event.period) || !period) throw new Error("Unknown invoice period.");
    const prior = Object.hasOwn(state.invoices, event.invoiceId) ? state.invoices[event.invoiceId] : null;
    if (prior && prior.period !== event.period) throw new Error("Invoice was rebound to another period.");
    if (Object.entries(state.invoices).some(([id, row]) => id !== event.invoiceId && row.period === event.period)) throw new Error("Multiple invoices for one period require review.");
    const invoice: InvoiceState = prior ? structuredClone(prior) : { period: event.period, paymentIntentId: null, paidAt: null, firstFailureAt: null, failedAttempts: 0, refunds: {}, disputes: {} };
    if (event.kind !== "failed") {
      if (!event.paymentIntentId || (invoice.paymentIntentId && invoice.paymentIntentId !== event.paymentIntentId)
        || Object.entries(state.invoices).some(([id, row]) => id !== event.invoiceId && row.paymentIntentId === event.paymentIntentId)) throw new Error("Payment was rebound or changed.");
      invoice.paymentIntentId = event.paymentIntentId;
    }
    if (event.kind === "paid") {
      const paid = instant(event.paidAt);
      if (!event.paymentIntentId || paid > now.getTime() || paid < instant(period.from)) throw new Error("Invalid invoice payment.");
      // Late payments remain in accounting history but cannot create a new term.
      if (invoice.paidAt && invoice.paidAt !== event.paidAt) throw new Error("Payment was rebound or changed.");
      invoice.paymentIntentId = event.paymentIntentId; invoice.paidAt = event.paidAt;
    } else if (event.kind === "failed") {
      if (event.failureId !== undefined) {
        if (!event.failureId || event.failedAttempts !== undefined) throw new Error("Invalid confirmed failure identity.");
        // Older stored counts already include the initial invoice failure.
        const ids = invoice.failureIds ?? (invoice.failedAttempts > 0 ? [`invoice:${event.invoiceId}:initial`] : []);
        if (!ids.includes(event.failureId)) invoice.failedAttempts += 1;
        invoice.failureIds = [...new Set([...ids, event.failureId])];
      } else {
        // Preserve historical aggregate events; new provider/worker facts use identities.
        if (!Number.isSafeInteger(event.failedAttempts) || event.failedAttempts! < 1) throw new Error("Invalid failed-attempt count.");
        invoice.failedAttempts = Math.max(invoice.failedAttempts, event.failedAttempts!);
      }
      if (event.firstFailureAt) {
        const failed = instant(event.firstFailureAt);
        if (failed < instant(period.from) || failed >= instant(period.to) || failed > now.getTime()) throw new Error("Invalid first failure time.");
        invoice.firstFailureAt = new Date(Math.min(failed, invoice.firstFailureAt ? instant(invoice.firstFailureAt) : Infinity)).toISOString();
      }
    } else if (event.kind === "refund") {
      if (!event.refundId || !Number.isSafeInteger(event.amountCents) || event.amountCents <= 0 || event.amountCents > period.amountCents || !["pending", "failed", "succeeded"].includes(event.status)) throw new Error("Invalid refund facts.");
      const previous = Object.hasOwn(invoice.refunds, event.refundId) ? invoice.refunds[event.refundId] : null;
      if (previous && previous.amountCents !== event.amountCents) throw new Error("Refund amount changed.");
      const observed = instant(event.observedAt);
      if (observed > now.getTime() || observed < instant(period.from)) throw new Error("Invalid refund observation time.");
      const version = event.observedVersion;
      if (version !== undefined && (!Number.isSafeInteger(version) || version < 1 || version > state.version + 1)) throw new Error("Invalid refund observation version.");
      if (version === undefined && previous?.observedVersion !== undefined) throw new Error("Ordered refund snapshot required.");
      const sameOrder = version === undefined ? previous && instant(previous.observedAt) === observed : previous?.observedVersion === version;
      if (sameOrder && previous?.status !== event.status) throw new Error("Conflicting refund snapshots require retrieval.");
      // Fresh reads under a fenced lease are ordered by its claimed state version,
      // not request-start time. Old timestamp-only snapshots remain readable.
      const newer = version === undefined ? !previous || observed > instant(previous.observedAt)
        : previous?.observedVersion === undefined || version > previous.observedVersion;
      if (newer) Object.defineProperty(invoice.refunds, event.refundId, { value: { amountCents: event.amountCents, status: event.status, observedAt: event.observedAt, ...(version === undefined ? {} : { observedVersion: version }) }, enumerable: true, configurable: true, writable: true });
      if (Object.values(invoice.refunds).filter((refund) => refund.status === "succeeded").reduce((sum, refund) => sum + refund.amountCents, 0) > period.amountCents) throw new Error("Refund total exceeds this payment.");
    } else {
      const opened = instant(event.openedAt);
      if (!event.disputeId || opened < instant(period.from) || opened > now.getTime() || !["open", "won", "lost"].includes(event.status)) throw new Error("Invalid dispute facts.");
      const previous = Object.hasOwn(invoice.disputes, event.disputeId) ? invoice.disputes[event.disputeId] : null;
      if (previous && (previous.openedAt !== event.openedAt || (previous.status !== "open" && event.status !== "open" && previous.status !== event.status))) throw new Error("Conflicting dispute facts require review.");
      Object.defineProperty(invoice.disputes, event.disputeId, { value: { openedAt: event.openedAt, status: previous?.status && previous.status !== "open" ? previous.status : event.status }, enumerable: true, configurable: true, writable: true });
      result.billingStoppedAt = new Date(Math.min(opened, state.billingStoppedAt ? instant(state.billingStoppedAt) : Infinity)).toISOString();
    }
    // Define own keys even for unexpected object-prototype-looking identifiers.
    Object.defineProperty(result.invoices, event.invoiceId, { value: invoice, enumerable: true, writable: true, configurable: true });
  }
  Object.defineProperty(result.events, event.eventId, { value: fingerprint, enumerable: true, writable: true, configurable: true });
  result.version++;
  return result;
}

function previouslyPaid(state: MonthlyState, period: number) {
  return Object.values(state.invoices).some((invoice) => invoice.period === period - 1 && invoice.paidAt !== null && instant(invoice.paidAt) < instant(state.binding.periods[invoice.period].to) && usablePayment(state, invoice));
}

function usablePayment(state: MonthlyState, invoice: InvoiceState) {
  return Object.values(invoice.refunds).filter((refund) => refund.status === "succeeded").reduce((sum, refund) => sum + refund.amountCents, 0) < state.binding.periods[invoice.period].amountCents
    && Object.values(invoice.disputes).every((dispute) => dispute.status === "won");
}

/** Only this subscription's purchase grants; callers retain all independent grants. */
export function monthlyPurchaseGrants(state: MonthlyState): InSeasonGrant[] {
  return Object.entries(state.invoices).flatMap(([invoiceId, invoice]) => {
    const period = state.binding.periods[invoice.period];
    if (!usablePayment(state, invoice)) return [];
    let from = invoice.paidAt;
    let to = Math.min(instant(period.to), cutoff, state.cancelledAt ? instant(state.cancelledAt) : Infinity);
    if (!from && invoice.firstFailureAt && invoice.failedAttempts < IN_SEASON_COMMERCE.monthlyBilling.failedPayment.maxFailedAttempts && previouslyPaid(state, invoice.period)) {
      from = invoice.firstFailureAt;
      to = Math.min(to, instant(monthlyFailureWindow(new Date(from)).graceEndsAt));
      if (state.billingStoppedAt) to = Math.min(to, instant(state.billingStoppedAt));
    }
    if (!from || to <= instant(from)) return [];
    return [{ source: "purchase" as const, reference: `stripe:sandbox:monthly:${invoiceId}`, status: "active", effectiveFrom: from, effectiveTo: new Date(to).toISOString() }];
  });
}

export function monthlyAccess(state: MonthlyState, now: Date, independentGrants: InSeasonGrant[] = []) {
  return resolveInSeasonAccess([...independentGrants, ...monthlyPurchaseGrants(state)], now);
}

/** Durable retry intents only, not a timer or Stripe execution path. */
export function monthlyRetryIntents(state: MonthlyState, now: Date) {
  if (!Number.isFinite(now.getTime())) throw new Error("Invalid retry observation time.");
  if (state.cancelledAt || state.billingStoppedAt || now.getTime() >= cutoff) return [];
  return Object.entries(state.invoices).flatMap(([invoiceId, invoice]) => {
    if (invoice.paidAt || !invoice.firstFailureAt || invoice.failedAttempts >= 3) return [];
    return monthlyFailureWindow(new Date(invoice.firstFailureAt)).retryAt.flatMap((at, index) => {
      const attempt = index + 2;
      if (attempt <= invoice.failedAttempts || invoice.failureIds?.includes(`in-season-monthly-retry:${invoiceId}:${attempt}`) || instant(at) < now.getTime() || instant(at) >= instant(state.binding.periods[invoice.period].to)) return [];
      return [{ invoiceId, subscriptionId: state.binding.subscriptionId, userId: state.binding.userId,
        at, attempt, idempotencyKey: `in-season-monthly-retry:${invoiceId}:${attempt}` }];
    });
  });
}

/** Record this before provider work so request acceptance immediately ends access. */
export function acceptMonthlyCancellation(state: MonthlyState, userId: string, requestId: string, now: Date) {
  if (userId !== state.binding.userId || !requestId.trim()) throw new Error("Cancellation ownership mismatch.");
  if (Object.hasOwn(state.events, `cancel:${requestId}`)) return state;
  return reduceMonthlyEvent(state, { kind: "cancelled", eventId: `cancel:${requestId}`, userId,
    subscriptionId: state.binding.subscriptionId, cancelledAt: now.toISOString() }, now);
}
