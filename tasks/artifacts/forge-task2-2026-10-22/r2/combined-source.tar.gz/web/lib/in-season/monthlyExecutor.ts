import type Stripe from "stripe";
import { IN_SEASON_COMMERCE } from "./commerce";
import { IN_SEASON_SANDBOX_CATALOG as catalog, verifyInSeasonSandboxAccount } from "./billingConfig";
import { monthlyRetryIntents, reduceMonthlyEvent } from "./monthlyLifecycle";
import { verifyMonthlyInvoice, verifyMonthlySubscription } from "./monthlyStripe";
import type { MonthlyStore } from "./monthlyStore";
import { reconcileMonthlySubscriptionEnd, reconcilePaidMonthlyInvoice } from "./monthlyWebhook";

const id = (value: string | { id?: string } | null | undefined) => typeof value === "string" ? value : value?.id;
const cutoff = Date.parse(IN_SEASON_COMMERCE.accessEndsAt);
export type VerifiedRetryConfiguration = { accountId: string; automaticRetriesDisabled: true; verificationReference: string };

/** Internal bounded worker, not exposed by a cron/API route. No automatic launch.
 * Both DB leases and provider idempotency keys protect retries. Unknown provider
 * outcomes remain unfinished and are inspected before another mutation.
 */
export async function runMonthlyBillingJobs({ stripe, store, limit = 10, now: fixedNow, retries }: {
  stripe: Stripe; store: MonthlyStore; limit?: number; now?: Date; retries?: VerifiedRetryConfiguration;
}) {
  await verifyInSeasonSandboxAccount(stripe);
  const jobs = await store.jobs(limit); const completed: string[] = []; const failed: { id: string; error: string }[] = [];
  for (const candidate of jobs) {
    try {
      let now = fixedNow ?? new Date();
      const claim = await store.claimJob(candidate.id); if (!claim) continue;
      const { job, token } = claim;
      const locked = await store.claim(job.subscription_id, `job:${job.id}`);
      if ("duplicate" in locked) { await store.finishJob(job.id, token); completed.push(job.id); continue; }
      let state = locked.state;
      if (state.binding.userId !== job.user_id || state.binding.subscriptionId !== job.subscription_id) throw new Error("Billing job owner mismatch.");
      const subscription = await stripe.subscriptions.retrieve(job.subscription_id);
      const price = await stripe.prices.retrieve(catalog.monthlyPriceId);
      const schedule = state.binding.scheduleId ? await stripe.subscriptionSchedules.retrieve(state.binding.scheduleId) : undefined;
      verifyMonthlySubscription(state.binding, subscription, price, schedule);
      if (job.kind === "retry") {
        if (!job.invoice_id || !state.invoices[job.invoice_id]) throw new Error("Retry invoice binding missing.");
        if (![2, 3].includes(job.attempt ?? 0) || job.id !== `in-season-monthly-retry:${job.invoice_id}:${job.attempt}` || !Array.isArray(job.accounting_snapshots)
          || job.accounting_snapshots.some(row => !row || typeof row !== "object" || Array.isArray(row))) throw new Error("Retry attempt history unavailable.");
        const attempts = job.accounting_snapshots.filter(row => row?.operation === "retry" || row?.operation === "retry_declined");
        if (attempts.length !== job.accounting_snapshots.length) throw new Error("Retry attempt history unavailable.");
        for (const row of attempts) {
          if (row.invoiceId !== job.invoice_id || row.attempt !== job.attempt || (row.idempotencyKey !== undefined && row.idempotencyKey !== job.id)
            || (row.operation === "retry_declined" && (row.idempotencyKey !== job.id || row.statusCode !== 402))) throw new Error("Retry attempt receipt binding mismatch.");
        }
        const started = attempts.some(row => row.operation === "retry");
        let declined = attempts.some(row => row.operation === "retry_declined");
        if (declined && !started) throw new Error("Retry decline has no durable attempt identity.");
        if (subscription.status === "canceled") state = reconcileMonthlySubscriptionEnd(state, subscription, `job:${job.id}:ended`, now);
        const due = Date.parse(job.due_at);
        const eligible = !state.cancelledAt && !state.billingStoppedAt && subscription.status !== "canceled"
          && now.getTime() >= due && now.getTime() <= due + 5 * 60_000 && now.getTime() < cutoff
          && monthlyRetryIntents(state, new Date(due)).some((intent) => intent.idempotencyKey === job.id && intent.invoiceId === job.invoice_id && intent.attempt === job.attempt);
        // The collection window limits new charges, never read-only recovery of a
        // prior unknown result. A paid invoice must reach the grant ledger first.
        let invoice = await stripe.invoices.retrieve(job.invoice_id);
        const line = invoice.lines.data.find((row) => row.amount !== 0);
        const initialPrice = state.binding.scheduleId && line?.pricing?.price_details?.price && line.pricing.price_details.price !== catalog.monthlyPriceId ? await stripe.prices.retrieve(line.pricing.price_details.price) : undefined;
        const period = verifyMonthlyInvoice(state.binding, invoice, initialPrice);
        if (eligible && !started && invoice.status === "open" && now.getTime() < Date.parse(state.binding.periods[period].to)) {
          if (retries?.accountId !== catalog.accountId || retries.automaticRetriesDisabled !== true || !retries.verificationReference.trim()) throw new Error("Automatic retry configuration has not been verified.");
          if (invoice.auto_advance !== false) throw new Error("Automatic invoice collection must be disabled before a controlled retry.");
          await store.snapshotJob(job.id, token, { operation: "retry", invoiceId: invoice.id, amount: invoice.amount_remaining, attempt: job.attempt, idempotencyKey: job.id, observedAt: now.toISOString() });
          const paymentTime = (fixedNow ?? new Date()).getTime();
          if (paymentTime >= cutoff || paymentTime >= Date.parse(state.binding.periods[period].to) || paymentTime > due + 5 * 60_000) throw new Error("Retry window closed before collection.");
          try {
            await stripe.invoices.pay(job.invoice_id, { off_session: true }, { idempotencyKey: job.id });
          }
          catch (error) {
            // Only a definitive provider decline counts as a failed attempt.
            // Transport errors and timeouts retain the unfinished job.
            if ((error as { statusCode?: number }).statusCode !== 402) throw error;
            await store.snapshotJob(job.id, token, { operation: "retry_declined", invoiceId: invoice.id, attempt: job.attempt, idempotencyKey: job.id, statusCode: 402, observedAt: (fixedNow ?? new Date()).toISOString() });
            declined = true;
          }
          if (!declined) {
            invoice = await stripe.invoices.retrieve(job.invoice_id);
            if (invoice.status !== "paid") throw new Error("Retry payment outcome has not settled.");
          }
        }
        now = fixedNow ?? new Date();
        if (invoice.status === "paid") {
          state = await reconcilePaidMonthlyInvoice({ stripe, state, eventId: `job:${job.id}:outcome`, invoice, subscription, price, schedule, initialPrice, now });
        } else if (invoice.status === "open") {
          if (invoice.auto_advance !== false || invoice.amount_paid !== 0 || invoice.amount_remaining !== invoice.total) throw new Error("Unpaid retry outcome is not verified.");
          const allocations = await stripe.invoicePayments.list({ invoice: invoice.id!, limit: 2 });
          if (allocations.has_more || allocations.data.length > 1) throw new Error("Retry payment allocation ambiguous.");
          for (const payment of allocations.data) {
            const intentId = id(payment.payment.payment_intent);
            if (payment.livemode !== false || id(payment.invoice) !== invoice.id || payment.currency !== "usd" || !["open", "canceled"].includes(payment.status) || payment.amount_paid || !intentId) throw new Error("Retry payment outcome is not verified.");
            const intent = await stripe.paymentIntents.retrieve(intentId);
            if (intent.livemode !== false || id(intent.customer) !== state.binding.customerId || intent.currency !== "usd" || intent.amount !== invoice.total || intent.amount_received !== 0
              || !["requires_payment_method", "canceled"].includes(intent.status)) throw new Error("Retry payment outcome is still uncertain.");
          }
          // Invoice retry-schedule counts do not identify manual attempts. Only a
          // durable response for this exact attempt proves its decline.
          if (declined) state = reduceMonthlyEvent(state, { kind: "failed", eventId: `declined:${job.id}`, userId: job.user_id, subscriptionId: job.subscription_id,
            invoiceId: job.invoice_id, period, failureId: job.id, firstFailureAt: state.invoices[job.invoice_id].firstFailureAt }, now);
          else if (started) throw new Error("Manual retry outcome unresolved; retain the job for read-only reconciliation.");
        } else if (!["void", "uncollectible"].includes(invoice.status ?? "")) {
          throw new Error("Invoice is not retryable.");
        }
      } else {
        const atCutoff = now.getTime() >= cutoff;
        const exhausted = Object.values(state.invoices).some((row) => !row.paidAt && row.failedAttempts >= 3);
        if (!atCutoff && !state.cancelledAt && !state.billingStoppedAt && !exhausted) throw new Error("Stop job has no matching lifecycle condition.");
        await store.snapshotJob(job.id, token, { operation: "stop", subscriptionId: subscription.id, scheduleId: schedule?.id, status: subscription.status, observedAt: now.toISOString() });
        if (subscription.status !== "canceled") {
          if (schedule) await stripe.subscriptionSchedules.cancel(schedule.id, { invoice_now: false, prorate: false }, { idempotencyKey: `${job.id}:cancel` });
          else await stripe.subscriptions.cancel(subscription.id, { invoice_now: false, prorate: false }, { idempotencyKey: `${job.id}:cancel` });
        }
        if (atCutoff) {
          const invoices = await stripe.invoices.list({ subscription: subscription.id, limit: 100 });
          const items = await stripe.invoiceItems.list({ customer: state.binding.customerId, pending: true, limit: 100 });
          if (invoices.has_more || items.has_more) throw new Error("Cutoff inventory exceeds the verified bound.");
          for (const invoice of invoices.data) {
            if (!invoice.id || invoice.livemode !== false || id(invoice.customer) !== state.binding.customerId || id(invoice.parent?.subscription_details?.subscription) !== subscription.id) throw new Error("Foreign cutoff invoice.");
          }
          for (const item of items.data) {
            if (item.livemode !== false || id(item.customer) !== state.binding.customerId || item.invoice || item.parent?.subscription_details?.subscription !== subscription.id) throw new Error("Unbound pending invoice item requires review.");
          }
          for (const invoice of invoices.data) {
            if (["paid", "void"].includes(invoice.status ?? "")) continue;
            if (!["open", "uncollectible", "draft"].includes(invoice.status ?? "")) throw new Error("Unknown cutoff invoice state.");
            await store.snapshotJob(job.id, token, { operation: "clear_invoice", invoiceId: invoice.id, status: invoice.status, amount: invoice.total, currency: invoice.currency, periodStart: invoice.period_start, periodEnd: invoice.period_end });
            if (invoice.status === "draft") await stripe.invoices.del(invoice.id!, { idempotencyKey: `${job.id}:delete:${invoice.id}` });
            else await stripe.invoices.voidInvoice(invoice.id!, {}, { idempotencyKey: `${job.id}:void:${invoice.id}` });
          }
          for (const item of items.data) {
            await store.snapshotJob(job.id, token, { operation: "clear_pending_item", itemId: item.id, amount: item.amount, currency: item.currency, period: item.period });
            await stripe.invoiceItems.del(item.id, { idempotencyKey: `${job.id}:item:${item.id}` });
          }
        }
      }
      state = reduceMonthlyEvent(state, { kind: "observed", eventId: `job:${job.id}`, userId: job.user_id, subscriptionId: job.subscription_id, observedAt: now.toISOString() }, now);
      await store.commit(job.subscription_id, `job:${job.id}`, locked.token, state, now);
      await store.finishJob(job.id, token); completed.push(job.id);
    } catch (error) {
      // Keep this job unfinished; its lease expires for later reconciliation.
      // A failed/unknown job must not prevent other cancellation or cutoff work.
      failed.push({ id: candidate.id, error: error instanceof Error ? error.message : "Billing job failed." });
    }
  }
  return { completed, failed };
}
