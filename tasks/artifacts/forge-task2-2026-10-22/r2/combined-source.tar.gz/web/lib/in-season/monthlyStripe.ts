import type Stripe from "stripe";
import { IN_SEASON_COMMERCE } from "./commerce";
import { IN_SEASON_SANDBOX_CATALOG as catalog } from "./billingConfig";
import { monthlyMetadata, type MonthlyBinding, type MonthlyEvent, type MonthlyState } from "./monthlyLifecycle";
import { monthlyInvoicePeriod, verifyMonthlySchedule } from "./monthlySchedule";

const cutoff = Date.parse(IN_SEASON_COMMERCE.accessEndsAt) / 1000;
const id = (object: string | { id?: string } | null | undefined) => typeof object === "string" ? object : object?.id;
const sameMetadata = (actual: Stripe.Metadata | null, binding: MonthlyBinding) => Object.entries(monthlyMetadata(binding)).every(([key, value]) => actual?.[key] === value);

/** Basil+ invoices put this binding on the typed line parent. Reject conflicts
 * with older event shapes instead of trusting whichever field appears first. */
export function monthlyLineSubscriptionId(line: Stripe.InvoiceLineItem) {
  const parent = line.parent?.type === "subscription_item_details" ? line.parent.subscription_item_details?.subscription
    : line.parent?.type === "invoice_item_details" ? line.parent.invoice_item_details?.subscription : undefined;
  const legacy = id(line.subscription);
  if (parent && legacy && parent !== legacy) throw new Error("Conflicting invoice line subscription.");
  return parent ?? legacy;
}

/** Validate fresh server-fetched facts, never browser or webhook metadata alone.
 * The caller must first authenticate the Stripe event and pin its sandbox account.
 */
export function verifyMonthlySubscription(binding: MonthlyBinding, subscription: Stripe.Subscription, price: Stripe.Price, schedule?: Stripe.SubscriptionSchedule) {
  if (subscription.livemode !== false || subscription.id !== binding.subscriptionId || id(subscription.customer) !== binding.customerId
    || !sameMetadata(subscription.metadata, binding) || subscription.items.has_more || subscription.items.data.length !== 1
    || subscription.items.data[0].quantity !== 1 || subscription.items.data[0].price.id !== catalog.monthlyPriceId
    || price.id !== catalog.monthlyPriceId || price.livemode !== false || id(price.product) !== catalog.productId
    || price.type !== "recurring" || price.unit_amount !== 499 || price.currency !== "usd" || price.recurring?.interval !== "month" || price.recurring.interval_count !== 1) throw new Error("Monthly subscription binding or price mismatch.");
  // Reject an uncapped subscription even if its payment succeeded. The cutoff
  // must already be configured at creation; no later webhook repair is trusted.
  if (binding.scheduleId) {
    if (!schedule || id(subscription.schedule) !== binding.scheduleId) throw new Error("Monthly schedule proof is missing.");
    // Stripe removes the one-time initial item after invoicing it. The invoice
    // verifier independently proves its exact amount, price, period and owner.
    verifyMonthlySchedule(binding, schedule, true);
  } else if (subscription.status !== "canceled" && subscription.cancel_at !== cutoff) throw new Error("Monthly subscription is missing its fixed cancellation boundary.");
  if (subscription.status === "canceled" && (!Number.isSafeInteger(subscription.ended_at) || !subscription.ended_at
    || subscription.ended_at < Date.parse(binding.periods[0].from) / 1000 || subscription.ended_at > cutoff
    || !Number.isSafeInteger(subscription.canceled_at) || !subscription.canceled_at || subscription.canceled_at > subscription.ended_at)) throw new Error("Cancellation occurred outside the season boundary.");
}

export function verifyMonthlyInvoice(binding: MonthlyBinding, invoice: Stripe.Invoice, initialPrice?: Stripe.Price) {
  const details = invoice.parent?.subscription_details;
  const lines = invoice.lines;
  const paidLines = lines.data.filter((line) => line.amount !== 0);
  const line = paidLines[0];
  const period = binding.periods.findIndex((candidate, index) => {
    const expected = binding.scheduleId ? monthlyInvoicePeriod(binding, index) : { from: Date.parse(candidate.from) / 1000, to: Date.parse(candidate.to) / 1000 };
    return expected.from === line?.period.start && expected.to === line.period.end;
  });
  const initial = !!binding.scheduleId && period === 0;
  const validPrice = initial ? initialPrice?.id === line?.pricing?.price_details?.price && initialPrice?.livemode === false && initialPrice.type === "one_time"
    && id(initialPrice.product) === catalog.productId && initialPrice.unit_amount === binding.periods[0].amountCents && initialPrice.currency === "usd" && sameMetadata(line.metadata, binding)
    : line?.pricing?.price_details?.price === catalog.monthlyPriceId;
  if (invoice.livemode !== false || id(invoice.customer) !== binding.customerId || id(details?.subscription) !== binding.subscriptionId
    || !sameMetadata(details?.metadata ?? null, binding) || lines.has_more || paidLines.length !== 1 || period < 0
    || lines.data.some((zero) => zero.amount === 0 && (!initial || zero.pricing?.price_details?.price !== catalog.monthlyPriceId || zero.quantity !== 1 || monthlyLineSubscriptionId(zero) !== binding.subscriptionId))
    || line.quantity !== 1 || line.currency !== "usd" || (!initial && monthlyLineSubscriptionId(line) !== binding.subscriptionId)
    || (initial && monthlyLineSubscriptionId(line) && monthlyLineSubscriptionId(line) !== binding.subscriptionId)
    || !validPrice || line.pricing?.price_details?.product !== catalog.productId
    || invoice.currency !== "usd" || invoice.total !== binding.periods[period].amountCents || line.amount !== binding.periods[period].amountCents
    || invoice.total_discount_amounts?.some((discount) => discount.amount !== 0)
    || invoice.total_taxes?.some((tax) => tax.amount !== 0)) throw new Error("Monthly invoice ownership, period or amount mismatch.");
  return period;
}

export function verifiedMonthlyPayment(input: {
  eventId: string; binding: MonthlyBinding; invoice: Stripe.Invoice;
  payment: Stripe.InvoicePayment; intent: Stripe.PaymentIntent; subscription: Stripe.Subscription; price: Stripe.Price;
  schedule?: Stripe.SubscriptionSchedule; initialPrice?: Stripe.Price;
}): MonthlyEvent {
  const { binding, invoice, payment, intent } = input;
  verifyMonthlySubscription(binding, input.subscription, input.price, input.schedule);
  const period = verifyMonthlyInvoice(binding, invoice, input.initialPrice);
  const amount = binding.periods[period].amountCents;
  const charge = intent.latest_charge;
  const paidAt = invoice.status_transitions.paid_at;
  if (!input.eventId || !invoice.id || invoice.status !== "paid" || invoice.amount_paid !== amount || invoice.amount_remaining !== 0 || !paidAt
    || payment.livemode !== false || id(payment.invoice) !== invoice.id || payment.status !== "paid" || payment.amount_paid !== amount || payment.currency !== "usd"
    || payment.payment.type !== "payment_intent" || id(payment.payment.payment_intent) !== intent.id
    || intent.livemode !== false || id(intent.customer) !== binding.customerId || intent.status !== "succeeded" || intent.amount !== amount || intent.amount_received !== amount || intent.currency !== "usd"
    || !charge || typeof charge === "string" || charge.livemode !== false || id(charge.payment_intent) !== intent.id || id(charge.customer) !== binding.customerId
    || charge.currency !== "usd" || charge.amount !== amount || !charge.paid || !charge.captured) throw new Error("Monthly payment chain is not verified.");
  // Refund/dispute facts are applied independently; a payment success may arrive
  // after its refund event without resurrecting that payment's entitlement.
  return { kind: "paid", eventId: input.eventId, userId: binding.userId, subscriptionId: binding.subscriptionId,
    invoiceId: invoice.id, period, paymentIntentId: intent.id, paidAt: new Date(paidAt * 1000).toISOString() };
}

/** Fresh provider objects must be retrieved under the verified sandbox account.
 * Refund/dispute facts are bound through the same invoice-payment-charge chain.
 * No refunds are issued here; pending/failed attempts never become full refunds.
 */
export function verifiedMonthlyAdjustment(input: Parameters<typeof verifiedMonthlyPayment>[0] & (
  { kind: "refund"; adjustment: Stripe.Refund; observedAt: Date } | { kind: "dispute"; adjustment: Stripe.Dispute }
)): MonthlyEvent {
  const payment = verifiedMonthlyPayment(input);
  if (payment.kind !== "paid") throw new Error("Payment chain is unavailable.");
  const adjustment = input.adjustment;
  const charge = input.intent.latest_charge as Stripe.Charge;
  if (id(adjustment.charge) !== charge.id || id(adjustment.payment_intent) !== payment.paymentIntentId || adjustment.currency !== "usd") throw new Error("Adjustment belongs to another payment.");
  const base = { eventId: input.eventId, userId: payment.userId, subscriptionId: payment.subscriptionId,
    invoiceId: payment.invoiceId, period: payment.period, paymentIntentId: payment.paymentIntentId };
  if (input.kind === "refund") {
    const refund = input.adjustment;
    const status = refund.status === "succeeded" ? "succeeded" : ["failed", "canceled"].includes(refund.status ?? "") ? "failed"
      : ["pending", "requires_action"].includes(refund.status ?? "") ? "pending" : null;
    if (!status || !refund.id || !Number.isSafeInteger(refund.amount) || refund.amount <= 0 || refund.amount > input.invoice.amount_paid) throw new Error("Refund facts are incomplete.");
    return { ...base, kind: "refund", refundId: refund.id, amountCents: refund.amount, status, observedAt: input.observedAt.toISOString() };
  }
  const dispute = input.adjustment;
  const status = dispute.status === "won" ? "won" : dispute.status === "lost" ? "lost"
    : ["needs_response", "under_review"].includes(dispute.status) ? "open" : null;
  if (!status || dispute.livemode !== false || !dispute.id || !Number.isSafeInteger(dispute.created) || dispute.created <= 0) throw new Error("Dispute facts are incomplete.");
  return { ...base, kind: "dispute", disputeId: dispute.id, openedAt: new Date(dispute.created * 1000).toISOString(), status };
}

/** A signed original failure event supplies the first failure time. A later
 * attempt alone cannot restart a new 48-hour window. Fresh retrieval still
 * establishes the subscription/invoice/customer binding before calling this.
 * Invoice events share one initial-failure identity: their retry-schedule count
 * does not identify manual attempts, which use durable worker receipts.
 */
export function verifiedMonthlyFailure(binding: MonthlyBinding, event: Stripe.Event, initialPrice?: Stripe.Price): MonthlyEvent {
  if (event.livemode !== false || !["invoice.payment_failed", "invoice.payment_action_required"].includes(event.type) || !Number.isSafeInteger(event.created) || event.created <= 0) throw new Error("Not a verified monthly failure event.");
  const invoice = event.data.object as Stripe.Invoice;
  const period = verifyMonthlyInvoice(binding, invoice, initialPrice);
  if (!invoice.id || !Number.isSafeInteger(invoice.attempt_count) || invoice.attempt_count < 1 || invoice.status !== "open") throw new Error("Invalid failed invoice.");
  return { kind: "failed", eventId: event.id, userId: binding.userId, subscriptionId: binding.subscriptionId,
    invoiceId: invoice.id, period, failureId: `invoice:${invoice.id}:initial`,
    firstFailureAt: invoice.attempt_count === 1 ? new Date(event.created * 1000).toISOString() : null };
}

export type MonthlyBillingCommand = {
  kind: "cancel_subscription" | "void_invoice" | "delete_draft_invoice" | "delete_pending_invoice_item";
  objectId: string; userId: string; subscriptionId: string; idempotencyKey: string;
  retainAccountingSnapshot: true;
  cancellationParams?: Stripe.SubscriptionCancelParams;
};
type OwnedInventory = { id: string; customerId: string; subscriptionId: string; status: string };

/** Produces a bounded owner-scoped outbox. It never calls Stripe or deletes data.
 * An executor must persist the accounting snapshot before a destructive command.
 */
export function monthlyStopCommands(state: MonthlyState, now: Date, inventory: { invoices: OwnedInventory[]; pendingItems: OwnedInventory[] }) {
  if (!Number.isFinite(now.getTime())) throw new Error("Invalid stop time.");
  const atSeasonEnd = now.getTime() / 1000 >= cutoff;
  const exhausted = Object.values(state.invoices).some((invoice) => !invoice.paidAt && invoice.failedAttempts >= IN_SEASON_COMMERCE.monthlyBilling.failedPayment.maxFailedAttempts);
  if (!state.cancelledAt && !state.billingStoppedAt && !atSeasonEnd && !exhausted) return [];
  const binding = state.binding;
  const command = (kind: MonthlyBillingCommand["kind"], objectId: string): MonthlyBillingCommand => ({ kind, objectId,
    userId: binding.userId, subscriptionId: binding.subscriptionId, retainAccountingSnapshot: true,
    idempotencyKey: `in-season-monthly-stop:${binding.subscriptionId}:${kind}:${objectId}`,
    ...(kind === "cancel_subscription" ? { cancellationParams: { invoice_now: false, prorate: false } } : {}),
  });
  const result = [command("cancel_subscription", binding.subscriptionId)];
  // Voiding balances is approved at season end, not automatically on an earlier
  // customer cancellation or dispute. Such events stop future billing only.
  if (!atSeasonEnd) return result;
  const all = [...inventory.invoices, ...inventory.pendingItems];
  if (all.some((row) => !row.id || row.customerId !== binding.customerId || row.subscriptionId !== binding.subscriptionId)) throw new Error("Cutoff cleanup inventory crosses an account/subscription boundary.");
  if (new Set(all.map((row) => row.id)).size !== all.length) throw new Error("Duplicate cutoff inventory.");
  for (const invoice of inventory.invoices) {
    if (invoice.status === "open" || invoice.status === "uncollectible") result.push(command("void_invoice", invoice.id));
    else if (invoice.status === "draft") result.push(command("delete_draft_invoice", invoice.id));
    else if (!["paid", "void"].includes(invoice.status)) throw new Error("Unrecognized invoice status.");
  }
  for (const item of inventory.pendingItems) {
    if (item.status !== "pending") throw new Error("Invoice item is not pending.");
    result.push(command("delete_pending_invoice_item", item.id));
  }
  return result;
}
