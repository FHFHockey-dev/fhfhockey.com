import { getNextOpenPick, keeperUsesPick, type KeeperEntry } from "./keepers";
import { originalPickOwner, type PickTradeEntry } from "./pickTrades";
import { normalizeDraftOrderPattern } from "./draftOrder";

import type { ProcessedPlayer } from "hooks/useProcessedProjectionsData";
import { STATS_MASTER_LIST } from "lib/projectionsConfig/statsMasterList";

export const YAHOO_DRAFT_SESSION_STORAGE_KEY =
  "draftDashboard.yahooLiveDraft.v3";

export type DraftDashboardMode = "manual" | "yahoo";

export type YahooDraftSessionStatus =
  | "predraft"
  | "active"
  | "stopped"
  | "complete"
  | "error"
  | "reauth_required";

export interface YahooDraftLeague {
  externalLeagueId: string;
  name: string;
  teamName?: string;
  season?: string | number;
  draftStatus?: string;
  draftTime?: string;
  yahooLeagueUrl?: string;
  supported: boolean;
  unsupportedReason?: string;
  session?: Pick<YahooDraftSession, "id" | "status" | "providerStatus"> | null;
}

export interface YahooDraftRankingOption {
  id: string;
  name?: string;
}

export interface YahooDraftSession {
  id: string;
  gameKey?: string | null;
  status: YahooDraftSessionStatus;
  providerStatus?: string | null;
  snapshotVersion?: number;
  lastSuccessfulPollAt?: string | null;
  lastWorkerHeartbeatAt?: string | null;
  lastPickNumber?: number;
  nextPollAt?: string | null;
  yahooLeagueUrl?: string | null;
  lastErrorCode?: string | null;
  lastErrorMessage?: string | null;
  yahooSeason?: string | null;
  targetSeasonId?: number | null;
  diagnostics?: Record<string, unknown> | null;
  stale?: boolean;
  staleSeverity?: "fresh" | "warning" | "critical";
}

export interface YahooDraftTeam {
  yahooTeamKey: string;
  name: string;
  draftPosition?: number;
  isUserTeam?: boolean;
}

export interface YahooDraftPick {
  pickNumber: number;
  roundNumber: number;
  pickInRound?: number;
  yahooTeamKey: string;
  yahooPlayerKey?: string | null;
  yahooPlayerId?: string | null;
  yahooGameKey?: string | null;
  fhfhPlayerId?: string | number | null;
  nhlPlayerId?: number | null;
  displayName?: string | null;
  mappingStatus?: string | null;
  cost?: number | null;
  active: boolean;
  isCorrection?: boolean;
  revision?: number;
  mappingRevision?: number;
  correctionConfirmedAt?: string | null;
}

export interface YahooDraftState {
  session: YahooDraftSession;
  teams: YahooDraftTeam[];
  settings: Record<string, unknown>;
  picks: YahooDraftPick[];
}

export interface YahooDraftListState {
  enabled: boolean;
  leagues: YahooDraftLeague[];
  ranking: YahooDraftRankingOption | null;
}

export function yahooUnsupportedLeagueMessage(reason?: string): string {
  switch (reason) {
    case "yahoo_salary_cap_unsupported":
      return "Salary-cap Yahoo drafts are not supported by live sync.";
    case "yahoo_draft_type_unsupported":
      return "Offline and autopick Yahoo drafts are not supported by live sync.";
    case "yahoo_settings_unavailable":
      return "Yahoo league settings are unavailable, so live sync cannot start.";
    default:
      return "This Yahoo league does not have a supported live draft configuration.";
  }
}

export interface YahooReconciledDraftedPlayer {
  playerId: string;
  teamId: string;
  pickNumber: number;
  round: number;
  pickInRound: number;
  isKeeper?: boolean;
  keeperVersion?: number;
  source?: "yahoo";
  yahooSessionId?: string;
  yahooPlayerKey?: string;
  yahooPlayerId?: string;
  yahooDisplayName?: string;
  yahooMappingStatus?: "mapped" | "unresolved" | "review_required";
  auctionCost?: number | null;
}

export interface YahooUnresolvedPick {
  pickNumber: number;
  yahooPlayerKey?: string;
  yahooPlayerId?: string;
  displayName: string;
  reason: string;
}

export interface YahooDraftReconciliation {
  draftedPlayers: YahooReconciledDraftedPlayer[];
  unresolved: YahooUnresolvedPick[];
  warnings: string[];
  currentPick: number;
  expectedNext: {
    pickNumber: number;
    roundNumber: number;
    pickInRound: number;
    yahooTeamKey?: string;
    teamName?: string;
    predicted: boolean;
  };
}

export interface YahooDraftLocalOrder {
  draftOrder: string[];
  draftOrderMode?: "standard" | "snake" | "custom";
  reversedRounds?: number[];
  keepers?: KeeperEntry[];
  trades?: PickTradeEntry[];
}

export function hasCompleteYahooPickOwnership(state: YahooDraftState | null): boolean {
  if (!state || !Array.isArray(state.settings.draftPickOwners) || !isRecord(state.settings.rosterConfig)) return false;
  const count = state.teams.length;
  const capacity = Object.values(state.settings.rosterConfig).reduce<number>((sum, value) => sum + (Number(value) || 0), 0);
  const slots = [...state.settings.draftPickOwners].sort((a, b) => Number(a.pickNumber) - Number(b.pickNumber));
  return count > 0 && capacity > 0 && slots.length === count * capacity && slots.every((slot, index) =>
    isRecord(slot) && slot.pickNumber === index + 1 && slot.roundNumber === Math.ceil((index + 1) / count) &&
    state.teams.some((team) => team.yahooTeamKey === slot.yahooTeamKey));
}

export function hasCompleteYahooDraftPositions(state: YahooDraftState | null): boolean {
  if (!state) return false;
  const count = Number(state.settings.teamCount) || state.teams.length;
  const positions = state.teams.map((team) => team.draftPosition);
  return count > 0 && positions.length === count && new Set(positions).size === count &&
    positions.every((position) => Number.isInteger(position) && Number(position) >= 1 && Number(position) <= count);
}

function localOrderMatchesLeague(state: YahooDraftState, local?: YahooDraftLocalOrder): boolean {
  return Boolean(local && local.draftOrder.length === state.teams.length &&
    new Set(local.draftOrder).size === state.teams.length &&
    state.teams.every((team) => local.draftOrder.includes(team.yahooTeamKey)));
}

export interface YahooDraftDashboardConfiguration {
  draftOrderMode?: "standard" | "snake" | "custom";
  reversedRounds?: number[];
  teamCount: number;
  draftOrder: string[];
  customTeamNames: Record<string, string>;
  myTeamId?: string;
  isSnakeDraft?: boolean;
  rosterConfig?: Record<string, number>;
  playoffWeeks?: number[];
  leagueType?: "points" | "categories";
  scoringCategories?: Record<string, number>;
  goalieScoringCategories?: Record<string, number>;
  categoryWeights?: Record<string, number>;
}

export interface YahooDraftPersistenceV3 {
  v: 3;
  mode: DraftDashboardMode;
  sessionId: string | null;
  externalLeagueId: string | null;
}

type JsonRecord = Record<string, unknown>;

function isRecord(value: unknown): value is JsonRecord {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function readString(
  value: JsonRecord,
  ...keys: string[]
): string | undefined {
  for (const key of keys) {
    const candidate = value[key];
    if (typeof candidate === "string" && candidate.trim()) {
      return candidate.trim();
    }
    if (typeof candidate === "number" && Number.isFinite(candidate)) {
      return String(candidate);
    }
  }
  return undefined;
}

function readNumber(
  value: JsonRecord,
  ...keys: string[]
): number | undefined {
  for (const key of keys) {
    const candidate = value[key];
    const parsed =
      typeof candidate === "number"
        ? candidate
        : typeof candidate === "string" && candidate.trim()
          ? Number(candidate)
          : Number.NaN;
    if (Number.isFinite(parsed)) return parsed;
  }
  return undefined;
}

function readBoolean(
  value: JsonRecord,
  ...keys: string[]
): boolean | undefined {
  for (const key of keys) {
    const candidate = value[key];
    if (typeof candidate === "boolean") return candidate;
    if (candidate === "true" || candidate === 1) return true;
    if (candidate === "false" || candidate === 0) return false;
  }
  return undefined;
}

function readRecord(value: JsonRecord, ...keys: string[]): JsonRecord {
  for (const key of keys) {
    if (isRecord(value[key])) return value[key] as JsonRecord;
  }
  return {};
}

function normalizeSessionStatus(value: unknown): YahooDraftSessionStatus {
  switch (String(value || "").toLowerCase()) {
    case "active":
    case "drafting":
      return "active";
    case "stopped":
      return "stopped";
    case "complete":
    case "completed":
    case "postdraft":
      return "complete";
    case "error":
      return "error";
    case "reauth_required":
    case "reauth-required":
      return "reauth_required";
    default:
      return "predraft";
  }
}

export function normalizeYahooDraftListResponse(
  value: unknown,
): YahooDraftListState {
  const root = isRecord(value) ? value : {};
  const payload = isRecord(root.data) ? root.data : root;
  const leagues = Array.isArray(payload.leagues) ? payload.leagues : [];
  const rankingValue = isRecord(payload.ranking) ? payload.ranking : null;

  return {
    // The feature is deliberately fail-closed. Only an explicit true exposes it.
    enabled: payload.enabled === true,
    leagues: leagues.flatMap((candidate) => {
      if (!isRecord(candidate)) return [];
      const externalLeagueId = readString(
        candidate,
        "externalLeagueId",
        "external_league_id",
        "id",
      );
      if (!externalLeagueId) return [];
      const rawLeagueSession = isRecord(candidate.session)
        ? candidate.session
        : null;
      const leagueSessionId = rawLeagueSession
        ? readString(rawLeagueSession, "id")
        : undefined;
      return [
        {
          externalLeagueId,
          name:
            readString(candidate, "name", "leagueName", "league_name") ||
            "Yahoo league",
          teamName: readString(candidate, "teamName", "team_name"),
          draftTime: readString(candidate, "draftTime", "draft_time"),
          season: readString(candidate, "season") || readNumber(candidate, "season"),
          draftStatus: readString(
            candidate,
            "draftStatus",
            "draft_status",
          ),
          yahooLeagueUrl: readString(
            candidate,
            "yahooLeagueUrl",
            "yahoo_league_url",
          ),
          supported:
            readBoolean(candidate, "supported", "isSupported", "is_supported") ??
            true,
          unsupportedReason: readString(
            candidate,
            "unsupportedReason",
            "unsupported_reason",
          ),
          session: leagueSessionId
            ? {
                id: leagueSessionId,
                status: normalizeSessionStatus(
                  rawLeagueSession?.status || rawLeagueSession?.providerStatus,
                ),
                providerStatus:
                  readString(
                    rawLeagueSession as JsonRecord,
                    "providerStatus",
                    "provider_status",
                  ) || null,
              }
            : null,
        },
      ];
    }),
    ranking:
      rankingValue && readString(rankingValue, "id")
        ? {
            id: readString(rankingValue, "id") as string,
            name: readString(rankingValue, "name", "title"),
          }
        : null,
  };
}

function normalizeYahooDraftPick(value: unknown): YahooDraftPick | null {
  if (!isRecord(value)) return null;
  const pickNumber = readNumber(value, "pickNumber", "pick_number", "pick");
  if (!pickNumber || pickNumber < 1) return null;
  const roundNumber =
    readNumber(value, "roundNumber", "round_number", "round") || 1;
  const yahooTeamKey =
    readString(value, "yahooTeamKey", "yahoo_team_key", "teamKey") || "";
  return {
    pickNumber,
    roundNumber,
    pickInRound: readNumber(value, "pickInRound", "pick_in_round"),
    yahooTeamKey,
    yahooPlayerKey: readString(
      value,
      "yahooPlayerKey",
      "yahoo_player_key",
      "playerKey",
    ),
    yahooPlayerId: readString(
      value,
      "yahooPlayerId",
      "yahoo_player_id",
      "playerId",
    ),
    yahooGameKey: readString(value, "yahooGameKey", "yahoo_game_key"),
    fhfhPlayerId: readString(value, "fhfhPlayerId", "fhfh_player_id"),
    nhlPlayerId: readNumber(value, "nhlPlayerId", "nhl_player_id"),
    displayName: readString(
      value,
      "displayName",
      "playerName",
      "player_name",
    ),
    mappingStatus: readString(value, "mappingStatus", "mapping_status"),
    cost: readNumber(value, "cost", "auctionCost", "auction_cost"),
    active: readBoolean(value, "active", "isActive", "is_active") ?? true,
    isCorrection:
      readBoolean(value, "isCorrection", "is_correction") || false,
    revision: readNumber(value, "revision"),
    mappingRevision: readNumber(
      value,
      "mappingRevision",
      "mapping_revision",
    ),
    correctionConfirmedAt:
      readString(
        value,
        "correctionConfirmedAt",
        "correction_confirmed_at",
      ) || null,
  };
}

function normalizeYahooDraftTeam(value: unknown): YahooDraftTeam | null {
  if (!isRecord(value)) return null;
  const yahooTeamKey = readString(
    value,
    "yahooTeamKey",
    "yahoo_team_key",
    "teamKey",
    "externalTeamKey",
    "external_team_key",
  );
  if (!yahooTeamKey) return null;
  return {
    yahooTeamKey,
    name:
      readString(value, "name", "displayName", "teamName", "team_name") ||
      yahooTeamKey,
    draftPosition: readNumber(
      value,
      "draftPosition",
      "draft_position",
      "position",
    ),
    isUserTeam:
      readBoolean(
        value,
        "isUserTeam",
        "is_user_team",
        "isMyTeam",
        "isOwned",
      ) || false,
  };
}

export function normalizeYahooDraftStateResponse(
  value: unknown,
): YahooDraftState | null {
  const root = isRecord(value) ? value : {};
  const payload = isRecord(root.data) ? root.data : root;
  const rawSession = readRecord(payload, "session");
  const id = readString(rawSession, "id");
  if (!id) return null;

  const picks = (Array.isArray(payload.picks) ? payload.picks : [])
    .map(normalizeYahooDraftPick)
    .filter((pick): pick is YahooDraftPick => Boolean(pick));
  const teams = (Array.isArray(payload.teams) ? payload.teams : [])
    .map(normalizeYahooDraftTeam)
    .filter((team): team is YahooDraftTeam => Boolean(team));

  return {
    session: {
      id,
      gameKey: readString(rawSession, "gameKey", "game_key") || null,
      status: normalizeSessionStatus(
        rawSession.status || rawSession.providerStatus || rawSession.provider_status,
      ),
      providerStatus:
        readString(rawSession, "providerStatus", "provider_status") || null,
      snapshotVersion: readNumber(
        rawSession,
        "snapshotVersion",
        "snapshot_version",
      ),
      lastSuccessfulPollAt:
        readString(
          rawSession,
          "lastSuccessfulPollAt",
          "last_successful_poll_at",
          "lastSnapshotAt",
          "last_snapshot_at",
        ) || null,
      lastWorkerHeartbeatAt:
        readString(
          rawSession,
          "lastWorkerHeartbeatAt",
          "last_worker_heartbeat_at",
        ) || null,
      lastPickNumber: readNumber(
        rawSession,
        "lastPickNumber",
        "last_pick_number",
      ),
      nextPollAt:
        readString(rawSession, "nextPollAt", "next_poll_at") || null,
      yahooLeagueUrl:
        readString(rawSession, "yahooLeagueUrl", "yahoo_league_url") || null,
      lastErrorCode:
        readString(rawSession, "lastErrorCode", "last_error_code") || null,
      lastErrorMessage:
        readString(rawSession, "lastErrorMessage", "last_error_message") ||
        null,
      yahooSeason:
        readString(rawSession, "yahooSeason", "yahoo_season") || null,
      targetSeasonId:
        readNumber(rawSession, "targetSeasonId", "target_season_id") || null,
      diagnostics: isRecord(rawSession.diagnostics)
        ? rawSession.diagnostics
        : null,
      stale: readBoolean(rawSession, "stale") || false,
      staleSeverity:
        readString(rawSession, "staleSeverity", "stale_severity") ===
        "critical"
          ? "critical"
          : readString(rawSession, "staleSeverity", "stale_severity") ===
              "warning"
            ? "warning"
            : "fresh",
    },
    teams,
    settings: readRecord(payload, "settings"),
    picks,
  };
}

export function getFirstMissingYahooPick(picks: YahooDraftPick[]): number {
  const occupied = new Set(
    picks
      .filter((pick) => pick.active && pick.pickNumber > 0)
      .map((pick) => pick.pickNumber),
  );
  let pickNumber = 1;
  while (occupied.has(pickNumber)) pickNumber += 1;
  return pickNumber;
}

function yahooIdFromPlayerKey(
  playerKey: string | null | undefined,
  gameKey: string | null | undefined,
): string | undefined {
  if (!playerKey || !gameKey) return undefined;
  const escapedGameKey = gameKey.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
  return playerKey.match(new RegExp(`^${escapedGameKey}\\.p\\.(\\d+)$`, "u"))?.[1];
}

function readDraftOrderMode(settings: Record<string, unknown>): {
  isSnakeDraft: boolean;
  explicit: boolean;
} {
  const diagnostics = isRecord(settings.diagnostics)
    ? settings.diagnostics
    : {};
  const inferred =
    readBoolean(
      diagnostics,
      "inferredDraftOrder",
      "inferred_draft_order",
    ) === true;
  const explicit = readBoolean(
    settings,
    "isSnakeDraft",
    "is_snake_draft",
    "snakeDraft",
  );
  if (explicit !== undefined) {
    return { isSnakeDraft: explicit, explicit: !inferred };
  }
  const draftOrder = readString(
    settings,
    "draftOrder",
    "draft_order",
    "draftOrderType",
    "draft_order_type",
  )?.toLowerCase();
  if (draftOrder === "snake") return { isSnakeDraft: true, explicit: true };
  if (draftOrder === "straight") return { isSnakeDraft: false, explicit: true };
  return { isSnakeDraft: true, explicit: false };
}

function orderedTeams(state: YahooDraftState, local?: YahooDraftLocalOrder): YahooDraftTeam[] {
  const teams = [...state.teams];
  const slots = state.settings.draftPickOwners;
  if (!hasCompleteYahooDraftPositions(state) && Array.isArray(slots)) {
    const firstRound = slots.filter((slot) => isRecord(slot) && Number(slot.roundNumber) === 1)
      .sort((a, b) => Number(a.pickNumber) - Number(b.pickNumber));
    if (firstRound.length === teams.length && new Set(firstRound.map((slot) => slot.yahooTeamKey)).size === teams.length &&
      firstRound.every((slot, index) => Number(slot.pickNumber) === index + 1 && teams.some((team) => team.yahooTeamKey === slot.yahooTeamKey))) {
      return firstRound.map((slot) => teams.find((team) => team.yahooTeamKey === slot.yahooTeamKey)!);
    }
  }
  if (!hasCompleteYahooDraftPositions(state) && localOrderMatchesLeague(state, local)) {
    return teams.sort((a, b) => local!.draftOrder.indexOf(a.yahooTeamKey) - local!.draftOrder.indexOf(b.yahooTeamKey));
  }
  teams.sort((a, b) => {
    if (a.draftPosition && b.draftPosition) {
      return a.draftPosition - b.draftPosition;
    }
    if (a.draftPosition) return -1;
    if (b.draftPosition) return 1;
    return a.yahooTeamKey.localeCompare(b.yahooTeamKey);
  });
  return teams;
}

/** Yahoo-owned slots override manual ownership only where the provider supplied it. */
export function yahooDraftPickTrades(state: YahooDraftState | null, local: YahooDraftLocalOrder): PickTradeEntry[] {
  const trades = new Map((local.trades || []).map((trade) => [trade.pickNumber, trade]));
  const rows = state?.settings.draftPickOwners;
  const count = local.draftOrder.length;
  if (!state || !Array.isArray(rows) || !count || !localOrderMatchesLeague(state, local)) return [...trades.values()];
  const pattern = normalizeDraftOrderPattern({ mode: local.draftOrderMode, reversedRounds: local.reversedRounds }, Math.max(1, ...rows.map((row) => isRecord(row) ? Number(row.roundNumber) || 1 : 1)));
  for (const row of rows) {
    if (!isRecord(row)) continue;
    const pickNumber = Number(row.pickNumber), round = Number(row.roundNumber);
    const currentTeamId = String(row.yahooTeamKey || "");
    if (!Number.isInteger(pickNumber) || pickNumber < 1 || round !== Math.ceil(pickNumber / count) || !local.draftOrder.includes(currentTeamId)) continue;
    const pickInRound = (pickNumber - 1) % count + 1;
    const originalTeamId = originalPickOwner(local.draftOrder, round, pickInRound, pattern);
    if (!originalTeamId) continue;
    if (originalTeamId === currentTeamId) { trades.delete(pickNumber); continue; }
    trades.set(pickNumber, { version: 1, status: "valid", round, pickInRound, pickNumber, originalTeamId, currentTeamId });
  }
  return [...trades.values()].sort((a, b) => a.pickNumber - b.pickNumber);
}

/** Match keeper identities exactly; unknown costs reserve no draft slot. */
export function yahooDraftKeepers(state: YahooDraftState | null, players: ProcessedPlayer[], manual: KeeperEntry[]) {
  const keepers = new Map(manual.map((keeper) => [keeper.playerId, keeper]));
  const warnings: string[] = [];
  const rows = state?.settings.draftKeepers;
  if (typeof state?.settings.draftKeepersWarning === "string") warnings.push(state.settings.draftKeepersWarning);
  if (!state || !Array.isArray(rows)) return { keepers: [...keepers.values()], warnings };
  let unknownCosts = 0;
  for (const row of rows) {
    if (!isRecord(row)) continue;
    const candidates = players.filter((player) => {
      const id = String(player.yahooPlayerId || "");
      const key = /^\d+$/.test(id) ? `${state.session.gameKey}.p.${id}` : id;
      return Boolean(yahooIdFromPlayerKey(key, state.session.gameKey || null)) && key === row.yahooPlayerKey;
    });
    if (candidates.length !== 1 || !state.teams.some((team) => team.yahooTeamKey === row.yahooTeamKey)) {
      warnings.push(`Keeper ${String(row.displayName || row.yahooPlayerKey)} needs an exact player/team match before it can be imported.`);
      continue;
    }
    const playerId = String(candidates[0].playerId);
    const reportedPick = state.picks.find((pick) => pick.active && pick.yahooPlayerKey === row.yahooPlayerKey && pick.yahooTeamKey === row.yahooTeamKey);
    if (reportedPick && reportedPick.pickNumber > 0 && state.teams.length > 0) {
      keepers.set(playerId, { version: 2, status: "valid", cost: "pick", playerId, teamId: String(row.yahooTeamKey),
        pickNumber: reportedPick.pickNumber, round: reportedPick.roundNumber,
        pickInRound: reportedPick.pickInRound || (reportedPick.pickNumber - 1) % state.teams.length + 1 });
      continue;
    }
    const existing = keepers.get(playerId);
    if (existing?.teamId === row.yahooTeamKey) continue;
    keepers.set(playerId, { version: 2, status: "valid", cost: "none", playerId, teamId: String(row.yahooTeamKey) });
    unknownCosts++;
  }
  // Resolve collisions after all reported assignments have been applied, so swaps
  // are independent of keeper row order. Never discard a displaced roster player.
  for (const [playerId, keeper] of keepers) {
    if (!keeperUsesPick(keeper)) continue;
    const occupied = state.picks.find((pick) => pick.active && pick.pickNumber === keeper.pickNumber);
    const player = players.find((entry) => String(entry.playerId) === playerId);
    const yahooId = String(player?.yahooPlayerId || "");
    const yahooKey = /^\d+$/.test(yahooId) ? `${state.session.gameKey}.p.${yahooId}` : yahooId;
    if (occupied && (occupied.yahooPlayerKey !== yahooKey || occupied.yahooTeamKey !== keeper.teamId)) {
      keepers.set(playerId, { version: 2, status: "valid", cost: "none", playerId, teamId: keeper.teamId });
      warnings.push(`Yahoo assigned pick ${keeper.pickNumber} to another player. Keeper ${player?.fullName || playerId} remains on the roster; assign a different keeper pick.`);
    }
  }
  if (unknownCosts) warnings.push("Yahoo listed keeper players but did not supply their pick assignments. They are not confirmed as free keepers; assign their picks in the Draft Graph if your league charges them.");
  return { keepers: [...keepers.values()], warnings };
}

export function yahooCompatibleKeepers(
  keepers: KeeperEntry[],
  picks: YahooReconciledDraftedPlayer[],
): KeeperEntry[] {
  const confirmed = picks.filter((pick) => pick.source === "yahoo");
  return keepers.flatMap((keeper): KeeperEntry[] => {
    const selected = confirmed.find((pick) => pick.playerId === keeper.playerId);
    if (selected) {
      return keeperUsesPick(keeper) && selected.pickNumber === keeper.pickNumber && selected.teamId === keeper.teamId ? [keeper] : [];
    }
    if (keeperUsesPick(keeper) && confirmed.some((pick) => pick.pickNumber === keeper.pickNumber)) {
      return [{ version: 2, status: "valid", cost: "none", playerId: keeper.playerId, teamId: keeper.teamId }];
    }
    return [keeper];
  });
}

export function reconcileYahooDraftState(
  state: YahooDraftState | null,
  players: ProcessedPlayer[],
  localOrder?: YahooDraftLocalOrder,
): YahooDraftReconciliation {
  const picks = state?.picks || [];
  let currentPick = getFirstMissingYahooPick(picks);
  const teamCount = Math.max(
    1,
    state?.teams.length ||
      readNumber(state?.settings || {}, "teamCount", "numTeams", "num_teams") ||
      1,
  );

  const byNhlId = new Map<number, ProcessedPlayer[]>();
  const byFhfhId = new Map<number, ProcessedPlayer[]>();
  const byYahooPlayerKey = new Map<string, ProcessedPlayer[]>();
  const configuredGameKey = state?.session.gameKey || null;
  for (const player of players) {
    if (
      Number.isSafeInteger(player.fhfhPlayerId) &&
      Number(player.fhfhPlayerId) > 0
    ) {
      const fhfhPlayerId = Number(player.fhfhPlayerId);
      byFhfhId.set(fhfhPlayerId, [
        ...(byFhfhId.get(fhfhPlayerId) || []),
        player,
      ]);
    }
    byNhlId.set(player.playerId, [
      ...(byNhlId.get(player.playerId) || []),
      player,
    ]);
    if (player.yahooPlayerId != null && String(player.yahooPlayerId)) {
      const yahooPlayerId = String(player.yahooPlayerId);
      const scopedPlayerKey = configuredGameKey
        ? `${configuredGameKey}.p.${yahooPlayerId}`
        : null;
      if (!scopedPlayerKey) continue;
      byYahooPlayerKey.set(scopedPlayerKey, [
        ...(byYahooPlayerKey.get(scopedPlayerKey) || []),
        player,
      ]);
    }
  }

  const activeByPickNumber = new Map<number, YahooDraftPick>();
  for (const pick of picks) {
    if (pick.active) activeByPickNumber.set(pick.pickNumber, pick);
  }

  const draftedPlayers: YahooReconciledDraftedPlayer[] = [];
  const unresolved: YahooUnresolvedPick[] = [];
  for (const pick of [...activeByPickNumber.values()].sort(
    (a, b) => a.pickNumber - b.pickNumber,
  )) {
    const pickGameKey = pick.yahooGameKey || configuredGameKey;
    const exactYahooId =
      yahooIdFromPlayerKey(pick.yahooPlayerKey, pickGameKey) ||
      (pickGameKey === configuredGameKey ? pick.yahooPlayerId || undefined : undefined);
    const fhfhCandidates =
      pick.fhfhPlayerId == null
        ? []
        : byFhfhId.get(Number(pick.fhfhPlayerId)) || [];
    const nhlCandidates =
      pick.nhlPlayerId == null ? [] : byNhlId.get(pick.nhlPlayerId) || [];
    const scopedPlayerKey =
      pick.yahooPlayerKey && pickGameKey === configuredGameKey
        ? pick.yahooPlayerKey
        : exactYahooId && configuredGameKey
          ? `${configuredGameKey}.p.${exactYahooId}`
          : null;
    const yahooCandidates = scopedPlayerKey
      ? byYahooPlayerKey.get(scopedPlayerKey) || []
      : [];
    const candidates = fhfhCandidates.length
      ? fhfhCandidates
      : nhlCandidates.length
        ? nhlCandidates
        : yahooCandidates;
    const matchedPlayer = candidates.length === 1 ? candidates[0] : undefined;
    const reviewRequired = pick.mappingStatus === "review_required";
    const displayName = pick.displayName || pick.yahooPlayerKey || "Unknown Yahoo player";

    if (!matchedPlayer || reviewRequired) {
      unresolved.push({
        pickNumber: pick.pickNumber,
        yahooPlayerKey: pick.yahooPlayerKey || undefined,
        yahooPlayerId: exactYahooId,
        displayName,
        reason: reviewRequired
          ? "This identity match requires review and was not applied automatically."
          : candidates.length > 1
            ? "The Yahoo player ID matched multiple projection players, so no player was selected."
            : "No exact Yahoo player ID mapping was found. Name matching was not attempted.",
      });
    }

    draftedPlayers.push({
      playerId: matchedPlayer && !reviewRequired
        ? String(matchedPlayer.playerId)
        : String(-pick.pickNumber),
      teamId: pick.yahooTeamKey || `Yahoo Team ${pick.pickInRound || 1}`,
      pickNumber: pick.pickNumber,
      round: pick.roundNumber,
      pickInRound:
        pick.pickInRound || ((pick.pickNumber - 1) % teamCount) + 1,
      isKeeper: Array.isArray(state?.settings.draftKeepers) && state.settings.draftKeepers.some((entry) =>
        isRecord(entry) && entry.yahooPlayerKey === pick.yahooPlayerKey && entry.yahooTeamKey === pick.yahooTeamKey),
      source: "yahoo",
      yahooSessionId: state?.session.id || "",
      yahooPlayerKey: pick.yahooPlayerKey || undefined,
      yahooPlayerId: exactYahooId,
      yahooDisplayName: displayName,
      yahooMappingStatus: reviewRequired
        ? "review_required"
        : matchedPlayer
          ? "mapped"
          : "unresolved",
      auctionCost: pick.cost,
    });
  }

  // Manual keeper reservations supplement Yahoo's confirmed picks; they never
  // overwrite a confirmed pick or duplicate a player Yahoo has already reported.
  const importedKeepers = yahooDraftKeepers(state, players, localOrder?.keepers || []);
  const setupWarnings: string[] = [...importedKeepers.warnings];
  const confirmedPlayers = new Set(draftedPlayers.map((pick) => pick.playerId));
  const confirmedPicks = new Set(draftedPlayers.map((pick) => pick.pickNumber));
  for (const keeper of importedKeepers.keepers) {
    if (!state?.teams.some((team) => team.yahooTeamKey === keeper.teamId)) continue;
    if (confirmedPlayers.has(keeper.playerId)) continue;
    if (!keeperUsesPick(keeper)) continue;
    if (confirmedPicks.has(keeper.pickNumber)) {
      setupWarnings.push(`Yahoo reported a different player at keeper pick ${keeper.pickNumber}. The Yahoo pick is shown; review your manual keeper setup.`);
      continue;
    }
    draftedPlayers.push({
      playerId: keeper.playerId, teamId: keeper.teamId,
      pickNumber: keeper.pickNumber, round: keeper.round, pickInRound: keeper.pickInRound,
      isKeeper: true, keeperVersion: keeper.version,
    });
  }
  draftedPlayers.sort((a, b) => a.pickNumber - b.pickNumber);
  currentPick = getNextOpenPick(currentPick, Number.MAX_SAFE_INTEGER, draftedPlayers);
  const roundNumber = Math.ceil(currentPick / teamCount);
  const pickInRound = ((currentPick - 1) % teamCount) + 1;

  const configuration = state ? deriveYahooDraftDashboardConfiguration(state, localOrder) : null;
  const teams = state ? orderedTeams(state, localOrder) : [];
  const baseIndex = (currentPick - 1) % teamCount;
  const draftOrderMode = readDraftOrderMode(state?.settings || {});
  const teamIndex =
    (configuration?.draftOrderMode === "custom"
      ? configuration.reversedRounds?.includes(roundNumber)
      : (configuration?.isSnakeDraft ?? draftOrderMode.isSnakeDraft) && roundNumber % 2 === 0)
      ? teamCount - baseIndex - 1
      : baseIndex;
  const trade = localOrder ? yahooDraftPickTrades(state, localOrder).find((entry) => entry.pickNumber === currentPick) : undefined;
  const suppliedOwner = Array.isArray(state?.settings.draftPickOwners)
    ? state.settings.draftPickOwners.find((slot) => isRecord(slot) && slot.pickNumber === currentPick && slot.roundNumber === roundNumber)
    : undefined;
  const suppliedTeam = teams.find((team) => team.yahooTeamKey === suppliedOwner?.yahooTeamKey);
  const expectedTeam = suppliedTeam || teams.find((team) => team.yahooTeamKey === trade?.currentTeamId) || teams[teamIndex];

  return {
    draftedPlayers,
    unresolved,
    warnings: [...setupWarnings, ...(!state || draftOrderMode.explicit || hasCompleteYahooPickOwnership(state)
      ? []
      : [
          "Yahoo did not provide an explicit snake or straight draft order. Upcoming turns use the dashboard's configured draft format; check it against your Yahoo draft room.",
        ])],
    currentPick,
    expectedNext: {
      pickNumber: currentPick,
      roundNumber,
      pickInRound,
      yahooTeamKey: expectedTeam?.yahooTeamKey,
      teamName: expectedTeam?.name,
      predicted: !suppliedTeam,
    },
  };
}

function normalizeNumericRecord(value: unknown, allowNegative = false): Record<string, number> | undefined {
  if (!isRecord(value)) return undefined;
  const entries = Object.entries(value).flatMap(([key, candidate]) => {
    const parsed = Number(candidate);
    return Number.isFinite(parsed) && (allowNegative || parsed >= 0) ? [[key, parsed] as const] : [];
  });
  return entries.length ? Object.fromEntries(entries) : undefined;
}

export function deriveYahooDraftDashboardConfiguration(
  state: YahooDraftState,
  localOrder?: YahooDraftLocalOrder,
): YahooDraftDashboardConfiguration {
  const teams = orderedTeams(state, localOrder);
  const providerMode = readDraftOrderMode(state.settings);
  const keepLocalFormat = !providerMode.explicit && localOrderMatchesLeague(state, localOrder);
  const draftOrderMode = keepLocalFormat && localOrder?.draftOrderMode
    ? localOrder.draftOrderMode : providerMode.isSnakeDraft ? "snake" : "standard";
  const draftOrder = teams.map((team) => team.yahooTeamKey);
  for (const pick of state.picks) {
    if (pick.active && pick.yahooTeamKey && !draftOrder.includes(pick.yahooTeamKey)) {
      draftOrder.push(pick.yahooTeamKey);
    }
  }

  const rawRoster =
    state.settings.rosterConfig || state.settings.roster_config || undefined;
  const rawScoring =
    state.settings.scoringCategories ||
    state.settings.scoring_categories ||
    undefined;
  const rawCategoryWeights =
    state.settings.categoryWeights || state.settings.category_weights || undefined;
  const scoring = normalizeNumericRecord(rawScoring, true);
  const goalieStatKeys = new Set(STATS_MASTER_LIST
    .filter((stat) => stat.isGoalieStat && !stat.isSkaterStat)
    .map((stat) => stat.key));
  // Yahoo's normalized stat 18 uses this legacy key for goalie starts.
  goalieStatKeys.add("GAMES_STARTED");
  const scoringEntries = scoring ? Object.entries(scoring) : undefined;
  const leagueType = readString(
    state.settings,
    "leagueType",
    "league_type",
  );

  return {
    teamCount:
      readNumber(state.settings, "teamCount", "numTeams", "num_teams") ||
      draftOrder.length ||
      1,
    draftOrder,
    customTeamNames: Object.fromEntries(
      teams.map((team) => [team.yahooTeamKey, team.name]),
    ),
    myTeamId: teams.find((team) => team.isUserTeam)?.yahooTeamKey,
    isSnakeDraft: draftOrderMode === "snake",
    draftOrderMode,
    reversedRounds: draftOrderMode === "custom" ? [...(localOrder?.reversedRounds || [])] : [],
    rosterConfig: normalizeNumericRecord(rawRoster),
    playoffWeeks: Array.isArray(state.settings.playoffWeeks) &&
      state.settings.playoffWeeks.every((week) => Number.isInteger(week) && week > 0 && week <= 53)
      ? [...new Set(state.settings.playoffWeeks as number[])].sort((a, b) => a - b)
      : undefined,
    leagueType:
      leagueType === "points" || leagueType === "categories"
        ? leagueType
        : undefined,
    scoringCategories: scoringEntries && Object.fromEntries(scoringEntries.filter(([key]) => !goalieStatKeys.has(key))),
    goalieScoringCategories: scoringEntries && Object.fromEntries(scoringEntries.filter(([key]) => goalieStatKeys.has(key))),
    categoryWeights: normalizeNumericRecord(rawCategoryWeights),
  };
}

export function yahooSettingsRequireScoringConfirmation(
  state: YahooDraftState | null,
): boolean {
  if (!state) return false;
  const settings = state.settings;
  if (
    readBoolean(
      settings,
      "requiresScoringConfirmation",
      "requires_scoring_confirmation",
    ) === true
  ) {
    return true;
  }

  const diagnostics = isRecord(settings.scoringDiagnostics)
    ? settings.scoringDiagnostics
    : isRecord(settings.scoring_diagnostics)
      ? settings.scoring_diagnostics
      : state.session.diagnostics || {};
  const unsupported =
    settings.unsupportedScoringStats ||
    settings.unsupported_scoring_stats ||
    diagnostics.unsupportedStats ||
    diagnostics.unsupported_stats ||
    diagnostics.unsupportedStatIds ||
    diagnostics.unsupported_stat_ids ||
    diagnostics.unmappedStats ||
    diagnostics.unmapped_stats;
  if (Array.isArray(unsupported) && unsupported.length > 0) return true;

  const configuration = deriveYahooDraftDashboardConfiguration(state);
  return (
    !configuration.scoringCategories && !configuration.categoryWeights
  );
}

export function yahooSettingsRequireDraftOrderConfirmation(
  state: YahooDraftState | null,
): boolean {
  if (!state) return false;
  if (
    readBoolean(
      state.settings,
      "requiresDraftOrderConfirmation",
      "requires_draft_order_confirmation",
    ) === true
  ) {
    return true;
  }
  const diagnostics = isRecord(state.settings.diagnostics)
    ? state.settings.diagnostics
    : {};
  if (
    readBoolean(
      diagnostics,
      "inferredDraftOrder",
      "inferred_draft_order",
    ) === true
  ) {
    return true;
  }
  return !readDraftOrderMode(state.settings).explicit;
}

export function yahooSettingsWarnings(state: YahooDraftState | null): string[] {
  if (!state) return [];
  const diagnostics = isRecord(state.settings.diagnostics)
    ? state.settings.diagnostics
    : {};
  return Array.isArray(diagnostics.warnings)
    ? diagnostics.warnings.filter(
        (warning): warning is string =>
          typeof warning === "string" && Boolean(warning.trim()),
      )
    : [];
}

export function yahooSettingsRequireGeneralConfirmation(
  state: YahooDraftState | null,
): boolean {
  return state
    ? readBoolean(
        state.settings,
        "requiresConfirmation",
        "requires_confirmation",
      ) === true || yahooSettingsWarnings(state).length > 0
    : false;
}

export function loadYahooDraftPersistence(
  storage: Pick<Storage, "getItem">,
): YahooDraftPersistenceV3 {
  const fallback: YahooDraftPersistenceV3 = {
    v: 3,
    mode: "manual",
    sessionId: null,
    externalLeagueId: null,
  };
  try {
    const raw = storage.getItem(YAHOO_DRAFT_SESSION_STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<YahooDraftPersistenceV3>;
    if (parsed.v !== 3) return fallback;
    return {
      v: 3,
      mode: parsed.mode === "yahoo" ? "yahoo" : "manual",
      sessionId:
        typeof parsed.sessionId === "string" && parsed.sessionId
          ? parsed.sessionId
          : null,
      externalLeagueId:
        typeof parsed.externalLeagueId === "string" && parsed.externalLeagueId
          ? parsed.externalLeagueId
          : null,
    };
  } catch {
    return fallback;
  }
}

export function saveYahooDraftPersistence(
  storage: Pick<Storage, "setItem">,
  value: Omit<YahooDraftPersistenceV3, "v">,
): void {
  storage.setItem(
    YAHOO_DRAFT_SESSION_STORAGE_KEY,
    JSON.stringify({ v: 3, ...value } satisfies YahooDraftPersistenceV3),
  );
}

export function selectDraftedPlayersForMode<T>(
  mode: DraftDashboardMode,
  manualDraftedPlayers: T[],
  yahooDraftedPlayers: T[],
): T[] {
  return mode === "yahoo" ? yahooDraftedPlayers : manualDraftedPlayers;
}

export function continueManuallyFromYahoo(
  reconciliation: YahooDraftReconciliation,
): {
  draftedPlayers: YahooReconciledDraftedPlayer[];
  currentPick: number;
} {
  return {
    draftedPlayers: reconciliation.draftedPlayers.map((player) => ({
      ...player,
    })),
    currentPick: reconciliation.currentPick,
  };
}
