import { describe, expect, it } from "vitest";

import {
  PICK_TRADE_CONTRACT_VERSION,
  findNextActionablePick,
  findSelectionHorizon,
  findPicksUntilTeamTurn,
  migratePickTrades,
  parsePickTradeImport,
  resolvePickOwner,
  upsertPickTrade,
  validatePickTradeBatch
} from "./pickTrades";
import { KEEPER_CONTRACT_VERSION } from "./keepers";

const base = {
  draftOrder: ["Team 1", "Team 2", "Team 3", "Team 4"],
  roundCount: 3,
  isSnakeDraft: true
};

describe("pick trade contract", () => {
  it("derives original owners and stable global identity across snake rounds", () => {
    const result = upsertPickTrade(
      { round: 2, pickInRound: 1, currentTeamId: "Team 1" },
      base
    );
    expect(result).toMatchObject({
      ok: true,
      trade: {
        version: PICK_TRADE_CONTRACT_VERSION,
        pickNumber: 5,
        originalTeamId: "Team 4",
        currentTeamId: "Team 1"
      }
    });
  });

  it("rejects bounds, unknown/no-op owners, and completed ordinary picks", () => {
    expect(
      upsertPickTrade(
        { round: 4, pickInRound: 5, currentTeamId: "Missing" },
        base
      )
    ).toMatchObject({ ok: false });
    expect(
      upsertPickTrade(
        { round: 1, pickInRound: 1, currentTeamId: "Team 1" },
        base
      )
    ).toMatchObject({ ok: false });
    expect(
      upsertPickTrade(
        { round: 1, pickInRound: 1, currentTeamId: "Team 2" },
        {
          ...base,
          draftedPlayers: [
            { playerId: "1", teamId: "Team 1", round: 1, pickInRound: 1, pickNumber: 1 }
          ]
        }
      )
    ).toMatchObject({ ok: false });
  });

  it("keeps keeper display precedence while preserving the underlying trade", () => {
    const result = upsertPickTrade(
      { round: 1, pickInRound: 1, currentTeamId: "Team 2" },
      {
        ...base,
        keepers: [
          {
            version: KEEPER_CONTRACT_VERSION,
            status: "valid",
            cost: "pick",
            playerId: "1",
            teamId: "Team 3",
            round: 1,
            pickInRound: 1,
            pickNumber: 1
          }
        ]
      }
    );
    if (!result.ok) throw new Error("fixture failed");
    expect(result.warnings[0]).toContain("Team 3");
    expect(
      resolvePickOwner({
        round: 1,
        pickInRound: 1,
        draftOrder: base.draftOrder,
        isSnakeDraft: true,
        trades: result.trades,
        keepers: [
          {
            version: KEEPER_CONTRACT_VERSION,
            status: "valid",
            cost: "pick",
            playerId: "1",
            teamId: "Team 3",
            round: 1,
            pickInRound: 1,
            pickNumber: 1
          }
        ]
      })
    ).toMatchObject({ currentTeamId: "Team 3", tradedTeamId: "Team 2", source: "keeper" });
  });

  it("migrates legacy maps and validates bulk input transactionally", () => {
    expect(migratePickTrades({ "2-1": "Team 1" }, base)).toEqual([
      expect.objectContaining({ pickNumber: 5, originalTeamId: "Team 4" })
    ]);
    const parsed = parsePickTradeImport(
      "round,pickInRound,currentTeamId\n1,1,Team 2\n1,2,Team 2"
    );
    if (!parsed.ok) throw new Error("fixture failed");
    expect(validatePickTradeBatch(parsed.candidates, base)).toMatchObject({
      ok: false,
      trades: [],
      errors: [expect.stringContaining("Row 2")]
    });

    const multiple = validatePickTradeBatch(
      [
        { round: 1, pickInRound: 1, currentTeamId: "Team 2" },
        { round: 2, pickInRound: 1, currentTeamId: "Team 1" }
      ],
      base
    );
    expect(multiple).toMatchObject({ ok: true });
    if (!multiple.ok) return;
    expect(multiple.trades).toHaveLength(2);
    const edited = upsertPickTrade(
      { round: 1, pickInRound: 1, currentTeamId: "Team 3" },
      { ...base, trades: multiple.trades }
    );
    expect(edited).toMatchObject({ ok: true });
    if (edited.ok) {
      expect(edited.trades).toHaveLength(2);
      expect(edited.trade.currentTeamId).toBe("Team 3");
    }
  });

  it("uses traded ownership and skips completed keeper turns in forecasts", () => {
    const traded = upsertPickTrade(
      { round: 1, pickInRound: 2, currentTeamId: "Team 1" },
      base
    );
    if (!traded.ok) throw new Error("fixture failed");
    expect(
      findPicksUntilTeamTurn({
        currentPick: 1,
        teamId: "Team 1",
        draftOrder: base.draftOrder,
        isSnakeDraft: true,
        trades: traded.trades,
        maxPickNumber: 12
      })
    ).toBe(1);
    expect(
      findPicksUntilTeamTurn({
        currentPick: 1,
        teamId: "Team 1",
        draftOrder: base.draftOrder,
        isSnakeDraft: true,
        trades: traded.trades,
        completedPickNumbers: [2],
        maxPickNumber: 12
      })
    ).toBe(7);
  });

  it("uses exact custom reversed rounds for ownership, trades, and forecasts", () => {
    const orderPattern = { mode: "custom" as const, reversedRounds: [3] };
    expect(
      resolvePickOwner({
        round: 2,
        pickInRound: 1,
        draftOrder: base.draftOrder,
        orderPattern,
      }).currentTeamId,
    ).toBe("Team 1");
    expect(
      resolvePickOwner({
        round: 3,
        pickInRound: 1,
        draftOrder: base.draftOrder,
        orderPattern,
      }).currentTeamId,
    ).toBe("Team 4");

    const trade = upsertPickTrade(
      { round: 3, pickInRound: 1, currentTeamId: "Team 2" },
      { ...base, orderPattern, isSnakeDraft: undefined },
    );
    expect(trade).toMatchObject({
      ok: true,
      trade: { originalTeamId: "Team 4", currentTeamId: "Team 2" },
    });
    expect(
      findPicksUntilTeamTurn({
        currentPick: 4,
        teamId: "Team 4",
        draftOrder: base.draftOrder,
        orderPattern,
        maxPickNumber: 12,
      }),
    ).toBe(4);
  });

  it("skips future cells owned by teams whose rosters are full", () => {
    expect(
      findNextActionablePick({
        startPick: 1,
        maxPickNumber: 4,
        draftOrder: ["Team 1", "Team 2"],
        orderPattern: { mode: "standard", reversedRounds: [] },
        rosterCapacity: 1,
        teamRosterCounts: { "Team 1": 1 },
      }),
    ).toBe(2);
    expect(
      findNextActionablePick({
        startPick: 1,
        maxPickNumber: 4,
        draftOrder: ["Team 1", "Team 2"],
        orderPattern: { mode: "standard", reversedRounds: [] },
        rosterCapacity: 1,
        teamRosterCounts: { "Team 1": 1, "Team 2": 1 },
      }),
    ).toBe(5);
  });
});


describe("tier selection horizon", () => {
  const input = { draftOrder: ["A", "B", "C", "D"], isSnakeDraft: true, currentPick: 4, teamId: "D", onClock: true, maxPickNumber: 12, rosterCapacity: 3 };
  it("recognizes consecutive snake selections and previews off-clock selections", () => {
    expect(findSelectionHorizon(input)).toEqual({ currentPick: 4, targetPick: 5, opposingPicks: 0 });
    expect(findSelectionHorizon({ ...input, currentPick: 1, onClock: false })).toEqual({ currentPick: 1, targetPick: 4, opposingPicks: 3 });
  });
  it("never invents a final selection or a slot on a full roster", () => {
    expect(findSelectionHorizon({ ...input, currentPick: 12 })).toBeNull();
    expect(findSelectionHorizon({ ...input, teamRosterCounts: { D: 2 } })).toBeNull();
    expect(findSelectionHorizon({ ...input, draftOrder: [] })).toBeNull();
  });
  it("accounts for trades, keepers, completed selections and opponent capacity", () => {
    const trade = upsertPickTrade({ round: 2, pickInRound: 1, currentTeamId: "A" }, { draftOrder: input.draftOrder, roundCount: 3, isSnakeDraft: true });
    expect(trade.ok).toBe(true);
    if (!trade.ok) return;
    const result = findSelectionHorizon({ ...input, trades: trade.trades, completedPickNumbers: [6], teamRosterCounts: { B: 3 } });
    expect(result).toEqual({ currentPick: 4, targetPick: 12, opposingPicks: 4 });
    expect(findSelectionHorizon({ ...input, keepers: [{ version: KEEPER_CONTRACT_VERSION, playerId: "k", teamId: "D", cost: "pick", pickNumber: 5, round: 2, pickInRound: 1 } as any] })?.targetPick).toBe(12);
  });
});
