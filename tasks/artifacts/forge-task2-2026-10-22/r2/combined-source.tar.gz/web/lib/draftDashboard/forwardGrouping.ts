export type ForwardGrouping = "split" | "fwd";
export type RosterConfig = Record<string, number>;

export const FORWARD_GROUPING_STORAGE_KEY =
  "draftDashboard.forwardGrouping.v1";

type PreferenceStorage = Pick<Storage, "getItem" | "setItem">;

export function loadForwardGroupingPreference(
  storage: Pick<PreferenceStorage, "getItem">
): ForwardGrouping {
  try {
    return storage.getItem(FORWARD_GROUPING_STORAGE_KEY) === "fwd"
      ? "fwd"
      : "split";
  } catch {
    return "split";
  }
}

export function saveForwardGroupingPreference(
  storage: Pick<PreferenceStorage, "setItem">,
  grouping: ForwardGrouping
) {
  storage.setItem(FORWARD_GROUPING_STORAGE_KEY, grouping);
}

const FORWARD_POSITIONS = new Set(["C", "LW", "RW", "F", "FWD"]);

export function normalizePlayerEligibility(
  displayPosition?: string | null,
  eligiblePositions?: string[] | null
) {
  const source =
    Array.isArray(eligiblePositions) && eligiblePositions.length
      ? eligiblePositions
      : String(displayPosition ?? "").split(",");
  const output = new Set<string>();
  for (const raw of source) {
    const position = String(raw).trim().toUpperCase();
    if (position === "F" || position === "FWD") {
      output.add("C");
      output.add("LW");
      output.add("RW");
    } else if (["C", "LW", "RW", "D", "G"].includes(position)) {
      output.add(position);
    }
  }
  return Array.from(output);
}

export function groupPlayerEligibility(
  positions: string[],
  grouping: ForwardGrouping,
  includeGenericForward = false
) {
  if (grouping === "split") {
    const grouped = new Set(positions);
    if (
      includeGenericForward &&
      positions.some((position) => FORWARD_POSITIONS.has(position))
    ) {
      grouped.add("FWD");
    }
    return Array.from(grouped);
  }
  const grouped = new Set<string>();
  for (const position of positions) {
    if (FORWARD_POSITIONS.has(position)) grouped.add("FWD");
    else if (position === "D" || position === "G") grouped.add(position);
  }
  return Array.from(grouped);
}

export function getForwardRosterTotal(rosterConfig: RosterConfig) {
  if (Number.isFinite(rosterConfig.FWD)) return Math.max(0, rosterConfig.FWD);
  return ["C", "LW", "RW"].reduce(
    (sum, position) => sum + Math.max(0, Number(rosterConfig[position]) || 0),
    0
  );
}

export function getRosterPositions(
  grouping: ForwardGrouping,
  rosterConfig?: RosterConfig
) {
  if (grouping === "fwd") return ["FWD", "D", "G"];
  const positions = ["C", "LW", "RW", "D", "G"];
  if ((rosterConfig?.FWD ?? 0) > 0) positions.push("FWD");
  return positions;
}

export function getEffectiveRosterConfig(
  rosterConfig: RosterConfig,
  grouping: ForwardGrouping
): RosterConfig {
  if (grouping === "split") return { ...rosterConfig };
  const { C: _c, LW: _lw, RW: _rw, ...rest } = rosterConfig;
  return { ...rest, FWD: getForwardRosterTotal(rosterConfig) };
}

export function setForwardRosterTotal(
  rosterConfig: RosterConfig,
  requestedTotal: number
) {
  const total = Math.max(0, Math.round(requestedTotal));
  const current = ["C", "LW", "RW"].map(
    (position) => Math.max(0, Number(rosterConfig[position]) || 0)
  );
  const currentTotal = current.reduce((sum, value) => sum + value, 0);
  const basis = currentTotal > 0 ? current : [1, 1, 1];
  const basisTotal = basis.reduce((sum, value) => sum + value, 0);
  const exact = basis.map((value) => (value / basisTotal) * total);
  const distributed = exact.map(Math.floor);
  let remainder = total - distributed.reduce((sum, value) => sum + value, 0);
  exact
    .map((value, index) => ({ index, fraction: value - Math.floor(value) }))
    .sort((left, right) => right.fraction - left.fraction || left.index - right.index)
    .forEach(({ index }) => {
      if (remainder > 0) {
        distributed[index] += 1;
        remainder -= 1;
      }
    });
  return {
    ...rosterConfig,
    C: distributed[0],
    LW: distributed[1],
    RW: distributed[2]
  };
}

export function buildPositionPools(
  playerIds: Iterable<string>,
  values: ReadonlyMap<string, number>,
  eligibility: ReadonlyMap<string, string[]>,
  grouping: ForwardGrouping,
  rosterConfig?: RosterConfig
) {
  const pools: Record<string, Array<{ id: string; value: number }>> = {};
  for (const position of getRosterPositions(grouping, rosterConfig)) {
    pools[position] = [];
  }
  for (const id of playerIds) {
    const groupedPositions = groupPlayerEligibility(
      eligibility.get(id) ?? [],
      grouping
    );
    for (const position of groupedPositions) {
      if (!pools[position]) continue;
      pools[position].push({ id, value: values.get(id) ?? 0 });
    }
  }
  for (const pool of Object.values(pools)) {
    pool.sort((left, right) => right.value - left.value || left.id.localeCompare(right.id));
  }
  return pools;
}

export function allocateGroupedRosterSlots({
  players,
  rosterConfig,
  grouping,
  overrides = {}
}: {
  players: Array<{ id: string; eligibility: string[] }>;
  rosterConfig: RosterConfig;
  grouping: ForwardGrouping;
  overrides?: Record<string, string>;
}) {
  const effective = getEffectiveRosterConfig(rosterConfig, grouping);
  const includeGenericForward =
    grouping === "split" && (effective.FWD ?? 0) > 0;
  const positions = getRosterPositions(grouping, effective);
  const counts: Record<string, number> = Object.fromEntries([
    ...positions.map((position) => [position, 0] as const),
    ["UTILITY", 0],
    ["BENCH", 0]
  ]);
  const assignments: Record<string, string> = {};
  const occupants: Record<string, string[]> = Object.fromEntries(
    [...positions, "UTILITY", "BENCH"].map((position) => [position, []]),
  );

  const reserved = new Set<string>();
  for (const player of players) {
    const eligible = groupPlayerEligibility(player.eligibility, grouping, includeGenericForward);
    const override = overrides[player.id]?.trim().toUpperCase();
    if (!override || (override === "UTILITY" ? !eligible.length || eligible.includes("G") : !eligible.includes(override))) continue;
    const capacity = Math.max(0, Number(effective[override === "UTILITY" ? "utility" : override]) || 0);
    if ((counts[override] ?? 0) >= capacity) continue;
    counts[override] += 1;
    occupants[override].push(player.id);
    assignments[player.id] = override;
    reserved.add(player.id);
  }

  const place = (player: { id: string; eligibility: string[] }, blocked = new Set<string>(), relocating = false): boolean => {
    const eligible = groupPlayerEligibility(
      player.eligibility,
      grouping,
      includeGenericForward
    );
    const override = overrides[player.id]?.toUpperCase();
    const candidates = override && eligible.includes(override)
      ? [override, ...eligible.filter((position) => position !== override)]
      : eligible;
    const canUse = (position: string) =>
      eligible.includes(position) &&
      counts[position] < Math.max(0, Number(effective[position]) || 0);
    for (const position of candidates) {
      if (blocked.has(position)) continue;
      if (canUse(position)) {
        counts[position] += 1;
        occupants[position].push(player.id);
        assignments[player.id] = position;
        return true;
      }
    }
    for (const position of candidates) {
      if (blocked.has(position)) continue;
      for (const currentOccupant of [...(occupants[position] ?? [])].reverse()) {
        if (reserved.has(currentOccupant)) continue;
        const occupiedPosition = assignments[currentOccupant];
        const occupiedPlayer = players.find((candidate) => candidate.id === currentOccupant);
        if (!occupiedPlayer || !occupiedPosition) continue;
        const occupantIndex = occupants[position].indexOf(currentOccupant);
        occupants[position].splice(occupantIndex, 1);
        counts[position] -= 1;
        delete assignments[currentOccupant];
        if (place(occupiedPlayer, new Set([...blocked, position]), true)) {
          counts[position] += 1;
          occupants[position].push(player.id);
          assignments[player.id] = position;
          return true;
        }
        counts[position] += 1;
        occupants[position].splice(occupantIndex, 0, currentOccupant);
        assignments[currentOccupant] = occupiedPosition;
      }
    }
    if (relocating) return false;
    if (!eligible.includes("G") && counts.UTILITY < Math.max(0, Number(effective.utility) || 0) && !blocked.has("UTILITY")) {
      counts.UTILITY += 1;
      occupants.UTILITY.push(player.id);
      assignments[player.id] = "UTILITY";
      return true;
    }
    counts.BENCH += 1;
    occupants.BENCH.push(player.id);
    assignments[player.id] = "BENCH";
    return true;
  };

  for (const player of players) if (!assignments[player.id]) place(player);
  return { assignments, counts, effectiveRosterConfig: effective };
}
