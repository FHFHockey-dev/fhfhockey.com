import type {
  ProjectionSourceConfig,
  SourceStatMapping
} from "lib/projectionsConfig/projectionSourcesConfig";
import { coerceSafeNumber } from "./csvImportValidation";
import { CSV_IDENTITY_COLUMNS } from "./csvImportContract";
import type { SessionCsvEntry } from "./csvImportSession";

export interface CustomAdditionalProjectionSource {
  id: string;
  displayName: string;
  playerType: "skater" | "goalie";
  rows: Array<Record<string, any>>;
  primaryPlayerIdKey: string;
  originalPlayerNameKey: string;
  teamKey?: string;
  positionKey?: string;
  statMappings: SourceStatMapping[];
  resolution?: {
    totalRows: number;
    idMatched: number;
    nameMatched: number;
    fuzzyMatched?: number;
    manualOverrides?: number;
    unresolved: number;
    invalidIds?: number;
    coverage: number;
    lastUpdated: number;
    unresolvedNames: string[];
  };
}

function stableSerialize(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableSerialize).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableSerialize(record[key])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

/**
 * Captures every input that changes how an in-memory projection source is
 * processed. Row contents are included so same-length edits cannot reuse a
 * stale source-input cache.
 */
export function buildCustomProjectionSourcesFingerprint(
  sources: CustomAdditionalProjectionSource[]
): string {
  return stableSerialize(
    sources.map((source) => ({
      id: source.id,
      displayName: source.displayName,
      playerType: source.playerType,
      rows: source.rows,
      primaryPlayerIdKey: source.primaryPlayerIdKey,
      originalPlayerNameKey: source.originalPlayerNameKey,
      teamKey: source.teamKey,
      positionKey: source.positionKey,
      statMappings: source.statMappings,
      resolution: source.resolution
    }))
  );
}

export function buildCustomProjectionSources(
  entries: readonly SessionCsvEntry[],
  playerType: "skater" | "goalie",
  statMappings: SourceStatMapping[],
): CustomAdditionalProjectionSource[] {
  return entries.flatMap((entry) => {
    if (entry.playerType && entry.playerType !== "both" && entry.playerType !== playerType) return [];
    const rows = (entry.rows || []).map((raw): Record<string, any> => {
      const row = Object.fromEntries(Object.entries(raw).map(([key, value]) => [
        key, (CSV_IDENTITY_COLUMNS as readonly string[]).includes(key) ? value : coerceSafeNumber(value) ?? value,
      ]));
      return { ...row, Ga: row.Goals_Against_Goalie ?? row.Ga, Sa: row.Shots_Against ?? row.Sa, Otl: row.Overtime_Losses_Goalie ?? row.Otl, Games_Played: row.Games_Played ?? row.Games_Started_Goalie };
    }).filter((row) => {
      const positions = String(row.Position || "")
        .toUpperCase()
        .split(",")
        .map((position) => position.trim());
      return playerType === "goalie" ? positions.includes("G") : !positions.includes("G");
    });
    if (!rows.length) return [];
    return [{
      id: entry.id,
      displayName: entry.label || entry.id,
      playerType,
      rows,
      primaryPlayerIdKey: "player_id",
      originalPlayerNameKey: "Player_Name",
      teamKey: "Team_Abbreviation",
      positionKey: "Position",
      statMappings,
      resolution: entry.resolution,
    }];
  });
}

export function buildActiveProjectionSources({
  baseSources,
  playerType,
  sourceControls,
  customSources = []
}: {
  baseSources: ProjectionSourceConfig[];
  playerType: "skater" | "goalie";
  sourceControls: Record<string, { isSelected: boolean; weight: number }>;
  customSources?: CustomAdditionalProjectionSource[];
}) {
  const activeSources = baseSources.filter(
    (source) =>
      source.playerType === playerType && sourceControls[source.id]?.isSelected
  );
  const customById = new Map<string, CustomAdditionalProjectionSource>();

  for (const source of customSources) {
    if (!source.id.startsWith("custom_csv")) continue;
    customById.set(source.id, source);
  }

  for (const source of customById.values()) {
    if (
      source.playerType !== playerType ||
      !sourceControls[source.id]?.isSelected
    ) {
      continue;
    }
    activeSources.push({
      id: source.id,
      displayName: source.displayName,
      tableName: "__custom_session__",
      playerType: source.playerType,
      primaryPlayerIdKey: source.primaryPlayerIdKey,
      originalPlayerNameKey: source.originalPlayerNameKey,
      teamKey: source.teamKey,
      positionKey: source.positionKey,
      statMappings: source.statMappings
    });
  }

  return { activeSources, customById };
}

export function buildProjectionInputCacheKey({
  playerType,
  activeSources,
  season,
  customFingerprint,
  refreshKey
}: {
  playerType: "skater" | "goalie";
  activeSources: ProjectionSourceConfig[];
  season?: string;
  customFingerprint: string;
  refreshKey?: number | string;
}) {
  return JSON.stringify({
    playerType,
    sourceIds: activeSources.map((source) => source.id).sort(),
    season: season || "",
    custom: customFingerprint,
    refreshKey: refreshKey ?? ""
  });
}
