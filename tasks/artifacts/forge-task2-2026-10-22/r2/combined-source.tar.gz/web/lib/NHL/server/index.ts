// C:\Users\timbr\Desktop\FHFH\fhfhockey.com-3\web\lib\NHL\server\index.ts

import { differenceInYears } from "date-fns";
import type { SupabaseClient } from "@supabase/supabase-js";
import { get, restGet } from "lib/NHL/base";
import {
  Boxscore,
  DAYS,
  DAY_ABBREVIATION,
  Player,
  PlayerGameLog,
  ScheduleData,
  Season,
  Team,
  GameData,
} from "lib/NHL/types";
import supabase from "lib/supabase/public-client";
import { activeTeamAbbreviations, teamsInfo } from "lib/teamsInfo";
import { normalizeDependencyError } from "lib/cron/normalizeDependencyError";
import type { Database, Tables } from "lib/supabase/database-generated.types";

function buildStaticTeamsFallback(): Team[] {
  return (
    Object.entries(teamsInfo) as Array<
      [keyof typeof teamsInfo, (typeof teamsInfo)[keyof typeof teamsInfo]]
    >
  )
    .map(([abbr, info]) => {
      const abbreviation = info.abbrev ?? String(abbr);
      return {
        id: info.id,
        name: info.name,
        abbreviation,
        logo: getTeamLogo(abbreviation),
      };
    })
    .sort((a, b) => a.id - b.id);
}

export type GetTeamsMode = "current-canonical" | "season-exact";

export type GetTeamsOptions = {
  mode?: GetTeamsMode;
};

export function isValidNhlSeasonId(seasonId: number): boolean {
  if (!Number.isSafeInteger(seasonId)) return false;

  const value = String(seasonId);
  if (!/^\d{8}$/.test(value)) return false;

  const startYear = Number(value.slice(0, 4));
  const endYear = Number(value.slice(4));
  return endYear === startYear + 1;
}

export type CanonicalTeamLineage = {
  id: number;
  abbreviation: keyof typeof teamsInfo;
};

export function resolveCanonicalTeamLineage(
  teamId: number,
  abbreviation: string,
): CanonicalTeamLineage | null {
  if (
    (teamId === 53 && abbreviation === "ARI") ||
    (teamId === 59 && abbreviation === "UTA") ||
    (teamId === 68 && abbreviation === "UTA")
  ) {
    return { id: 68, abbreviation: "UTA" };
  }

  const abbreviationKey = abbreviation as keyof typeof teamsInfo;
  if (!activeTeamAbbreviations.has(abbreviationKey)) return null;

  const team = teamsInfo[abbreviationKey];
  if (team.id !== teamId) return null;
  return { id: team.id, abbreviation: abbreviationKey };
}

export async function getPlayerGameLog(
  id: number | string,
  seasonId: number | string,
  gameType: number | string = 2,
): Promise<PlayerGameLog[]> {
  try {
    const data =
      (await get(`/player/${id}/game-log/${seasonId}/${gameType}`)).gameLog ??
      [];
    return data;
  } catch (e: any) {
    console.error("Cannot find the game log for player " + id);
    return [];
  }
}

/**
 * Server only
 * @param id
 * @returns
 */
export async function getPlayer(id: number): Promise<Player> {
  const { data } = await supabase
    .from("rosters")
    .select("teamId, sweaterNumber, players(*), teams(name,abbreviation)")
    .eq("playerId", id)
    .eq("is_current", true)
    .order("seasonId", { ascending: false })
    .limit(1)
    .maybeSingle()
    .throwOnError();
  if (data === null) {
    throw new Error("Unable to find the player. " + id);
  }
  return {
    sweaterNumber: data.sweaterNumber,
    teamId: data.teamId,
    teamName: data.teams?.name,
    teamAbbreviation: data.teams?.abbreviation,
    age: differenceInYears(new Date(), new Date(data.players?.birthDate ?? "")),
    ...data.players,
  } as Player;
}

/**
 * Server only
 * @returns
 */
export async function getTeams(
  seasonId?: number,
  options: GetTeamsOptions = {},
): Promise<Team[]> {
  if (seasonId !== undefined && !isValidNhlSeasonId(seasonId)) {
    throw new Error("A valid consecutive eight-digit season ID is required.");
  }

  const mode =
    options.mode ??
    (seasonId === undefined ? "current-canonical" : "season-exact");
  const resolvedSeasonId = seasonId ?? (await getCurrentSeason()).seasonId;

  if (!isValidNhlSeasonId(resolvedSeasonId)) {
    throw new Error("A valid consecutive eight-digit season ID is required.");
  }

  let teams: Tables<"teams">[];
  try {
    const result = (await supabase
      .from("teams")
      .select("id, name, abbreviation, team_season!inner()")
      .eq("team_season.seasonId", resolvedSeasonId)) as unknown as {
      data: Tables<"teams">[] | null;
      error?: unknown;
    };

    if (result.error) throw result.error;
    if (!Array.isArray(result.data)) throw new Error("Missing team rows");
    teams = result.data;
  } catch (error: unknown) {
    if (mode === "season-exact") throw error;

    const normalized = normalizeDependencyError(error);
    console.warn("Team lookup failed; falling back to static team catalog.", {
      seasonId: resolvedSeasonId,
      message: normalized.message,
      detail: normalized.detail,
    });
    return buildStaticTeamsFallback();
  }

  if (mode === "season-exact") {
    return teams
      .map((team) => ({
        id: team.id,
        name: team.name,
        abbreviation: team.abbreviation,
        logo: getTeamLogo(team.abbreviation),
      }))
      .sort((a, b) => a.id - b.id);
  }

  const canonical = new Map<number, Team>();

  for (const team of teams) {
    const lineage = resolveCanonicalTeamLineage(team.id, team.abbreviation);
    if (!lineage) continue;

    const abbr = lineage.abbreviation;
    const info = teamsInfo[abbr];
    const canonicalId = lineage.id;
    const abbreviation = info.abbrev ?? String(abbr);
    const normalized: Team = {
      id: canonicalId,
      name: info.name,
      abbreviation,
      logo: getTeamLogo(abbreviation),
    };
    const existing = canonical.get(canonicalId);
    if (!existing || team.id === canonicalId) {
      canonical.set(canonicalId, normalized);
    }
  }

  for (const [abbr, info] of Object.entries(teamsInfo) as Array<
    [keyof typeof teamsInfo, (typeof teamsInfo)[keyof typeof teamsInfo]]
  >) {
    if (!canonical.has(info.id)) {
      const abbreviation = info.abbrev ?? String(abbr);
      canonical.set(info.id, {
        id: info.id,
        name: info.name,
        abbreviation,
        logo: getTeamLogo(abbreviation),
      });
    }
  }

  return Array.from(canonical.values()).sort((a, b) => a.id - b.id);
}

export function getTeamLogo(teamAbbreviation: string | undefined) {
  return teamAbbreviation
    ? `/teamLogos/${teamAbbreviation}.png`
    : "/pictures/circle.png";
}

/**
 * Server only
 * @returns
 */
export async function getCurrentSeason(): Promise<Season> {
  const toSeason = (currentSeason: any, lastSeason: any): Season => ({
    seasonId: currentSeason.id,
    regularSeasonStartDate: currentSeason.startDate,
    regularSeasonEndDate: currentSeason.regularSeasonEndDate,
    seasonEndDate: currentSeason.endDate,
    numberOfGames: currentSeason.numberOfGames,
    lastSeasonId: lastSeason.id,
    lastRegularSeasonStartDate: lastSeason.startDate,
    lastRegularSeasonEndDate: lastSeason.regularSeasonEndDate,
    lastSeasonEndDate: lastSeason.endDate,
    lastNumberOfGames: lastSeason.numberOfGames,
    slice: function (arg0: number, arg1: number): string {
      return "";
    },
  });

  try {
    const { data, error } = await supabase
      .from("seasons")
      .select("*")
      .lte("startDate", new Date().toISOString()) // ensure season has started
      .order("startDate", { ascending: false })
      .limit(2);
    if (error) {
      throw error;
    }
    if (!data || data.length === 0) {
      throw new Error(
        "Cannot find the current season (no rows in seasons table).",
      );
    }

    const currentSeason = data[0];
    const lastSeason = data[1] ?? data[0];
    return toSeason(currentSeason, lastSeason);
  } catch (error: any) {
    const normalized = normalizeDependencyError(error);
    console.warn(
      "Primary season lookup failed; falling back to NHL season feed.",
      {
        message: normalized.message,
        detail: normalized.detail,
      },
    );
  }

  try {
    const { data } = await restGet<{
      id: number;
      startDate: string;
      regularSeasonEndDate: string;
      endDate: string;
      numberOfGames: number;
    }>("/season");
    const seasons = [...(data ?? [])].sort((a, b) => b.id - a.id);

    if (seasons.length === 0) {
      throw new Error("NHL season feed returned no rows.");
    }

    const now = new Date();
    const currentIndex = seasons.findIndex((season) => {
      const start = new Date(season.startDate);
      const end = new Date(season.regularSeasonEndDate || season.endDate);
      return start <= now && now <= end;
    });
    const startedIndex = seasons.findIndex(
      (season) => new Date(season.startDate) <= now,
    );
    const resolvedIndex =
      currentIndex !== -1
        ? currentIndex
        : startedIndex !== -1
          ? startedIndex
          : 0;
    const currentSeason = seasons[resolvedIndex];
    const lastSeason = seasons[resolvedIndex + 1] ?? currentSeason;

    return toSeason(currentSeason, lastSeason);
  } catch (fallbackError: any) {
    throw new Error(`Cannot fetch seasons: ${fallbackError.message}`);
  }
}

export type SeasonDetails = Pick<
  Tables<"seasons">,
  "id" | "startDate" | "regularSeasonEndDate" | "endDate" | "numberOfGames"
>;

const EXACT_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function toEndOfDayUtc(date: string): string {
  if (!EXACT_DATE_PATTERN.test(date)) {
    throw new Error("A valid date in YYYY-MM-DD format is required.");
  }

  const parsedDate = new Date(`${date}T00:00:00.000Z`);
  if (
    Number.isNaN(parsedDate.getTime()) ||
    parsedDate.toISOString().slice(0, 10) !== date
  ) {
    throw new Error("A valid date in YYYY-MM-DD format is required.");
  }

  return `${date}T23:59:59.999Z`;
}

export async function getLatestStartedSeasonForDate(
  date: string,
  client: SupabaseClient<Database> = supabase,
): Promise<SeasonDetails | null> {
  const endOfDayUtc = toEndOfDayUtc(date);
  const { data, error } = await client
    .from("seasons")
    .select("id,startDate,regularSeasonEndDate,endDate,numberOfGames")
    .lte("startDate", endOfDayUtc)
    .order("startDate", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function resolveLatestStartedSeasonIdForDate(
  date: string,
  client: SupabaseClient<Database> = supabase,
): Promise<number> {
  const season = await getLatestStartedSeasonForDate(date, client);
  const seasonId = Number(season?.id);
  if (!Number.isSafeInteger(seasonId) || seasonId <= 0) {
    throw new Error(`Unable to resolve season id for date=${date}`);
  }
  return seasonId;
}

export async function getSeasonById(
  seasonId: number,
  client: SupabaseClient<Database> = supabase,
): Promise<SeasonDetails | null> {
  if (!Number.isSafeInteger(seasonId) || seasonId <= 0) {
    throw new Error("A valid season ID is required.");
  }

  const { data, error } = await client
    .from("seasons")
    .select("id,startDate,regularSeasonEndDate,endDate,numberOfGames")
    .eq("id", seasonId)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function getSeasons(): Promise<Season[]> {
  const data = (await restGet(`/season`)).data.map((item) => ({
    seasonId: item.id,
    regularSeasonStartDate: item.startDate,
    regularSeasonEndDate: item.regularSeasonEndDate,
    seasonEndDate: item.endDate,
    numberOfGames: item.numberOfGames,
    lastSeasonId: item.id,
    lastRegularSeasonStartDate: item.startDate,
    lastRegularSeasonEndDate: item.regularSeasonEndDate,
    lastSeasonEndDate: item.endDate,
    lastNumberOfGames: item.numberOfGames,

    slice: function (arg0: number, arg1: number): string {
      return "";
    },
  }));
  return data;
}

export async function getAllPlayers(seasonId?: number): Promise<Player[]> {
  if (!seasonId) {
    seasonId = (await getCurrentSeason()).seasonId;
  }
  const { data } = await supabase
    .from("rosters")
    .select("sweaterNumber, players(*), teams(id, name,abbreviation)")
    .eq("seasonId", seasonId)
    .eq("is_current", true);

  // ADDED "ANY" TYPE TO player
  // 02/19/2024 10:23AM EST
  return data!.map((player: any) => ({
    ...player.players!,
    age: differenceInYears(
      new Date(),
      new Date(player.players?.birthDate ?? ""),
    ),
    sweaterNumber: player.sweaterNumber,
    teamId: player.teams?.id,
    teamAbbreviation: player.teams?.abbreviation,
    teamName: player.teams?.name,
  }));
}

type GameWeek = {
  date: string;
  dayAbbrev: DAY_ABBREVIATION;
  numberOfGames: number;
  games: {
    id: number;
    season: number;
    gameScheduleState?: string;
    gameState?: string;
    startTimeUTC?: string;
    venue?: string | { default?: string };
    awayTeam: {
      id: number;
      abbrev: string;
      score: number;
    };
    homeTeam: {
      id: number;
      abbrev: string;
      score: number;
    };
  }[];
}[];

/**
 *
 * @param startDate e.g., 2023-11-06
 * @returns
 */
export async function getSchedule(
  startDate: string,
  opts: { includeOdds?: boolean } = {},
) {
  const includeOdds = opts.includeOdds !== false;
  const { gameWeek } = await get<{ gameWeek: GameWeek }>(
    `/schedule/${startDate}`,
  );
  const TEAM_DAY_DATA: ScheduleData["data"] = {};
  const numGamesPerDay: number[] = [];
  const result = {
    data: TEAM_DAY_DATA,
    numGamesPerDay,
    coveredDates: gameWeek.map((day) => day.date),
    retrievedAt: new Date().toISOString(),
  };

  // Get number of games per day
  DAYS.forEach((item) => {
    numGamesPerDay.push(
      gameWeek.find((day) => day.dayAbbrev === item)?.numberOfGames ?? 0,
    );
  });

  const oddsByGameId: Record<number, any> = {};
  if (includeOdds) {
    // Collect all game IDs
    const gameIds: number[] = [];
    gameWeek.forEach((day) => {
      day.games.forEach((game) => {
        gameIds.push(game.id);
      });
    });

    // Fetch win odds from 'expected_goals' table
    const { data: oddsData, error } = await supabase
      .from("expected_goals")
      .select(
        "game_id, home_win_odds, away_win_odds, home_api_win_odds, away_api_win_odds",
      )
      .in("game_id", gameIds);

    if (error) {
      const normalized = normalizeDependencyError(error);
      console.warn("Win odds lookup failed; continuing without odds.", {
        message: normalized.message,
        detail: normalized.detail,
      });
    }

    // Map odds data by game_id
    (oddsData || []).forEach((item) => {
      oddsByGameId[item.game_id] = item;
    });
  }

  const tasksForOneWeek = gameWeek.map((day) => async () => {
    const tasksForOneDay = day.games.map((game) => async () => {
      const { homeTeam, awayTeam } = game;
      // Preserve the source schedule's team IDs, including relocated or newly
      // branded teams such as UTA 68. Client metadata can fall back through
      // teamsInfo/useTeamsMap without hiding either side of the game.

      // Fetch win odds from the oddsByGameId (optional)
      const odds = includeOdds ? oddsByGameId[game.id] : null;
      const homeWinOdds = odds?.home_win_odds ?? null;
      const awayWinOdds = odds?.away_win_odds ?? null;
      const homeApiWinOdds = odds?.home_api_win_odds ?? null;
      const awayApiWinOdds = odds?.away_api_win_odds ?? null;

      const derivedGameType = Math.floor(game.id / 10000) % 100;
      const gameData: GameData = {
        id: game.id,
        season: game.season,
        gameDate: day.date,
        gameScheduleState: game.gameScheduleState,
        gameState: game.gameState,
        startTimeUTC: game.startTimeUTC,
        venue: game.venue,
        gameType: derivedGameType,
        homeTeam: {
          id: homeTeam.id,
          score: homeTeam.score,
          winOdds: homeWinOdds,
          apiWinOdds: homeApiWinOdds,
        },
        awayTeam: {
          id: awayTeam.id,
          score: awayTeam.score,
          winOdds: awayWinOdds,
          apiWinOdds: awayApiWinOdds,
        },
      };

      if (!TEAM_DAY_DATA[homeTeam.id]) TEAM_DAY_DATA[homeTeam.id] = {};
      TEAM_DAY_DATA[homeTeam.id][day.dayAbbrev] = gameData;

      if (!TEAM_DAY_DATA[awayTeam.id]) TEAM_DAY_DATA[awayTeam.id] = {};
      TEAM_DAY_DATA[awayTeam.id][day.dayAbbrev] = gameData;
    });
    await Promise.all(tasksForOneDay.map((task) => task()));
  });

  await Promise.all(tasksForOneWeek.map((task) => task()));

  return result;
}

export async function getBoxscore(id: number): Promise<Boxscore> {
  const data = await get(`/gamecenter/${id}/boxscore`);
  return data;
}
