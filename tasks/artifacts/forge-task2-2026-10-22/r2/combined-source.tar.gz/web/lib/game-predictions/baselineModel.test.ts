import { describe, expect, it } from "vitest";

import type { BinaryLogisticModel } from "lib/xg/binaryLogistic";
import {
  BASELINE_FEATURE_KEYS,
  BASELINE_MODEL_VERSION,
  analyzeBaselineFeatureSignals,
  buildBaselineFeatureLeakageChecks,
  buildBaselineFeatureVector,
  buildBaselineTrainingDataset,
  buildGamePredictionHistoryInsert,
  buildGamePredictionOutputUpsert,
  getRecentTeamFormFeatureEligibility,
  explainBaselineModelPrediction,
  predictGameWithExtraTreesModel,
  predictGameWithBaselineModel,
  trainGamePredictionExtraTreesModel,
  trainGamePredictionBaselineModel,
} from "./baselineModel";
import {
  buildGamePredictionFeatureSnapshotPayload,
  type GamePredictionFeatureInputs,
} from "./featureBuilder";
import {
  RECENT_TEAM_FORM_APPROVED_PUBLICATION_STATUS,
  RECENT_TEAM_FORM_FORMULA_VERSION,
  RECENT_TEAM_FORM_INPUT_VERSION,
} from "lib/trends/ctpi";

function createPayload(homeOffRating = 60) {
  const inputs: GamePredictionFeatureInputs = {
    game: {
      id: 2025020001,
      date: "2026-01-10",
      startTime: "2026-01-10T23:00:00+00:00",
      seasonId: 20252026,
      homeTeamId: 1,
      awayTeamId: 2,
      type: 2,
    },
    sourceAsOfDate: "2026-01-10",
    homeTeam: { id: 1, abbreviation: "BOS", name: "Boston Bruins" },
    awayTeam: { id: 2, abbreviation: "MTL", name: "Montreal Canadiens" },
    priorGames: [],
    teamPowerRows: [
      {
        team_abbreviation: "BOS",
        date: "2026-01-09",
        off_rating: homeOffRating,
        def_rating: 55,
        goalie_rating: 52,
        special_rating: 54,
        pace_rating: 49,
        xgf60: 3,
        xga60: 2.5,
        gf60: 3,
        ga60: 2.5,
        sf60: 31,
        sa60: 28,
      },
      {
        team_abbreviation: "MTL",
        date: "2026-01-09",
        off_rating: 48,
        def_rating: 50,
        goalie_rating: 49,
        special_rating: 47,
        pace_rating: 51,
        xgf60: 2.8,
        xga60: 3,
        gf60: 2.7,
        ga60: 3.1,
        sf60: 29,
        sa60: 32,
      },
    ],
    standingsRows: [
      {
        team_abbrev: "BOS",
        season_id: 20252026,
        date: "2026-01-09",
        games_played: 40,
        point_pctg: 0.62,
        win_pctg: 0.56,
        goal_differential: 20,
        l10_games_played: 10,
        l10_goal_differential: 5,
      },
      {
        team_abbrev: "MTL",
        season_id: 20252026,
        date: "2026-01-09",
        games_played: 40,
        point_pctg: 0.5,
        win_pctg: 0.45,
        goal_differential: -5,
        l10_games_played: 10,
        l10_goal_differential: -2,
      },
    ],
    wgoTeamRows: [],
    nstTeamGamelogRows: [],
    teamCtpiRows: [],
    goalieStartRows: [
      {
        game_id: 2025020001,
        team_id: 1,
        player_id: 100,
        game_date: "2026-01-10",
        start_probability: 1,
        confirmed_status: true,
        projected_gsaa_per_60: 0.3,
        created_at: "2026-01-10T14:00:00+00:00",
        updated_at: "2026-01-10T14:00:00+00:00",
      },
      {
        game_id: 2025020001,
        team_id: 2,
        player_id: 200,
        game_date: "2026-01-10",
        start_probability: 1,
        confirmed_status: true,
        projected_gsaa_per_60: -0.1,
        created_at: "2026-01-10T14:00:00+00:00",
        updated_at: "2026-01-10T14:00:00+00:00",
      },
    ],
    lineCombinationRows: [],
    linesCccRows: [],
    goaliePerformanceRows: [],
    forgeGoalieGameRows: [],
    wgoGoalieRows: [],
    forgeTeamProjectionRows: [],
  };

  return buildGamePredictionFeatureSnapshotPayload(inputs);
}

describe("game prediction baseline model", () => {
  it("records the approved-only CTPI reader boundary", () => {
    expect(
      buildBaselineFeatureLeakageChecks().find(
        (row) => row.featureKey === "homeMinusAwayCtpi",
      ),
    ).toMatchObject({
      status: "pass",
      sourceAsOfRule: "strict_before_game_date",
      reasons: [expect.stringContaining("explicitly approved")],
    });
  });

  it("excludes legacy snapshot CTPI until both teams carry approved provenance", () => {
    const payload = createPayload();
    payload.matchup.homeMinusAwayCtpi = 16;
    payload.home.ctpi = {
      sourceDate: "2026-01-09",
      computedAt: "2026-01-09T10:00:00.000Z",
      ctpi0To100: 64,
      ctpiRaw: 0.64,
      offense: 1,
      defense: 1,
      goaltending: 1,
      specialTeams: 1,
      luck: null,
    };
    payload.away.ctpi = {
      ...payload.home.ctpi,
      ctpi0To100: 48,
      ctpiRaw: 0.48,
    };

    const featureIndex = BASELINE_FEATURE_KEYS.indexOf("homeMinusAwayCtpi");
    expect(buildBaselineFeatureVector(payload)[featureIndex]).toBe(0);
    expect(getRecentTeamFormFeatureEligibility(payload)).toMatchObject({
      eligible: false,
      reason: "unapproved_or_unversioned_pair",
    });

    for (const teamForm of [payload.home.ctpi, payload.away.ctpi]) {
      Object.assign(teamForm!, {
        publicationStatus: RECENT_TEAM_FORM_APPROVED_PUBLICATION_STATUS,
        formulaVersion: RECENT_TEAM_FORM_FORMULA_VERSION,
        inputVersion: RECENT_TEAM_FORM_INPUT_VERSION,
        sourceGameCount: 10,
      });
    }

    expect(buildBaselineFeatureVector(payload)[featureIndex]).toBe(0.16);
    expect(getRecentTeamFormFeatureEligibility(payload)).toMatchObject({
      eligible: true,
      reason: "approved_pair",
    });
  });

  it("builds finite baseline feature vectors", () => {
    const vector = buildBaselineFeatureVector(createPayload());
    const valueFor = (featureKey: (typeof BASELINE_FEATURE_KEYS)[number]) =>
      vector[BASELINE_FEATURE_KEYS.indexOf(featureKey)];

    expect(vector).toHaveLength(BASELINE_FEATURE_KEYS.length);
    expect(valueFor("homeMinusAwayOffRating")).toBe(12);
    expect(valueFor("homeMinusAwayDefRating")).toBe(5);
    expect(valueFor("homeMinusAwayGoalieRating")).toBe(3);
    expect(valueFor("homeMinusAwaySpecialRating")).toBe(7);
    expect(valueFor("homeMinusAwayPointPctg")).toBe(0.12);
    expect(valueFor("homeMinusAwayGoalDifferential")).toBe(0.5);
    expect(valueFor("homeMinusAwayRecent20ShotShare")).toBe(0);
    expect(valueFor("homeMinusAwayRecent40ShotShare")).toBe(0);
    expect(valueFor("homeMinusAwayWeightedGoalieGsaaPer60")).toBe(0.4);
  });

  it("explains present zero-weight, masked, missing, rejected and genuine zero inputs using the supplied artifact", () => {
    const payload = createPayload();
    payload.matchup.homeMinusAwayOffRating = 0;
    payload.matchup.homeMinusAwayDefRating = null;
    payload.matchup.homeMinusAwayRosterOffImpact = 1.2;
    payload.matchup.homeMinusAwayCtpi = 16;
    const model = { featureCount: BASELINE_FEATURE_KEYS.length, weights: BASELINE_FEATURE_KEYS.map(() => 0), bias: 0.25,
      featureNormalization: { means: BASELINE_FEATURE_KEYS.map(() => 1), scales: BASELINE_FEATURE_KEYS.map(() => 2) } };
    model.weights[BASELINE_FEATURE_KEYS.indexOf("homeMinusAwayRosterOffImpact")] = 2;
    const args = { payload, model, predictionCutoffAt: payload.predictionCutoffAt! };
    const explanation = explainBaselineModelPrediction(args);
    const feature = (key: string) => explanation.features.find(row => row.featureKey === key)!;
    expect(feature("homeMinusAwayOffRating")).toMatchObject({ inputPresent: true, rawValue: 0, fallback: null, coefficient: 0, scoreContribution: 0 });
    expect(feature("homeMinusAwayDefRating")).toMatchObject({ inputPresent: false, fallback: "missing_to_zero" });
    expect(feature("homeMinusAwayCtpi")).toMatchObject({ inputPresent: true, featureEligibility: "rejected", fallback: "rejected_to_zero", transformedValue: 0 });
    expect(feature("homeMinusAwayRosterOffImpact")).toMatchObject({ inputPresent: true, policyActive: false, transformedValue: 0, normalizedValue: -0.5, coefficient: 2, scoreContribution: -1 });
    const prediction = predictGameWithBaselineModel(args);
    expect(explanation.rawHomeWinProbability).toBe(prediction.components.raw_home_win_probability);
    expect(explanation.adjustments.homeWinProbability).toBe(prediction.homeWinProbability);
    expect(explanation.adjustments.dataQualityPenalties).toEqual(prediction.components.data_quality_penalties);
    expect(explanation.score).toBe(-0.75);
  });

  it("keeps unused trailing features separate and rejects incomplete influence artifacts", () => {
    const args = { payload: createPayload(), predictionCutoffAt: "2026-01-10T11:45:00Z", model: { featureCount: 1, weights: [0.1], bias: 0 } };
    expect(explainBaselineModelPrediction(args).features[1]).toMatchObject({ selectedByModel: false, coefficient: null, normalizedValue: null, scoreContribution: 0 });
    expect(() => explainBaselineModelPrediction({ ...args, model: { ...args.model, weights: [] } })).toThrow("selected logistic artifact");
  });

  it("keeps roster/form candidates excluded by default and opt-in for ablations", () => {
    const payload = createPayload();
    payload.matchup.homeMinusAwayRosterOffImpact = 1.2;
    payload.matchup.homeMinusAwayWeightedRecent10GoalDifferentialPerGame = 0.9;
    const defaultVector = buildBaselineFeatureVector(payload);
    const candidateVector = buildBaselineFeatureVector(payload, {
      includeDefaultExcludedFeatureKeys: true,
    });
    const valueFor = (
      vector: number[],
      featureKey: (typeof BASELINE_FEATURE_KEYS)[number],
    ) => vector[BASELINE_FEATURE_KEYS.indexOf(featureKey)];

    expect(valueFor(defaultVector, "homeMinusAwayRosterOffImpact")).toBe(0);
    expect(
      valueFor(
        defaultVector,
        "homeMinusAwayWeightedRecent10GoalDifferentialPerGame",
      ),
    ).toBe(0);
    expect(valueFor(candidateVector, "homeMinusAwayRosterOffImpact")).toBe(1.2);
    expect(
      valueFor(
        candidateVector,
        "homeMinusAwayWeightedRecent10GoalDifferentialPerGame",
      ),
    ).toBe(0.3);
  });

  it("creates training examples from feature snapshots and outcomes", () => {
    const examples = buildBaselineTrainingDataset(
      [{ featureSnapshotId: "snapshot-1", payload: createPayload() }],
      [{ gameId: 2025020001, homeWon: true }],
    );

    expect(examples).toHaveLength(1);
    expect(examples[0]).toMatchObject({
      gameId: 2025020001,
      featureSnapshotId: "snapshot-1",
      label: 1,
    });
  });

  it("trains a regularized logistic baseline", () => {
    const winningPayload = createPayload(65);
    const losingPayload = createPayload(40);
    losingPayload.gameId = 2025020002;
    const examples = buildBaselineTrainingDataset(
      [
        { featureSnapshotId: "win", payload: winningPayload },
        { featureSnapshotId: "loss", payload: losingPayload },
      ],
      [
        { gameId: winningPayload.gameId, homeWon: true },
        { gameId: losingPayload.gameId, homeWon: false },
      ],
    );

    const model = trainGamePredictionBaselineModel(examples, {
      iterations: 5,
      learningRate: 0.01,
      l2: 0.01,
    });
    expect(model.featureCount).toBe(BASELINE_FEATURE_KEYS.length);
    expect(model.weights).toHaveLength(BASELINE_FEATURE_KEYS.length);
    expect(model.featureNormalization?.means).toHaveLength(
      BASELINE_FEATURE_KEYS.length,
    );
    expect(model.featureNormalization?.scales).toHaveLength(
      BASELINE_FEATURE_KEYS.length,
    );
    expect(model.probabilityFloor).toBe(0.05);
  });

  it("trains and predicts with the ExtraTrees candidate model", () => {
    const winningPayload = createPayload(75);
    const losingPayload = createPayload(35);
    losingPayload.gameId = 2025020002;
    const examples = buildBaselineTrainingDataset(
      [
        { featureSnapshotId: "win", payload: winningPayload },
        { featureSnapshotId: "loss", payload: losingPayload },
      ],
      [
        { gameId: winningPayload.gameId, homeWon: true },
        { gameId: losingPayload.gameId, homeWon: false },
      ],
      {
        includeDefaultExcludedFeatureKeys: true,
        excludedFeatureKeys: ["homeMarketNoVigProbability"],
      },
    );

    const model = trainGamePredictionExtraTreesModel(examples, {
      treeCount: 9,
      maxDepth: 3,
      minLeafExamples: 1,
      seed: 7,
    });
    const prediction = predictGameWithExtraTreesModel({
      payload: winningPayload,
      model,
      predictionCutoffAt: "2026-01-10T18:00:00+00:00",
      featureVectorOptions: {
        includeDefaultExcludedFeatureKeys: true,
        excludedFeatureKeys: ["homeMarketNoVigProbability"],
      },
    });
    const calibratedPrediction = predictGameWithExtraTreesModel({
      payload: winningPayload,
      model,
      predictionCutoffAt: "2026-01-10T18:00:00+00:00",
      calibrator: {
        method: "platt",
        model: { method: "raw" },
        predict: () => 0.6,
      },
      featureVectorOptions: {
        includeDefaultExcludedFeatureKeys: true,
        excludedFeatureKeys: ["homeMarketNoVigProbability"],
      },
    });

    expect(model.modelFamily).toBe("extra_trees");
    expect(model.trees).toHaveLength(9);
    expect(model.featureImportances).toHaveLength(BASELINE_FEATURE_KEYS.length);
    expect(prediction.homeWinProbability).toBeGreaterThan(0);
    expect(prediction.homeWinProbability).toBeLessThan(1);
    expect(prediction.components).toMatchObject({
      model_family: "extra_trees",
      calibration_method: "raw_extra_trees",
      market_edge_bucket: "no_market",
    });
    expect(prediction.metadata.market_edge_bucket).toBe("no_market");
    expect(calibratedPrediction.components).toMatchObject({
      calibration_method: "platt",
      calibrated_home_win_probability: 0.6,
    });
    expect(prediction.metadata.public_explanation_feature_keys).toEqual([]);
  });

  it("analyzes per-feature winning signal with standardized logistic weights", () => {
    const winningPayload = createPayload(75);
    const losingPayload = createPayload(35);
    losingPayload.gameId = 2025020002;
    const examples = buildBaselineTrainingDataset(
      [
        { featureSnapshotId: "win", payload: winningPayload },
        { featureSnapshotId: "loss", payload: losingPayload },
      ],
      [
        { gameId: winningPayload.gameId, homeWon: true },
        { gameId: losingPayload.gameId, homeWon: false },
      ],
    );

    const analysis = analyzeBaselineFeatureSignals(examples, {
      iterations: 20,
      learningRate: 0.05,
      l2: 0.01,
    });
    const offRatingSignal = analysis.signals.find(
      (signal) => signal.featureKey === "homeMinusAwayOffRating",
    );

    expect(analysis.sampleSize).toBe(2);
    expect(analysis.homeWins).toBe(1);
    expect(analysis.awayWins).toBe(1);
    expect(offRatingSignal?.pearsonCorrelation).toBeGreaterThan(0);
    expect(offRatingSignal?.mutualInformationScore).toBeGreaterThanOrEqual(0);
    expect(offRatingSignal?.univariateOddsRatioPerStdDev).toBeGreaterThan(1);
    expect(offRatingSignal?.multivariateOddsRatioPerStdDev).toBeGreaterThan(1);
    expect(
      analysis.leakageChecks.find(
        (check) => check.featureKey === "homeMinusAwayRecent20ShotShare",
      ),
    ).toMatchObject({
      status: "review",
      defaultExcluded: true,
    });
    expect(
      analysis.leakageChecks.find(
        (check) => check.featureKey === "homeMarketNoVigProbability",
      ),
    ).toMatchObject({
      status: "blocked_by_default",
      defaultExcluded: true,
    });
  });

  it("bounds extreme probabilities and records normalization metadata", () => {
    const winningPayload = createPayload(65);
    const losingPayload = createPayload(40);
    losingPayload.gameId = 2025020002;
    const examples = buildBaselineTrainingDataset(
      [
        { featureSnapshotId: "win", payload: winningPayload },
        { featureSnapshotId: "loss", payload: losingPayload },
      ],
      [
        { gameId: winningPayload.gameId, homeWon: true },
        { gameId: losingPayload.gameId, homeWon: false },
      ],
    );
    const model = trainGamePredictionBaselineModel(examples, {
      iterations: 20,
      learningRate: 0.05,
      l2: 0.01,
    });

    const prediction = predictGameWithBaselineModel({
      payload: createPayload(1000),
      model: {
        ...model,
        weights: model.weights.map(() => 100),
        bias: 100,
      },
      predictionCutoffAt: "2026-01-10T18:00:00+00:00",
    });

    expect(prediction.homeWinProbability).toBeLessThanOrEqual(0.95);
    expect(prediction.homeWinProbability).toBeGreaterThan(0.75);
    expect(prediction.components.normalization_method).toBe(
      "training_set_standard_score",
    );
    expect(prediction.components.probability_floor).toBe(0.05);
    expect(prediction.components.market_edge_bucket).toBe("no_market");
    expect(prediction.metadata.market_edge_bucket).toBe("no_market");
  });

  it("dampens confidence when source quality is weaker", () => {
    const model: BinaryLogisticModel = {
      featureCount: 17,
      weights: [
        0.12, 0.08, 0.04, 0.04, 0.4, 0.2, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02,
        0.02, 0.02, 0.02, 0.1, 0.05,
      ],
      bias: 0,
    };
    const cleanPayload = createPayload(65);
    const weakerPayload = {
      ...createPayload(65),
      sourceAsOfDate: "2026-01-03",
      missingFeatures: [
        ...cleanPayload.missingFeatures,
        "home.goalie_start_projection",
        "away.goalie_start_projection",
      ],
      sourceCutoffs: [
        {
          table: "team_power_ratings_daily",
          cutoff: "2025-12-15",
          asOfRule: "strict_before_source_as_of_date",
          stale: true,
        },
      ],
      home: {
        ...cleanPayload.home,
        lineup: null,
        goalie: {
          ...cleanPayload.home.goalie,
          source: "fallback" as const,
          confirmed: false,
        },
      },
      away: {
        ...cleanPayload.away,
        lineup: null,
        goalie: {
          ...cleanPayload.away.goalie,
          source: "fallback" as const,
          confirmed: false,
        },
      },
    };

    const clean = predictGameWithBaselineModel({
      payload: cleanPayload,
      model,
      predictionCutoffAt: "2026-01-10T18:00:00+00:00",
    });
    const weaker = predictGameWithBaselineModel({
      payload: weakerPayload,
      model,
      predictionCutoffAt: "2026-01-10T18:00:00+00:00",
    });

    expect(Math.abs(weaker.homeWinProbability - 0.5)).toBeLessThan(
      Math.abs(clean.homeWinProbability - 0.5),
    );
    expect(Number(weaker.components.data_quality_multiplier)).toBeLessThan(1);
    expect(weaker.components.data_quality_penalties).toMatchObject({
      goalie_fallback: 0.12,
    });
  });

  it("generates probability-consistent prediction payloads and persistence rows", () => {
    const model: BinaryLogisticModel = {
      featureCount: 17,
      weights: [
        0.02, 0.01, 0.03, 0.01, 0.4, 0.2, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02,
        0.02, 0.02, 0.02, 0.3, 0.05,
      ],
      bias: 0,
    };
    const prediction = predictGameWithBaselineModel({
      payload: createPayload(),
      model,
      predictionCutoffAt: "2026-01-10T18:00:00+00:00",
    });

    expect(
      prediction.homeWinProbability + prediction.awayWinProbability,
    ).toBeCloseTo(1);
    expect(prediction.predictedWinnerTeamId).toBe(1);
    expect(prediction.topFactors.length).toBeGreaterThan(0);
    expect(prediction.components).toMatchObject({
      threshold_50_predicted_winner_team_id: 1,
      selected_threshold_predicted_winner_team_id: 1,
      model_audit: {
        winnerPolicyVersion:
          "winner_policy_v1_report_50_and_selected_threshold",
        rosterImpactVersion: "forge_team_projection_proxy_v1",
        strengthOfScheduleVersion: "past_opponent_power_v1",
        seasonDecayVersion: "none",
        probabilityBlendVersion: "none",
      },
    });

    expect(
      buildGamePredictionHistoryInsert({
        prediction,
        featureSnapshotId: "11111111-1111-1111-1111-111111111111",
      }),
    ).toMatchObject({
      game_id: 2025020001,
      feature_snapshot_id: "11111111-1111-1111-1111-111111111111",
      home_team_id: 1,
      away_team_id: 2,
      prediction_scope: "pregame",
    });

    expect(buildGamePredictionOutputUpsert(prediction)).toMatchObject({
      game_id: 2025020001,
      model_name: "nhl_game_baseline_logistic",
      model_version: BASELINE_MODEL_VERSION,
      prediction_scope: "pregame",
    });
  });
});
