import fs from "fs";
import { describe, expect, it, vi } from "vitest";

import {
  aggregateSeasonGames,
  evaluatePortableSeasonGame,
  mergeAdvancedSeasonArtifact,
  type AdvancedSeasonArtifact,
  type PortableSeasonArtifact,
} from "./evaluator";
import {
  FANTASY_PROJECTION_CONTRACT_CHECKSUM,
  FANTASY_PROJECTION_CONTRACT_VERSION,
  FANTASY_PROJECTION_SUMMARY_ENCODING,
  FANTASY_PROJECTION_V4_CONTRACT_CHECKSUM,
  FANTASY_PROJECTION_V4_CONTRACT_VERSION,
  FANTASY_PROJECTION_V5_CONTRACT_CHECKSUM,
  FANTASY_PROJECTION_V5_CONTRACT_VERSION,
  expandFantasyProjectionSummary,
  fantasyProjectionTotal,
  reconcileProjectionQuantiles,
  reconcileProjectionValues,
  SKATER_PRIMITIVE_TARGETS,
} from "./contracts";
import { validateSeasonDraft } from "./validation";
import {
  allocateSeasonTotalAdjustment,
  scoreSeasonPrimitive,
} from "./settlement";
import {
  parseOfficialNhlPlayerEvidence,
  planSeasonIdentityResolution,
  persistSeasonIdentityResolution,
  searchSeasonIdentityCandidates,
} from "./identityResolution";
import {
  activePendingPlayerPoolReviews,
  assertSystemPublishableSeasonView,
  isPrimitiveOverrideTargetForPopulation,
} from "./admin";
import { releaseMatchesPublicContract } from "./queries";
import { resolveSeasonRosterConsensus } from "./rosterIntegrity";
import {
  applyPersistentPlayerAssumptions,
  buildRuntimeNewcomerPrior,
  prepareForecastCadence,
  type ForecastCadenceInput,
} from "./seasonJobs";
import {
  captureOfficialNhlTransactionAudit,
  findOfficialRosterAuditEvidence,
  OFFICIAL_TRANSACTION_AUDIT_URLS,
  parseOfficialNhlArticleCapture,
} from "./transactionAudit";
import { playerForecastEditorConfiguration } from "../../utils/playerForecastSeasonEditorOnlyMiddleware";

describe("approved forecast cadence preparation", () => {
  const fixture = (date = "2026-10-15", now = `${date}T12:00:00Z`): ForecastCadenceInput => ({
    date, now: new Date(now), requiredSources: ["overnight_results", "roster_schedule"],
    sources: ["overnight_results", "roster_schedule"].map(key => ({ key, date, status: "complete",
      revision: `${key}-r1`, completedAt: `${date}T11:30:00Z`, expectedItems: 12, completedItems: 12 })),
    games: [{ gameId: 2026020001, startsAt: `${date}T23:00:00Z` }], previous: [],
  });

  it.each([["2026-03-07", "13"], ["2026-03-08", "12"], ["2026-10-31", "12"], ["2026-11-01", "13"]])(
    "keeps morning issuance at 08:00 New York across DST on %s", (date, hour) => {
      const result = prepareForecastCadence(fixture(date, `${date}T${hour}:00:00Z`));
      expect(result.slots[0].dueAt).toBe(`${date}T${hour}:00:00.000Z`);
      expect(result.slots[0].action).toBe("enqueue");
      expect(result.activationApproved).toBe(false);
    });

  it("holds incomplete overnight sources even when their timestamps are fresh", () => {
    const input = fixture();
    input.sources[0].status = "partial";
    let morning = prepareForecastCadence(input).slots[0];
    expect(morning.action).toBe("hold");
    expect(morning.reasons).toContain("source_incomplete:overnight_results");
    input.sources[0].status = "complete";
    input.sources[0].expectedItems = null;
    expect(prepareForecastCadence(input).slots[0].action).toBe("hold");
    input.sources[0].expectedItems = 13;
    expect(prepareForecastCadence(input).slots[0].action).toBe("hold");
    input.sources[0].expectedItems = 12;
    input.now = new Date("2026-10-15T12:05:00Z");
    morning = prepareForecastCadence(input).slots[0];
    expect(morning.action).toBe("enqueue");
    expect(morning.late).toBe(true);
    expect(morning.dueAt).toBe("2026-10-15T12:00:00.000Z");
    expect(morning.decisionAsOf).toBe("2026-10-15T12:05:00.000Z");
  });

  it("plans the separate 18:45 revision for 19:00 puck drop and deduplicates successful baselines", () => {
    const input = fixture("2026-10-15", "2026-10-15T22:44:59Z");
    input.previous = [{ key: "morning:2026-10-15", status: "succeeded", attempts: 1 }];
    const before = prepareForecastCadence(input);
    expect(before.slots[0].reasons).toContain("slot_succeeded");
    expect(before.slots[1].dueAt).toBe("2026-10-15T22:45:00.000Z");
    expect(before.slots[1].reasons).toContain("not_due");
    input.now = new Date("2026-10-15T22:45:00Z");
    const revision = prepareForecastCadence(input).slots[1];
    expect(revision.action).toBe("enqueue");
    expect(revision.kind).toBe("news_revision");
    expect(revision.key).not.toBe(before.slots[0].key);
    input.now = new Date("2026-10-15T23:00:00Z");
    expect(prepareForecastCadence(input).slots[1].reasons).toContain("game_started");
  });

  it("recovers only failed slots within the finite attempt budget and holds unknown commits", () => {
    const input = fixture();
    input.previous = [{ key: "morning:2026-10-15", status: "failed", attempts: 2 }];
    expect(prepareForecastCadence(input).slots[0].action).toBe("recover_failed");
    input.previous[0].attempts = 3;
    expect(prepareForecastCadence(input).slots[0].reasons).toContain("recovery_exhausted");
    for (const status of ["pending", "running", "succeeded", "unknown"] as const) {
      input.previous[0] = { ...input.previous[0], status, attempts: 1 };
      expect(prepareForecastCadence(input).slots[0].action).toBe("hold");
    }
  });
});

describe("fantasy projection contracts", () => {
  it("reserves the opening release for an editor", () => {
    expect(() => assertSystemPublishableSeasonView("current")).not.toThrow();
    expect(() => assertSystemPublishableSeasonView("ros")).not.toThrow();
    expect(() => assertSystemPublishableSeasonView("opening")).toThrow(
      "PLAYER_FORECAST_SEASON_OPENING_REQUIRES_EDITOR",
    );
  });

  it("applies persistent roster and deployment assumptions without carrying stat edits", () => {
    const prior: PortableSeasonArtifact["players"][string] = {
      fhfhPlayerId: 10,
      population: "forward",
      position: "C",
      teamId: 1,
      poolStatus: "verified_active",
      playProbability: 0.9,
      conditionalRates: { GAMES_PLAYED: 1, GOALS: 0.4 },
      conditionalVariances: { GAMES_PLAYED: 0.1, GOALS: 0.3 },
      ratings: { offense: 70 },
      deployment: { mostLikelyRole: { forwardLine: 2 } },
    };
    const adjusted = applyPersistentPlayerAssumptions(prior, [
      { field_path: "player.teamId", override_value: 24 },
      { field_path: "player.position", override_value: "R" },
      { field_path: "ratings.offense", override_value: 82 },
      { field_path: "deployment.mostLikelyRole.forwardLine", override_value: 1 },
      { field_path: "stats.GOALS", override_value: 99 },
    ]);

    expect(adjusted).toMatchObject({
      teamId: 24,
      position: "R",
      ratings: { offense: 82 },
      deployment: { mostLikelyRole: { forwardLine: 1 } },
      conditionalRates: { GOALS: 0.4 },
    });
    expect(() => applyPersistentPlayerAssumptions(prior, [
      { field_path: "player.position", override_value: "G" },
    ])).toThrow("PLAYER_FORECAST_SEASON_POSITION_POPULATION_MISMATCH");
  });

  it("gives post-artifact rookie identities a deterministic conservative cohort prior", () => {
    const artifact = {
      schemaVersion: "player-forecast-season-artifact-v1",
      seasonId: 20262027,
      contractVersion: FANTASY_PROJECTION_V5_CONTRACT_VERSION,
      contractChecksum: FANTASY_PROJECTION_V5_CONTRACT_CHECKSUM,
      artifactVersion: "v5-test",
      featureSchemaVersion: "v5-test",
      trainingCutoffAt: "2026-04-16T23:59:59Z",
      codeVersion: "test",
      players: Object.fromEntries(
        [0.1, 0.2, 0.3, 0.4].map((playProbability, index) => [
          String(index + 1),
          {
            fhfhPlayerId: index + 1,
            population: "forward" as const,
            position: "C" as const,
            teamId: 1,
            poolStatus: "active_prospect",
            playProbability,
            conditionalRates: { GAMES_PLAYED: 1, GOALS: playProbability },
            baselineConditionalRates: { GAMES_PLAYED: 1, GOALS: playProbability },
            conditionalVariances: { GAMES_PLAYED: 0, GOALS: playProbability },
            ratings: { offense: 40 + index, defense: 50 + index },
            rookieProfile: { rookie: true },
            deployment: {},
            fallbackFlags: ["prior_based_projection"],
            primitiveTargets: ["GAMES_PLAYED", "GOALS"],
          },
        ]),
      ),
      teams: {},
    } satisfies PortableSeasonArtifact;
    const input = {
      artifact,
      fhfhPlayerId: 99,
      nhlPlayerId: 8489999,
      playerName: "New Prospect",
      position: "R" as const,
      teamId: 24,
      poolStatus: "active_prospect",
      rosterStatus: "prospect_reserve",
      rosterConfidence: 0.4,
    };

    const first = buildRuntimeNewcomerPrior(input);
    const second = buildRuntimeNewcomerPrior(input);

    expect(first).toEqual(second);
    expect(first).toMatchObject({
      fhfhPlayerId: 99,
      population: "forward",
      position: "R",
      teamId: 24,
      playProbability: 0.175,
      conditionalRates: { GOALS: 0.25 },
      conditionalVariances: { GOALS: 0.5625 },
      deployment: { mostLikelyRole: { forwardLine: 4 } },
      rookieProfile: {
        rookie: true,
        nhleMethod: "generic_population_prior_pending_next_artifact_freeze",
        fallback: "post_artifact_identity",
      },
    });
    expect(first.fallbackFlags).toEqual(expect.arrayContaining([
      "prior_based_projection",
      "runtime_new_identity_population_prior",
      "advanced_v5_runtime_population_prior",
    ]));
  });

  it("limits editorial primitive overrides to the selected player population", () => {
    expect(isPrimitiveOverrideTargetForPopulation("EXPECTED_GOALS", "forward")).toBe(true);
    expect(isPrimitiveOverrideTargetForPopulation("EXPECTED_GOALS", "defense")).toBe(true);
    expect(isPrimitiveOverrideTargetForPopulation("EXPECTED_GOALS", "goalie")).toBe(false);
    expect(
      isPrimitiveOverrideTargetForPopulation(
        "EXPECTED_GOALS_AGAINST_GOALIE",
        "goalie",
      ),
    ).toBe(true);
    expect(
      isPrimitiveOverrideTargetForPopulation(
        "EXPECTED_GOALS_AGAINST_GOALIE",
        "forward",
      ),
    ).toBe(false);
    expect(isPrimitiveOverrideTargetForPopulation("POINTS", "forward")).toBe(false);
  });

  it("keeps superseded contract releases out of the current public release list", () => {
    expect(releaseMatchesPublicContract({
      contract_version: FANTASY_PROJECTION_CONTRACT_VERSION,
      contract_checksum: FANTASY_PROJECTION_CONTRACT_CHECKSUM,
    })).toBe(true);
    expect(releaseMatchesPublicContract({
      contract_version: FANTASY_PROJECTION_CONTRACT_VERSION,
      contract_checksum: "superseded-checksum",
    })).toBe(false);
    expect(releaseMatchesPublicContract({
      contract_version: FANTASY_PROJECTION_V4_CONTRACT_VERSION,
      contract_checksum: FANTASY_PROJECTION_V4_CONTRACT_CHECKSUM,
    })).toBe(true);
  });

  it("automatically resolves only approved two-source roster consensus", () => {
    const automatic = resolveSeasonRosterConsensus({
      currentOrganizationTeamId: 14,
      observations: [
        {
          id: "landing",
          observationKind: "player_landing",
          organizationTeamId: 2,
          rosterStatus: "active_nhl",
          availableAt: "2026-08-18T10:00:00Z",
          confidence: 1,
        },
        {
          id: "transaction",
          observationKind: "official_transaction",
          organizationTeamId: 2,
          rosterStatus: "active_nhl",
          availableAt: "2026-08-18T11:00:00Z",
          confidence: 0.99,
        },
      ],
    });
    expect(automatic).toMatchObject({
      resolution: "automatic",
      organizationTeamId: 2,
      rosterStatus: "active_nhl",
      observationIds: ["landing", "transaction"],
    });

    const singleSource = resolveSeasonRosterConsensus({
      currentOrganizationTeamId: 14,
      observations: [{
        id: "landing-only",
        observationKind: "player_landing",
        organizationTeamId: 2,
        rosterStatus: "active_nhl",
        availableAt: "2026-08-18T10:00:00Z",
        confidence: 1,
      }],
    });
    expect(singleSource).toMatchObject({
      resolution: "review_required",
      organizationTeamId: 14,
      conflictType: "single_source",
    });
  });

  it("does not treat an offseason roster omission as release evidence", () => {
    const consensus = resolveSeasonRosterConsensus({
      currentOrganizationTeamId: 24,
      currentRosterStatus: "prospect_reserve",
      observations: [],
    });
    expect(consensus).toMatchObject({
      resolution: "review_required",
      organizationTeamId: 24,
      rosterStatus: "prospect_reserve",
    });
  });

  it("separates offseason organization consensus from active-roster status", () => {
    const consensus = resolveSeasonRosterConsensus({
      currentOrganizationTeamId: 24,
      currentRosterStatus: "prospect_reserve",
      observations: [
        {
          id: "organization-roster",
          observationKind: "official_roster",
          organizationTeamId: 24,
          rosterStatus: "unresolved",
          availableAt: "2026-08-19T10:00:00Z",
          confidence: 1,
        },
        {
          id: "player-landing",
          observationKind: "player_landing",
          organizationTeamId: 24,
          rosterStatus: "unresolved",
          availableAt: "2026-08-19T10:01:00Z",
          confidence: 1,
        },
      ],
    });
    expect(consensus).toMatchObject({
      resolution: "automatic",
      organizationTeamId: 24,
      rosterStatus: "prospect_reserve",
      conflictType: null,
    });
  });

  it("holds an organization match when official roster statuses conflict", () => {
    const consensus = resolveSeasonRosterConsensus({
      currentOrganizationTeamId: 24,
      currentRosterStatus: "prospect_reserve",
      observations: [
        {
          id: "landing",
          observationKind: "player_landing",
          organizationTeamId: 24,
          rosterStatus: "active_nhl",
          availableAt: "2026-08-19T10:00:00Z",
          confidence: 1,
        },
        {
          id: "transaction",
          observationKind: "official_transaction",
          organizationTeamId: 24,
          rosterStatus: "affiliate",
          availableAt: "2026-08-19T10:01:00Z",
          confidence: 1,
        },
      ],
    });
    expect(consensus).toMatchObject({
      resolution: "review_required",
      organizationTeamId: 24,
      rosterStatus: "prospect_reserve",
      conflictType: "status_disagreement",
    });
  });

  it("matches roster conflicts only to corroborating official NHL tracker evidence", () => {
    const capture = parseOfficialNhlArticleCapture(
      '<script type="application/ld&#x2B;json">' +
        JSON.stringify({
          articleBody:
            "## WASHINGTON CAPITALS Group 3 Unrestricted Free Agents: Jonny Brodzinski (signed: WSH). " +
            "**JUNE 29:** Utah Mammoth acquire forward Joshua Roy from the Montreal Canadiens.",
          datePublished: "2026-08-19T16:20:00Z",
        }) +
        "</script>",
      "https://www.nhl.com/news/topic/free-agency/free-agency-signings-nhl-2026-27",
    );
    expect(findOfficialRosterAuditEvidence({
      playerName: "Jonny Brodzinski",
      teamName: "Washington Capitals",
      teamAbbreviation: "WSH",
      captures: [capture],
    })).toMatchObject({ eventType: "signing" });
    expect(findOfficialRosterAuditEvidence({
      playerName: "Jonny Brodzinski",
      teamName: "New York Rangers",
      teamAbbreviation: "NYR",
      captures: [capture],
    })).toBeNull();
  });

  it("refreshes every official transaction tracker as one cutoff-bound audit", async () => {
    const fetchImpl = vi.fn(async (input: string | URL | Request) => ({
      ok: true,
      status: 200,
      text: async () =>
        '<script type="application/ld+json">' +
        JSON.stringify({
          articleBody: "Official NHL transaction tracker.",
          datePublished: "2026-06-16T12:00:00Z",
          dateModified: "2026-08-26T09:25:00Z",
        }) +
        "</script>",
      url: String(input),
    })) as unknown as typeof fetch;

    const result = await captureOfficialNhlTransactionAudit({
      fetchImpl,
      capturedAt: "2026-08-26T09:30:00Z",
    });

    expect(result.capturedAt).toBe("2026-08-26T09:30:00Z");
    expect(result.captures.map((capture) => capture.url)).toEqual(
      OFFICIAL_TRANSACTION_AUDIT_URLS,
    );
    expect(result.captures.every((capture) => /^[0-9a-f]{64}$/.test(capture.sourceHash)))
      .toBe(true);
    expect(fetchImpl).toHaveBeenCalledTimes(OFFICIAL_TRANSACTION_AUDIT_URLS.length);
  });

  it("does not advance official transaction coverage from a partial tracker capture", async () => {
    const fetchImpl = vi.fn(async (input: string | URL | Request) => ({
      ok: !String(input).includes("free-agency"),
      status: String(input).includes("free-agency") ? 503 : 200,
      text: async () =>
        '<script type="application/ld+json">' +
        JSON.stringify({ articleBody: "Official NHL transaction tracker." }) +
        "</script>",
    })) as unknown as typeof fetch;

    await expect(captureOfficialNhlTransactionAudit({ fetchImpl })).rejects.toThrow(
      "Official NHL source returned 503",
    );
  });

  it("decodes the compact all-player payload without losing sortable metrics", () => {
    const result = expandFantasyProjectionSummary({
      success: true,
      betaLabel: "beta",
      release: { id: "release-1" } as any,
      encoding: FANTASY_PROJECTION_SUMMARY_ENCODING,
      metricKeys: ["GAMES_PLAYED", "POINTS", "SHOTS"],
      players: [[
        10, 21, "COL", "Nathan MacKinnon", "C", "forward",
        "verified_active", "active_nhl", 1, "2026-08-18T12:00:00Z",
        0, 100, 0.9, [1, null, 1, null, null], 0, [], [81.9, 132.8, 409],
      ]],
    });
    expect(result.players[0]).toMatchObject({
      fhfhPlayerId: 10,
      expectedGames: 81.9,
      publishedValues: { GAMES_PLAYED: 81.9, POINTS: 132.8, SHOTS: 409 },
      deployment: { mostLikelyRole: { forwardLine: 1, powerPlayUnit: 1 } },
    });
  });

  it("merges checksum-verified v5 rates into the portable v4 runtime", () => {
    const base = {
      schemaVersion: "player-forecast-season-artifact-v1",
      seasonId: 20262027,
      contractVersion: FANTASY_PROJECTION_V4_CONTRACT_VERSION,
      contractChecksum: FANTASY_PROJECTION_V4_CONTRACT_CHECKSUM,
      artifactVersion: "v4-test",
      featureSchemaVersion: "v4-test",
      trainingCutoffAt: "2026-04-16T23:59:59Z",
      codeVersion: "test",
      players: {
        "10": {
          fhfhPlayerId: 10,
          population: "forward",
          position: "C",
          teamId: 1,
          playProbability: 0.8,
          conditionalRates: { GAMES_PLAYED: 1, PRIMARY_ASSISTS: 0.5 },
          baselineConditionalRates: { GAMES_PLAYED: 1, PRIMARY_ASSISTS: 0.4 },
          conditionalVariances: { GAMES_PLAYED: 0, PRIMARY_ASSISTS: 0.2 },
          ratings: {},
          deployment: {},
          primitiveTargets: ["GAMES_PLAYED", "PRIMARY_ASSISTS"],
        },
      },
      teams: {
        "1": { teamId: 1, offenseMultiplier: 1, defenseMultiplier: 1, paceMultiplier: 1, ratings: {} },
        "2": { teamId: 2, offenseMultiplier: 1, defenseMultiplier: 1, paceMultiplier: 1, ratings: {} },
      },
    } satisfies PortableSeasonArtifact;
    const advanced = {
      schemaVersion: "player-forecast-season-advanced-artifact-v1",
      seasonId: 20262027,
      contractVersion: FANTASY_PROJECTION_V5_CONTRACT_VERSION,
      contractChecksum: FANTASY_PROJECTION_V5_CONTRACT_CHECKSUM,
      artifactVersion: "v5-test",
      featureSchemaVersion: "v5-test",
      trainingCutoffAt: "2026-04-16T23:59:59Z",
      codeVersion: "test",
      baseV4ArtifactChecksum: "a".repeat(64),
      players: { "10": { fhfhPlayerId: 10, population: "forward", rates: { SHOT_ATTEMPTS: 4 } } },
      teams: { "1": { teamId: 1, rates: { TEAM_PACE: 61 } }, "2": { teamId: 2, rates: {} } },
      targetPolicies: {
        forward: {
          SHOT_ATTEMPTS: { baselineRate: 3, residual80PerGame: 2 },
          EXPECTED_PRIMARY_ASSISTS: { fallback: true },
        },
      },
    } satisfies AdvancedSeasonArtifact;
    const merged = mergeAdvancedSeasonArtifact(base, advanced);
    const result = evaluatePortableSeasonGame(merged, 10, {
      gameId: 1,
      scheduledStartAt: "2026-10-01T00:00:00Z",
      teamId: 1,
      opponentTeamId: 2,
      isHome: true,
    });
    expect(result.conditionalMeans.SHOT_ATTEMPTS).toBe(4);
    expect(result.unconditionalMeans.SHOT_ATTEMPTS).toBe(3.2);
    expect(result.conditionalMeans.EXPECTED_PRIMARY_ASSISTS).toBe(0.5);
    expect(merged.teams["1"].advancedRates?.TEAM_PACE).toBe(61);
    const second = evaluatePortableSeasonGame(merged, 10, {
      gameId: 2,
      scheduledStartAt: "2026-10-03T00:00:00Z",
      teamId: 1,
      opponentTeamId: 2,
      isHome: false,
    });
    const firstAggregate = aggregateSeasonGames([result, second]);
    const secondAggregate = aggregateSeasonGames([result, second]);
    expect(firstAggregate).toEqual(secondAggregate);
    expect(firstAggregate.quantiles.p90.GAMES_PLAYED).toBeLessThanOrEqual(2);
    expect(firstAggregate.quantiles.p10.SHOT_ATTEMPTS).toBeLessThanOrEqual(
      firstAggregate.quantiles.p50.SHOT_ATTEMPTS,
    );
    expect(firstAggregate.quantiles.p50.SHOT_ATTEMPTS).toBeLessThanOrEqual(
      firstAggregate.quantiles.p90.SHOT_ATTEMPTS,
    );
    expect(firstAggregate.quantiles.p50.GAMES_PLAYED).toBe(1.595495311);
    expect(firstAggregate.quantiles.p50.SHOT_ATTEMPTS).toBe(6.3010162613);
    expect(firstAggregate.quantiles.p50.EXPECTED_PRIMARY_ASSISTS).toBe(0.8010794892);
  });

  it("uses cross-bound interval arithmetic for rate metrics", () => {
    const quantiles = reconcileProjectionQuantiles({
      p10: { GAMES_PLAYED: 60, TOTAL_TOI: 900 * 60 },
      p50: { GAMES_PLAYED: 75, TOTAL_TOI: 1350 * 60 },
      p90: { GAMES_PLAYED: 84, TOTAL_TOI: 1764 * 60 },
    }, "forward");
    expect(quantiles.p10.TOI_PER_GAME).toBeLessThanOrEqual(quantiles.p50.TOI_PER_GAME);
    expect(quantiles.p50.TOI_PER_GAME).toBeLessThanOrEqual(quantiles.p90.TOI_PER_GAME);
    expect(quantiles.p50.TOI_PER_GAME).toBe(18 * 60);

    const sparseProspect = reconcileProjectionQuantiles({
      p10: { GAMES_PLAYED: 1, TOTAL_TOI: 60 * 60 },
      p50: { GAMES_PLAYED: 4, TOTAL_TOI: 4 * 60 * 60 },
      p90: { GAMES_PLAYED: 12, TOTAL_TOI: 12 * 65 * 60 },
    }, "forward");
    expect(sparseProspect.p90.TOI_PER_GAME).toBe(65 * 60);
  });

  it("coalesces repeated roster changes by player and view", () => {
    const migration = fs.readFileSync(
      "../supabase/migrations/20260818150256_player_forecast_season_v4_integrity.sql",
      "utf8",
    );
    expect(migration).toContain(":view:current:roster:player:");
    expect(migration).toContain(":view:ros:roster:player:");
    expect(migration).not.toContain(":departure:");
  });

  it("compacts covered season jobs without deleting their audit history", () => {
    const migration = fs.readFileSync(
      "../supabase/migrations/20260820014700_player_forecast_season_queue_compaction.sql",
      "utf8",
    );
    expect(migration).toContain("compact_player_forecast_season_queue");
    expect(migration).toContain("max(queue.source_high_watermark)");
    expect(migration).toContain("status = 'cancelled'");
    expect(migration).toContain("'allLeague', true");
    expect(migration).not.toMatch(/delete\s+from\s+public\.player_forecast_season_queue/i);
  });

  it("keeps raw hockey identities independent of fantasy scoring", () => {
    const values = reconcileProjectionValues(
      { GOALS: 20, PRIMARY_ASSISTS: 24, SECONDARY_ASSISTS: 16, PP_GOALS: 5, PP_ASSISTS: 9 },
      "forward",
    );
    expect(values.ASSISTS).toBe(40);
    expect(values.POINTS).toBe(60);
    expect(values.PP_POINTS).toBe(14);
    expect(fantasyProjectionTotal(values, { GOALS: 3, ASSISTS: 2 })).toBe(140);
  });

  it("keeps all-situations scoring authoritative and makes EV the strength residual", () => {
    const values = reconcileProjectionValues({
      GOALS: 0.6,
      PRIMARY_ASSISTS: 0.7,
      SECONDARY_ASSISTS: 0.3,
      EV_GOALS: 0.1,
      PP_GOALS: 0.15,
      SH_GOALS: 0.01,
      EMPTY_NET_GOALS: 0.04,
      EV_PRIMARY_ASSISTS: 0.1,
      PP_PRIMARY_ASSISTS: 0.2,
      SH_PRIMARY_ASSISTS: 0.01,
      EN_PRIMARY_ASSISTS: 0.04,
      EV_SECONDARY_ASSISTS: 0.1,
      PP_SECONDARY_ASSISTS: 0.08,
      SH_SECONDARY_ASSISTS: 0.01,
      EN_SECONDARY_ASSISTS: 0.01,
    }, "forward");
    expect(values.GOALS).toBe(0.6);
    expect(values.PRIMARY_ASSISTS).toBe(0.7);
    expect(values.SECONDARY_ASSISTS).toBe(0.3);
    expect(values.EV_GOALS).toBe(0.4);
    expect(values.EV_PRIMARY_ASSISTS).toBe(0.45);
    expect(values.EV_SECONDARY_ASSISTS).toBe(0.2);
    expect(values.POINTS).toBe(1.6);
  });

  it("requires exactly one editor UUID in production", () => {
    const first = "11111111-1111-4111-8111-111111111111";
    const second = "22222222-2222-4222-8222-222222222222";
    expect(playerForecastEditorConfiguration({ NODE_ENV: "production", PLAYER_FORECAST_EDITOR_USER_IDS: first }).valid).toBe(true);
    expect(playerForecastEditorConfiguration({ NODE_ENV: "production", PLAYER_FORECAST_EDITOR_USER_IDS: `${first},${second}` }).valid).toBe(false);
    expect(playerForecastEditorConfiguration({ NODE_ENV: "production" }).valid).toBe(false);
  });

  it("scores model and baseline losses and preserves aggregate editorial deltas", () => {
    const score = scoreSeasonPrimitive({
      actual: 1,
      forecast: 0.8,
      baselineForecast: 0.5,
      p10: 0,
      p90: 1,
      probability: true,
    });
    expect(score).toMatchObject({
      baselineAbsoluteError: 0.5,
      interval80Covered: true,
      skillIndex: 80,
    });
    expect(score.absoluteError).toBeCloseTo(0.2);
    expect(score.brier).toBeCloseTo(0.04);
    const adjusted = [1, 2, 3].map((modelGameForecast) =>
      allocateSeasonTotalAdjustment({
        modelGameForecast,
        modelRemainingTotal: 6,
        adjustmentDelta: 3,
        remainingGames: 3,
      }),
    );
    expect(adjusted.reduce((total, value) => total + value, 0)).toBe(9);
  });

  it("imports checksum-bound advanced-v5 outcomes for prospective accountability", () => {
    const importer = fs.readFileSync(
      "scripts/import-player-forecast-season-settlement.ts",
      "utf8",
    );
    expect(importer).toContain("FANTASY_PROJECTION_V5_CONTRACT_VERSION");
    expect(importer).toContain("SKATER_ADVANCED_V5_PRIMITIVE_TARGETS");
    expect(importer).toContain("GOALIE_ADVANCED_V5_PRIMITIVE_TARGETS");
    expect(importer).not.toContain(
      "Advanced-v5 settlement requires its dedicated outcome source batch.",
    );
  });

  it("validates nested deployment probability families and their sums", () => {
    const gamesPerTeam = Object.fromEntries(
      Array.from({ length: 32 }, (_, index) => [String(index + 1), 84]),
    );
    const rosterCounts = Object.fromEntries(
      Object.keys(gamesPerTeam).map((teamId) => [
        teamId,
        { forwards: 12, defensemen: 6, goalies: 2 },
      ]),
    );
    const primitives = Object.fromEntries(
      SKATER_PRIMITIVE_TARGETS.map((target) => [target, 0]),
    );
    const values = reconcileProjectionValues(primitives, "forward");
    const base = {
      contractVersion: FANTASY_PROJECTION_CONTRACT_VERSION,
      contractChecksum: FANTASY_PROJECTION_CONTRACT_CHECKSUM,
      scheduleGameCount: 1344,
      gamesPerTeam,
      rosterCounts,
      players: [{
        fhfhPlayerId: 1,
        teamId: 1,
        population: "forward" as const,
        expectedGames: 0,
        expectedStarts: null,
        modelValues: values,
        publishedValues: values,
        p10: values,
        p50: values,
        p90: values,
        deployment: {
          roleProbabilities: {
            forwardLine: { F1: 0.7, other: 0.3 },
            powerPlayUnit: { PP1: 0.6, other: 0.4 },
          },
        },
      }],
    };
    expect(validateSeasonDraft(base)).toEqual([]);
    const invalid = structuredClone(base);
    invalid.players[0].deployment.roleProbabilities.forwardLine = {
      F1: 0.7,
      other: 0.4,
    };
    expect(validateSeasonDraft(invalid)).toContainEqual(
      expect.objectContaining({ code: "role_probability_sum_invalid" }),
    );
  });

  it("normalizes checksum-bound official NHL evidence without fabricated fields", () => {
    const evidence = parseOfficialNhlPlayerEvidence(
      {
        playerId: 8481538,
        firstName: { default: "Judd" },
        lastName: { default: "Caulfield" },
        position: "R",
        birthDate: "2001-03-19",
        birthCity: { default: "Grand Forks" },
        birthCountry: "USA",
        heightInCentimeters: 191,
        weightInKilograms: 100,
        currentTeamId: 24,
        fullTeamName: { default: "Anaheim Ducks" },
        sweaterNumber: 36,
        headshot: "https://assets.nhle.com/player.png",
      },
      8481538,
      "2026-08-13T15:00:00.000Z",
    );
    expect(evidence).toMatchObject({
      nhlPlayerId: 8481538,
      firstName: "Judd",
      lastName: "Caulfield",
      currentTeamId: 24,
      birthDate: "2001-03-19",
    });
    expect(evidence.sourcePayloadHash).toMatch(/^[a-f0-9]{64}$/);
    expect(() =>
      parseOfficialNhlPlayerEvidence(
        { ...evidence, playerId: 1 },
        8481538,
      ),
    ).toThrow("incomplete or mismatched");
  });

  it("deduplicates exact-ID and fuzzy identity candidates and blocks conflicting NHL IDs", async () => {
    const rpc = vi.fn(async (_name: string, params: { p_query: string }) => ({
      data:
        params.p_query === "8481538"
          ? [{
              player_id: 10,
              canonical_name: "Judd Caulfield",
              birth_year: 2001,
              canonical_position: "R",
              current_organization_name: "Anaheim Ducks",
              current_organization_type: "nhl",
              lifecycle_status: "active_nhl",
              headshot_url: null,
              nhl_player_id: 8481538,
              match_kind: "external_id_exact",
              similarity_score: 1,
            }]
          : [
              {
                player_id: 10,
                canonical_name: "Judd Caulfield",
                birth_year: 2001,
                canonical_position: "R",
                current_organization_name: "Anaheim Ducks",
                current_organization_type: "nhl",
                lifecycle_status: "active_nhl",
                headshot_url: null,
                nhl_player_id: 8481538,
                match_kind: "canonical_exact",
                similarity_score: 1,
              },
              {
                player_id: 11,
                canonical_name: "Cole Caufield",
                birth_year: 2001,
                canonical_position: "R",
                current_organization_name: "Montreal Canadiens",
                current_organization_type: "nhl",
                lifecycle_status: "active_nhl",
                headshot_url: null,
                nhl_player_id: 8481600,
                match_kind: "fuzzy",
                similarity_score: 0.58,
              },
            ],
      error: null,
    }));
    const candidates = await searchSeasonIdentityCandidates({
      supabase: { rpc } as any,
      query: "Judd Caulfield",
      reviewNhlPlayerId: 8481538,
    });
    expect(candidates).toHaveLength(2);
    expect(candidates[0]).toMatchObject({
      fhfhPlayerId: 10,
      matchKind: "external_id_exact",
      mappingAllowed: true,
    });
    expect(candidates[1]).toMatchObject({
      fhfhPlayerId: 11,
      mappingAllowed: false,
    });
  });

  it("persists identity decisions only through the atomic service RPC", async () => {
    const rpc = vi.fn().mockResolvedValue({
      data: { reviewId: "resolved", resolutionStatus: "excluded" },
      error: null,
    });
    const result = await persistSeasonIdentityResolution({
      supabase: { rpc } as any,
      editorUserId: "11111111-1111-4111-8111-111111111111",
      reviewId: "22222222-2222-4222-8222-222222222222",
      action: "exclude",
      reason: "Official roster evidence was superseded.",
    });
    expect(result).toMatchObject({ resolutionStatus: "excluded" });
    expect(rpc).toHaveBeenCalledWith(
      "resolve_player_forecast_season_identity",
      expect.objectContaining({
        p_resolution_action: "exclude",
        p_official_player: null,
      }),
    );
  });

  it("plans conservative automatic identity resolutions from exact official evidence", () => {
    const review = {
      id: "review-1",
      seasonId: 20262027,
      nhlPlayerId: 8481538,
      rawPlayerName: "Judd Caulfield",
      teamId: 24,
      position: "R",
      issueCode: "official_roster_identity_unmapped",
    };
    const officialPlayer = {
      nhlPlayerId: 8481538,
      firstName: "Judd",
      lastName: "Caulfield",
      position: "R" as const,
      birthDate: "2001-03-19",
      birthCity: null,
      birthCountry: "USA",
      heightInCentimeters: 191,
      weightInKilograms: 93,
      currentTeamId: 24,
      teamName: "Anaheim Ducks",
      sweaterNumber: null,
      headshotUrl: null,
      sourceUrl: "https://api-web.nhle.com/v1/player/8481538/landing",
      observedAt: "2026-08-19T12:00:00Z",
      sourcePayloadHash: "a".repeat(64),
    };

    expect(planSeasonIdentityResolution({
      review,
      officialPlayer,
      identities: [],
    })).toMatchObject({
      action: "create_new",
      lifecycleStatus: "active_prospect",
    });
    expect(planSeasonIdentityResolution({
      review,
      officialPlayer,
      identities: [{
        fhfhPlayerId: 101,
        nhlPlayerId: null,
        canonicalName: "Judd Caulfield",
        birthDate: "2001-03-19",
        position: "R",
        verificationStatus: "provisional",
        mergedIntoId: null,
      }],
    })).toMatchObject({
      action: "map_existing",
      fhfhPlayerId: 101,
    });
    expect(planSeasonIdentityResolution({
      review: { ...review, teamId: 2 },
      officialPlayer,
      identities: [],
    })).toMatchObject({ action: "manual_review" });
  });

  it("removes superseded identity reviews from the unresolved editor list", () => {
    const pending = {
      id: "pending-judd",
      resolution_status: "pending",
      supersedes_id: null,
    };
    const mapped = {
      id: "mapped-judd",
      resolution_status: "mapped",
      supersedes_id: pending.id,
    };
    expect(activePendingPlayerPoolReviews([pending, mapped])).toEqual([]);
    expect(activePendingPlayerPoolReviews([pending])).toEqual([pending]);
  });
});

describe("portable season evaluator", () => {
  it("does not multiply player-specific rates by own-team offense twice", () => {
    const zeroRates = Object.fromEntries(
      SKATER_PRIMITIVE_TARGETS.map((target) => [target, 0]),
    );
    const artifact = {
      schemaVersion: "player-forecast-season-artifact-v1",
      seasonId: 20262027,
      contractVersion: FANTASY_PROJECTION_CONTRACT_VERSION,
      contractChecksum: FANTASY_PROJECTION_CONTRACT_CHECKSUM,
      artifactVersion: "test",
      featureSchemaVersion: "test",
      trainingCutoffAt: "2026-04-16T23:59:59Z",
      codeVersion: "test",
      players: {
        "10": {
          fhfhPlayerId: 10,
          population: "forward",
          position: "C",
          teamId: 1,
          playProbability: 1,
          conditionalRates: { ...zeroRates, GOALS: 0.5 },
          conditionalVariances: zeroRates,
          ratings: {},
          deployment: {},
        },
      },
      teams: {
        "1": {
          teamId: 1,
          offenseMultiplier: 1.3,
          defenseMultiplier: 1,
          paceMultiplier: 1,
          ratings: {},
        },
        "2": {
          teamId: 2,
          offenseMultiplier: 1,
          defenseMultiplier: 1,
          paceMultiplier: 1,
          ratings: {},
        },
      },
    } satisfies PortableSeasonArtifact;
    const result = evaluatePortableSeasonGame(artifact, 10, {
      gameId: 2026020001,
      scheduledStartAt: "2026-10-01T23:00:00Z",
      teamId: 1,
      opponentTeamId: 2,
      isHome: true,
    });
    expect(result.conditionalMeans.GOALS).toBe(0.5);
    expect(result.quantiles.p90.GAMES_PLAYED).toBeLessThanOrEqual(1);
  });

  it("applies selected home and back-to-back effects only to the candidate model", () => {
    const artifact = {
      schemaVersion: "player-forecast-season-artifact-v1",
      seasonId: 20262027,
      contractVersion: FANTASY_PROJECTION_CONTRACT_VERSION,
      contractChecksum: FANTASY_PROJECTION_CONTRACT_CHECKSUM,
      artifactVersion: "test",
      featureSchemaVersion: "test",
      trainingCutoffAt: "2026-04-16T23:59:59Z",
      codeVersion: "test",
      players: {
        "10": {
          fhfhPlayerId: 10,
          population: "forward",
          position: "C",
          teamId: 1,
          playProbability: 1,
          baselinePlayProbability: 1,
          conditionalRates: { GAMES_PLAYED: 1, GOALS: 0.5 },
          baselineConditionalRates: { GAMES_PLAYED: 1, GOALS: 0.4 },
          conditionalVariances: { GAMES_PLAYED: 0, GOALS: 0.2 },
          contextEffects: {
            GOALS: {
              selected: true,
              ageMultiplier: 1.02,
              backToBackMultiplier: 0.9,
              homeMultiplier: 1.1,
              awayMultiplier: 0.95,
            },
          },
          ratings: {},
          deployment: {},
          primitiveTargets: ["GAMES_PLAYED", "GOALS"],
        },
      },
      teams: {
        "1": { teamId: 1, offenseMultiplier: 1, defenseMultiplier: 1, paceMultiplier: 1, ratings: {} },
        "2": { teamId: 2, offenseMultiplier: 1, defenseMultiplier: 1, paceMultiplier: 1, ratings: {} },
      },
    } satisfies PortableSeasonArtifact;
    const result = evaluatePortableSeasonGame(artifact, 10, {
      gameId: 2026020002,
      scheduledStartAt: "2026-10-03T23:00:00Z",
      teamId: 1,
      opponentTeamId: 2,
      isHome: true,
      restDays: 1,
      isBackToBack: true,
    });
    expect(result.conditionalMeans.GOALS).toBe(0.495);
    expect(result.baselineUnconditionalMeans.GOALS).toBe(0.4);
  });

  it("does not scale deployment time by event pace", () => {
    const artifact = {
      schemaVersion: "player-forecast-season-artifact-v1",
      seasonId: 20262027,
      contractVersion: FANTASY_PROJECTION_CONTRACT_VERSION,
      contractChecksum: FANTASY_PROJECTION_CONTRACT_CHECKSUM,
      artifactVersion: "test",
      featureSchemaVersion: "test",
      trainingCutoffAt: "2026-04-16T23:59:59Z",
      codeVersion: "test",
      players: {
        "10": {
          fhfhPlayerId: 10,
          population: "forward",
          position: "C",
          teamId: 1,
          playProbability: 1,
          baselinePlayProbability: 1,
          conditionalRates: { GAMES_PLAYED: 1, TOTAL_TOI: 1200, SHOTS_ON_GOAL: 3 },
          baselineConditionalRates: { GAMES_PLAYED: 1, TOTAL_TOI: 1200, SHOTS_ON_GOAL: 3 },
          conditionalVariances: { GAMES_PLAYED: 0, TOTAL_TOI: 1, SHOTS_ON_GOAL: 1 },
          ratings: {},
          deployment: {},
          primitiveTargets: ["GAMES_PLAYED", "TOTAL_TOI", "SHOTS_ON_GOAL"],
        },
      },
      teams: {
        "1": { teamId: 1, offenseMultiplier: 1, defenseMultiplier: 1, paceMultiplier: 1.21, ratings: {} },
        "2": { teamId: 2, offenseMultiplier: 1, defenseMultiplier: 1, paceMultiplier: 0.81, ratings: {} },
      },
    } satisfies PortableSeasonArtifact;
    const result = evaluatePortableSeasonGame(artifact, 10, {
      gameId: 2026020003,
      scheduledStartAt: "2026-10-05T23:00:00Z",
      teamId: 1,
      opponentTeamId: 2,
      isHome: true,
    });
    expect(result.conditionalMeans.TOTAL_TOI).toBe(1200);
    expect(result.conditionalMeans.SHOTS_ON_GOAL).toBeCloseTo(
      3 * Math.sqrt(1.21 * 0.81),
    );
  });

  const artifactPath = process.env.PLAYER_FORECAST_SEASON_GOLDEN_ARTIFACT;
  const golden = artifactPath ? it : it.skip;

  golden("matches Python golden vectors byte-for-byte", () => {
    const artifact = JSON.parse(fs.readFileSync(artifactPath!, "utf8")) as PortableSeasonArtifact;
    expect(artifact.goldenVectors).toHaveLength(3);
    for (const vector of artifact.goldenVectors ?? []) {
      const actual = evaluatePortableSeasonGame(artifact, vector.fhfhPlayerId, vector.game);
      expect({ ...actual, componentHash: vector.expected.componentHash }).toEqual(
        vector.expected,
      );
      expect(actual.componentHash).toBe(vector.expected.componentHash);
    }
    const evaluations = (artifact.goldenVectors ?? []).map((vector) =>
      evaluatePortableSeasonGame(artifact, vector.fhfhPlayerId, vector.game),
    );
    const otherPopulation = evaluations[0].population === "goalie" ? "forward" : "goalie";
    expect(() => aggregateSeasonGames([
      evaluations[0],
      { ...evaluations[1], population: otherPopulation },
    ])).toThrow(
      "PLAYER_FORECAST_SEASON_POPULATION_MISMATCH",
    );
  });
});
