import React, { useState, useEffect, useMemo, useRef } from "react";
import publicSupabase from "lib/supabase/public-client";
import styles from "./PlayerPickupTable.module.scss";
import Image from "next/image";
import clsx from "clsx";
import { useCurrentSeasonQuery } from "hooks/useCurrentSeason";
import { useProviderSyncAccess } from "hooks/useProviderSyncAccess";
import ProviderSyncNotice from "components/account/ProviderSyncNotice";
import supabase from "lib/supabase/client";
import { isYahooPickupPlayer, type YahooPickupContext } from "lib/integrations/yahoo/pickup";
import { teamsInfo } from "lib/teamsInfo";
import PanelStatus from "components/common/PanelStatus";
import { getLocalTeamLogoPath } from "lib/images";
import OptimizedImage from "components/common/OptimizedImage";
import type { PlayerOwnershipContext } from "lib/dashboard/playerOwnership";

// TO DO
// integrate week score, dynamic. if toggle turns off a day, update score
// add Line/PP "extension" look from lines

// ---------------------------
// Type Definitions
// ---------------------------
export type UnifiedPlayerData = {
  nhl_player_id: string;
  nhl_player_name: string;
  nhl_team_abbreviation: string | null;
  yahoo_player_id: string | null;
  yahoo_player_name: string | null;
  yahoo_team: string | null;
  percent_ownership: number | null;
  ownershipEvidence?: PlayerOwnershipContext["ownershipEvidence"];
  eligible_positions: string[] | null;
  off_nights: number | null;
  points: number | null;
  goals: number | null;
  assists: number | null;
  shots: number | null;
  pp_points: number | null;
  blocked_shots: number | null;
  hits: number | null;
  total_fow: number | null;
  penalty_minutes: number | null;
  sh_points: number | null;
  wins: number | null;
  saves: number | null;
  shots_against: number | null;
  shutouts: number | null;
  quality_start: number | null;
  goals_against_avg: number | null;
  save_pct: number | null;
  player_type: "skater" | "goalie";
  current_team_abbreviation: string | null;
  percent_games: number | null;
  status: string | null;
  injury_note: string | null;
};

type RawDataFromDb = UnifiedPlayerData;

export interface PlayerWithPercentiles extends UnifiedPlayerData {
  percentiles: Record<MetricKey, number>;
  composite: number; // Original overall score based on all relevant metrics
}

export interface PlayerWithScores extends PlayerWithPercentiles {
  displayScore: number; // The score shown in the table (can be composite, selected avg, or other avg)
  sortByValue: number; // The value used when sorting by the 'Score' column
  filterMode: "all" | "single" | "multiple" | "none"; // What kind of filtering is active for this player
  activeSelectedMetrics: MetricKey[]; // Which metrics were actually used for the score calculation
}

export type MetricKey =
  | "points"
  | "goals"
  | "assists"
  | "shots"
  | "pp_points"
  | "blocked_shots"
  | "hits"
  | "total_fow"
  | "penalty_minutes"
  | "sh_points"
  | "wins"
  | "saves"
  | "shots_against"
  | "shutouts"
  | "quality_start"
  | "goals_against_avg"
  | "save_pct"
  | "percent_games";

export interface MetricDefinition {
  key: MetricKey;
  label: string;
}

// --- NEW: Interface for Mobile Detail Items ---
interface DetailItemData {
  key: MetricKey;
  label: string;
  value: number | undefined | null;
  displayValue: string;
}

// --- Base Metric Definitions (Used for Percentile Calculation, Presets etc.) ---
// NOTE: GP% is included here because it's needed for percentile calculations for both types.
// We will explicitly exclude it in the preset button logic later.
const skaterMetrics: MetricDefinition[] = [
  { key: "points", label: "PTS" },
  { key: "goals", label: "G" },
  { key: "assists", label: "A" },
  { key: "shots", label: "SOG" },
  { key: "pp_points", label: "PPP" },
  { key: "blocked_shots", label: "BLK" },
  { key: "hits", label: "HIT" },
  { key: "total_fow", label: "FOW" },
  { key: "penalty_minutes", label: "PIM" },
  { key: "sh_points", label: "SHP" },
  { key: "percent_games", label: "GP%" } // GP% included for skaters calc
];

const goalieMetrics: MetricDefinition[] = [
  { key: "wins", label: "W" },
  { key: "saves", label: "SV" },
  { key: "shots_against", label: "SA" },
  { key: "shutouts", label: "SO" },
  { key: "quality_start", label: "QS" },
  { key: "goals_against_avg", label: "GAA" },
  { key: "save_pct", label: "SV%" },
  { key: "percent_games", label: "GP%" } // GP% included for goalies calc
];

// --- Define Metric Groups for Filter UI ---
const skaterPointKeys: MetricKey[] = [
  "goals",
  "assists",
  "points",
  "pp_points",
  "sh_points"
];

const skaterPeripheralKeys: MetricKey[] = [
  "shots",
  "blocked_shots",
  "hits",
  "total_fow",
  "penalty_minutes"
];
const goalieQualityKeys: MetricKey[] = [
  "save_pct",
  "goals_against_avg",
  "quality_start"
  // Note: 'SO' is listed under Quantity in the diagram, adjust if needed
];
const goalieQuantityKeys: MetricKey[] = [
  "wins",
  "saves",
  "shots_against",
  "shutouts" // SO listed here as per diagram
];
const gamePlayedKey: MetricKey = "percent_games"; // Keep GP% separate for UI Grouping

type OwnershipTimelineEntry = {
  date?: string | null;
  value?: number | string | null;
};

const OWNERSHIP_MAX_AGE_MS = 3 * 86400000;

const ownershipPct = (value: unknown): number | null => {
  const parsed = typeof value === "string" && /^\d+(\.\d+)?$/.test(value) ? Number(value)
    : typeof value === "number" ? value : NaN;
  return Number.isFinite(parsed) && parsed >= 0 && parsed <= 100 ? parsed : null;
};

const getLatestOwnershipEvidence = (timelineRaw: unknown): PlayerOwnershipContext["ownershipEvidence"] => {
  let entries: OwnershipTimelineEntry[] | null = null;

  if (Array.isArray(timelineRaw)) {
    entries = timelineRaw as OwnershipTimelineEntry[];
  } else if (typeof timelineRaw === "string") {
    try {
      const parsed = JSON.parse(timelineRaw);
      if (Array.isArray(parsed)) {
        entries = parsed as OwnershipTimelineEntry[];
      }
    } catch (err) {
      console.warn("Failed to parse ownership_timeline string", err);
    }
  }

  if (!entries || entries.length === 0) {
    return null;
  }

  let latest: PlayerOwnershipContext["ownershipEvidence"] = null;

  for (const entry of entries) {
    if (!entry || typeof entry !== "object") continue;
    const entryDateRaw = typeof entry.date === "string" ? entry.date : null;
    if (!entryDateRaw || !/^\d{4}-\d{2}-\d{2}$/.test(entryDateRaw)) continue;
    const parsedTimestamp = Date.parse(entryDateRaw);
    const value = ownershipPct(entry.value);
    if (value === null || !Number.isFinite(parsedTimestamp) || new Date(parsedTimestamp).toISOString().slice(0, 10) !== entryDateRaw) continue;
    if (!latest || entryDateRaw > latest.observedOn!) {
      latest = { value, observedOn: entryDateRaw, provider: "yahoo", status: "unknown" };
    }
  }

  return latest;
};

function currentPickupOwnership(evidence: PlayerOwnershipContext["ownershipEvidence"], now: number): Pick<UnifiedPlayerData, "percent_ownership" | "ownershipEvidence"> {
  if (!evidence) return { percent_ownership: null, ownershipEvidence: null };
  const age = evidence.observedOn === null ? NaN : now - Date.parse(evidence.observedOn);
  const status = !Number.isFinite(age) || age < 0 ? "unknown" : age <= OWNERSHIP_MAX_AGE_MS ? "fresh" : "stale";
  return { percent_ownership: status === "fresh" ? evidence.value : null, ownershipEvidence: { ...evidence, status } };
}

function resolvePickupOwnership(timeline: unknown, seasonValue: unknown, rowValue: unknown): Pick<UnifiedPlayerData, "percent_ownership" | "ownershipEvidence"> {
  const dated = getLatestOwnershipEvidence(timeline);
  const value = ownershipPct(seasonValue) ?? ownershipPct(rowValue);
  const ownershipEvidence = dated ?? (value === null ? null : { value, observedOn: null, provider: "yahoo" as const, status: "unknown" as const });
  return currentPickupOwnership(ownershipEvidence, Date.now());
}

function pickupOwnershipLabel(player: Pick<UnifiedPlayerData, "percent_ownership" | "ownershipEvidence">): string {
  if (player.percent_ownership !== null) return `${player.percent_ownership}%`;
  const evidence = player.ownershipEvidence;
  if (!evidence) return "Unknown";
  return `Last known ${evidence.value}% · ${evidence.observedOn ? `${evidence.observedOn} (${evidence.status === "stale" ? "stale" : "unverified"})` : "date unknown"}`;
}

function summarizePlayerPickupError(error: unknown): string {
  const message =
    error instanceof Error ? error.message : typeof error === "string" ? error : "";

  if (
    message.includes("<!DOCTYPE html") ||
    message.includes("<html") ||
    message.includes("Connection timed out") ||
    message.includes("Failed to fetch")
  ) {
    return "Best available player data is temporarily unavailable.";
  }

  return message || "Best available player data is temporarily unavailable.";
}

// ---------------------------
// Default Filter Settings & Props
// ---------------------------
const defaultOwnershipThreshold = 50;
const defaultTeamFilter = "ALL";
const defaultPositions: Record<string, boolean> = {
  C: true,
  LW: true,
  RW: true,
  D: true,
  G: true
};

export function normalizePickupPositions(value: unknown): string[] {
  const values = Array.isArray(value) ? value : [value];
  const positions: string[] = [];
  for (const entry of values) {
    const token = typeof entry === "string" ? entry
      : entry && typeof entry === "object" && "position" in entry
        ? entry.position : null;
    if (typeof token !== "string") continue;
    const position = token.trim().toUpperCase();
    if (Object.prototype.hasOwnProperty.call(defaultPositions, position) && !positions.includes(position)) {
      positions.push(position);
    }
  }
  return positions;
}
export type TeamWeekData = {
  teamAbbreviation: string;
  gamesPlayed: number;
  offNights: number;
  avgOpponentPointPct: number;
  weekScore?: number; // current week's team score (optional)
};
export type PlayerPickupTableProps = {
  teamWeekData?: TeamWeekData[];
  layoutVariant?: "full" | "sidebar";
};

// ---------------------------
// Helper Functions & Hooks
// ---------------------------

export const getYahooSeasonStartYear = (
  seasonId: string | number | null | undefined
): number | null => {
  if (seasonId === null || seasonId === undefined) return null;
  const seasonIdAsString = String(seasonId);
  if (!/^\d{8}$/.test(seasonIdAsString)) return null;

  const startYear = Number(seasonIdAsString.slice(0, 4));
  return Number.isNaN(startYear) ? null : startYear;
};

export const getNhlSeasonIdFromYahooSeasonYear = (
  yahooSeasonYear: number
): string => `${yahooSeasonYear}${yahooSeasonYear + 1}`;

const chunkArray = <T,>(items: T[], chunkSize: number): T[][] => {
  if (items.length === 0) return [];
  const result: T[][] = [];
  for (let i = 0; i < items.length; i += chunkSize) {
    result.push(items.slice(i, i + chunkSize));
  }
  return result;
};

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    function handleResize() {
      setIsMobile(window.innerWidth < 768);
    }
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  return isMobile;
}

function shortenName(fullName: string): string {
  if (!fullName) return "N/A";
  const parts = fullName.split(" ");
  if (parts.length <= 1) return fullName;
  return `${parts[0].charAt(0)}. ${parts[parts.length - 1]}`;
}

const playerNameMapping: Record<string, string> = {
  "Alex Wennberg": "Alexander Wennberg"
};
const normalizePlayerName = (name: string | null): string => {
  if (!name) return "N/A";
  const mappedName = playerNameMapping[name] || name;
  return shortenName(mappedName);
};

const sanitizeTeamValue = (value: string | number): string =>
  String(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-Za-z]/g, "")
    .toUpperCase();

const DIRECT_TEAM_ABBREVIATION_OVERRIDES: Record<
  string,
  keyof typeof teamsInfo
> = {
  TB: "TBL",
  TAMPA: "TBL",
  SJ: "SJS",
  SJS: "SJS",
  SJSHARKS: "SJS",
  NJ: "NJD",
  NJD: "NJD",
  LA: "LAK",
  LAKINGS: "LAK",
  LOSANGELESKINGS: "LAK"
};

const teamAliasMap: Map<string, keyof typeof teamsInfo> = (() => {
  const map = new Map<string, keyof typeof teamsInfo>();
  const addAlias = (
    alias: string | number | null | undefined,
    abbr: keyof typeof teamsInfo
  ) => {
    if (alias === null || alias === undefined) return;
    const key = sanitizeTeamValue(alias);
    if (!key) return;
    if (!map.has(key)) {
      map.set(key, abbr);
    }
  };

  (
    Object.entries(teamsInfo) as Array<
      [keyof typeof teamsInfo, (typeof teamsInfo)[keyof typeof teamsInfo]]
    >
  ).forEach(([abbr, info]) => {
    addAlias(abbr, abbr);
    addAlias(info.abbrev, abbr);
    addAlias(info.nstAbbr, abbr);
    addAlias(info.name, abbr);
    addAlias(info.shortName, abbr);
    addAlias(`${info.name} ${info.shortName}`, abbr);
    if (info.location) {
      addAlias(info.location, abbr);
      addAlias(`${info.location} ${info.shortName}`, abbr);
      addAlias(`${info.location}${info.shortName}`, abbr);
    }
    addAlias(`${abbr}${info.shortName}`, abbr);
    if (info.nstAbbr) {
      addAlias(`${info.nstAbbr}${info.shortName}`, abbr);
      addAlias(`${info.nstAbbr}.${info.shortName}`, abbr);
    }
  });

  return map;
})();

const resolveTeamAlias = (raw: string | null | undefined): string | null => {
  if (!raw) return null;
  const sanitized = sanitizeTeamValue(raw);
  if (!sanitized) return null;

  const override = DIRECT_TEAM_ABBREVIATION_OVERRIDES[sanitized];
  if (override) return String(override);

  if ((teamsInfo as Record<string, unknown>)[sanitized]) {
    return sanitized;
  }

  const aliasResolved = teamAliasMap.get(sanitized);
  if (aliasResolved) return String(aliasResolved);

  // Heuristic: try to infer from team names when alias lookup fails.
  for (const [abbr, info] of Object.entries(teamsInfo) as Array<
    [keyof typeof teamsInfo, (typeof teamsInfo)[keyof typeof teamsInfo]]
  >) {
    const abbrSan = sanitizeTeamValue(abbr);
    const shortSan = sanitizeTeamValue(info.shortName);
    const locationSan = info.location ? sanitizeTeamValue(info.location) : "";
    const nameSan = sanitizeTeamValue(info.name);
    const nstSan = info.nstAbbr ? sanitizeTeamValue(info.nstAbbr) : "";

    if (sanitized === nameSan || sanitized === shortSan) {
      return String(abbr);
    }

    if (shortSan && sanitized.endsWith(shortSan)) {
      const prefix = sanitized.slice(0, sanitized.length - shortSan.length);
      if (
        !prefix ||
        prefix === abbrSan ||
        (abbrSan && abbrSan.startsWith(prefix)) ||
        prefix === nstSan ||
        (nstSan && nstSan.startsWith(prefix)) ||
        prefix === locationSan ||
        (locationSan &&
          (locationSan.startsWith(prefix) || prefix.startsWith(locationSan))) ||
        prefix.length <= 3
      ) {
        return String(abbr);
      }
    }
  }

  return null;
};

const normalizeTeamAbbreviation = (
  team: string | null,
  expectedTeam?: string | null
): string | null => {
  const expectedResolved = resolveTeamAlias(expectedTeam);
  if (expectedResolved) return expectedResolved;

  if (!team) return null;
  const teamsArray = team
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);

  for (const t of teamsArray) {
    const resolved = resolveTeamAlias(t);
    if (resolved) return resolved;
  }

  const fallback = teamsArray[0];
  if (!fallback) return null;
  const sanitizedFallback = sanitizeTeamValue(fallback);
  if (
    sanitizedFallback &&
    (teamsInfo as Record<string, unknown>)[sanitizedFallback]
  ) {
    return sanitizedFallback;
  }
  return fallback.toUpperCase();
};

function getRankColorStyle(
  percentile: number | undefined | null
): React.CSSProperties {
  if (percentile === undefined || percentile === null) {
    // expose a var even for undefined to keep CSS stable
    return {
      backgroundColor: `rgba(128, 128, 128, 0.45)`,
      ["--metric-color" as any]: `rgba(128, 128, 128, 0.45)`
    } as React.CSSProperties;
  }
  const weight = Math.max(0, Math.min(100, percentile)) / 100;
  // Red to Green gradient
  const r = Math.round(255 * (1 - weight));
  const g = Math.round(255 * weight);
  const color = `rgba(${r}, ${g}, 0, 0.45)`;
  // set CSS var for use in border-color via SCSS
  return {
    backgroundColor: color,
    ["--metric-color" as any]: color
  } as React.CSSProperties;
}

// ---------------------------
// Child Components
// ---------------------------

// Filters Component
interface FiltersProps {
  ownershipThreshold: number;
  includeUnknownOwnership: boolean;
  setIncludeUnknownOwnership: (value: boolean) => void;
  leagueMode?: boolean;
  setOwnershipThreshold: (value: number) => void;
  teamFilter: string;
  setTeamFilter: (value: string) => void;
  selectedPositions: Record<string, boolean>;
  setSelectedPositions: React.Dispatch<
    // Allow direct setting for presets
    React.SetStateAction<Record<string, boolean>>
  >;
  resetFilters: () => void;
  teamOptions: string[];
  isMobile: boolean;
  isMobileMinimized: boolean;
  toggleMobileMinimize: () => void;
  // --- Props for Metric Filtering ---
  allPossibleMetrics: MetricDefinition[]; // Still needed for lookups and presets
  selectedMetrics: Record<MetricKey, boolean>;
  setSelectedMetrics: React.Dispatch<
    React.SetStateAction<Record<MetricKey, boolean>>
  >;
  layoutVariant?: "full" | "sidebar";
  // Team boost toggle
  teamBoostEnabled: boolean;
  setTeamBoostEnabled: React.Dispatch<React.SetStateAction<boolean>>;
}

const Filters: React.FC<FiltersProps> = ({
  leagueMode = false,
  ownershipThreshold,
  includeUnknownOwnership,
  setIncludeUnknownOwnership,
  setOwnershipThreshold,
  teamFilter,
  setTeamFilter,
  selectedPositions,
  setSelectedPositions, // Receive the setter function
  resetFilters,
  teamOptions,
  isMobile,
  isMobileMinimized,
  toggleMobileMinimize,
  // --- Destructure metric props ---
  allPossibleMetrics,
  selectedMetrics,
  setSelectedMetrics,
  layoutVariant = "full",
  teamBoostEnabled,
  setTeamBoostEnabled
}) => {
  const isCompactSidebar = layoutVariant === "sidebar";
  // --- NEW: Handler for clicking sub-group titles ---
  const handleSubGroupPresetClick = (
    keysToSelect: MetricKey[],
    playerType: "skater" | "goalie"
  ) => {
    // 1. Set Position Filters
    const skaterPositions = { C: true, LW: true, RW: true, D: true, G: false };
    const goaliePositions = {
      C: false,
      LW: false,
      RW: false,
      D: false,
      G: true
    };
    setSelectedPositions(
      playerType === "skater" ? skaterPositions : goaliePositions
    );

    // 2. Set Metric Filters (only select keys from the specific subgroup)
    const nextMetricsState = Object.fromEntries(
      allPossibleMetrics.map((metric) => [metric.key, false]) // Start all false
    ) as Record<MetricKey, boolean>;

    keysToSelect.forEach((key) => {
      if (key in nextMetricsState) {
        nextMetricsState[key] = true;
      }
    });
    setSelectedMetrics(nextMetricsState);
  };

  const handlePositionChange = (pos: string) => {
    setSelectedPositions((prev: Record<string, boolean>) => ({
      ...prev,
      [pos]: !prev[pos]
    }));
  };

  const handleMetricChange = (key: MetricKey) => {
    setSelectedMetrics((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // --- UPDATED handleSelectPreset ---
  const handleSelectPreset = (type: "all" | "skater" | "goalie" | "none") => {
    const nextMetricsState: Record<MetricKey, boolean> = Object.fromEntries(
      allPossibleMetrics.map((metric) => [metric.key, false])
    ) as Record<MetricKey, boolean>; // Start fresh with all metrics false

    // Use the original skater/goalie metric definitions for determining which metrics to select
    const skaterMetricKeys = new Set(skaterMetrics.map((m) => m.key));
    const goalieMetricKeys = new Set(goalieMetrics.map((m) => m.key));

    // --- Define Position States for Presets ---
    const skaterPositions = { C: true, LW: true, RW: true, D: true, G: false };
    const goaliePositions = {
      C: false,
      LW: false,
      RW: false,
      D: false,
      G: true
    };

    // Update Metric Selection based on type
    allPossibleMetrics.forEach((metric) => {
      switch (type) {
        case "all":
          nextMetricsState[metric.key] = true;
          break;
        case "none":
          nextMetricsState[metric.key] = false;
          break;
        case "skater":
          // Select metric IF it's a skater metric AND NOT percent_games
          nextMetricsState[metric.key] =
            skaterMetricKeys.has(metric.key) && metric.key !== "percent_games";
          break;
        case "goalie":
          // Select metric IF it's a goalie metric AND NOT percent_games
          nextMetricsState[metric.key] =
            goalieMetricKeys.has(metric.key) && metric.key !== "percent_games";
          break;
      }
    });
    setSelectedMetrics(nextMetricsState); // Update the selected metrics state

    // --- Update Position Selection based on type ---
    switch (type) {
      case "skater":
        setSelectedPositions(skaterPositions); // Show only skater positions
        break;
      case "goalie":
        setSelectedPositions(goaliePositions); // Show only goalie position
        break;
      case "all":
      case "none":
        setSelectedPositions(defaultPositions); // Reset to default positions
        break;
    }
  };

  // Determine active metrics count and states for disabling buttons
  const activeMetricKeys = useMemo(
    () =>
      Object.entries(selectedMetrics)
        .filter(([, isSelected]) => isSelected)
        .map(([key]) => key as MetricKey),
    [selectedMetrics]
  );

  const isAllSelected = activeMetricKeys.length === allPossibleMetrics.length;
  const isNoneSelected = activeMetricKeys.length === 0;

  // Helper to find metric definition (label) by key
  const getMetricDefinition = (
    key: MetricKey
  ): MetricDefinition | undefined => {
    return allPossibleMetrics.find((m) => m.key === key);
  };

  // Renders the inner checkboxes for a specific sub-group
  const renderCheckboxGroup = (metricKeys: MetricKey[]) => {
    const validMetrics = metricKeys
      .map((key) => getMetricDefinition(key))
      .filter((metric): metric is MetricDefinition => !!metric);

    if (validMetrics.length === 0) return null;

    return (
      <div className={styles.metricGroupCheckboxes}>
        {validMetrics.map((metric) => (
          <label key={metric.key} className={styles.metricCheckbox}>
            <input
              type="checkbox"
              checked={selectedMetrics[metric.key] ?? false}
              onChange={() => handleMetricChange(metric.key)}
            />{" "}
            {metric.label}
          </label>
        ))}
      </div>
    );
  };

  // Handler for title click, only works on mobile
  const handleTitleClick = isMobile ? toggleMobileMinimize : undefined;
  const useCompactLayout = isMobile || isCompactSidebar;

  return (
    <div
      className={clsx(
        styles.filters,
        isMobile && isMobileMinimized && styles.minimized,
        isCompactSidebar && styles.sidebarFilters
      )}
    >
      <div
        className={styles.filtersTitle}
        onClick={handleTitleClick}
        onKeyDown={isMobile ? event => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            toggleMobileMinimize();
          }
        } : undefined}
        role={isMobile ? "button" : undefined}
        tabIndex={isMobile ? 0 : undefined}
        aria-expanded={isMobile ? !isMobileMinimized : undefined}
        aria-controls={isMobile ? "player-table-content" : undefined}
        data-interactive={isMobile ? true : undefined}
      >
        <h2 className={styles.titleContent} aria-label="Best Players Available">
          <span className={styles.titleWord}>
            <span className={styles.acronym}>B</span>est
          </span>{" "}
          <span className={styles.titleWord}>
            <span className={styles.acronym}>P</span>layers
          </span>{" "}
          <span className={styles.titleWord}>
            <span className={styles.acronym}>A</span>vailable
          </span>
        </h2>
        {isMobile && (
          <span
            className={clsx(
              styles.minimizeToggleIcon,
              isMobileMinimized && styles.minimized
            )}
            aria-hidden="true"
          >
            ▼
          </span>
        )}
      </div>

      <div
        className={styles.filtersBody}
        hidden={isMobile && isMobileMinimized}
      >
        {(!isMobile || !isMobileMinimized) && (
          <>
            {/* --- Ownership, Team, Position Filters --- */}
            {/* Conditionally render based on compact layout */}
            {useCompactLayout ? (
              // Compact (mobile/sidebar) Layout for Basic Filters - single combined row
              <div className={styles.filterContainerMobile}>
                <div className={styles.filterRowMobileCombined}>
                  <div className={styles.compactField}>
                    <label
                      className={styles.labelMobile}
                      htmlFor="pickup-ownership-threshold"
                    >
                      Own %: {ownershipThreshold}%
                    </label>
                    <input
                      id="pickup-ownership-threshold"
                      type="range"
                      min="0"
                      max="100"
                      value={ownershipThreshold}
                      disabled={leagueMode}
                      title={leagueMode ? "Yahoo league availability replaces the ownership filter" : undefined}
                      onChange={(e) =>
                        setOwnershipThreshold(Number(e.target.value))
                      }
                      className={styles.sliderMobile}
                    />
                  </div>
                  <div
                    className={clsx(
                      styles.compactField,
                      styles.compactFieldInline
                    )}
                  >
                    <label
                      className={styles.labelMobile}
                      htmlFor="pickup-team-filter"
                    >
                      Team:
                    </label>
                    <select
                      id="pickup-team-filter"
                      value={teamFilter}
                      onChange={(e) => setTeamFilter(e.target.value)}
                      className={styles.selectMobile}
                    >
                      {teamOptions.map((team) => (
                        <option key={team} value={team}>
                          {team}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div
                    className={clsx(styles.compactField, styles.positionsField)}
                  >
                    <span className={styles.labelMobile}>Pos:</span>
                    <div className={styles.positionCheckboxGroup}>
                      {Object.keys(defaultPositions).map((pos) => (
                        <label key={pos} className={styles.positionCheckbox}>
                          <input
                            type="checkbox"
                            checked={selectedPositions[pos] ?? false}
                            onChange={() => handlePositionChange(pos)}
                          />
                          {pos}
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              // Desktop Layout for Basic Filters
              <div className={styles.filterContainer}>
                <div className={styles.filterRowGridTop}>
                  <div className={styles.filterRow}>
                    <label
                      className={styles.label}
                      htmlFor="pickup-ownership-threshold"
                    >
                      Ownership %: {ownershipThreshold}%
                    </label>
                    <input
                      id="pickup-ownership-threshold"
                      type="range"
                      min="0"
                      max="100"
                      value={ownershipThreshold}
                      disabled={leagueMode}
                      title={leagueMode ? "Yahoo league availability replaces the ownership filter" : undefined}
                      onChange={(e) =>
                        setOwnershipThreshold(Number(e.target.value))
                      }
                      className={styles.slider}
                    />
                  </div>
                  <div className={clsx(styles.filterRow, styles.filterRowTeam)}>
                    <label
                      className={styles.label}
                      htmlFor="pickup-team-filter"
                    >
                      Team:
                    </label>
                    <select
                      id="pickup-team-filter"
                      value={teamFilter}
                      onChange={(e) => setTeamFilter(e.target.value)}
                      className={styles.select}
                    >
                      {teamOptions.map((team) => (
                        <option key={team} value={team}>
                          {team}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div
                  className={clsx(styles.filterRow, styles.filterRowPositions)}
                >
                  <span className={styles.label}>Positions:</span>
                  <div className={styles.positionCheckboxGroup}>
                    {Object.keys(defaultPositions).map((pos) => (
                      <label key={pos} className={styles.positionCheckbox}>
                        <input
                          type="checkbox"
                          checked={selectedPositions[pos] ?? false}
                          onChange={() => handlePositionChange(pos)}
                        />{" "}
                        {pos}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div className={styles.filterRow}>
              <label>
                <input type="checkbox" checked={includeUnknownOwnership} disabled={leagueMode}
                  onChange={(event) => setIncludeUnknownOwnership(event.target.checked)} />{" "}
                Include unknown ownership
              </label>
            </div>
            <div className={styles.metricFilterContainer}>
              {/* Header: Label + Preset Buttons */}
              <div className={styles.metricFilterHeader}>
                <span className={styles.label}>Filter by Metrics:</span>
                <div className={styles.metricPresetButtons}>
                  <button
                    onClick={() => handleSelectPreset("all")}
                    disabled={isAllSelected}
                  >
                    All
                  </button>
                  <button onClick={() => handleSelectPreset("skater")}>
                    Skaters
                  </button>
                  <button onClick={() => handleSelectPreset("goalie")}>
                    Goalies
                  </button>
                  <button
                    onClick={() => handleSelectPreset("none")}
                    disabled={isNoneSelected}
                  >
                    None
                  </button>
                </div>
                {/* Inline GP% toggle to save vertical space */}
                <div className={styles.inlineGpToggle}>
                  <label className={styles.metricCheckbox}>
                    <input
                      type="checkbox"
                      checked={selectedMetrics[gamePlayedKey] ?? false}
                      onChange={() => handleMetricChange(gamePlayedKey)}
                    />
                    GP%
                  </label>
                </div>
                {/* Inline Team Boost toggle */}
                <div className={styles.inlineTeamBoostToggle}>
                  <label className={styles.metricCheckbox}>
                    <input
                      type="checkbox"
                      checked={teamBoostEnabled}
                      onChange={() => setTeamBoostEnabled((v) => !v)}
                    />
                    Team boost
                  </label>
                </div>
              </div>
              {/* Skaters and Goalies Row */}
              {/* Skaters and Goalies Row */}
              <div className={styles.skaterGoalieRow}>
                {/* Skaters Column */}
                <fieldset className={styles.skaterMetricsColumn}>
                  <legend className={styles.columnLabel}>Skaters</legend>
                  <div className={styles.skaterSubGroupsRow}>
                    <div className={styles.metricGroup}>
                      {" "}
                      {/* Points Group */}
                      <button
                        type="button" // Prevent form submission if wrapped in form
                        className={styles.metricGroupTitle}
                        onClick={() =>
                          handleSubGroupPresetClick(skaterPointKeys, "skater")
                        }
                      >
                        Points
                      </button>
                      {renderCheckboxGroup(skaterPointKeys)}
                    </div>
                    <div className={styles.metricGroup}>
                      {" "}
                      {/* Peripherals Group */}
                      <button
                        type="button"
                        className={styles.metricGroupTitle}
                        onClick={() =>
                          handleSubGroupPresetClick(
                            skaterPeripheralKeys,
                            "skater"
                          )
                        }
                      >
                        Peripherals
                      </button>
                      {renderCheckboxGroup(skaterPeripheralKeys)}
                    </div>
                  </div>
                </fieldset>

                {/* Goalies Column */}
                <fieldset className={styles.goalieMetricsColumn}>
                  <legend className={styles.columnLabel}>Goalies</legend>
                  <div className={styles.goalieSubGroupsRow}>
                    <div className={styles.metricGroup}>
                      {" "}
                      {/* Quality Group */}
                      <button
                        type="button"
                        className={styles.metricGroupTitle}
                        onClick={() =>
                          handleSubGroupPresetClick(goalieQualityKeys, "goalie")
                        }
                      >
                        Quality
                      </button>
                      {renderCheckboxGroup(goalieQualityKeys)}
                    </div>
                    <div className={styles.metricGroup}>
                      {" "}
                      {/* Quantity Group */}
                      {/* UPDATED: Title is now a button */}
                      <button
                        type="button"
                        className={styles.metricGroupTitle}
                        onClick={() =>
                          handleSubGroupPresetClick(
                            goalieQuantityKeys,
                            "goalie"
                          )
                        }
                      >
                        Quantity
                      </button>
                      {renderCheckboxGroup(goalieQuantityKeys)}
                    </div>
                  </div>
                </fieldset>
              </div>{" "}
            </div>{" "}
            <button className={styles.buttonReset} onClick={resetFilters}>
              Reset Filters
            </button>
          </>
        )}
      </div>
    </div>
  );
};

// Table Components (Desktop & Mobile)
type SortKey = keyof PlayerWithScores | "composite"; // Allow 'composite' for the score column key
interface PlayerTableCommonProps {
  // Use PlayerWithScores here
  players: PlayerWithScores[];
  sortKey: SortKey;
  sortOrder: "asc" | "desc";
  handleSort: (column: SortKey) => void;
  getOffNightsForPlayer: (player: UnifiedPlayerData) => number | string;
  // Pass selectedMetrics for styling
  selectedMetrics: Record<MetricKey, boolean>;
}

type SortableHeaderProps = {
  column: SortKey;
  label: string;
  sortKey: SortKey;
  sortOrder: "asc" | "desc";
  handleSort: (column: SortKey) => void;
};

const SortableHeader: React.FC<SortableHeaderProps> = ({
  column,
  label,
  sortKey,
  sortOrder,
  handleSort
}) => {
  const isActive = sortKey === column;
  const ariaSort = isActive
    ? sortOrder === "asc"
      ? "ascending"
      : "descending"
    : "none";

  return (
    <th aria-sort={ariaSort}>
      <button
        type="button"
        className={styles.sortButton}
        onClick={() => handleSort(column)}
        aria-label={`Sort by ${label}${isActive ? `, currently ${ariaSort}` : ""}`}
      >
        {label}
        <span aria-hidden="true">
          {isActive ? (sortOrder === "desc" ? " ▼" : " ▲") : ""}
        </span>
      </button>
    </th>
  );
};

// --- DesktopTable, MobileTable, PaginationControls (No changes needed in these child components) ---
interface DesktopTableProps extends PlayerTableCommonProps {}
const DesktopTable: React.FC<DesktopTableProps> = ({
  players,
  sortKey,
  sortOrder,
  handleSort,
  getOffNightsForPlayer,
  selectedMetrics // Receive selectedMetrics
}) => {
  // Determine header text based on the mode of the first player (or default)
  let scoreHeader = "Score";
  let currentFilterMode: PlayerWithScores["filterMode"] | null = null;
  if (players.length > 0) {
    currentFilterMode = players[0].filterMode; // Assume consistency for the page
    const firstPlayerActiveMetrics = players[0].activeSelectedMetrics;

    // Get *all* metric definitions for label lookup
    const allMetricDefs = [...skaterMetrics, ...goalieMetrics];

    if (currentFilterMode === "single" && firstPlayerActiveMetrics.length > 0) {
      // Find the label for the single metric
      scoreHeader = `Other Avg`; // Simpler header for single metric mode
    } else if (currentFilterMode === "multiple") {
      scoreHeader = "Selected Avg";
    } else if (currentFilterMode === "none") {
      scoreHeader = "Score (N/A)";
    }
  }

  return (
    <div className={styles.tableContainer}>
      <table className={styles.table}>
        <thead>
          <tr>
            <SortableHeader
              column="nhl_player_name"
              label="Name"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <SortableHeader
              column="nhl_team_abbreviation"
              label="Team"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <SortableHeader
              column="percent_ownership"
              label="Own %"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <th>Pos.</th>
            <SortableHeader
              column="off_nights"
              label="Off-Nights"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <SortableHeader
              column="percent_games"
              label="GP%"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <th>Metrics</th>
            <SortableHeader
              column="composite"
              label={scoreHeader}
              {...{ sortKey, sortOrder, handleSort }}
            />
          </tr>
        </thead>
        <tbody>
          {players.map((player, index) => {
            // Use base metric definitions based on player type for display
            const relevantMetrics =
              player.player_type === "skater" ? skaterMetrics : goalieMetrics;
            const teamAbbr = normalizeTeamAbbreviation(
              player.current_team_abbreviation || player.yahoo_team,
              player.yahoo_team
            );

            // Determine styling based on filter mode and active selections for this player
            const isMetricSelected = (key: MetricKey) =>
              player.activeSelectedMetrics.includes(key);
            const isDimmed =
              player.filterMode === "single" ||
              player.filterMode === "multiple";

            const percentileMetrics = relevantMetrics.filter(
              ({ key }) => key !== "percent_games"
            );
            const pairClass =
              index % 2 === 0 ? styles.evenPair : styles.oddPair;

            // Determine primary position for styling
            let primaryPos = "C";
            if (player.player_type === "goalie") primaryPos = "G";
            else if (
              player.eligible_positions &&
              player.eligible_positions.length > 0
            ) {
              // Simple heuristic: take the first position
              primaryPos = player.eligible_positions[0];
            }
            const posClass = styles[`pos${primaryPos}`] || styles.posC;

            return (
              <React.Fragment key={player.nhl_player_id}>
                <tr className={clsx(styles.primaryRow, pairClass, posClass)}>
                  <td className={styles.nameCell}>
                    <div className={styles.nameAndInjuryWrapper}>
                      <div className={styles.leftNamePart}>
                        {teamAbbr ? (
                          <span className={styles.teamLogoSmall}>
                            <OptimizedImage
                              src={getLocalTeamLogoPath(teamAbbr)}
                              alt={teamAbbr}
                              width={20}
                              height={20}
                            />
                          </span>
                        ) : null}
                        <span className={styles.playerName}>
                          {normalizePlayerName(
                            player.yahoo_player_name || player.nhl_player_name
                          )}
                        </span>
                      </div>
                      {player.status &&
                        ["IR-LT", "IR", "O", "DTD", "IR-NR"].includes(
                          player.status
                        ) && (
                          <div className={styles.rightInjuryPart}>
                            <div className={styles.statusRightInjuryPart}>
                              {player.status}
                            </div>
                            <div className={styles.injuryNoteRightInjuryPart}>
                              {player.injury_note}
                            </div>
                            <div className={styles.imageContainer}>
                              <Image
                                src="/pictures/injured.png"
                                alt="Injured"
                                width={20}
                                height={20}
                              />
                            </div>
                          </div>
                        )}
                    </div>
                  </td>
                  <td>
                    {teamAbbr ? (
                      <span className={styles.teamAbbr}>{teamAbbr}</span>
                    ) : (
                      "N/A"
                    )}
                  </td>
                  <td className={styles.numCell}>
                    <span title={player.ownershipEvidence?.observedOn ? `Yahoo ownership · ${player.ownershipEvidence.observedOn}` : undefined}>
                      {pickupOwnershipLabel(player)}
                    </span>
                  </td>
                  <td className={styles.positionsCell}>
                    {player.eligible_positions?.join(", ") ||
                      (player.player_type === "goalie" ? "G" : "N/A")}
                  </td>
                  <td className={styles.numCell}>
                    {getOffNightsForPlayer(player)}
                  </td>
                  <td className={styles.numCell}>
                    {player.percent_games !== null ? (
                      <div
                        className={clsx(
                          styles.percentileContainer,
                          isMetricSelected("percent_games") && styles.selected,
                          isDimmed &&
                            !isMetricSelected("percent_games") &&
                            styles.dimmed
                        )}
                      >
                        <div
                          className={clsx(
                            styles.percentileLabel,
                            isMetricSelected("percent_games") &&
                              styles.selectedLabel
                          )}
                        >
                          GP%
                        </div>
                        <div
                          className={clsx(
                            styles.percentileBox,
                            isMetricSelected("percent_games") &&
                              styles.selectedBox
                          )}
                          style={getRankColorStyle(
                            player.percentiles?.percent_games
                          )}
                        >
                          {(Math.min(player.percent_games, 1) * 100).toFixed(0)}
                          %
                        </div>
                      </div>
                    ) : (
                      "N/A"
                    )}
                  </td>
                  <td className={styles.metricsCell}>
                    <div className={styles.percentileRow}>
                      {percentileMetrics.length === 0 ? (
                        <span className={styles.emptyPercentile}>
                          No percentile data available
                        </span>
                      ) : (
                        percentileMetrics.map(({ key, label }) => {
                          const pctVal = player.percentiles?.[key];
                          const isSelected = isMetricSelected(key);
                          return (
                            <div
                              key={key}
                              className={clsx(
                                styles.percentileContainer,
                                styles.rowPairMetric,
                                isSelected && styles.selected,
                                isDimmed && !isSelected && styles.dimmed
                              )}
                            >
                              <div
                                className={clsx(
                                  styles.percentileLabel,
                                  isSelected && styles.selectedLabel
                                )}
                              >
                                {label}
                              </div>
                              <div
                                className={clsx(
                                  styles.percentileBox,
                                  isSelected && styles.selectedBox
                                )}
                                style={getRankColorStyle(pctVal)}
                              >
                                {pctVal !== undefined && pctVal !== null
                                  ? `${pctVal.toFixed(0)}%`
                                  : "0%"}
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </td>
                  <td className={styles.scoreCell}>
                    {player.displayScore.toFixed(1)}
                  </td>
                </tr>
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
// ... (MobileTable component remains the same) ...
interface MobileTableProps extends PlayerTableCommonProps {
  expanded: Record<string, boolean>;
  toggleExpand: (playerId: string) => void;
}
const MobileTable: React.FC<MobileTableProps> = ({
  players,
  sortKey,
  sortOrder,
  handleSort,
  expanded,
  toggleExpand,
  getOffNightsForPlayer,
  selectedMetrics // Receive selectedMetrics
}) => {
  const totalColumns = 7;

  // Determine header text for mobile score column (optional, could keep as "Score")
  let scoreHeaderMobile = "Score";
  if (players.length > 0) {
    const firstPlayerMode = players[0].filterMode;
    if (firstPlayerMode === "single") scoreHeaderMobile = "Other Avg";
    else if (firstPlayerMode === "multiple") scoreHeaderMobile = "Sel. Avg";
    else if (firstPlayerMode === "none") scoreHeaderMobile = "N/A";
  }

  return (
    <div className={styles.containerMobile}>
      <table className={styles.tableMobile}>
        <colgroup>
          <col style={{ width: "5%" }} />
          <col style={{ width: "35%" }} />
          <col style={{ width: "10%" }} />
          <col style={{ width: "10%" }} />
          <col style={{ width: "15%" }} />
          <col style={{ width: "10%" }} />
          <col style={{ width: "15%" }} />
        </colgroup>
        <thead>
          <tr>
            <th aria-label="Player details"></th>
            <SortableHeader
              column="nhl_player_name"
              label="Name"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <SortableHeader
              column="nhl_team_abbreviation"
              label="Team"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <SortableHeader
              column="percent_ownership"
              label="Own"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <th>Pos.</th>
            <SortableHeader
              column="off_nights"
              label="Offs"
              {...{ sortKey, sortOrder, handleSort }}
            />
            <SortableHeader
              column="composite"
              label={scoreHeaderMobile}
              {...{ sortKey, sortOrder, handleSort }}
            />
          </tr>
        </thead>
        <tbody>
          {players.map((player) => {
            // Use base metric definitions based on player type
            const relevantMetrics =
              player.player_type === "skater" ? skaterMetrics : goalieMetrics;
            const teamAbbr = normalizeTeamAbbreviation(
              player.current_team_abbreviation || player.yahoo_team,
              player.yahoo_team
            );
            const isExpanded = expanded[player.nhl_player_id] ?? false;

            // Determine styling based on filter mode and active selections for this player
            const isMetricSelected = (key: MetricKey) =>
              player.activeSelectedMetrics.includes(key);
            const isDimmed =
              player.filterMode === "single" ||
              player.filterMode === "multiple";

            // Prepare items for expanded view using DetailItemData interface
            // Include GP% first
            const allDetailItems: DetailItemData[] = [
              {
                key: "percent_games",
                label: "GP%",
                // Safely access percentile value
                value: player.percentiles?.percent_games,
                displayValue:
                  player.percent_games !== null
                    ? `${(Math.min(player.percent_games, 1) * 100).toFixed(0)}%`
                    : "N/A"
              },
              // Add other relevant metrics (excluding GP% as it's already added)
              ...relevantMetrics
                .filter(({ key }) => key !== "percent_games")
                .map(({ key, label }): DetailItemData => {
                  // Safely access percentile value
                  const pctVal = player.percentiles?.[key];
                  return {
                    key: key,
                    label: label,
                    value: pctVal,
                    displayValue:
                      pctVal !== undefined && pctVal !== null
                        ? `${pctVal.toFixed(0)}%`
                        : "0%" // Handle undefined/null
                  };
                })
            ];
            const midpoint = Math.ceil(allDetailItems.length / 2);
            const row1Items = allDetailItems.slice(0, midpoint);
            const row2Items = allDetailItems.slice(midpoint);

            return (
              <React.Fragment key={player.nhl_player_id}>
                <tr>
                  {/* Main Row */}
                  <td>
                    {/* Expand Button */}
                    <button
                      type="button"
                      onClick={() => toggleExpand(player.nhl_player_id)}
                      className={styles.expandButton}
                      aria-expanded={isExpanded}
                      aria-controls={`details-${player.nhl_player_id}`}
                      aria-label={`${isExpanded ? "Collapse" : "Expand"} details for ${player.nhl_player_name}`}
                    >
                      {isExpanded ? "−" : "+"}
                    </button>
                  </td>
                  <td>
                    {" "}
                    {/* Name */}
                    <div className={styles.nameAndInjuryWrapperMobile}>
                      <div className={styles.leftNamePartMobile}>
                        <span className={styles.playerName}>
                          {normalizePlayerName(
                            player.yahoo_player_name || player.nhl_player_name
                          )}
                        </span>
                      </div>
                      {player.status &&
                        ["IR-LT", "IR", "O", "DTD", "IR-NR"].includes(
                          player.status
                        ) && (
                          <div className={styles.rightInjuryPartMobile}>
                            <div className={styles.imageContainer}>
                              <Image
                                src="/pictures/injured.png"
                                alt="Injured"
                                width={18}
                                height={18}
                              />
                            </div>
                          </div>
                        )}
                    </div>
                  </td>
                  <td>
                    {" "}
                    {/* Team */}
                    {teamAbbr ? (
                      <OptimizedImage
                        src={getLocalTeamLogoPath(teamAbbr)}
                        alt={teamAbbr}
                        width={25}
                        height={25}
                      />
                    ) : (
                      "N/A"
                    )}
                  </td>
                  <td>
                    {" "}
                    {/* Own% */}
                    <span title={player.ownershipEvidence?.observedOn ? `Yahoo ownership · ${player.ownershipEvidence.observedOn}` : undefined}>
                      {pickupOwnershipLabel(player)}
                    </span>
                  </td>
                  <td>
                    {" "}
                    {/* Pos */}
                    {player.eligible_positions?.join(", ") ||
                      (player.player_type === "goalie" ? "G" : "N/A")}
                  </td>
                  <td>{getOffNightsForPlayer(player)}</td>
                  <td>{player.displayScore.toFixed(1)}</td>
                  {/* Use displayScore */}
                </tr>
                {/* Expanded Row */}
                {isExpanded && (
                  <tr className={styles.expandedRow}>
                    <td
                      colSpan={totalColumns}
                      id={`details-${player.nhl_player_id}`}
                    >
                      <div className={styles.expandedDetails}>
                        {/* Row 1 Details */}
                        <div className={styles.detailRow}>
                          {row1Items.map((item) => {
                            const isSelected = isMetricSelected(item.key);
                            return (
                              <div
                                key={item.key}
                                className={clsx(
                                  styles.detailItem,
                                  isSelected && styles.selected,
                                  isDimmed && !isSelected && styles.dimmed
                                )}
                              >
                                <span
                                  className={clsx(
                                    styles.detailLabel,
                                    isSelected && styles.selectedLabel
                                  )}
                                >
                                  {item.label}:
                                </span>
                                <span
                                  className={clsx(
                                    styles.detailValue,
                                    isSelected && styles.selectedBox
                                  )}
                                  style={getRankColorStyle(item.value)}
                                >
                                  {item.displayValue}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                        {/* Row 2 Details */}
                        {row2Items.length > 0 && (
                          <div className={styles.detailRow}>
                            {row2Items.map((item) => {
                              const isSelected = isMetricSelected(item.key);
                              return (
                                <div
                                  key={item.key}
                                  className={clsx(
                                    styles.detailItem,
                                    isSelected && styles.selected,
                                    isDimmed && !isSelected && styles.dimmed
                                  )}
                                >
                                  <span
                                    className={clsx(
                                      styles.detailLabel,
                                      isSelected && styles.selectedLabel
                                    )}
                                  >
                                    {item.label}:
                                  </span>
                                  <span
                                    className={clsx(
                                      styles.detailValue,
                                      isSelected && styles.selectedBox
                                    )}
                                    style={getRankColorStyle(item.value)}
                                  >
                                    {item.displayValue}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

// Pagination Component

interface PaginationControlsProps {
  currentPage: number;

  totalPages: number;

  setCurrentPage: (page: number) => void;
}

const PaginationControls: React.FC<PaginationControlsProps> = ({
  currentPage,
  totalPages,
  setCurrentPage
}) => {
  if (totalPages <= 1) return null;
  return (
    <div className={styles.pagination}>
      <button
        onClick={() => setCurrentPage(Math.max(currentPage - 1, 1))}
        disabled={currentPage === 1}
      >
        Previous
      </button>
      <span>
        {" "}
        Page {currentPage} of {totalPages}{" "}
      </span>
      <button
        onClick={() => setCurrentPage(Math.min(currentPage + 1, totalPages))}
        disabled={currentPage === totalPages}
      >
        Next
      </button>
    </div>
  );
};

// ---------------------------
// Main Component
// ---------------------------
const PlayerPickupTable: React.FC<PlayerPickupTableProps> = ({
  teamWeekData,
  layoutVariant = "full"
}) => {
  const isMobile = useIsMobile();
  const isSidebarLayout = layoutVariant === "sidebar";
  const seasonQuery = useCurrentSeasonQuery();
  const currentSeasonInfo = seasonQuery.data;
  const pro = useProviderSyncAccess();
  const [yahooContext, setYahooContext] = useState<YahooPickupContext | null>(null);
  const [yahooStatus, setYahooStatus] = useState<"loading" | "ready" | "error">("ready");
  const [yahooError, setYahooError] = useState<string | null>(null);
  const [yahooRefresh, setYahooRefresh] = useState(0);
  const [playerView, setPlayerView] = useState<"available" | "roster">("available");
  const [retryCount, setRetryCount] = useState(0);
  const leagueContext = pro.status === "ready" && pro.access?.eligible ? yahooContext : null;
  const yahooSyncDate = leagueContext?.fetchedAt ? new Date(leagueContext.fetchedAt) : null;
  const yahooSyncLabel = yahooSyncDate && Number.isFinite(yahooSyncDate.getTime())
    ? `Synced ${yahooSyncDate.toLocaleString()}`
    : "Sync time unavailable";

  useEffect(() => {
    const controller = new AbortController();
    setYahooContext(null);
    setYahooError(null);
    setPlayerView("available");
    if (pro.status !== "ready" || !pro.access?.eligible) {
      setYahooStatus("ready");
      return;
    }
    setYahooStatus("loading");
    void (async () => {
      try {
        const token = (await supabase.auth.getSession()).data.session?.access_token;
        if (!token) throw new Error("Sign in to sync your Yahoo league.");
        const response = await fetch("/api/v1/account/yahoo/pickup", {
          headers: { Authorization: `Bearer ${token}` }, signal: controller.signal,
        });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "Yahoo sync is unavailable.");
        if (!controller.signal.aborted) {
          setYahooContext(payload.data);
          setYahooStatus("ready");
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          setYahooStatus("error");
          setYahooError(error instanceof Error ? error.message : "Yahoo sync is unavailable.");
        }
      }
    })();
    return () => controller.abort();
  }, [pro.status, pro.access, yahooRefresh]);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isInBottomDrawer, setIsInBottomDrawer] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const root = containerRef.current;
    if (!root) return;
    const drawerContent = document.getElementById("gg-bottom-drawer-content");
    setIsInBottomDrawer(!!drawerContent && drawerContent.contains(root));
  }, []);

  const yahooSeasonYear = useMemo(() => {
    return leagueContext?.season ?? getYahooSeasonStartYear(currentSeasonInfo?.seasonId);
  }, [currentSeasonInfo, leagueContext?.season]);

  // --- States ---
  const [ownershipThreshold, setOwnershipThreshold] = useState<number>(
    defaultOwnershipThreshold
  );
  const [includeUnknownOwnership, setIncludeUnknownOwnership] = useState(true);
  const [teamFilter, setTeamFilter] = useState<string>(defaultTeamFilter);
  const [selectedPositions, setSelectedPositions] =
    useState<Record<string, boolean>>(defaultPositions); // State for positions
  const [playersData, setPlayersData] = useState<UnifiedPlayerData[]>([]);
  const [, setOwnershipClock] = useState(0);
  const ownershipNow = Date.now();
  const [loading, setLoading] = useState<boolean>(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [sortKey, setSortKey] = useState<SortKey>("composite");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const pageSize = 25;
  const [isMobileMinimized, setIsMobileMinimized] = useState(false);
  // Team boost toggle (default ON)
  const [teamBoostEnabled, setTeamBoostEnabled] = useState<boolean>(true);
  const [teamGamesPlayedByAbbr, setTeamGamesPlayedByAbbr] = useState<
    Record<string, number>
  >({});
  const [playerGamesPlayedById, setPlayerGamesPlayedById] = useState<
    Record<string, number>
  >({});

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const recheck = () => {
      clearTimeout(timer);
      setOwnershipClock(value => value + 1);
      if (document.visibilityState === "hidden") return;
      const now = Date.now();
      let nextTransition = Infinity;
      for (const player of playersData) {
        const observedAt = Date.parse(player.ownershipEvidence?.observedOn ?? "");
        if (!Number.isFinite(observedAt)) continue;
        // The existing policy includes the exact three-day boundary.
        const transition = observedAt > now ? observedAt : observedAt + OWNERSHIP_MAX_AGE_MS + 1;
        if (transition > now) nextTransition = Math.min(nextTransition, transition);
      }
      if (Number.isFinite(nextTransition)) {
        timer = setTimeout(recheck, Math.min(nextTransition - now, 2147483647));
      }
    };
    recheck();
    document.addEventListener("visibilitychange", recheck);
    window.addEventListener("focus", recheck);
    window.addEventListener("pageshow", recheck);
    return () => {
      clearTimeout(timer);
      document.removeEventListener("visibilitychange", recheck);
      window.removeEventListener("focus", recheck);
      window.removeEventListener("pageshow", recheck);
    };
  }, [playersData]);

  // --- Calculate all possible metrics once (for filter UI, presets, state init) ---
  const allPossibleMetrics = useMemo(() => {
    const metricsMap = new Map<MetricKey, MetricDefinition>();
    // Add all skater and goalie metrics, ensuring uniqueness
    [...skaterMetrics, ...goalieMetrics].forEach((m) => {
      metricsMap.set(m.key, m);
    });
    return Array.from(metricsMap.values()).sort((a, b) => {
      return a.label.localeCompare(b.label);
    });
  }, []);

  // --- Metric Filter State (Initialize with all true) ---
  const [selectedMetrics, setSelectedMetrics] = useState<
    Record<MetricKey, boolean>
  >(() => {
    return Object.fromEntries(
      allPossibleMetrics.map((metric) => [metric.key, true])
    ) as Record<MetricKey, boolean>;
  });

  // --- Data Fetching ---
  useEffect(() => {
    if (yahooSeasonYear === null) {
      setLoading(false);
      setLoadError(null);
      setPlayersData([]);
      return;
    }

    let isCancelled = false;

    const fetchAllData = async () => {
      setLoading(true);
      setLoadError(null);
      const allData: UnifiedPlayerData[] = [];
      const supabasePageSize = 1000;
      let from = 0;

      try {
        let gameIdOverride: string | null = null;
        if (typeof window !== "undefined") {
          const params = new URLSearchParams(window.location.search);
          const override = params.get("gameId");
          if (override) gameIdOverride = override;
        }

        const allowedPlayerKeys = new Set<string>();
        const allowedPlayerIds = new Set<string>();
        const percentOwnershipByIdentifier = new Map<string, number>();

        // Build lookup of valid Yahoo identifiers for the active season
        let playersFrom = 0;
        while (true) {
          const { data: seasonPlayerRows, error: seasonPlayersError } =
            await publicSupabase
              .from("yahoo_players")
              .select(
                "player_key, player_id, percent_ownership"
              )
              .eq("season", yahooSeasonYear)
              .order("player_key")
              .range(playersFrom, playersFrom + supabasePageSize - 1);

          if (seasonPlayersError) throw seasonPlayersError;
          if (!seasonPlayerRows || seasonPlayerRows.length === 0) break;

          (seasonPlayerRows as any[]).forEach((row) => {
            const key = row?.player_key;
            const id = row?.player_id;
            const percentFromRow = ownershipPct(row?.percent_ownership);

            if (typeof key === "string" && key.length > 0) {
              allowedPlayerKeys.add(key);
              if (percentFromRow !== null && !Number.isNaN(percentFromRow)) {
                percentOwnershipByIdentifier.set(key, percentFromRow);
              }
            }
            if (id !== null && id !== undefined) {
              const idString = String(id);
              allowedPlayerIds.add(idString);
              if (percentFromRow !== null && !Number.isNaN(percentFromRow)) {
                percentOwnershipByIdentifier.set(idString, percentFromRow);
              }
            }
          });

          if (seasonPlayerRows.length < supabasePageSize) break;
          playersFrom += supabasePageSize;
        }

        const hasAllowedIdentifiers =
          allowedPlayerKeys.size > 0 || allowedPlayerIds.size > 0;

        if (!hasAllowedIdentifiers) {
          console.warn(
            `No yahoo_players identifiers found for season ${yahooSeasonYear}; excluding rows without explicit season.`
          );
        }

        // Query the security-invoker canonical Yahoo/NHL mapping reader with pagination
        while (true) {
          const { data, error } = await publicSupabase
            .from("yahoo_nhl_player_map_read")
            .select("*")
            .order("yahoo_player_id")
            .range(from, from + supabasePageSize - 1);

          if (error) throw error;
          if (!data || data.length === 0) break;

          const filteredRows = (data as any[]).filter((row) => {
            if (!row || typeof row !== "object") return false;

            const rowSeasonValue =
              row.season !== undefined && row.season !== null
                ? Number(row.season)
                : null;

            if (rowSeasonValue !== null) {
              if (Number.isNaN(rowSeasonValue)) return false;
              if (rowSeasonValue !== yahooSeasonYear) return false;
            } else {
              if (!hasAllowedIdentifiers) return false;

              const yahooIdRaw = row.yahoo_player_id;
              const yahooIdString =
                yahooIdRaw !== null && yahooIdRaw !== undefined
                  ? String(yahooIdRaw)
                  : "";
              if (!yahooIdString) return false;

              const matchesSeason = yahooIdString.includes(".")
                ? allowedPlayerKeys.has(yahooIdString)
                : allowedPlayerIds.has(yahooIdString);
              if (!matchesSeason) return false;
            }

            if (gameIdOverride) {
              const yahooIdString =
                row.yahoo_player_id !== null &&
                row.yahoo_player_id !== undefined
                  ? String(row.yahoo_player_id)
                  : "";
              if (!yahooIdString.startsWith(`${gameIdOverride}.`)) return false;
            }

            return true;
          });

          const mapped = filteredRows.map((r) => {
            const yahooPlayerIdString =
              r.yahoo_player_id !== null && r.yahoo_player_id !== undefined
                ? String(r.yahoo_player_id)
                : null;

            const ownershipFromSeasonLookup = (() => {
              if (!yahooPlayerIdString) return null;
              const direct =
                percentOwnershipByIdentifier.get(yahooPlayerIdString);
              if (direct !== undefined) return direct;

              if (yahooPlayerIdString.includes(".")) {
                const tail = yahooPlayerIdString.split(".").pop() || "";
                if (tail) {
                  const fromTail = percentOwnershipByIdentifier.get(tail);
                  if (fromTail !== undefined) return fromTail;
                }
              }

              return null;
            })();

            const ownership = resolvePickupOwnership(r.ownership_timeline, ownershipFromSeasonLookup, r.percent_ownership);

            return {
              nhl_player_id: r.nhl_player_id ? String(r.nhl_player_id) : "",
              nhl_player_name: r.nhl_player_name || "",
              nhl_team_abbreviation:
                r.nhl_team_abbreviation || r.normalized_team || null,
              yahoo_player_id: r.yahoo_player_id
                ? String(r.yahoo_player_id)
                : null,
              yahoo_player_name: r.yahoo_player_name || null,
              yahoo_team: r.yahoo_team || null,
              ...ownership,
              eligible_positions: normalizePickupPositions(r.eligible_positions),
              off_nights: r.off_nights ?? null,
              points:
                r.points != null
                  ? typeof r.points === "number"
                    ? r.points
                    : Number(r.points)
                  : null,
              goals:
                r.goals != null
                  ? typeof r.goals === "number"
                    ? r.goals
                    : Number(r.goals)
                  : null,
              assists:
                r.assists != null
                  ? typeof r.assists === "number"
                    ? r.assists
                    : Number(r.assists)
                  : null,
              shots:
                r.shots != null
                  ? typeof r.shots === "number"
                    ? r.shots
                    : Number(r.shots)
                  : null,
              pp_points:
                r.pp_points != null
                  ? typeof r.pp_points === "number"
                    ? r.pp_points
                    : Number(r.pp_points)
                  : null,
              blocked_shots:
                r.blocked_shots != null
                  ? typeof r.blocked_shots === "number"
                    ? r.blocked_shots
                    : Number(r.blocked_shots)
                  : null,
              hits:
                r.hits != null
                  ? typeof r.hits === "number"
                    ? r.hits
                    : Number(r.hits)
                  : null,
              total_fow:
                r.total_fow != null
                  ? typeof r.total_fow === "number"
                    ? r.total_fow
                    : Number(r.total_fow)
                  : null,
              penalty_minutes:
                r.penalty_minutes != null
                  ? typeof r.penalty_minutes === "number"
                    ? r.penalty_minutes
                    : Number(r.penalty_minutes)
                  : null,
              sh_points:
                r.sh_points != null
                  ? typeof r.sh_points === "number"
                    ? r.sh_points
                    : Number(r.sh_points)
                  : null,
              wins:
                r.wins != null
                  ? typeof r.wins === "number"
                    ? r.wins
                    : Number(r.wins)
                  : null,
              saves:
                r.saves != null
                  ? typeof r.saves === "number"
                    ? r.saves
                    : Number(r.saves)
                  : null,
              shots_against:
                r.shots_against != null
                  ? typeof r.shots_against === "number"
                    ? r.shots_against
                    : Number(r.shots_against)
                  : null,
              shutouts:
                r.shutouts != null
                  ? typeof r.shutouts === "number"
                    ? r.shutouts
                    : Number(r.shutouts)
                  : null,
              quality_start:
                r.quality_start != null
                  ? typeof r.quality_start === "number"
                    ? r.quality_start
                    : Number(r.quality_start)
                  : null,
              goals_against_avg:
                r.goals_against_avg != null
                  ? typeof r.goals_against_avg === "number"
                    ? r.goals_against_avg
                    : Number(r.goals_against_avg)
                  : null,
              save_pct:
                r.save_pct != null
                  ? typeof r.save_pct === "number"
                    ? r.save_pct
                    : Number(r.save_pct)
                  : null,
              player_type:
                r.player_type === "goalie" || r.player_type === "G"
                  ? "goalie"
                  : "skater",
              current_team_abbreviation:
                r.nhl_team_abbreviation ||
                r.normalized_team ||
                r.yahoo_team ||
                null,
              percent_games:
                r.percent_games != null
                  ? typeof r.percent_games === "number"
                    ? r.percent_games
                    : Number(r.percent_games)
                  : null,
              status: r.status || null,
              injury_note: r.injury_note || null
            };
          });

          allData.push(...(mapped as UnifiedPlayerData[]));

          if (data.length < supabasePageSize) break;
          from += supabasePageSize;
        }

        if (!isCancelled) {
          setPlayersData(allData);
          setLoadError(null);
        }
      } catch (error) {
        console.error("Failed to load player data:", error);
        if (!isCancelled) {
          setPlayersData([]);
          setLoadError(summarizePlayerPickupError(error));
        }
      } finally {
        if (!isCancelled) {
          setLoading(false);
        }
      }
    };
    fetchAllData();
    return () => {
      isCancelled = true;
    };
  }, [yahooSeasonYear, retryCount]);

  // Fetch latest team games played for the season (used to compute GP%).
  useEffect(() => {
    if (yahooSeasonYear === null) {
      setTeamGamesPlayedByAbbr({});
      return;
    }

    let isCancelled = false;
    const nhlSeasonIdString = getNhlSeasonIdFromYahooSeasonYear(yahooSeasonYear);
    const nhlSeasonIdNumber = Number(nhlSeasonIdString);
    if (Number.isNaN(nhlSeasonIdNumber)) return;

    const fetchTeamGamesPlayed = async () => {
      try {
        const { data: latest, error: latestError } = await publicSupabase
          .from("nhl_standings_details")
          .select("date")
          .eq("season_id", nhlSeasonIdNumber)
          .order("date", { ascending: false })
          .limit(1)
          .maybeSingle();

        if (latestError) throw latestError;
        const latestDate = latest?.date;
        if (!latestDate) {
          if (!isCancelled) setTeamGamesPlayedByAbbr({});
          return;
        }

        const { data: rows, error: rowsError } = await publicSupabase
          .from("nhl_standings_details")
          .select("team_abbrev,games_played")
          .eq("season_id", nhlSeasonIdNumber)
          .eq("date", latestDate);

        if (rowsError) throw rowsError;

        const map: Record<string, number> = {};
        (rows as any[] | null)?.forEach((row) => {
          const abbr =
            typeof row?.team_abbrev === "string" ? row.team_abbrev : null;
          const gamesPlayed =
            typeof row?.games_played === "number"
              ? row.games_played
              : row?.games_played != null
                ? Number(row.games_played)
                : NaN;
          if (!abbr || Number.isNaN(gamesPlayed)) return;
          map[abbr] = gamesPlayed;
        });

        if (!isCancelled) setTeamGamesPlayedByAbbr(map);
      } catch (err) {
        console.warn("Failed to fetch nhl_standings_details for GP%:", err);
        if (!isCancelled) setTeamGamesPlayedByAbbr({});
      }
    };

    fetchTeamGamesPlayed();
    return () => {
      isCancelled = true;
    };
  }, [yahooSeasonYear]);

  // Fetch player games played totals for the season (skaters + goalies).
  useEffect(() => {
    if (yahooSeasonYear === null) {
      setPlayerGamesPlayedById({});
      return;
    }

    if (playersData.length === 0) {
      setPlayerGamesPlayedById({});
      return;
    }

    let isCancelled = false;

    const nhlSeasonIdString = getNhlSeasonIdFromYahooSeasonYear(yahooSeasonYear);
    const nhlSeasonIdNumber = Number(nhlSeasonIdString);
    if (Number.isNaN(nhlSeasonIdNumber)) return;

    const skaterIds = Array.from(
      new Set(
        playersData
          .filter((p) => p.player_type === "skater")
          .map((p) => Number(p.nhl_player_id))
          .filter((n) => Number.isFinite(n))
      )
    );

    const goalieIds = Array.from(
      new Set(
        playersData
          .filter((p) => p.player_type === "goalie")
          .map((p) => Number(p.nhl_player_id))
          .filter((n) => Number.isFinite(n))
      )
    );

    const fetchPlayerGamesPlayed = async () => {
      try {
        const combined: Record<string, number> = {};

        for (const chunk of chunkArray(skaterIds, 500)) {
          const { data, error } = await publicSupabase
            .from("wgo_skater_stats_totals")
            .select("player_id,games_played")
            .eq("season", nhlSeasonIdString)
            .in("player_id", chunk);
          if (error) throw error;
          (data as any[] | null)?.forEach((row) => {
            const playerId =
              row?.player_id !== null && row?.player_id !== undefined
                ? String(row.player_id)
                : null;
            const gamesPlayed =
              typeof row?.games_played === "number"
                ? row.games_played
                : row?.games_played != null
                  ? Number(row.games_played)
                  : NaN;
            if (!playerId || Number.isNaN(gamesPlayed)) return;
            combined[playerId] = gamesPlayed;
          });
        }

        for (const chunk of chunkArray(goalieIds, 500)) {
          const { data, error } = await publicSupabase
            .from("wgo_goalie_stats_totals")
            .select("goalie_id,games_played")
            .eq("season_id", nhlSeasonIdNumber)
            .in("goalie_id", chunk);
          if (error) throw error;
          (data as any[] | null)?.forEach((row) => {
            const goalieId =
              row?.goalie_id !== null && row?.goalie_id !== undefined
                ? String(row.goalie_id)
                : null;
            const gamesPlayed =
              typeof row?.games_played === "number"
                ? row.games_played
                : row?.games_played != null
                  ? Number(row.games_played)
                  : NaN;
            if (!goalieId || Number.isNaN(gamesPlayed)) return;
            combined[goalieId] = gamesPlayed;
          });
        }

        if (!isCancelled) setPlayerGamesPlayedById(combined);
      } catch (err) {
        console.warn("Failed to fetch wgo_*_stats_totals for GP%:", err);
        if (!isCancelled) setPlayerGamesPlayedById({});
      }
    };

    fetchPlayerGamesPlayed();
    return () => {
      isCancelled = true;
    };
  }, [playersData, yahooSeasonYear]);

  // ---------------------------
  // Memoized Calculations (Unchanged logic, but dependencies ensure updates)
  // ---------------------------

  const getOffNightsForPlayer = useMemo(
    /* ... unchanged ... */
    () =>
      (player: UnifiedPlayerData): number | string => {
        if (!teamWeekData || teamWeekData.length === 0) {
          return player.off_nights !== null ? player.off_nights : "N/A";
        }
        const teamAbbr = normalizeTeamAbbreviation(
          player.current_team_abbreviation || player.yahoo_team,
          player.yahoo_team
        );
        const teamData = teamWeekData.find(
          (team) => team.teamAbbreviation === teamAbbr
        );
        return teamData
          ? teamData.offNights
          : player.off_nights !== null
            ? player.off_nights
            : "N/A";
      },
    [teamWeekData]
  );

  const playersDataWithComputedGp = useMemo(() => {
    if (playersData.length === 0) return playersData;

    return playersData.map((player) => {
      const teamAbbr = normalizeTeamAbbreviation(
        player.current_team_abbreviation || player.yahoo_team,
        player.yahoo_team
      );

      const playerGamesPlayed =
        playerGamesPlayedById[player.nhl_player_id] ?? null;

      const teamGamesPlayed =
        teamAbbr && teamGamesPlayedByAbbr[teamAbbr] != null
          ? teamGamesPlayedByAbbr[teamAbbr]
          : null;

      const computed =
        playerGamesPlayed !== null &&
        teamGamesPlayed !== null &&
        teamGamesPlayed > 0
          ? Math.max(0, Math.min(1, playerGamesPlayed / teamGamesPlayed))
          : null;

      return {
        ...player,
        ...currentPickupOwnership(player.ownershipEvidence ?? null, ownershipNow),
        percent_games: computed ?? player.percent_games
      };
    });
  }, [playersData, playerGamesPlayedById, teamGamesPlayedByAbbr, ownershipNow]);

  // --- Filtered Players (Now depends on selectedPositions state) ---
  const filteredPlayers = useMemo(() => {
    const result = playersDataWithComputedGp.filter((player) => {
      if (leagueContext && !isYahooPickupPlayer(player.yahoo_player_id, leagueContext, playerView)) return false;
      // League rosters determine availability regardless of global ownership.
      if (!leagueContext && (
        player.percent_ownership === null ? !includeUnknownOwnership : player.percent_ownership > ownershipThreshold
      ))
        return false;

      // Team filter
      const playerTeamAbbr = normalizeTeamAbbreviation(
        player.current_team_abbreviation || player.yahoo_team,
        player.yahoo_team
      );
      if (teamFilter !== "ALL" && teamFilter !== playerTeamAbbr) return false;

      // --- Position Filter (Crucial Part) ---
      const hasEligiblePositions =
        player.eligible_positions && player.eligible_positions.length > 0;

      // Handle Goalies
      if (player.player_type === "goalie") {
        // Show goalie ONLY if the 'G' position filter is selected
        return selectedPositions["G"];
      }
      // Handle Skaters
      else {
        // Skater needs eligible positions defined
        if (!hasEligiblePositions) return false;
        // Show skater if ANY of their eligible positions match ANY selected non-G position filter
        return player.eligible_positions!.some(
          (pos) => pos !== "G" && selectedPositions[pos]
        );
      }
    });
    return result;
    // Dependency on selectedPositions is key here!
  }, [playersDataWithComputedGp, ownershipThreshold, includeUnknownOwnership, teamFilter, selectedPositions, leagueContext, playerView]);

  // --- Compute Percentiles (Logic unchanged) ---
  const playersWithPercentiles: PlayerWithPercentiles[] = useMemo(() => {
    if (filteredPlayers.length === 0) return [];

    const skaters = filteredPlayers.filter((p) => p.player_type === "skater");
    const goalies = filteredPlayers.filter((p) => p.player_type === "goalie");

    function computePercentile(
      values: (number | null)[],
      value: number | null
    ): number {
      if (value === null || value === undefined) return 0;
      const validValues = values.filter(
        (v) => v !== null && v !== undefined
      ) as number[];
      if (validValues.length === 0) return 0;
      validValues.sort((a, b) => a - b);
      const count = validValues.length;
      let numBelow = 0;
      let numEqual = 0;
      for (const v of validValues) {
        if (v < value) numBelow++;
        else if (v === value) numEqual++;
        else break;
      }
      if (count === 1) return 50.0;
      return count > 0 ? ((numBelow + 0.5 * numEqual) / count) * 100 : 0;
    }
    function computeInvertedPercentile(
      values: (number | null)[],
      value: number | null
    ): number {
      if (value === null || value === undefined) return 0;
      const validValues = values.filter(
        (v) => v !== null && v !== undefined
      ) as number[];
      if (validValues.length === 0) return 0;
      validValues.sort((a, b) => a - b);
      const count = validValues.length;
      let numAbove = 0;
      let numEqual = 0;
      for (const v of validValues) {
        if (v > value) {
          numAbove++;
        } else if (v === value) {
          numEqual++;
        }
      }
      if (count === 1) return 50.0;
      return count > 0 ? ((numAbove + 0.5 * numEqual) / count) * 100 : 0;
    }

    function assignPercentiles(
      group: UnifiedPlayerData[],
      metrics: MetricDefinition[]
    ): PlayerWithPercentiles[] {
      if (group.length === 0) return [];
      const metricValuesMap: Map<MetricKey, (number | null)[]> = new Map();

      metrics.forEach(({ key }) => {
        metricValuesMap.set(
          key,
          group.map((p) => p[key as keyof UnifiedPlayerData] as number | null)
        );
      });

      return group.map((player) => {
        const percentiles: Partial<Record<MetricKey, number>> = {};
        let sum = 0;
        let count = 0;

        for (const { key } of metrics) {
          const rawVal = player[key as keyof UnifiedPlayerData] as
            | number
            | null;
          const allValues = metricValuesMap.get(key) || [];
          let pct = 0;

          if (key === "goals_against_avg") {
            pct = computeInvertedPercentile(allValues, rawVal);
          } else {
            pct = computePercentile(allValues, rawVal);
          }

          percentiles[key] = pct;
          if (rawVal !== null && rawVal !== undefined) {
            sum += pct;
            count++;
          }
        }

        const composite = count > 0 ? sum / count : 0;

        const finalPercentiles = metrics.reduce(
          (acc, { key }) => {
            acc[key] = percentiles[key] ?? 0;
            return acc;
          },
          {} as Record<MetricKey, number>
        );

        return {
          ...player,
          percentiles: finalPercentiles,
          composite
        };
      });
    }

    const skatersWithPct = assignPercentiles(skaters, skaterMetrics);
    const goaliesWithPct = assignPercentiles(goalies, goalieMetrics);

    // Combine and ensure `percentiles` is always an object
    const result = [...skatersWithPct, ...goaliesWithPct].map((player) => ({
      ...player,
      percentiles: player.percentiles || {} // Ensure percentiles object exists
    }));
    return result;
  }, [filteredPlayers]);

  // --- Calculate Display Scores (Logic unchanged, depends on playersWithPercentiles & selectedMetrics) ---
  const playersWithScores: PlayerWithScores[] = useMemo(() => {
    const activeMetricKeys = Object.entries(selectedMetrics)
      .filter(([, isSelected]) => isSelected)
      .map(([key]) => key as MetricKey);

    const numActiveMetrics = activeMetricKeys.length;
    const totalPossibleMetricsCount = allPossibleMetrics.length;

    let globalFilterMode: PlayerWithScores["filterMode"] = "multiple";
    if (numActiveMetrics === 0) globalFilterMode = "none";
    else if (numActiveMetrics === totalPossibleMetricsCount)
      globalFilterMode = "all";
    else if (numActiveMetrics === 1) globalFilterMode = "single";

    const result = playersWithPercentiles.map((player): PlayerWithScores => {
      const relevantMetricsForPlayer =
        player.player_type === "skater" ? skaterMetrics : goalieMetrics;
      const relevantMetricKeysForPlayer = new Set(
        relevantMetricsForPlayer.map((m) => m.key)
      );

      const applicableSelectedMetrics = activeMetricKeys.filter((key) =>
        relevantMetricKeysForPlayer.has(key)
      );
      const numApplicableSelected = applicableSelectedMetrics.length;

      let playerFilterMode = globalFilterMode;
      if (globalFilterMode === "all") {
        if (numApplicableSelected === relevantMetricsForPlayer.length)
          playerFilterMode = "all";
        else if (numApplicableSelected === 0) playerFilterMode = "none";
        else if (numApplicableSelected === 1) playerFilterMode = "single";
        else playerFilterMode = "multiple";
      } else if (globalFilterMode === "single") {
        playerFilterMode = numApplicableSelected === 1 ? "single" : "none";
      } else if (globalFilterMode === "multiple") {
        if (numApplicableSelected === 0) playerFilterMode = "none";
        else if (numApplicableSelected === 1) playerFilterMode = "single";
        else playerFilterMode = "multiple";
      }

      let displayScore = 0;
      let sortByValue = 0;

      switch (playerFilterMode) {
        case "all":
          displayScore = player.composite;
          sortByValue = player.composite;
          break;
        case "single":
          const singleMetricKey = applicableSelectedMetrics[0];
          let otherSum = 0;
          let otherCount = 0;
          relevantMetricsForPlayer.forEach(({ key }) => {
            // Safely access percentile value
            const pct = player.percentiles?.[key];
            if (key !== singleMetricKey && pct !== undefined && pct !== null) {
              otherSum += pct;
              otherCount++;
            }
          });
          displayScore = otherCount > 0 ? otherSum / otherCount : 0;
          // Safely access percentile value for sorting
          sortByValue = player.percentiles?.[singleMetricKey] ?? 0;
          break;
        case "multiple":
          let selectedSum = 0;
          let selectedCount = 0;
          applicableSelectedMetrics.forEach((key) => {
            // Safely access percentile value
            const pct = player.percentiles?.[key];
            if (pct !== undefined && pct !== null) {
              selectedSum += pct;
              selectedCount++;
            }
          });
          displayScore = selectedCount > 0 ? selectedSum / selectedCount : 0;
          sortByValue = displayScore;
          break;
        case "none":
        default:
          displayScore = 0;
          sortByValue = -1;
          break;
      }

      return {
        ...player,
        displayScore,
        sortByValue,
        filterMode: playerFilterMode,
        activeSelectedMetrics: applicableSelectedMetrics
      };
    });
    return result;
  }, [playersWithPercentiles, selectedMetrics, allPossibleMetrics]);

  // --- Compute team-based multiplier from weekly team scores ---
  const teamScoreMultiplierMap = useMemo(() => {
    if (!teamWeekData || teamWeekData.length === 0)
      return {} as Record<string, number>;
    const entries = teamWeekData.filter(
      (t) => typeof t.weekScore === "number"
    ) as Array<TeamWeekData & { weekScore: number }>;
    if (entries.length === 0) return {} as Record<string, number>;

    // Normalize scores to 0..1 based on min..max this week
    let min = Infinity;
    let max = -Infinity;
    for (const e of entries) {
      if (e.weekScore < min) min = e.weekScore;
      if (e.weekScore > max) max = e.weekScore;
    }
    const range = max - min;
    const intensity = 0.25; // up to ±25% boost/dilution
    const map: Record<string, number> = {};
    for (const e of entries) {
      const norm = range === 0 ? 0.5 : (e.weekScore - min) / range; // 0..1
      const centered = norm * 2 - 1; // -1..1
      const multiplier = 1 + centered * intensity; // 0.75..1.25 with intensity=0.25
      map[e.teamAbbreviation] = Number.isFinite(multiplier) ? multiplier : 1;
    }
    return map;
  }, [teamWeekData]);

  // --- Apply team multiplier to players' display/sort values (non-destructive) ---
  const playersWithScoresBoosted: PlayerWithScores[] = useMemo(() => {
    if (!teamWeekData || teamWeekData.length === 0) return playersWithScores;
    if (!playersWithScores || playersWithScores.length === 0)
      return playersWithScores;
    return playersWithScores.map((p) => {
      const abbr = normalizeTeamAbbreviation(
        p.current_team_abbreviation || p.yahoo_team,
        p.yahoo_team
      );
      const mult = (abbr && teamScoreMultiplierMap[abbr]) || 1;
      return {
        ...p,
        displayScore: p.displayScore * mult,
        sortByValue: p.sortByValue * mult
      };
    });
  }, [playersWithScores, teamScoreMultiplierMap, teamWeekData]);

  // --- Sorted Players (Logic unchanged) ---
  // Choose boosted vs base scores based on toggle
  const effectivePlayersWithScores = teamBoostEnabled
    ? playersWithScoresBoosted
    : playersWithScores;

  const sortedPlayers = useMemo(() => {
    const sortablePlayers = [...effectivePlayersWithScores];
    sortablePlayers.sort((a, b) => {
      let aValue: any;
      let bValue: any;

      if (sortKey === "composite") {
        aValue = a.sortByValue;
        bValue = b.sortByValue;
      } else if (sortKey === "off_nights") {
        aValue = getOffNightsForPlayer(a);
        bValue = getOffNightsForPlayer(b);
      } else if (sortKey === "nhl_team_abbreviation") {
        aValue =
          normalizeTeamAbbreviation(
            a.current_team_abbreviation || a.yahoo_team,
            a.yahoo_team
          ) || "";
        bValue =
          normalizeTeamAbbreviation(
            b.current_team_abbreviation || b.yahoo_team,
            b.yahoo_team
          ) || "";
      } else if (sortKey === "nhl_player_name") {
        aValue = (a.yahoo_player_name || a.nhl_player_name || "").toLowerCase();
        bValue = (b.yahoo_player_name || b.nhl_player_name || "").toLowerCase();
      } else if (sortKey === "percent_games") {
        aValue = a.percent_games;
        bValue = b.percent_games;
      } else {
        aValue = a[sortKey as keyof PlayerWithScores];
        bValue = b[sortKey as keyof PlayerWithScores];
      }

      const isInvalidA =
        aValue === "N/A" || aValue === null || aValue === undefined;
      const isInvalidB =
        bValue === "N/A" || bValue === null || bValue === undefined;

      if (isInvalidA && isInvalidB) return 0;
      if (isInvalidA) return sortOrder === "desc" ? 1 : -1;
      if (isInvalidB) return sortOrder === "desc" ? -1 : 1;

      if (typeof aValue === "string" && typeof bValue === "string") {
        const comparison = aValue.localeCompare(bValue);
        return sortOrder === "asc" ? comparison : -comparison;
      } else {
        if (aValue < bValue) return sortOrder === "asc" ? -1 : 1;
        if (aValue > bValue) return sortOrder === "asc" ? 1 : -1;
        return 0;
      }
    });
    return sortablePlayers;
  }, [effectivePlayersWithScores, sortKey, sortOrder, getOffNightsForPlayer]);

  // --- Pagination Calculation (Unchanged) ---
  const totalPages = Math.ceil(sortedPlayers.length / pageSize);
  const paginatedPlayers = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return sortedPlayers.slice(startIndex, startIndex + pageSize);
  }, [sortedPlayers, currentPage, pageSize]);

  // --- Team Options Calculation (Unchanged) ---
  const teamOptions = useMemo(() => {
    const teamsSet = new Set<string>(teamWeekData?.map((team) => team.teamAbbreviation) ?? []);
    playersData.forEach((p) => {
      const teamAbbr = normalizeTeamAbbreviation(
        p.current_team_abbreviation || p.yahoo_team
      );
      if (teamAbbr) teamsSet.add(teamAbbr);
    });
    return ["ALL", ...Array.from(teamsSet).sort()];
  }, [playersData, teamWeekData]);

  // --- Event Handlers (handleSort, toggleExpand, toggleMobileMinimize unchanged) ---
  const handleSort = (column: SortKey) => {
    setCurrentPage(1);
    if (sortKey === column) {
      setSortOrder(sortOrder === "desc" ? "asc" : "desc");
    } else {
      setSortKey(column);
      setSortOrder("desc");
    }
  };

  const toggleExpand = (playerId: string) => {
    setExpanded((prev) => ({ ...prev, [playerId]: !prev[playerId] }));
  };

  const toggleMobileMinimize = () => {
    if (isMobile) {
      setIsMobileMinimized((prev) => !prev);
    }
  };

  // --- resetFilters (Now resets selectedPositions too) ---
  const resetFilters = () => {
    setOwnershipThreshold(defaultOwnershipThreshold);
    setIncludeUnknownOwnership(true);
    setTeamFilter(defaultTeamFilter);
    setSelectedPositions(defaultPositions); // Reset positions to default
    // Reset metric filters to all true
    const initialMetrics = Object.fromEntries(
      allPossibleMetrics.map((metric) => [metric.key, true])
    ) as Record<MetricKey, boolean>;
    setSelectedMetrics(initialMetrics);
    // Reset sort order and pagination
    setCurrentPage(1);
    setSortKey("composite");
    setSortOrder("desc");
    setIsMobileMinimized(false);
  };

  // --- Effects (Unchanged) ---
  useEffect(() => {
    setCurrentPage(1);
    setExpanded({});
  }, [ownershipThreshold, includeUnknownOwnership, teamFilter, selectedPositions, selectedMetrics, leagueContext, playerView]);

  useEffect(() => {
    if (totalPages > 0 && currentPage > totalPages) {
      setCurrentPage(totalPages);
    } else if (totalPages === 0 && currentPage !== 1) {
      setCurrentPage(1);
    } else if (currentPage < 1 && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [currentPage, totalPages]);

  // --- Render Logic ---
  const containerClass = clsx(
    styles.container,
    isSidebarLayout && styles.sidebarLayout,
    isMobile && isMobileMinimized && styles.containerMinimized,
    isInBottomDrawer && styles.inBottomDrawer
  );

  return (
    <div ref={containerRef} className={containerClass}>
      {/* Pass position state and setter to Filters */}
      <Filters
        leagueMode={Boolean(leagueContext)}
        ownershipThreshold={ownershipThreshold}
        setOwnershipThreshold={setOwnershipThreshold}
        includeUnknownOwnership={includeUnknownOwnership}
        setIncludeUnknownOwnership={setIncludeUnknownOwnership}
        teamFilter={teamFilter}
        setTeamFilter={setTeamFilter}
        selectedPositions={selectedPositions} // Pass state
        setSelectedPositions={setSelectedPositions} // Pass setter
        resetFilters={resetFilters}
        teamOptions={teamOptions}
        isMobile={isMobile}
        isMobileMinimized={isMobileMinimized}
        toggleMobileMinimize={toggleMobileMinimize}
        allPossibleMetrics={allPossibleMetrics}
        selectedMetrics={selectedMetrics}
        setSelectedMetrics={setSelectedMetrics}
        layoutVariant={layoutVariant}
        teamBoostEnabled={teamBoostEnabled}
        setTeamBoostEnabled={setTeamBoostEnabled}
      />

      {/* Table Content Area */}
      <div
        id="player-table-content"
        className={clsx(
          styles.collapsibleContent,
          isSidebarLayout && styles.sidebarContent
        )}
      >
        {isInBottomDrawer && !isMobile && (
          <div className={styles.tableToolbar}>
            <div className={styles.tableToolbarLeft}>
              <span className={styles.tableToolbarTitle}>
                {leagueContext && playerView === "roster" ? "My Yahoo" : leagueContext ? "Non-rostered" : "General candidate"}{" "}
                <span className={styles.tableToolbarAccent}>{leagueContext && playerView === "roster" ? "Roster" : "Players"}</span>
              </span>
              <span className={styles.tableToolbarMeta}>
                {sortedPlayers.length.toLocaleString()} results
              </span>
            </div>
            <div className={styles.tableToolbarRight}>
              <button
                type="button"
                className={styles.toolbarButton}
                onClick={resetFilters}
              >
                Reset
              </button>
            </div>
          </div>
        )}

        {!leagueContext && <p>General candidates · filtered by global ownership. Availability in your league and waiver status are unknown.</p>}
        <ProviderSyncNotice {...pro} />
        {pro.access?.eligible && (
          <div className={styles.yahooContext}>
            <p role="status">
              {yahooStatus === "loading" ? "Syncing Yahoo league rosters…" : leagueContext
                ? `${leagueContext.leagueName} · ${leagueContext.teamName} · ${yahooSyncLabel}`
                : yahooError || "Connect Yahoo and select your team in account settings to use your league’s player pool."}
            </p>
            <a href="/account?section=connected-accounts">Yahoo account settings</a>
            <button type="button" onClick={() => setYahooRefresh((value) => value + 1)} disabled={yahooStatus === "loading"}>Refresh Yahoo</button>
            {leagueContext ? <>
              <button type="button" aria-pressed={playerView === "available"} onClick={() => setPlayerView("available")}>Non-rostered in my league</button>
              <button type="button" aria-pressed={playerView === "roster"} onClick={() => setPlayerView("roster")}>My roster ({leagueContext.roster.length})</button>
              <p>Players were non-rostered at the displayed sync time. Waiver status and immediate addability are unknown. Global ownership % is not applied.</p>
              <details><summary>Synced roster · {leagueContext.roster.length} players</summary>
                {leagueContext.roster.length ? <ul>{leagueContext.roster.map((player) => <li key={player.key}>{player.name}{player.position ? ` · ${player.position}` : ""}</li>)}</ul> : <p>Your Yahoo roster is empty.</p>}
                <p>The scored table includes players with verified NHL mappings; the full Yahoo roster is listed here.</p>
              </details>
            </> : yahooStatus !== "loading" && <p>Showing the general player pool; Yahoo league availability is not applied.</p>}
          </div>
        )}
        {loading || seasonQuery.isLoading || yahooStatus === "loading" ? (
          <PanelStatus state="loading" message="Loading players..." />
        ) : loadError || seasonQuery.isError || yahooSeasonYear === null ? (
          <div>
            <PanelStatus state="error" message={loadError || "The current season could not be loaded."} />
            <button type="button" className={styles.toolbarButton} onClick={() => { setRetryCount((value) => value + 1); void seasonQuery.refetch(); }}>Retry player data</button>
          </div>
        ) : paginatedPlayers.length === 0 ? (
          <div className={styles.message}>
            No players match the current filters.
          </div>
        ) : (
          <>
            {(!isMobile || !isMobileMinimized) && (
              <>
                {isMobile ? (
                  <MobileTable
                    // Use paginatedPlayers derived from filteredPlayers
                    players={paginatedPlayers}
                    sortKey={sortKey}
                    sortOrder={sortOrder}
                    handleSort={handleSort}
                    expanded={expanded}
                    toggleExpand={toggleExpand}
                    getOffNightsForPlayer={getOffNightsForPlayer}
                    selectedMetrics={selectedMetrics}
                  />
                ) : (
                  <DesktopTable
                    // Use paginatedPlayers derived from filteredPlayers
                    players={paginatedPlayers}
                    sortKey={sortKey}
                    sortOrder={sortOrder}
                    handleSort={handleSort}
                    getOffNightsForPlayer={getOffNightsForPlayer}
                    selectedMetrics={selectedMetrics}
                  />
                )}
                <PaginationControls
                  currentPage={currentPage}
                  totalPages={totalPages}
                  setCurrentPage={setCurrentPage}
                />
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default PlayerPickupTable;
