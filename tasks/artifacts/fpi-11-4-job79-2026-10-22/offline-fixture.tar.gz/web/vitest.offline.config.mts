import { defineConfig } from "vitest/config";
import path from "node:path";
export default defineConfig({ resolve: { alias: { lib: path.resolve("lib") } },
  test: { environment: "node", maxWorkers: 1, fileParallelism: false,
    setupFiles: ["./offline.setup.ts"] } });
