import { withCronJobAudit } from "lib/cron/withCronJobAudit";
import { withNhlOffSeasonSkip } from "lib/cron/nhlOffSeason";
import type { NextApiRequest, NextApiResponse } from "next";
import adminOnly from "utils/adminOnlyMiddleware";
import supabase from "lib/supabase/server";
import { fetchCurrentSeason } from "../../../../utils/fetchCurrentSeason";
import {
  fetchGameLogs,
  calculateEwma,
  calculateLeagueMetrics,
  calculateZScores,
  calculateRawScores,
  calculateRawDistribution,
  calculateFinalRating,
  fetchWgoStats,
  fetchAllRatings,
  EwmaMetrics,
  LeagueMetrics,
  ZScored,
  RawScore,
  RawDistribution,
  FinalRating,
} from "../../../../lib/power-ratings";
import {
  TEAM_RATINGS_TREND_LOOKBACK_DAYS,
  deriveTrendOverridesFromLogs,
} from "../../../../lib/teamRatingsTrend";

export const TEAM_POWER_RATING_CALCULATION_VERSION =
  "team-power-v2-final-source-observed-pdo";
const LEGACY_TEAM_POWER_RATING_VERSION = "legacy_unversioned";

function parseBooleanFlag(value: unknown): boolean {
  if (typeof value !== "string") return false;
  const normalized = value.trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes";
}

function getRequestValue(req: NextApiRequest, key: string): unknown {
  if (req.method === "GET") {
    const raw = req.query[key];
    return Array.isArray(raw) ? raw[0] : raw;
  }
  return req.body?.[key];
}

function getRequestFlag(req: NextApiRequest, key: string): boolean {
  return parseBooleanFlag(getRequestValue(req, key));
}

function parseDateParam(value: unknown): string | null {
  if (typeof value !== "string" || !value.trim()) return null;
  return value.trim().slice(0, 10);
}

function isValidIsoDate(value: string): boolean {
  return (
    /^\d{4}-\d{2}-\d{2}$/.test(value) &&
    !Number.isNaN(new Date(`${value}T00:00:00.000Z`).getTime())
  );
}

function previousIsoDate(value: string): string {
  const date = new Date(`${value}T00:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() - 1);
  return date.toISOString().slice(0, 10);
}

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST" && req.method !== "GET") {
    res.setHeader("Allow", ["POST", "GET"]);
    return res.status(405).json({ error: "Method not allowed" });
  }

  const rawDateParam = getRequestValue(req, "date");
  const rawStartDateParam = getRequestValue(req, "startDate");
  const rawEndDateParam = getRequestValue(req, "endDate");
  const parsedDateParam = parseDateParam(rawDateParam);
  const parsedStartDateParam = parseDateParam(rawStartDateParam);
  const parsedEndDateParam = parseDateParam(rawEndDateParam);

  if (
    (rawDateParam != null &&
      (!parsedDateParam || !isValidIsoDate(parsedDateParam))) ||
    (rawStartDateParam != null &&
      (!parsedStartDateParam || !isValidIsoDate(parsedStartDateParam))) ||
    (rawEndDateParam != null &&
      (!parsedEndDateParam || !isValidIsoDate(parsedEndDateParam)))
  ) {
    return res.status(400).json({ error: "Invalid date parameter" });
  }

  const targetDateParam =
    parsedEndDateParam ??
    parsedDateParam ??
    new Date().toISOString().slice(0, 10);
  const explicitStartDate = parsedStartDateParam;
  const isDefaultScheduledWindow =
    rawDateParam == null &&
    rawStartDateParam == null &&
    rawEndDateParam == null;

  if (explicitStartDate && explicitStartDate > targetDateParam) {
    return res.status(400).json({ error: "Invalid startDate/endDate range" });
  }

  const smokeTestMode = getRequestFlag(req, "smokeTest");

  try {
    // Check if table is empty to decide if we need to backfill
    const { count } = await supabase
      .from("team_power_ratings_daily")
      .select("*", { count: "exact", head: true });

    let startDateStr = explicitStartDate ?? targetDateParam;
    const tableWasEmpty = count === 0;
    const explicitRangeApplied = Boolean(explicitStartDate);
    const autoBackfillApplied =
      !explicitRangeApplied && tableWasEmpty && !smokeTestMode;
    let lateArrivalRepairApplied = false;
    if (autoBackfillApplied) {
      console.log("Table is empty. Fetching season start date...");
      const season = await fetchCurrentSeason();
      startDateStr = season.startDate;
      console.log(`Backfilling from season start: ${startDateStr}`);
    } else if (tableWasEmpty && smokeTestMode) {
      console.log(
        `Smoke-test mode enabled; skipping empty-table backfill and probing only ${targetDateParam}.`,
      );
    } else if (explicitRangeApplied) {
      console.log(
        `Explicit rating refresh range requested: ${startDateStr} -> ${targetDateParam}.`,
      );
    } else if (isDefaultScheduledWindow && !smokeTestMode) {
      startDateStr = previousIsoDate(targetDateParam);
      lateArrivalRepairApplied = true;
      console.log(
        `Scheduled late-arrival repair window: ${startDateStr} -> ${targetDateParam}.`,
      );
    }

    const startDate = new Date(`${startDateStr}T00:00:00.000Z`);
    const endDate = new Date(`${targetDateParam}T00:00:00.000Z`);
    const executionWindowDays =
      Math.floor(
        (endDate.getTime() - startDate.getTime()) / (24 * 60 * 60 * 1000),
      ) + 1;
    let processedCount = 0;
    let totalUpserts = 0;

    // Loop through each day from startDate to endDate
    for (
      let d = new Date(startDate);
      d <= endDate;
      d.setDate(d.getDate() + 1)
    ) {
      const targetDate = d.toISOString().slice(0, 10);
      console.log(`Processing ${targetDate}...`);

      // Use the shared trend lookback so off-season dates still retain the last
      // played-game snapshots instead of propagating zero after day 90.
      const logEndDate = targetDate;
      const logStartDateObj = new Date(`${logEndDate}T00:00:00.000Z`);
      logStartDateObj.setUTCDate(
        logStartDateObj.getUTCDate() - TEAM_RATINGS_TREND_LOOKBACK_DAYS,
      );
      const logStartDate = logStartDateObj.toISOString().slice(0, 10);

      const logs = await fetchGameLogs(supabase, logStartDate, logEndDate);
      const trendOverrides = deriveTrendOverridesFromLogs(logs, targetDate);

      // Group by team
      const teamLogs = new Map<string, any[]>();
      logs.forEach((log) => {
        if (!teamLogs.has(log.team_abbreviation)) {
          teamLogs.set(log.team_abbreviation, []);
        }
      });

      // Sort and assign rn_desc
      for (const [team, teamGames] of teamLogs) {
        // Add all logs for this team
        const teamRawLogs = logs.filter((l) => l.team_abbreviation === team);
        teamRawLogs.sort((a, b) => b.date.localeCompare(a.date)); // DESC

        const processed = teamRawLogs.map((l, index) => ({
          ...l,
          rn_desc: index, // 0 is most recent
          gp_to_date: teamRawLogs.length - index, // 1 is first game
        }));

        teamLogs.set(team, processed);
      }

      // Calculate EWMA for targetDate
      const ewmaMetrics: EwmaMetrics[] = [];
      for (const [team, games] of teamLogs) {
        const ewma = calculateEwma(games, targetDate);
        if (ewma) {
          ewmaMetrics.push(ewma);
        }
      }

      let finalRatings: FinalRating[] = [];

      if (ewmaMetrics.length > 0) {
        // Calculate League Metrics
        const leagueMetrics = calculateLeagueMetrics(ewmaMetrics);

        // Calculate Z-Scores
        const zScores: ZScored[] = ewmaMetrics.map((m) =>
          calculateZScores(m, leagueMetrics),
        );

        // Calculate Raw Scores
        const rawScores: RawScore[] = zScores.map((z) => calculateRawScores(z));

        // Calculate Raw Distribution
        const rawDist = calculateRawDistribution(rawScores);

        // Calculate Final Ratings
        finalRatings = rawScores.map((s) => calculateFinalRating(s, rawDist));
      } else {
        console.log(`No games found for ${targetDate}.`);
      }

      // Fetch latest ratings for ALL teams from DB (before today)
      const trendStartDate = new Date(targetDate);
      trendStartDate.setDate(trendStartDate.getDate() - 60);

      const latestRatings = await fetchAllRatings(
        supabase,
        "team_power_ratings_daily",
        targetDate,
        trendStartDate.toISOString().slice(0, 10),
      );

      // Map of team -> latest rating
      const latestMap = new Map<string, any>();
      latestRatings?.forEach((r) => {
        if (r.team_abbreviation) {
          if (!latestMap.has(r.team_abbreviation)) {
            latestMap.set(r.team_abbreviation, r);
          }
        }
      });

      // Fetch WGO stats for tiers
      const wgoStats = await fetchWgoStats(supabase, logStartDate, targetDate);
      // Group by team, sort by date desc
      const wgoMap = new Map<string, any>();
      wgoStats.forEach((s) => {
        if (
          !wgoMap.has(s.team_abbreviation) ||
          s.date > wgoMap.get(s.team_abbreviation).date
        ) {
          wgoMap.set(s.team_abbreviation, s);
        }
      });

      // Calculate Percentiles for Tiers
      const ppValues: number[] = [];
      const pkValues: number[] = [];

      const allTeams = new Set<string>([
        ...Array.from(teamLogs.keys()),
        ...Array.from(latestMap.keys()),
      ]);

      for (const team of allTeams) {
        const wgo = wgoMap.get(team);
        if (wgo && wgo.power_play_pct != null)
          ppValues.push(wgo.power_play_pct);
        if (wgo && wgo.penalty_kill_pct != null)
          pkValues.push(wgo.penalty_kill_pct);
      }

      ppValues.sort((a, b) => a - b);
      pkValues.sort((a, b) => a - b);

      const getPercentile = (values: number[], p: number) => {
        if (values.length === 0) return 0;
        const index = Math.floor(values.length * p);
        return values[Math.min(index, values.length - 1)];
      };

      const pp33 = getPercentile(ppValues, 0.33);
      const pp67 = getPercentile(ppValues, 0.67);
      const pk33 = getPercentile(pkValues, 0.33);
      const pk67 = getPercentile(pkValues, 0.67);

      const getTier = (
        val: number | null | undefined,
        p33: number,
        p67: number,
      ) => {
        if (val == null) return 3;
        if (val >= p67) return 1;
        if (val >= p33) return 2;
        return 3;
      };

      const upserts: any[] = [];
      for (const team of allTeams) {
        const calculated = finalRatings.find(
          (r) => r.team_abbreviation === team,
        );
        const trend10 =
          trendOverrides.get(team) ?? Number(latestMap.get(team)?.trend10 ?? 0);

        // Tiers
        const wgo = wgoMap.get(team);
        const ppTier = getTier(wgo?.power_play_pct, pp33, pp67);
        const pkTier = getTier(wgo?.penalty_kill_pct, pk33, pk67);

        if (calculated) {
          upserts.push({
            ...calculated,
            calculation_version: TEAM_POWER_RATING_CALCULATION_VERSION,
            source_through_date: targetDate,
            trend10,
            pp_tier: ppTier,
            pk_tier: pkTier,
          });
        } else {
          const latest = latestMap.get(team);
          if (latest) {
            upserts.push({
              team_abbreviation: team,
              date: targetDate,
              calculation_version:
                latest.calculation_version ?? LEGACY_TEAM_POWER_RATING_VERSION,
              source_through_date:
                latest.source_through_date ?? latest.date ?? null,
              off_rating: latest.off_rating,
              def_rating: latest.def_rating,
              pace_rating: latest.pace_rating,
              xgf60: latest.xgf60,
              gf60: latest.gf60,
              sf60: latest.sf60,
              xga60: latest.xga60,
              ga60: latest.ga60,
              sa60: latest.sa60,
              pace60: latest.pace60,
              finishing_rating: latest.finishing_rating,
              goalie_rating: latest.goalie_rating,
              danger_rating: latest.danger_rating,
              special_rating: latest.special_rating,
              discipline_rating: latest.discipline_rating,
              variance_flag: latest.variance_flag,
              trend10,
              pp_tier: ppTier,
              pk_tier: pkTier,
            });
          }
        }
      }

      // Upsert
      if (upserts.length > 0) {
        const { error } = await supabase
          .from("team_power_ratings_daily" as any)
          .upsert(upserts, { onConflict: "team_abbreviation, date" });

        if (error) throw error;
        totalUpserts += upserts.length;
      }
      processedCount++;
    }

    return res.status(200).json({
      message: "Updated ratings",
      startDate: startDateStr,
      endDate: targetDateParam,
      processedDays: processedCount,
      totalUpserts,
      calculationVersion: TEAM_POWER_RATING_CALCULATION_VERSION,
      executionScope: {
        requestedDate: targetDateParam,
        requestedStartDate: explicitStartDate,
        requestedEndDate: targetDateParam,
        startDate: startDateStr,
        endDate: targetDateParam,
        windowDays: executionWindowDays,
        tableWasEmpty,
        smokeTestMode,
        autoBackfillApplied,
        lateArrivalRepairApplied,
        explicitRangeApplied,
        smokeTestComparable: executionWindowDays === 1,
        smokeTestGuidance:
          executionWindowDays === 1
            ? null
            : "This run expanded beyond a one-day smoke test. Pass smokeTest=true with a target date to force a bounded one-day operational probe when the table is empty.",
      },
    });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}

export default withCronJobAudit(adminOnly(withNhlOffSeasonSkip(handler as any)));
