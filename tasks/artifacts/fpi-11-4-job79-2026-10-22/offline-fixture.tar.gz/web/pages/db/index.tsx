// /Users/tim/Desktop/FHFH/fhfhockey.com/web/pages/db/index.tsx

import { useEffect, useRef, useState } from "react";
import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Typography,
  TextField
} from "@mui/material";
import Link from "next/link";
import { useAuth } from "contexts/AuthProviderContext";

import Grid from "@mui/material/Unstable_Grid2"; // Grid version 2

import { TextBanner } from "components/Banner/Banner";
import Container from "components/Layout/Container";
import supabase, { doPOST } from "lib/supabase";
import { useSnackbar } from "notistack";
import useCurrentSeason from "hooks/useCurrentSeason";
import AdminPageGate from "components/Admin/AdminPageGate";
import CronRouteRunner from "components/Admin/CronRouteRunner";

const NST_MANUAL_BACKFILL_DELAY_MS = 21_000;
const NST_TEAM_STATS_BACKFILL_STORAGE_KEY = "nst-team-stats-backfill";

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

type PendingNstBackfill =
  | {
      mode: "forward";
      startDate: string;
      cursor: string;
      requestsRun: number;
    }
  | {
      mode: "backward";
      startDate: string;
      cursor: string;
      requestsRun: number;
    };

function readPendingNstBackfill(): PendingNstBackfill | null {
  if (typeof window === "undefined") {
    return null;
  }

  const raw = window.localStorage.getItem(NST_TEAM_STATS_BACKFILL_STORAGE_KEY);
  if (!raw) {
    return null;
  }

  try {
    return JSON.parse(raw) as PendingNstBackfill;
  } catch {
    window.localStorage.removeItem(NST_TEAM_STATS_BACKFILL_STORAGE_KEY);
    return null;
  }
}

function writePendingNstBackfill(state: PendingNstBackfill) {
  if (typeof window === "undefined") {
    return;
  }

  window.localStorage.setItem(
    NST_TEAM_STATS_BACKFILL_STORAGE_KEY,
    JSON.stringify(state)
  );
}

function clearPendingNstBackfill() {
  if (typeof window === "undefined") {
    return;
  }

  window.localStorage.removeItem(NST_TEAM_STATS_BACKFILL_STORAGE_KEY);
}

function DatabasePage() {
  const { enqueueSnackbar } = useSnackbar();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [numPlayers, setNumPlayers] = useState(0);
  const [numSeasons, setNumSeasons] = useState(0);
  const [numTeams, setNumTeams] = useState(0);
  const [numGames, setNumGames] = useState(0);
  const [games, setGames] = useState<{ id: number; date: string }[]>([]);
  const [powerPlayInput, setPowerPlayInput] = useState<string>("all"); // State for gameId input
  const [shiftChartsInput, setShiftChartsInput] = useState<string>("all"); // State for Shift Charts input
  const [nstTeamStatsInput, setNstTeamStatsInput] = useState<string>("all"); // State for NST tables
  const [nstTeamStatsEndDateInput, setNstTeamStatsEndDateInput] =
    useState<string>("");
  const [standingsDetailsInput, setStandingsDetailsInput] =
    useState<string>("all");
  const [teamsSeasonIdInput, setTeamsSeasonIdInput] = useState<string>("");
  const [gamesSeasonIdInput, setGamesSeasonIdInput] = useState<string>("");
  const [skoAsOfInput, setSkoAsOfInput] = useState<string>("");
  const [skoLoading, setSkoLoading] = useState(false);
  const [nstTeamStatsLoading, setNstTeamStatsLoading] = useState(false);
  const [pendingNstBackfill, setPendingNstBackfill] =
    useState<PendingNstBackfill | null>(null);
  const nstCancelRequestedRef = useRef(false);
  const nstAbortControllerRef = useRef<AbortController | null>(null);

  const season = useCurrentSeason();
  console.log(season);

  function persistPendingNstBackfill(state: PendingNstBackfill | null) {
    if (state) {
      writePendingNstBackfill(state);
    } else {
      clearPendingNstBackfill();
    }
    setPendingNstBackfill(state);
  }

  function isNstCancellationError(error: unknown) {
    return (
      (error as any)?.name === "AbortError" ||
      (error as any)?.message === "NST backfill cancelled."
    );
  }

  function throwIfNstCancelled() {
    if (nstCancelRequestedRef.current) {
      throw new Error("NST backfill cancelled.");
    }
  }

  async function waitForNstBackfillDelay(ms: number) {
    let remainingMs = ms;

    while (remainingMs > 0) {
      throwIfNstCancelled();
      const chunkMs = Math.min(remainingMs, 250);
      await delay(chunkMs);
      remainingMs -= chunkMs;
    }
  }

  function cancelPendingNstBackfill() {
    nstCancelRequestedRef.current = true;
    persistPendingNstBackfill(null);
    nstAbortControllerRef.current?.abort();
    enqueueSnackbar(
      nstTeamStatsLoading
        ? "NST backfill cancellation requested."
        : "Cleared pending NST backfill.",
      {
        variant: "info"
      }
    );
  }

  async function runForwardNstBackfill(
    startDate: string,
    initialCursor = startDate,
    initialRequestsRun = 0,
    showResumeNotice = false
  ) {
    let cursor = initialCursor;
    let requestsRun = initialRequestsRun;
    let lastResponse: any = null;
    const visitedStartDates = new Set<string>();

    if (showResumeNotice) {
      enqueueSnackbar(`Resuming NST forward backfill from ${cursor}.`, {
        variant: "info"
      });
    }

    while (cursor) {
      throwIfNstCancelled();

      if (visitedStartDates.has(cursor)) {
        throw new Error(`NST backfill loop repeated startDate ${cursor}.`);
      }
      visitedStartDates.add(cursor);

      persistPendingNstBackfill({
        mode: "forward",
        startDate,
        cursor,
        requestsRun
      });

      requestsRun += 1;
      console.log(
        `[NST Team Stats UI] Forward backfill request ${requestsRun} starting at ${cursor}`
      );
      const controller = new AbortController();
      nstAbortControllerRef.current = controller;
      const response = await doPOST(
        `/api/Teams/nst-team-stats?startDate=${encodeURIComponent(cursor)}`,
        undefined,
        { signal: controller.signal }
      );
      nstAbortControllerRef.current = null;
      lastResponse = response;

      if (response.success === false) {
        throw new Error(response.message ?? "NST team stats backfill failed.");
      }

      if (response.complete || !response.nextStartDate) {
        persistPendingNstBackfill(null);
        enqueueSnackbar(
          response.message ??
            `NST team stats backfill completed in ${requestsRun} request(s).`,
          {
            variant: "success"
          }
        );
        return;
      }

      cursor = response.nextStartDate;
      persistPendingNstBackfill({
        mode: "forward",
        startDate,
        cursor,
        requestsRun
      });
      await waitForNstBackfillDelay(NST_MANUAL_BACKFILL_DELAY_MS);
    }

    persistPendingNstBackfill(null);
    enqueueSnackbar(
      lastResponse?.message ??
        `NST team stats backfill completed in ${requestsRun} request(s).`,
      {
        variant: "success"
      }
    );
  }

  async function runBackwardNstBackfill(
    startDate: string,
    initialCursor: string,
    initialRequestsRun = 0,
    showResumeNotice = false
  ) {
    let cursor = initialCursor;
    let requestsRun = initialRequestsRun;
    let lastResponse: any = null;
    const visitedEndDates = new Set<string>();

    if (showResumeNotice) {
      enqueueSnackbar(
        `Resuming NST backward backfill from ${startDate} through ${cursor}.`,
        {
          variant: "info"
        }
      );
    }

    while (cursor) {
      throwIfNstCancelled();

      if (visitedEndDates.has(cursor)) {
        throw new Error(`NST backward backfill loop repeated endDate ${cursor}.`);
      }
      visitedEndDates.add(cursor);

      persistPendingNstBackfill({
        mode: "backward",
        startDate,
        cursor,
        requestsRun
      });

      requestsRun += 1;
      console.log(
        `[NST Team Stats UI] Backward backfill request ${requestsRun} starting range ${startDate}..${cursor}`
      );
      const controller = new AbortController();
      nstAbortControllerRef.current = controller;
      const response = await doPOST(
        `/api/Teams/nst-team-stats?startDate=${encodeURIComponent(
          startDate
        )}&endDate=${encodeURIComponent(cursor)}`,
        undefined,
        { signal: controller.signal }
      );
      nstAbortControllerRef.current = null;
      lastResponse = response;

      if (response.success === false) {
        throw new Error(
          response.message ?? "NST team stats backward backfill failed."
        );
      }

      if (response.complete || !response.nextEndDate) {
        persistPendingNstBackfill(null);
        enqueueSnackbar(
          response.message ??
            `NST backward backfill completed in ${requestsRun} request(s).`,
          {
            variant: "success"
          }
        );
        return;
      }

      cursor = response.nextEndDate;
      persistPendingNstBackfill({
        mode: "backward",
        startDate,
        cursor,
        requestsRun
      });
      await waitForNstBackfillDelay(NST_MANUAL_BACKFILL_DELAY_MS);
    }

    persistPendingNstBackfill(null);
    enqueueSnackbar(
      lastResponse?.message ??
        `NST backward backfill completed in ${requestsRun} request(s).`,
      {
        variant: "success"
      }
    );
  }

  useEffect(() => {
    if (!isAdmin) return;

    const pendingBackfill = readPendingNstBackfill();
    setPendingNstBackfill(pendingBackfill);

    if (pendingBackfill) {
      setNstTeamStatsInput(pendingBackfill.startDate);
      if (pendingBackfill.mode === "backward") {
        setNstTeamStatsEndDateInput(pendingBackfill.cursor);
      } else {
        setNstTeamStatsEndDateInput("");
      }
    }
  }, [isAdmin]);

  useEffect(() => {
    return () => {
      nstCancelRequestedRef.current = true;
      nstAbortControllerRef.current?.abort();
    };
  }, []);

  async function resumePendingNstBackfill() {
    if (!pendingNstBackfill) {
      enqueueSnackbar("There is no pending NST backfill to resume.", {
        variant: "info"
      });
      return;
    }

    try {
      nstCancelRequestedRef.current = false;
      setNstTeamStatsLoading(true);
      if (pendingNstBackfill.mode === "backward") {
        await runBackwardNstBackfill(
          pendingNstBackfill.startDate,
          pendingNstBackfill.cursor,
          pendingNstBackfill.requestsRun,
          true
        );
      } else {
        await runForwardNstBackfill(
          pendingNstBackfill.startDate,
          pendingNstBackfill.cursor,
          pendingNstBackfill.requestsRun,
          true
        );
      }
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(
        isNstCancellationError(e) ? "NST backfill cancelled." : e.message,
        {
          variant: isNstCancellationError(e) ? "info" : "error"
        }
      );
    } finally {
      nstAbortControllerRef.current = null;
      setNstTeamStatsLoading(false);
      setPendingNstBackfill(readPendingNstBackfill());
    }
  }

  async function updatePlayers() {
    try {
      const { message, success } = await doPOST("/api/v1/db/update-players");
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  async function updateSeasons() {
    try {
      const { message, success } = await doPOST("/api/v1/db/update-seasons");
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  async function updateTeams() {
    try {
      const seasonId = teamsSeasonIdInput.trim();
      const endpoint = seasonId
        ? `/api/v1/db/update-teams?seasonId=${encodeURIComponent(seasonId)}`
        : "/api/v1/db/update-teams";
      const { message, success } = await doPOST(endpoint);
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  async function updateGames() {
    try {
      const seasonId = gamesSeasonIdInput.trim();
      const endpoint = seasonId
        ? `/api/v1/db/update-games?seasonId=${encodeURIComponent(seasonId)}`
        : "/api/v1/db/update-games";
      const { message, success } = await doPOST(endpoint);
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  async function updateStats() {
    try {
      if (games.length) {
        for (const game of games) {
          const { message, success } = await doPOST(
            `/api/v1/db/update-stats/${game.id}`
          );
          enqueueSnackbar(message, {
            variant: success ? "success" : "error"
          });
        }
      }
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  async function updateLineCombinations() {
    try {
      const { message, success } = await doPOST(
        "/api/v1/db/update-line-combinations"
      );
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  async function updatePowerPlayTimeframes() {
    try {
      // Validate input
      const trimmedInput = powerPlayInput.trim().toLowerCase();
      if (trimmedInput !== "all" && isNaN(Number(trimmedInput))) {
        enqueueSnackbar("Please enter a valid game ID or 'all'.", {
          variant: "error"
        });
        return;
      }

      // Construct the endpoint URL
      const endpoint =
        trimmedInput === "all"
          ? "/api/v1/db/powerPlayTimeFrame?gameId=all"
          : `/api/v1/db/powerPlayTimeFrame?gameId=${trimmedInput}`;

      const { message, success } = await doPOST(endpoint);
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  async function updateShiftCharts() {
    try {
      // Validate input
      const trimmedInput = shiftChartsInput.trim().toLowerCase();
      if (trimmedInput !== "all" && isNaN(Number(trimmedInput))) {
        enqueueSnackbar("Please enter a valid game ID or 'all'.", {
          variant: "error"
        });
        return;
      }

      // Construct the endpoint URL
      const endpoint =
        trimmedInput === "all"
          ? "/api/v1/db/shift-charts?gameId=all"
          : `/api/v1/db/shift-charts?gameId=${trimmedInput}`;

      const { message, success } = await doPOST(endpoint);
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  // Add this within your Page component
  async function updateNstTeamStats() {
    const trimmedInput = nstTeamStatsInput.trim().toLowerCase();
    const trimmedEndDateInput = nstTeamStatsEndDateInput.trim().toLowerCase();
    const isStartDate = /^\d{4}-\d{2}-\d{2}$/.test(trimmedInput);
    const isEndDate = /^\d{4}-\d{2}-\d{2}$/.test(trimmedEndDateInput);

    if (
      trimmedInput !== "all" &&
      !isStartDate
    ) {
      enqueueSnackbar(
        "Please enter 'all' or a start date in YYYY-MM-DD format.",
        {
          variant: "error"
        }
      );
      return;
    }

    if (trimmedInput === "all" && trimmedEndDateInput) {
      enqueueSnackbar("Clear the end date when running the incremental 'all' sync.", {
        variant: "error"
      });
      return;
    }

    if (trimmedEndDateInput && !isEndDate) {
      enqueueSnackbar("Please enter a valid backward end date in YYYY-MM-DD format.", {
        variant: "error"
      });
      return;
    }

    if (trimmedEndDateInput && trimmedInput > trimmedEndDateInput) {
      enqueueSnackbar("NST backward backfill requires start date on or before end date.", {
        variant: "error"
      });
      return;
    }

    try {
      nstCancelRequestedRef.current = false;
      setNstTeamStatsLoading(true);
      persistPendingNstBackfill(null);

      if (trimmedInput === "all") {
        const { message, success } = await doPOST(
          "/api/Teams/nst-team-stats?date=all"
        );
        enqueueSnackbar(message, {
          variant: success ? "success" : "error"
        });
        return;
      }

      if (trimmedEndDateInput) {
        await runBackwardNstBackfill(trimmedInput, trimmedEndDateInput);
        return;
      }

      await runForwardNstBackfill(trimmedInput);
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(
        isNstCancellationError(e) ? "NST backfill cancelled." : e.message,
        {
          variant: isNstCancellationError(e) ? "info" : "error"
        }
      );
      if (isNstCancellationError(e)) {
        persistPendingNstBackfill(null);
      }
    } finally {
      nstAbortControllerRef.current = null;
      setNstTeamStatsLoading(false);
      setPendingNstBackfill(readPendingNstBackfill());
    }
  }

  async function updateGameGoalProjections() {
    try {
      const { message, success } = await doPOST(
        "/api/v1/db/update-game-goal-projections?date=all"
      );
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  async function runSkoPredictions() {
    try {
      setSkoLoading(true);
      const trimmed = skoAsOfInput.trim();
      const endpoint = trimmed
        ? `/api/v1/ml/update-predictions-sko?asOfDate=${encodeURIComponent(
            trimmed
          )}`
        : "/api/v1/ml/update-predictions-sko";

      const { message, success } = await doPOST(endpoint);
      enqueueSnackbar(message ?? "sKO predictions updated", {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    } finally {
      setSkoLoading(false);
    }
  }

  async function updateStandingsDetails() {
    try {
      // Convert input to lowercase, trim whitespace
      const trimmedInput = standingsDetailsInput.trim().toLowerCase();

      // Validate: allow 'all' or a YYYY-MM-DD date
      if (trimmedInput !== "all" && !/^\d{4}-\d{2}-\d{2}$/.test(trimmedInput)) {
        enqueueSnackbar(
          "Please enter a valid date in YYYY-MM-DD format or 'all'.",
          {
            variant: "error"
          }
        );
        return;
      }

      // Construct the endpoint URL with the date query parameter
      const endpoint = `/api/v1/db/update-standings-details?date=${encodeURIComponent(
        trimmedInput
      )}`;

      // POST to the endpoint (adminOnly-protected)
      const { message, success } = await doPOST(endpoint);
      enqueueSnackbar(message, {
        variant: success ? "success" : "error"
      });
    } catch (e: any) {
      console.error(e.message);
      enqueueSnackbar(e.message, {
        variant: "error"
      });
    }
  }

  useEffect(() => {
    if (!isAdmin) return;

    (async () => {
      const { count: numPlayers } = await supabase
        .from("players")
        .select("id", { count: "exact", head: true });
      setNumPlayers(numPlayers ?? 0);

      const { count: numSeasons } = await supabase
        .from("seasons")
        .select("id", { count: "exact", head: true });
      setNumSeasons(numSeasons ?? 0);

      const { count: numTeams } = await supabase
        .from("teams")
        .select("id", { count: "exact", head: true });
      setNumTeams(numTeams ?? 0);
    })();
  }, [isAdmin]);

  useEffect(() => {
    if (!isAdmin || !season?.seasonId) return;
    (async () => {
      const { count: numGames } = await supabase
        .from("games")
        .select("id", { count: "exact", head: true })
        .eq("seasonId", season.seasonId);
      setNumGames(numGames ?? 0);

      const { data: finishedGames } = await supabase
        .from("games")
        .select("id,date")
        .eq("seasonId", season.seasonId)
        .lte("startTime", new Date().toISOString())
        .order("date", { ascending: false });
      setGames(finishedGames?.slice(0, 20) ?? []);
    })();
  }, [isAdmin, season?.seasonId]);

  return (
    <Container>
      <TextBanner text="Supabase Database" />

      <Grid container spacing={2} alignItems="stretch">
        {/* Players / Rosters Table Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%", // Ensures the card fills the Grid item's height
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/playersTable.png" // Local image path
              title="players table"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                PLAYERS / ROSTERS
              </Typography>
              <Typography variant="body2">
                The table contains the data for {numPlayers} players. The
                `players` and `rosters` tables will be updated simultaneously.
              </Typography>
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updatePlayers}>
                Update
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Seasons Table Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/seasonsTable.png" // Local image path
              title="seasons table"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                SEASONS
              </Typography>
              <Typography variant="body2">
                The table contains the data for {numSeasons} seasons. This card
                updates the `seasons` table.
              </Typography>
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updateSeasons}>
                Update
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Teams Table Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/teamsTable.png" // Local image path
              title="teams table"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                TEAMS
              </Typography>
              <Typography variant="body2">
                The table contains the data for {numTeams} teams. This card
                updates the `teams` & `team_season` tables.
              </Typography>
              <TextField
                label="Season ID (optional)"
                variant="outlined"
                size="small"
                fullWidth
                margin="normal"
                value={teamsSeasonIdInput}
                onChange={(e) => setTeamsSeasonIdInput(e.target.value)}
                placeholder="e.g. 20252026"
                sx={{
                  backgroundColor: "#202020",
                  border: "1px solid #07aae2",
                  borderRadius: "4px",
                  "& .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root, .css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input":
                    {
                      color: "#07aae2",
                      fontWeight: "900",
                      textTransform: "uppercase",
                      backgroundColor: "#202020",
                      margin: "1px"
                    }
                }}
              />
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updateTeams}>
                Update
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Games Table Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/gamesTable.png" // Local image path
              title="games table"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                GAMES
              </Typography>
              <Typography variant="body2">
                The table contains the data for {numGames} games in{" "}
                {season?.seasonId} season. This card updates the `games` tables.
              </Typography>
              <TextField
                label="Season ID (optional)"
                variant="outlined"
                size="small"
                fullWidth
                margin="normal"
                value={gamesSeasonIdInput}
                onChange={(e) => setGamesSeasonIdInput(e.target.value)}
                placeholder="e.g. 20252026"
                sx={{
                  backgroundColor: "#202020",
                  border: "1px solid #07aae2",
                  borderRadius: "4px",
                  "& .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root, .css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input":
                    {
                      color: "#07aae2",
                      fontWeight: "900",
                      textTransform: "uppercase",
                      backgroundColor: "#202020",
                      margin: "1px"
                    }
                }}
              />
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updateGames}>
                Update
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Stats Table Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/statsTable.png" // Local image path
              title="stats table"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                STATS
              </Typography>
              <Typography variant="body2">
                Update stats for {games.length} games between{" "}
                {games.at(0)?.date} ~ {games.at(-1)?.date}
              </Typography>
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updateStats}>
                Update
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Power Play Timeframes Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/ppTimeframes.png" // Local image path
              title="power play timeframes"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                PP TIMEFRAMES
              </Typography>
              <Typography variant="body2">
                Update the power play timeframes data for a specific game or all
                games.
              </Typography>
              {/* Optional Input Field for gameId */}
              <TextField
                label="Game ID or 'all'"
                variant="outlined"
                size="small"
                fullWidth
                margin="normal"
                value={powerPlayInput}
                onChange={(e) => setPowerPlayInput(e.target.value)}
                placeholder="Enter game ID or 'all'"
                sx={{
                  backgroundColor: "#202020",
                  border: "1px solid #07aae2",
                  borderRadius: "4px",
                  "& .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root, .css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input":
                    {
                      color: "#07aae2",
                      fontWeight: "900",
                      textTransform: "uppercase",
                      backgroundColor: "#202020",
                      margin: "1px"
                    }
                }}
              />
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updatePowerPlayTimeframes}>
                Update Power Play Timeframes
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Line Combinations Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/linesTable.png" // Local image path
              title="line combinations"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                LINE COMBOS
              </Typography>
              <Typography variant="body2">
                Update the line combinations data for unprocessed games.
              </Typography>
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updateLineCombinations}>
                Update
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Shift Charts Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/shiftsTable.png" // Local image path
              title="shift charts"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                SHIFT CHARTS
              </Typography>
              <Typography variant="body2">
                Update shift charts data for a specific game or all games.
              </Typography>
              {/* Input Field for gameId */}
              <TextField
                label="Game ID or 'all'"
                variant="outlined"
                size="small"
                fullWidth
                margin="normal"
                value={shiftChartsInput}
                onChange={(e) => setShiftChartsInput(e.target.value)}
                placeholder="Enter game ID or 'all'"
                sx={{
                  backgroundColor: "#202020",
                  border: "1px solid #07aae2",
                  borderRadius: "4px",
                  "& .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root, .css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input":
                    {
                      color: "#07aae2",
                      fontWeight: "900",
                      textTransform: "uppercase",
                      backgroundColor: "#202020",
                      margin: "1px"
                    }
                }}
              />
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updateShiftCharts}>
                Update Shift Charts
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* NST Team Stats Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/nstTables.png" // Replace with an appropriate image URL
              title="NST Team Stats"
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                NST Team Stats
              </Typography>
              <Typography variant="body2">
                Run the incremental NST sync with <strong>all</strong>, or
                enter a start date to backfill one date at a time through
                today. Add an end date to run the backfill in reverse and skip
                offseason gaps.
              </Typography>
              {pendingNstBackfill ? (
                <Typography variant="body2" sx={{ mt: 1, color: "#07aae2" }}>
                  Pending NST {pendingNstBackfill.mode} backfill:
                  {" "}
                  start={pendingNstBackfill.startDate}, cursor=
                  {pendingNstBackfill.cursor}, requests=
                  {pendingNstBackfill.requestsRun}
                </Typography>
              ) : null}
              <TextField
                label="Start Date or 'all'"
                variant="outlined"
                size="small"
                fullWidth
                margin="normal"
                value={nstTeamStatsInput}
                onChange={(e) => setNstTeamStatsInput(e.target.value)}
                placeholder="YYYY-MM-DD or all"
                sx={{
                  backgroundColor: "#202020",
                  border: "1px solid #07aae2",
                  borderRadius: "4px",
                  "& .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root, .css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input":
                    {
                      color: "#07aae2",
                      fontWeight: "900",
                      textTransform: "uppercase",
                      backgroundColor: "#202020",
                      margin: "1px"
                  }
                }}
              />
              <TextField
                label="Backward End Date (optional)"
                variant="outlined"
                size="small"
                fullWidth
                margin="normal"
                value={nstTeamStatsEndDateInput}
                onChange={(e) => setNstTeamStatsEndDateInput(e.target.value)}
                placeholder="YYYY-MM-DD"
                sx={{
                  backgroundColor: "#202020",
                  border: "1px solid #07aae2",
                  borderRadius: "4px",
                  "& .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root, .css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input":
                    {
                      color: "#07aae2",
                      fontWeight: "900",
                      textTransform: "uppercase",
                      backgroundColor: "#202020",
                      margin: "1px"
                    }
                }}
              />
            </CardContent>
            <CardActions>
              <Button
                size="small"
                onClick={updateNstTeamStats}
                disabled={nstTeamStatsLoading}
              >
                {nstTeamStatsLoading ? "Running NST Team Stats" : "Update NST Team Stats"}
              </Button>
              <Button
                size="small"
                onClick={resumePendingNstBackfill}
                disabled={nstTeamStatsLoading || !pendingNstBackfill}
              >
                Resume Pending
              </Button>
              <Button
                size="small"
                onClick={cancelPendingNstBackfill}
                disabled={!nstTeamStatsLoading && !pendingNstBackfill}
              >
                Cancel Pending
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Game Goal Projections Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/expectedGoals.png" // Replace with an appropriate image URL or local path
              title="Game Goal Projections"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                GAME GOAL PROJECTIONS
              </Typography>
              <Typography variant="body2">
                Update the legacy game-level projected goals and win odds for
                all current games. This updates the `expected_goals` table.
              </Typography>
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updateGameGoalProjections}>
                Update Goal Projections
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {/* Standings Details Card */}
        <Grid xs={4}>
          <Card
            sx={{
              border: "5px solid #07aae2",
              borderRadius: "8px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
              color: "#fff"
            }}
          >
            {/* (Optional) If you have a relevant image, replace the path below; or omit CardMedia. */}
            <CardMedia
              sx={{ height: 140 }}
              image="/pictures/fhfPlaceholder.png"
              title="standings details"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="div">
                STANDINGS DETAILS
              </Typography>
              <Typography variant="body2">
                Update NHL standings data for a single date (YYYY-MM-DD) or all
                dates (<strong>all</strong>) in the current season.
              </Typography>

              <TextField
                label="Date (YYYY-MM-DD) or 'all'"
                variant="outlined"
                size="small"
                fullWidth
                margin="normal"
                value={standingsDetailsInput}
                onChange={(e) => setStandingsDetailsInput(e.target.value)}
                placeholder="e.g. 2025-02-10 or 'all'"
                sx={{
                  backgroundColor: "#202020",
                  border: "1px solid #07aae2",
                  borderRadius: "4px",
                  "& .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root, .css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input":
                    {
                      color: "#07aae2",
                      fontWeight: "900",
                      textTransform: "uppercase",
                      backgroundColor: "#202020",
                      margin: "1px"
                    }
                }}
              />
            </CardContent>
            <CardActions>
              <Button size="small" onClick={updateStandingsDetails}>
                Update Standings Details
              </Button>
            </CardActions>
          </Card>
        </Grid>

        {isAdmin && (
          <Grid xs={12} md={4}>
            <Card
              sx={{
                border: "5px solid #ff6b6b",
                borderRadius: "8px",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
                color: "#fff"
              }}
            >
              <CardMedia
                sx={{ height: 140 }}
                image="/pictures/fhfPlaceholder.png"
                title="sKO predictions"
              />
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography gutterBottom variant="h5" component="div">
                  sKO PREDICTIONS
                </Typography>
                <Typography variant="body2">
                  Run the Supabase upsert for Sustainability K-Value Outlook
                  predictions using the latest modeling artifacts. Leave the
                  date blank to use the most recent run or enter YYYY-MM-DD to
                  override the as-of date.
                </Typography>
                <TextField
                  label="As-of date (optional)"
                  variant="outlined"
                  size="small"
                  fullWidth
                  margin="normal"
                  value={skoAsOfInput}
                  onChange={(e) => setSkoAsOfInput(e.target.value)}
                  placeholder="2025-01-05"
                  sx={{
                    backgroundColor: "#202020",
                    border: "1px solid #ff6b6b",
                    borderRadius: "4px",
                    "& .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root, .css-1n4twyu-MuiInputBase-input-MuiOutlinedInput-input":
                      {
                        color: "#ff6b6b",
                        fontWeight: "900",
                        textTransform: "uppercase",
                        backgroundColor: "#202020",
                        margin: "1px"
                      }
                  }}
                />
              </CardContent>
              <CardActions>
                <Button
                  size="small"
                  onClick={runSkoPredictions}
                  disabled={skoLoading}
                >
                  {skoLoading ? "Running…" : "Run sKO Upsert"}
                </Button>
              </CardActions>
            </Card>
          </Grid>
        )}

        {/* New Card/Button to link to the CSV Upsert Page */}
        {isAdmin && ( // Only show this card/link if user is admin
          <Grid xs={12} md={4}>
            {" "}
            {/* Adjust grid size as needed */}
            <Card
              sx={{
                border: "5px solid #4caf50", // Different color for distinction
                borderRadius: "8px",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                background: "linear-gradient(180deg, #202020 50%, #101010 80%)",
                color: "#fff"
              }}
            >
              <CardMedia
                sx={{ height: 140 }}
                image="/pictures/csvImportIcon.png" // Add a relevant icon/image
                title="CSV Projection Importer"
              />
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography gutterBottom variant="h5" component="div">
                  CSV PROJECTION IMPORTER
                </Typography>
                <Typography variant="body2">
                  Upload CSV files, standardize player names and column metrics,
                  and upsert projections to new Supabase tables.
                </Typography>
              </CardContent>
              <CardActions>
                <Link href="/db/upsert-projections" passHref legacyBehavior>
                  <Button
                    component="a"
                    size="small"
                    variant="contained"
                    color="success"
                  >
                    Go to Importer
                  </Button>
                </Link>
              </CardActions>
            </Card>
          </Grid>
        )}

        {isAdmin && (
          <Grid xs={12}>
            <CronRouteRunner />
            <Link href="/db/runner" passHref legacyBehavior>
              <Button component="a" variant="contained" color="warning" sx={{ mt: 1 }}>
                Long runs: open the route runner
              </Button>
            </Link>
          </Grid>
        )}
      </Grid>

      <Button
        onClick={async () => {
          console.log("click clll");
          const { data } = await supabase.from("goaliesGameStats").select("*");
          console.log(data);
        }}
      >
        Snackbar
      </Button>
    </Container>
  );
}

export default function Page() {
  return (
    <AdminPageGate>
      <DatabasePage />
    </AdminPageGate>
  );
}
