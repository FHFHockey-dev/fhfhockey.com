const deny = () => { throw new Error("Offline fixture forbids network connections"); };
require("node:net").Socket.prototype.connect = deny;
require("node:http").request = require("node:http").get = deny;
require("node:https").request = require("node:https").get = deny;
globalThis.fetch = deny;
