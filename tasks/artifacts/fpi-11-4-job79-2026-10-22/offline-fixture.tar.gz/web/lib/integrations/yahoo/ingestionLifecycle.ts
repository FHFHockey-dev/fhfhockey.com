type YahooGameRow = {
  game_id: string | number | null;
  game_key?: string | null;
  season?: string | number | null;
  is_offseason?: boolean | null;
  is_game_over?: boolean | null;
  current_week?: string | number | null;
};

const YAHOO_PUBLIC_API_ORIGIN = "https://pub-api-ro.fantasysports.yahoo.com";
const YAHOO_PUBLIC_API_BASE_URL = `${YAHOO_PUBLIC_API_ORIGIN}/fantasy/v2/`;

type YahooRetryOptions = {
  maxAttempts?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
  random?: () => number;
  sleep?: (delayMs: number) => Promise<void>;
  onRetry?: (event: {
    attempt: number;
    delayMs: number;
    rateLimited: boolean;
  }) => void;
};

export type YahooPlayerKeySnapshotRow = {
  player_key: string;
  player_id: number | null;
  player_name: string | null;
};

export type YahooSheetExportReceipt = {
  attempted: boolean;
  succeeded: boolean;
  statusCode: number | null;
  reason:
    | "complete_player_receipt"
    | "incomplete_player_receipt"
    | "missing_cron_secret"
    | "request_failed";
};

export type YahooGameWeekSnapshot = {
  game: {
    game_id: number;
    game_key: string;
    name: string | null;
    code: string | null;
    type: string | null;
    url: string | null;
    season: number;
  };
  weeks: Array<{
    week: number;
    start_date: string;
    end_date: string;
  }>;
};

export type YahooGameWeekSnapshotReceipt = {
  snapshotId?: string;
  gameId?: number;
  gameKey?: string;
  season?: number;
  sourceHash?: string;
  sourceCount?: number;
  metadataChanged?: boolean;
  changed?: number;
  removed?: number;
  replayed?: boolean;
};

type YahooPlayerKeySnapshot = {
  players: YahooPlayerKeySnapshotRow[];
  pagesFetched: number;
};

type YahooPlayerKeyPaginationOptions = {
  pageSize?: number;
  maxPages?: number;
};

function finiteNumber(value: unknown): number | null {
  if (value == null || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value != null && typeof value === "object" && !Array.isArray(value);
}

function nullableTrimmedText(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function exactIsoDate(value: unknown): string | null {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return null;
  }
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(parsed.getTime()) &&
    parsed.toISOString().slice(0, 10) === value
    ? value
    : null;
}

export async function fetchYahooPublicJson(
  pathOrUrl: string,
  fetchImpl: typeof fetch = fetch,
): Promise<unknown> {
  const url = new URL(pathOrUrl, YAHOO_PUBLIC_API_BASE_URL);
  if (
    url.origin !== YAHOO_PUBLIC_API_ORIGIN ||
    !url.pathname.startsWith("/fantasy/v2/")
  ) {
    throw new Error("Yahoo public API URL is invalid.");
  }
  url.searchParams.set("format", "json_f");

  const response = await fetchImpl(url.toString(), {
    headers: { Accept: "application/json" },
  });
  if (!response.ok) {
    const error = new Error("Yahoo public API request failed.") as Error & {
      response?: { headers: Headers; status: number };
      status?: number;
    };
    error.status = response.status;
    error.response = {
      headers: response.headers,
      status: response.status,
    };
    throw error;
  }

  return response.json();
}

export function prepareYahooGameWeekSnapshot(
  response: unknown,
): YahooGameWeekSnapshot {
  if (!isRecord(response)) {
    throw new Error("Yahoo game-week response is malformed.");
  }

  const fantasyContent = isRecord(response.fantasy_content)
    ? response.fantasy_content
    : null;
  const game =
    fantasyContent && isRecord(fantasyContent.game)
      ? fantasyContent.game
      : response;
  const rawWeeks = Array.isArray(game.weeks)
    ? game.weeks
    : Array.isArray(game.game_weeks)
      ? game.game_weeks.map((entry) =>
          isRecord(entry) && entry.game_week !== undefined
            ? entry.game_week
            : entry,
        )
      : null;

  const gameId = finiteNumber(game.game_id);
  const season = finiteNumber(game.season);
  const gameKey = nullableTrimmedText(game.game_key);
  if (
    gameId == null ||
    gameId <= 0 ||
    season == null ||
    season < 1900 ||
    !gameKey ||
    !/^[A-Za-z0-9._-]+$/.test(gameKey) ||
    !rawWeeks ||
    rawWeeks.length === 0
  ) {
    throw new Error("Yahoo game-week response is incomplete.");
  }

  const seenWeeks = new Set<number>();
  const weeks = rawWeeks
    .map((rawWeek) => {
      if (!isRecord(rawWeek)) {
        throw new Error("Yahoo game-week row is malformed.");
      }
      const week = finiteNumber(rawWeek.week);
      const startDate = exactIsoDate(rawWeek.start ?? rawWeek.start_date);
      const endDate = exactIsoDate(rawWeek.end ?? rawWeek.end_date);
      if (
        week == null ||
        !Number.isInteger(week) ||
        week <= 0 ||
        !startDate ||
        !endDate ||
        startDate > endDate ||
        seenWeeks.has(week)
      ) {
        throw new Error("Yahoo game-week row is invalid.");
      }
      seenWeeks.add(week);
      return { week, start_date: startDate, end_date: endDate };
    })
    .sort((left, right) => left.week - right.week);

  return {
    game: {
      game_id: Math.trunc(gameId),
      game_key: gameKey,
      name: nullableTrimmedText(game.name),
      code: nullableTrimmedText(game.code),
      type: nullableTrimmedText(game.type),
      url: nullableTrimmedText(game.url),
      season: Math.trunc(season),
    },
    weeks,
  };
}

export function isYahooGameWeekSnapshotReceipt(
  value: YahooGameWeekSnapshotReceipt | null,
  expected: {
    snapshotId: string;
    gameId: number;
    gameKey: string;
    season: number;
    sourceCount: number;
  },
): value is Required<YahooGameWeekSnapshotReceipt> {
  return (
    value?.snapshotId === expected.snapshotId &&
    value.gameId === expected.gameId &&
    value.gameKey === expected.gameKey &&
    value.season === expected.season &&
    value.sourceCount === expected.sourceCount &&
    /^[a-f0-9]{64}$/.test(value.sourceHash ?? "") &&
    typeof value.metadataChanged === "boolean" &&
    Number.isFinite(value.changed) &&
    Number.isFinite(value.removed) &&
    value.replayed === false
  );
}

function findNestedValue(value: unknown, key: string): unknown {
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findNestedValue(item, key);
      if (found !== undefined) return found;
    }
    return undefined;
  }
  if (!isRecord(value)) return undefined;
  if (value[key] !== undefined) return value[key];
  for (const nested of Object.values(value)) {
    const found = findNestedValue(nested, key);
    if (found !== undefined) return found;
  }
  return undefined;
}

export function extractYahooPlayerKeyPage(
  response: unknown,
): YahooPlayerKeySnapshotRow[] {
  if (!isRecord(response) || !isRecord(response.fantasy_content)) {
    throw new Error("Yahoo player-key page is malformed.");
  }

  const gameParts = Array.isArray(response.fantasy_content.game)
    ? response.fantasy_content.game
    : [response.fantasy_content.game];
  const holder = gameParts.find(
    (part) =>
      isRecord(part) && (isRecord(part.players) || Array.isArray(part.players)),
  );
  if (
    !isRecord(holder) ||
    (!isRecord(holder.players) && !Array.isArray(holder.players))
  ) {
    throw new Error("Yahoo player-key collection is missing.");
  }

  const entries = Array.isArray(holder.players)
    ? holder.players
    : Object.entries(holder.players)
        .filter(([key]) => /^\d+$/.test(key))
        .map(([, entry]) => entry);
  const rows = entries.map((entry) => {
    const playerKey = findNestedValue(entry, "player_key");
    if (typeof playerKey !== "string" || !/^\d+\.p\.\d+$/.test(playerKey)) {
      throw new Error("Yahoo player-key row is malformed.");
    }

    const rawPlayerId = findNestedValue(entry, "player_id");
    const playerId = finiteNumber(rawPlayerId);
    const rawName = findNestedValue(entry, "name");
    const playerName =
      isRecord(rawName) && typeof rawName.full === "string"
        ? rawName.full.trim() || null
        : null;

    return {
      player_key: playerKey,
      player_id: playerId == null ? null : Math.trunc(playerId),
      player_name: playerName,
    };
  });

  const uniqueKeys = new Set(rows.map((row) => row.player_key));
  if (uniqueKeys.size !== rows.length) {
    throw new Error("Yahoo player-key page contains duplicate keys.");
  }
  return rows;
}

export function extractYahooPlayerBatch(
  response: unknown,
): Array<Record<string, unknown>> {
  const fantasyContent = isRecord(response) ? response.fantasy_content : null;
  const contentPlayers = isRecord(fantasyContent)
    ? fantasyContent.players
    : null;
  const gamePlayers =
    isRecord(fantasyContent) && isRecord(fantasyContent.game)
      ? fantasyContent.game.players
      : null;
  const collection = Array.isArray(response)
    ? response
    : Array.isArray(contentPlayers) || isRecord(contentPlayers)
      ? contentPlayers
      : Array.isArray(gamePlayers) || isRecord(gamePlayers)
        ? gamePlayers
        : null;
  if (!collection) {
    throw new Error("Yahoo player batch is malformed.");
  }

  const entries = Array.isArray(collection)
    ? collection
    : Object.entries(collection)
        .filter(([key]) => /^\d+$/.test(key))
        .map(([, entry]) => entry);
  const players = entries.map((entry) => {
    const player =
      isRecord(entry) && isRecord(entry.player) ? entry.player : entry;
    if (
      !isRecord(player) ||
      typeof player.player_key !== "string" ||
      !/^\d+\.p\.\d+$/.test(player.player_key)
    ) {
      throw new Error("Yahoo player batch row is malformed.");
    }
    return player;
  });

  const uniqueKeys = new Set(players.map((player) => player.player_key));
  if (uniqueKeys.size !== players.length) {
    throw new Error("Yahoo player batch contains duplicate keys.");
  }
  return players;
}

export async function fetchCompleteYahooPlayerKeySnapshot(
  gameId: string,
  requestPage: (url: string) => Promise<unknown>,
  options: YahooPlayerKeyPaginationOptions = {},
): Promise<YahooPlayerKeySnapshot> {
  if (!/^\d+$/.test(gameId)) {
    throw new Error("Yahoo game ID is invalid.");
  }

  const pageSize = Math.min(
    2_000,
    Math.max(1, Math.trunc(options.pageSize ?? 2_000)),
  );
  const maxPages = Math.max(1, Math.trunc(options.maxPages ?? 200));
  const players: YahooPlayerKeySnapshotRow[] = [];
  const seen = new Set<string>();

  for (let page = 0; page < maxPages; page += 1) {
    const start = page * pageSize;
    const url =
      `${YAHOO_PUBLIC_API_BASE_URL}game/${gameId}` +
      `/players;start=${start};count=${pageSize}?format=json_f`;
    const pageRows = extractYahooPlayerKeyPage(await requestPage(url));

    for (const row of pageRows) {
      if (!row.player_key.startsWith(`${gameId}.p.`)) {
        throw new Error("Yahoo player-key page contains another game.");
      }
      if (seen.has(row.player_key)) {
        throw new Error("Yahoo player-key pagination repeated a key.");
      }
      seen.add(row.player_key);
      players.push(row);
    }

    if (pageRows.length < pageSize) {
      return {
        players: players.sort((left, right) =>
          left.player_key.localeCompare(right.player_key),
        ),
        pagesFetched: page + 1,
      };
    }
  }

  throw new Error("Yahoo player-key pagination exceeded its safety bound.");
}

export function selectCanonicalYahooGame<T extends YahooGameRow>(
  rows: T[],
): T | null {
  return (
    [...rows]
      .filter((row) => row.game_id != null)
      .sort((left, right) => {
        const seasonDifference =
          (finiteNumber(right.season) ?? Number.NEGATIVE_INFINITY) -
          (finiteNumber(left.season) ?? Number.NEGATIVE_INFINITY);
        if (seasonDifference !== 0) return seasonDifference;

        return (
          (finiteNumber(right.game_id) ?? Number.NEGATIVE_INFINITY) -
          (finiteNumber(left.game_id) ?? Number.NEGATIVE_INFINITY)
        );
      })[0] ?? null
  );
}

export function isYahooSheetExportEligible(args: {
  providerComplete: boolean;
  ownershipOmitted: number;
  persistedRows: number;
  sourceRows: number;
}): boolean {
  return (
    args.providerComplete &&
    args.ownershipOmitted === 0 &&
    args.sourceRows > 0 &&
    args.persistedRows === args.sourceRows
  );
}

export async function requestYahooSheetExport(args: {
  gameId: string | number;
  cronSecret: string | undefined;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}): Promise<YahooSheetExportReceipt> {
  if (!args.cronSecret) {
    return {
      attempted: false,
      succeeded: false,
      statusCode: null,
      reason: "missing_cron_secret",
    };
  }

  const controller = new AbortController();
  const timeout = setTimeout(
    () => controller.abort(),
    Math.max(1, args.timeoutMs ?? 3_000),
  );
  try {
    const response = await (args.fetchImpl ?? fetch)(
      `https://fhfhockey.com/api/internal/sync-yahoo-players-to-sheet?gameId=${encodeURIComponent(String(args.gameId))}`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${args.cronSecret}` },
        signal: controller.signal,
      },
    );
    if (!response.ok) {
      return {
        attempted: true,
        succeeded: false,
        statusCode: response.status,
        reason: "request_failed",
      };
    }

    let receipt: unknown;
    try {
      receipt = await response.json();
    } catch {
      return {
        attempted: true,
        succeeded: false,
        statusCode: response.status,
        reason: "request_failed",
      };
    }
    const count = isRecord(receipt) ? finiteNumber(receipt.count) : null;
    if (
      !isRecord(receipt) ||
      receipt.ok !== true ||
      count == null ||
      count <= 0
    ) {
      return {
        attempted: true,
        succeeded: false,
        statusCode: response.status,
        reason: "request_failed",
      };
    }

    return {
      attempted: true,
      succeeded: response.ok,
      statusCode: response.status,
      reason: response.ok ? "complete_player_receipt" : "request_failed",
    };
  } catch {
    return {
      attempted: true,
      succeeded: false,
      statusCode: null,
      reason: "request_failed",
    };
  } finally {
    clearTimeout(timeout);
  }
}

function getErrorStatus(error: any): number | null {
  return (
    finiteNumber(error?.statusCode) ??
    finiteNumber(error?.status) ??
    finiteNumber(error?.response?.status)
  );
}

function getRetryAfterHeader(error: any): string | null {
  const headers = error?.response?.headers ?? error?.headers;
  if (typeof headers?.get === "function") {
    return headers.get("retry-after");
  }

  const value = headers?.["retry-after"] ?? headers?.["Retry-After"];
  return value == null ? null : String(value);
}

export function getYahooRetryAfterMs(
  error: unknown,
  nowMs = Date.now(),
): number | null {
  const value = getRetryAfterHeader(error);
  if (!value) return null;

  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) {
    return Math.ceil(seconds * 1000);
  }

  const dateMs = Date.parse(value);
  return Number.isFinite(dateMs) ? Math.max(0, dateMs - nowMs) : null;
}

export function isRetryableYahooError(error: unknown): boolean {
  const status = getErrorStatus(error);
  if (status === 429 || (status != null && status >= 500 && status <= 599)) {
    return true;
  }
  if (status != null) return false;

  const code = String((error as any)?.code ?? "").toUpperCase();
  return ["ECONNABORTED", "ECONNRESET", "ENETUNREACH", "ETIMEDOUT"].includes(
    code,
  );
}

export async function withYahooRetry<T>(
  operation: () => Promise<T>,
  options: YahooRetryOptions = {},
): Promise<T> {
  const maxAttempts = Math.max(1, Math.trunc(options.maxAttempts ?? 3));
  const baseDelayMs = Math.max(0, options.baseDelayMs ?? 500);
  const maxDelayMs = Math.max(baseDelayMs, options.maxDelayMs ?? 10_000);
  const random = options.random ?? Math.random;
  const sleep =
    options.sleep ??
    ((delayMs: number) =>
      new Promise<void>((resolve) => setTimeout(resolve, delayMs)));

  for (let attempt = 1; ; attempt += 1) {
    try {
      return await operation();
    } catch (error) {
      if (attempt >= maxAttempts || !isRetryableYahooError(error)) {
        throw error;
      }

      const retryAfterMs = getYahooRetryAfterMs(error);
      const exponentialMs = Math.min(
        maxDelayMs,
        baseDelayMs * 2 ** (attempt - 1),
      );
      const jitteredMs = Math.ceil(exponentialMs * (0.75 + random() * 0.5));
      const delayMs = Math.min(
        maxDelayMs,
        Math.max(retryAfterMs ?? 0, jitteredMs),
      );

      options.onRetry?.({
        attempt,
        delayMs,
        rateLimited: getErrorStatus(error) === 429,
      });
      await sleep(delayMs);
    }
  }
}
