import path from "path";

import { describe, expect, it } from "vitest";

import {
  formatScheduleTime,
  getCronScheduleCandidates,
  parseCronInventoryFromMarkdown,
  readCronScheduleMarkdown,
} from "lib/cron/cronInventory";

describe("cronInventory", () => {
  it("parses and orders scheduled jobs chronologically while preserving tie order", () => {
    const inventory = parseCronInventoryFromMarkdown(`
-- STATUS: 404 NOT FOUND
-- SELECT cron.schedule(
--   'broken-job',
--   '45 7 * * *',
--   $$
--     SELECT net.http_get(
--       url := 'https://fhfhockey.com/api/v1/db/update-shifts?action=all'
--     );
--   $$
-- );

-- SELECT cron.schedule(
--   'sql-refresh',
--   '50 7 * * *',
--   'REFRESH MATERIALIZED VIEW player_stats_unified;'
-- );

-- SELECT cron.schedule(
--   'post-job',
--   '45 7 * * *',
--   $$
--     SELECT net.http_post(
--       url := 'https://fhfhockey.com/api/v1/db/run-projection-v2'
--     );
--   $$
-- );
`);

    expect(inventory.map((job) => job.name)).toEqual([
      "broken-job",
      "post-job",
      "sql-refresh",
    ]);
    expect(inventory[0]).toMatchObject({
      method: "GET",
      executionShape: "currently non-runnable in local/dev",
      route: "/api/v1/db/update-shifts?action=all",
      routePath: "/api/v1/db/update-shifts",
    });
    expect(inventory[1]).toMatchObject({
      method: "POST",
      executionShape: "HTTP route",
      route: "/api/v1/db/run-projection-v2",
    });
    expect(inventory[2]).toMatchObject({
      method: "SQL",
      executionShape: "SQL-only",
      sqlText: "REFRESH MATERIALIZED VIEW player_stats_unified;",
    });
  });

  it("formats cron slots as UTC HH:MM strings", () => {
    expect(formatScheduleTime("5 9 * * *")).toBe("09:05 UTC");
    expect(formatScheduleTime("invalid")).toBe("invalid");
  });

  it("resolves the canonical schedule from repository-root and web-root runtimes", () => {
    const webRoot = path.resolve("/workspace/repository/web");

    expect(getCronScheduleCandidates(webRoot)).toEqual([
      path.resolve(webRoot, "tasks/TASKS/cron-operations/cron-schedule.md"),
      path.resolve(webRoot, "../tasks/TASKS/cron-operations/cron-schedule.md"),
    ]);
  });

  it("loads a non-empty canonical schedule from the current workspace runtime", async () => {
    const markdown = await readCronScheduleMarkdown();

    expect(parseCronInventoryFromMarkdown(markdown).length).toBeGreaterThan(0);
  });

  it("uses active JSON inventory rows when SQL blocks are absent", () => {
    const inventory = parseCronInventoryFromMarkdown(`
# ALL CRON JOBS:
\`\`\`json
[
  {
    "jobid": 7,
    "jobname": "update-games-job",
    "schedule": "0 3 * * *",
    "run_time_utc": "03:00 UTC",
    "active": true
  },
  {
    "jobid": 8,
    "jobname": "retired-job",
    "schedule": "5 3 * * *",
    "run_time_utc": "03:05 UTC",
    "active": false
  }
]
\`\`\`
`);

    expect(inventory).toHaveLength(1);
    expect(inventory[0]).toMatchObject({
      name: "update-games-job",
      routePath: "/api/v1/db/update-games",
      executionShape: "wrapper-dependent",
    });
  });

  it("prefers the JSON inventory over stale SQL blocks when both are present", () => {
    const inventory = parseCronInventoryFromMarkdown(`
# ALL CRON JOBS:
\`\`\`json
[
  {
    "jobid": 1,
    "jobname": "daily-cron-report",
    "schedule": "15 21 * * *",
    "run_time_utc": "21:15 UTC",
    "active": true,
    "method": "GET",
    "route": "/api/v1/db/cron-report"
  },
  {
    "jobid": 2,
    "jobname": "retired-job",
    "schedule": "0 13 * * *",
    "run_time_utc": "13:00 UTC",
    "active": false,
    "method": "GET",
    "route": "/api/v1/db/retired"
  }
]
\`\`\`

SELECT cron.schedule(
  'daily-cron-report',
  '0 13 * * *',
  $$
    SELECT net.http_get(
      url := 'https://fhfhockey.com/api/v1/db/cron-report'
    );
  $$
);
`);

    expect(inventory).toHaveLength(1);
    expect(inventory[0]).toMatchObject({
      name: "daily-cron-report",
      cronExpression: "15 21 * * *",
      scheduleTimeDisplay: "21:15 UTC",
      method: "GET",
      executionShape: "HTTP route",
      route: "/api/v1/db/cron-report",
      routePath: "/api/v1/db/cron-report",
    });
  });
});
