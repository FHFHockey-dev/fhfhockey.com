globalThis.fetch = async () => { throw new Error("Offline fixture forbids network requests"); };
