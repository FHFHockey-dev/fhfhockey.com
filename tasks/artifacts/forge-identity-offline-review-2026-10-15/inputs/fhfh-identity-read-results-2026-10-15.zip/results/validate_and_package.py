from pathlib import Path
import json,re,hashlib,datetime,collections,zipfile
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda name,value:(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
raw=ROOT/'identity-execution-2026-10-15.json';execution=json.loads(raw.read_text());tool=execution['result']
assert tool.get('isError') is False
assert len(tool['content'])==1 and tool['content'][0]['type']=='text'
outer=json.loads(tool['content'][0]['text']);assert set(outer)=={'result'}
wrapped=outer['result'];m=re.search(r'<untrusted-data-([a-zA-Z0-9-]+)>\n(\[.*\])\n</untrusted-data-\1>',wrapped,re.S);assert m
returned=json.loads(m.group(2));assert len(returned)==1 and set(returned[0])=={'result'}
v=returned[0]['result'];assert set(v)=={'status','identity','metadata','identity_bytes','metadata_bytes'} and v['status']=='OK'
identity=v['identity'];metadata=v['metadata'];assert set(identity)=={'schema','input_sha256','returned_count','bigint_encoding','requested_count','project_ref_requested','rows'}
assert identity['schema']=='forge-identity-read-v1' and identity['bigint_encoding']=='decimal strings'
assert identity['project_ref_requested']=='fyhftlxokyjtpndbkfse' and identity['requested_count']==908
assert identity['input_sha256']=='720722d259dccba61369a6e4507ab8e723a70e6798ca11971b35939aaab0d48d'
assert metadata['schema']=='forge-identity-metadata-v1' and metadata['relation']=='public.fhfh_player_identities' and metadata['project_ref_requested']=='fyhftlxokyjtpndbkfse'
expected_checks={'base_table','utc_active','id_primary_key','nhl_foreign_key','iso_dates_active','read_only_active','six_column_types','fixed_search_path','six_column_select','nonnull_nhl_unique','idle_timeout_active','lock_timeout_active','default_row_security','repeatable_read_active','complete_row_visibility','statement_timeout_active','bounded_status_constraint'}
assert set(metadata['checks'])==expected_checks and all(x is True for x in metadata['checks'].values())
assert metadata['settings']=={'read_only':'on','isolation':'repeatable read','statement_timeout':'5s','lock_timeout':'1s','row_security':'on'}
for key,cap in [('identity',524288),('metadata',32768)]:
 # PostgreSQL jsonb text inserts comma/colon spaces; field ordering does not affect byte count.
 encoded=json.dumps(v[key],ensure_ascii=False,separators=(', ',': ')).encode()
 assert len(encoded)==v[key+'_bytes']<=cap,(key,len(encoded),v[key+'_bytes'])
b=(ROOT/'inputs'/'forge-pending-nhl-ids-908.json').read_bytes();assert hashlib.sha256(b).hexdigest()==identity['input_sha256']
ids=json.loads(b);assert len(ids)==908 and ids==sorted(set(ids))
rows=identity['rows'];assert identity['returned_count']==len(rows)<=908
fields={'id','nhl_player_id','verification_status','merged_into_id','verified_at','updated_at'}
statuses={'verified','provisional','review_required','rejected','merged'}
def bigint(s,nullable=False):
 if s is None and nullable:return None
 assert isinstance(s,str) and re.fullmatch(r'-?(?:0|[1-9][0-9]*)',s),repr(s)
 n=int(s);assert -(2**63)<=n<2**63;return n
def timestamp(s,nullable=False):
 if s is None and nullable:return
 assert isinstance(s,str)
 parsed=datetime.datetime.fromisoformat(s);assert parsed.utcoffset()==datetime.timedelta(0)
nhl=[];canonical=[];resolved=[];unverified=[];merged=[];invalid=[]
for row in rows:
 assert set(row)==fields and row['verification_status'] in statuses
 n=bigint(row['nhl_player_id']);c=bigint(row['id']);merge=bigint(row['merged_into_id'],True)
 timestamp(row['updated_at']);timestamp(row['verified_at'],True)
 nhl.append(n);canonical.append(c)
 assert n in ids
 if not(0<n<=9007199254740991 and 0<c<=9007199254740991):invalid.append(row)
 elif row['verification_status']=='merged' or merge is not None:merged.append(row)
 elif row['verification_status']!='verified':unverified.append(row)
 else:resolved.append(row)
assert len(nhl)==len(set(nhl)) and len(canonical)==len(set(canonical))
assert nhl==sorted(nhl)
not_returned=sorted(set(ids)-set(nhl))
assert nhl==ids # Actual successful result has every pinned member, in order.
assert len(resolved)==908 and not unverified and not merged and not invalid and not not_returned
write('identity-projected-response.json',v)
write('resolved-identities.json',resolved)
write('unresolved-identities.json',{'unverified':unverified,'merged':merged,'invalid':invalid,'not_returned_nhl_ids':not_returned})
write('mapping-pairs.json',[{'nhl_player_id':int(r['nhl_player_id']),'canonical_player_id':int(r['id'])} for r in resolved])
counts={'requested':len(ids),'matched_returned':len(rows),'resolved_verified':len(resolved),'unverified':len(unverified),'merged':len(merged),'invalid':len(invalid),'not_returned':len(not_returned)}
manifest={'status':'identity_only_read_complete_mapping_not_applied','project_ref':'fyhftlxokyjtpndbkfse','relation':'public.fhfh_player_identities','fields':sorted(fields),'input_sha256':identity['input_sha256'],'sql_sha256':execution['sql_sha256'],'request_sha256':execution['request_file_sha256'],'raw_execution_receipt_sha256':sha(raw),'started_at':execution['startedAt'],'finished_at':execution['finishedAt'],'approval_message_id':execution['approval_message_id'],'agent_issued_identity_requests':1,'schema_access_control_checks':metadata['checks'],'server_identity_json_bytes':v['identity_bytes'],'server_metadata_json_bytes':v['metadata_bytes'],'counts':counts,'bigint_output':'source decimal strings; mapping-pairs integer conversion only after positive-safe-integer validation','snapshot_meaning':'One current identity statement snapshot; not historical eligibility or outcome data','holds':['January 14, 2026 onward closed','blend comparison held','no allocation, labels, scores, fitting or models','no production writes or deployment','separate original live operation unchanged']}
write('mapping-access-manifest.json',manifest)
verification={'status':'PASS','counts':counts,'strict_input_hash_verified':True,'exact_query_hash_verified':execution['sql_sha256']=='c3195e134efc5c25fdf25e12db73c7167d89c95054476ce48ef9a73e67bbb8f6','complete_expected_response_shape':True,'all_17_metadata_checks_true':True,'six_fields_only':True,'byte_counts_recomputed_match_server':True,'exact_908_membership_and_order':True,'unique_nhl_and_canonical_ids':True,'all_pairs_positive_safe_integers':True,'all_908_verified_and_unmerged':True,'timestamps_valid_utc':True,'outcome_files_opened':0,'production_writes_issued':0,'followup_database_queries_issued':0,'mapping_applied_to_experiment':False,'independent_second_review':'not performed by this executor'}
write('mapping-verification.json',verification)
(OUT/'summary.md').write_text('''# FHFH identity-only read result

All 908 pinned official NHL IDs returned a unique canonical FHFH identity. All 908 pairs are verified and have no merge target.

- Matched and resolved: 908
- Unverified: 0
- Merged: 0
- Invalid/conflicting: 0
- Not returned: 0

All 17 schema, access and execution-control checks passed. The identity JSON was 180,421 bytes and the metadata JSON was 2,031 bytes, within the 512 KiB and 32 KiB caps. Offline validation independently recomputed those byte counts and confirmed exact input membership, uniqueness, the six-field response shape, positive safe-integer IDs, and UTC timestamps.

One approved identity request was issued between 2026-10-15 05:26:55.143 and 05:27:01.269 UTC. It used the hash-pinned query and 908-ID array. No further database query, outcome read, merge lookup, model run, production write or deployment was performed.

The mapping is a current identity registry snapshot. It does not establish historical eligibility and has not been applied to the experiment. January 14, 2026 onward remains closed; the blend comparison remains held; the separate original live operation remains unchanged.

The package includes the exact query/request, input pins, raw execution receipt, projected six-field results, validated mapping pairs, unresolved report and verification receipts. A separate independent reviewer has not yet reviewed these result artifacts.
''')
files=[p for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='sha256-manifest.json']+[raw,ROOT/'final'/'gated-identity-read.sql',ROOT/'final'/'gated-identity-read.request.json',ROOT/'inputs'/'forge-pending-nhl-ids-908.json']
checksums=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
write('sha256-manifest.json',checksums);files.append(OUT/'sha256-manifest.json')
zp=ROOT.parent/'fhfh-identity-read-results-2026-10-15.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None
 for item in checksums:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
print(json.dumps(verification,indent=2));print('PACKAGE',zp,zp.stat().st_size,sha(zp));print('RESOLVED_SHA256',sha(OUT/'resolved-identities.json'));print('PAIRS_SHA256',sha(OUT/'mapping-pairs.json'))
