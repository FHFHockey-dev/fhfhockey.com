# FHFH identity-only read result

All 908 pinned official NHL IDs returned a unique canonical FHFH identity. All 908 pairs are verified and have no merge target.

- Matched and resolved: 908
- Unverified: 0
- Merged: 0
- Invalid/conflicting: 0
- Not returned: 0

All 17 schema, access and execution-control checks passed. The identity JSON was 180,421 bytes and the metadata JSON was 2,031 bytes, within the 512 KiB and 32 KiB caps. Offline validation independently recomputed those byte counts and confirmed exact input membership, uniqueness, the six-field response shape, positive safe-integer IDs, and UTC timestamps.

One approved identity request was issued between 2026-10-15 05:26:55.143 and 05:27:01.269 UTC. It used the hash-pinned query and 908-ID array. No further database query, outcome read, merge lookup, model run, production write or deployment was performed.

The mapping is a current identity registry snapshot. It does not establish historical eligibility and has not been applied to the experiment. January 14, 2026 onward remains closed; the blend comparison remains held; the separate original live operation remains unchanged.

The package includes the exact query/request, input pins, raw execution receipt, projected six-field results, validated mapping pairs, unresolved report and verification receipts. A separate independent reviewer has not yet reviewed these result artifacts.
