-- FINAL APPROVAL PROPOSAL. IDENTITY READ NOT AUTHORIZED OR EXECUTED.
-- One top-level SELECT combines metadata gate and conditionally executed identity read in one snapshot.
-- Exact static bigint literal list generated only from the hash-verified ID array; this is NOT API parameter binding.
-- Input SHA-256: 720722d259dccba61369a6e4507ab8e723a70e6798ca11971b35939aaab0d48d
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout = '5s';
SET LOCAL lock_timeout = '1s';
SET LOCAL idle_in_transaction_session_timeout = '5s';
SET LOCAL search_path = pg_catalog;
SET LOCAL TimeZone = 'UTC';
SET LOCAL DateStyle = 'ISO, YMD';
WITH
expected_columns(name, type_name, not_null) AS (
  VALUES ('id', 'int8', true), ('nhl_player_id', 'int8', false),
         ('verification_status', 'text', true), ('merged_into_id', 'int8', false),
         ('verified_at', 'timestamptz', false), ('updated_at', 'timestamptz', true)
),
target AS MATERIALIZED (
  SELECT c.oid, c.relkind, c.relrowsecurity, c.relforcerowsecurity
  FROM pg_catalog.pg_class AS c
  JOIN pg_catalog.pg_namespace AS n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relname = 'fhfh_player_identities'
),
columns_checked AS MATERIALIZED (
  SELECT e.name, e.type_name AS expected_type, e.not_null AS expected_not_null,
         a.attnum, t.typname AS actual_type, tn.nspname AS type_schema,
         a.attnotnull AS actual_not_null,
         COALESCE(tn.nspname = 'pg_catalog' AND t.typname = e.type_name
           AND a.attnotnull = e.not_null AND a.attgenerated = ''
           AND a.attnum > 0 AND NOT a.attisdropped, false) AS matches,
         COALESCE(pg_catalog.has_column_privilege(c.oid, a.attnum, 'SELECT'), false) AS can_select
  FROM expected_columns AS e
  LEFT JOIN target AS c ON true
  LEFT JOIN pg_catalog.pg_attribute AS a ON a.attrelid = c.oid AND a.attname = e.name
  LEFT JOIN pg_catalog.pg_type AS t ON t.oid = a.atttypid
  LEFT JOIN pg_catalog.pg_namespace AS tn ON tn.oid = t.typnamespace
),
checks AS MATERIALIZED (
  SELECT
    (SELECT count(*) = 1 AND bool_and(relkind = 'r') FROM target) AS base_table,
    (SELECT count(*) = 6 AND bool_and(matches) FROM columns_checked) AS six_column_types,
    (SELECT bool_and(can_select) FROM columns_checked) AS six_column_select,
    COALESCE((SELECT NOT pg_catalog.row_security_active(oid) FROM target), false) AS complete_row_visibility,
    EXISTS (
      SELECT 1 FROM target AS c
      JOIN pg_catalog.pg_constraint AS k ON k.conrelid = c.oid
      JOIN pg_catalog.pg_index AS i ON i.indexrelid = k.conindid
      WHERE k.contype = 'p' AND k.convalidated
        AND k.conkey = ARRAY[(SELECT attnum FROM columns_checked WHERE name = 'id')]::pg_catalog.int2[]
        AND i.indisvalid AND i.indisready AND i.indislive AND i.indimmediate
    ) AS id_primary_key,
    EXISTS (
      SELECT 1 FROM target AS c
      JOIN pg_catalog.pg_index AS i ON i.indrelid = c.oid
      JOIN pg_catalog.pg_class AS ic ON ic.oid = i.indexrelid
      JOIN pg_catalog.pg_am AS am ON am.oid = ic.relam
      WHERE i.indisunique AND i.indisvalid AND i.indisready AND i.indislive AND i.indimmediate
        AND i.indnkeyatts = 1 AND i.indnatts = 1 AND i.indexprs IS NULL AND am.amname = 'btree'
        AND i.indkey[0] = (SELECT attnum FROM columns_checked WHERE name = 'nhl_player_id')
        AND (i.indpred IS NULL OR pg_catalog.pg_get_expr(i.indpred, i.indrelid) = '(nhl_player_id IS NOT NULL)')
    ) AS nonnull_nhl_unique,
    EXISTS (
      SELECT 1 FROM target AS c
      JOIN pg_catalog.pg_constraint AS k ON k.conrelid = c.oid
      JOIN pg_catalog.pg_class AS p ON p.oid = k.confrelid
      JOIN pg_catalog.pg_namespace AS pn ON pn.oid = p.relnamespace
      JOIN pg_catalog.pg_attribute AS pa ON pa.attrelid = p.oid AND pa.attname = 'id'
      WHERE k.contype = 'f' AND k.convalidated
        AND k.conkey = ARRAY[(SELECT attnum FROM columns_checked WHERE name = 'nhl_player_id')]::pg_catalog.int2[]
        AND pn.nspname = 'public' AND p.relname = 'players'
        AND k.confkey = ARRAY[pa.attnum]::pg_catalog.int2[]
        AND k.confupdtype = 'r' AND k.confdeltype = 'r'
    ) AS nhl_foreign_key,
    EXISTS (
      SELECT 1 FROM target AS c JOIN pg_catalog.pg_constraint AS k ON k.conrelid = c.oid
      WHERE k.contype = 'c' AND k.convalidated
        AND k.conname = 'fhfh_player_identities_verification_status_valid'
        AND pg_catalog.pg_get_constraintdef(k.oid) =
          'CHECK ((verification_status = ANY (ARRAY[''verified''::text, ''provisional''::text, ''review_required''::text, ''rejected''::text, ''merged''::text])))'
    ) AS bounded_status_constraint,
    pg_catalog.current_setting('transaction_read_only') = 'on' AS read_only_active,
    pg_catalog.current_setting('transaction_isolation') = 'repeatable read' AS repeatable_read_active,
    pg_catalog.current_setting('statement_timeout') = '5s' AS statement_timeout_active,
    pg_catalog.current_setting('lock_timeout') = '1s' AS lock_timeout_active,
    pg_catalog.current_setting('idle_in_transaction_session_timeout') = '5s' AS idle_timeout_active,
    pg_catalog.current_setting('row_security') = 'on' AS default_row_security,
    pg_catalog.current_setting('search_path') = 'pg_catalog' AS fixed_search_path,
    pg_catalog.current_setting('TimeZone') = 'UTC' AS utc_active,
    pg_catalog.current_setting('DateStyle') = 'ISO, YMD' AS iso_dates_active
),
metadata AS MATERIALIZED (
  SELECT pg_catalog.jsonb_build_object(
    'schema', 'forge-identity-metadata-v1',
    'project_ref_requested', 'fyhftlxokyjtpndbkfse',
    'relation', 'public.fhfh_player_identities',
    'checks', pg_catalog.to_jsonb(c),
    'columns', (SELECT pg_catalog.jsonb_agg(pg_catalog.to_jsonb(cc) ORDER BY cc.name) FROM columns_checked AS cc),
    'settings', pg_catalog.jsonb_build_object(
      'read_only', pg_catalog.current_setting('transaction_read_only'),
      'isolation', pg_catalog.current_setting('transaction_isolation'),
      'statement_timeout', pg_catalog.current_setting('statement_timeout'),
      'lock_timeout', pg_catalog.current_setting('lock_timeout'),
      'row_security', pg_catalog.current_setting('row_security'))
  ) AS payload,
  COALESCE(c.base_table AND c.six_column_types AND c.six_column_select
    AND c.complete_row_visibility AND c.id_primary_key AND c.nonnull_nhl_unique
    AND c.nhl_foreign_key AND c.bounded_status_constraint AND c.read_only_active
    AND c.repeatable_read_active AND c.statement_timeout_active AND c.lock_timeout_active
    AND c.idle_timeout_active AND c.default_row_security AND c.fixed_search_path
    AND c.utc_active AND c.iso_dates_active, false) AS passed
  FROM checks AS c
),
gate AS MATERIALIZED (
  SELECT payload, passed AND pg_catalog.octet_length(payload::text) <= 32768 AS passed
  FROM metadata
)
SELECT CASE
  WHEN pg_catalog.octet_length(g.payload::text) > 32768 THEN '{"status":"METADATA_BYTE_LIMIT"}'::pg_catalog.jsonb
  WHEN NOT g.passed THEN pg_catalog.jsonb_build_object('status', 'METADATA_GATE_FAILED', 'metadata', g.payload)
  ELSE (
    WITH identity_rows AS MATERIALIZED (
      SELECT i.id, i.nhl_player_id, i.verification_status, i.merged_into_id, i.verified_at, i.updated_at
      FROM ONLY public.fhfh_player_identities AS i
      WHERE i.nhl_player_id = ANY (ARRAY[8470613,8470621,8471214,8471215,8471675,8471685,8471724,8471734,8471817,8473419,8473422,8473507,8473533,8473604,8473986,8473994,8474013,8474037,8474090,8474102,8474149,8474150,8474151,8474189,8474563,8474564,8474567,8474568,8474574,8474578,8474586,8474593,8474596,8474600,8474612,8474641,8474679,8475149,8475151,8475158,8475166,8475167,8475168,8475169,8475170,8475171,8475172,8475179,8475181,8475184,8475188,8475191,8475200,8475208,8475218,8475220,8475231,8475235,8475279,8475287,8475311,8475314,8475324,8475343,8475413,8475455,8475462,8475660,8475683,8475690,8475692,8475714,8475717,8475722,8475726,8475745,8475752,8475753,8475754,8475755,8475760,8475762,8475763,8475764,8475765,8475768,8475784,8475786,8475790,8475791,8475794,8475795,8475798,8475799,8475809,8475810,8475831,8475842,8475848,8475852,8475883,8475906,8475913,8476278,8476292,8476312,8476331,8476341,8476372,8476374,8476389,8476392,8476393,8476399,8476412,8476419,8476422,8476425,8476429,8476432,8476434,8476438,8476441,8476448,8476453,8476454,8476455,8476456,8476457,8476458,8476459,8476460,8476461,8476462,8476463,8476467,8476468,8476469,8476473,8476474,8476479,8476480,8476483,8476525,8476539,8476624,8476822,8476826,8476854,8476856,8476867,8476869,8476871,8476872,8476873,8476874,8476875,8476878,8476879,8476880,8476881,8476882,8476883,8476885,8476887,8476889,8476891,8476892,8476897,8476899,8476902,8476905,8476906,8476907,8476914,8476917,8476921,8476923,8476925,8476927,8476931,8476932,8476945,8476952,8476958,8476967,8476979,8476981,8476988,8476994,8476999,8477015,8477018,8477021,8477034,8477070,8477073,8477149,8477220,8477320,8477346,8477365,8477369,8477380,8477401,8477402,8477404,8477405,8477406,8477407,8477409,8477416,8477419,8477424,8477425,8477426,8477429,8477435,8477444,8477446,8477447,8477450,8477451,8477454,8477456,8477463,8477465,8477476,8477478,8477479,8477480,8477484,8477488,8477492,8477494,8477495,8477496,8477497,8477498,8477499,8477500,8477501,8477503,8477504,8477505,8477506,8477507,8477508,8477511,8477527,8477541,8477573,8477810,8477831,8477839,8477845,8477903,8477919,8477932,8477933,8477934,8477935,8477938,8477939,8477940,8477947,8477948,8477950,8477951,8477952,8477953,8477955,8477956,8477960,8477964,8477967,8477968,8477969,8477970,8477979,8477986,8477987,8477989,8477990,8477992,8477993,8477996,8477998,8478007,8478009,8478010,8478013,8478020,8478024,8478038,8478039,8478042,8478043,8478046,8478047,8478048,8478055,8478057,8478104,8478109,8478133,8478136,8478147,8478173,8478178,8478233,8478366,8478396,8478397,8478398,8478399,8478401,8478403,8478406,8478407,8478413,8478414,8478416,8478420,8478421,8478424,8478427,8478434,8478435,8478438,8478440,8478443,8478444,8478445,8478449,8478450,8478452,8478454,8478458,8478460,8478462,8478463,8478468,8478469,8478470,8478472,8478474,8478476,8478483,8478493,8478498,8478499,8478500,8478502,8478507,8478508,8478519,8478542,8478569,8478831,8478840,8478841,8478851,8478854,8478856,8478859,8478864,8478872,8478873,8478874,8478882,8478891,8478904,8478911,8478916,8478970,8478971,8478975,8479022,8479026,8479066,8479193,8479291,8479292,8479293,8479312,8479316,8479318,8479323,8479324,8479325,8479336,8479337,8479339,8479343,8479345,8479351,8479353,8479359,8479361,8479362,8479365,8479368,8479369,8479370,8479371,8479372,8479378,8479383,8479385,8479388,8479390,8479393,8479395,8479398,8479402,8479406,8479407,8479410,8479414,8479420,8479421,8479425,8479442,8479496,8479520,8479525,8479533,8479542,8479576,8479591,8479619,8479638,8479639,8479644,8479661,8479671,8479675,8479705,8479941,8479944,8479973,8479977,8479980,8479981,8479982,8479983,8479985,8479987,8479992,8479996,8479998,8479999,8480001,8480002,8480003,8480009,8480012,8480014,8480015,8480018,8480021,8480023,8480027,8480028,8480035,8480036,8480039,8480043,8480045,8480049,8480051,8480058,8480064,8480068,8480069,8480074,8480078,8480084,8480113,8480144,8480145,8480185,8480188,8480192,8480193,8480196,8480220,8480238,8480245,8480246,8480259,8480280,8480281,8480289,8480313,8480336,8480355,8480426,8480434,8480448,8480459,8480528,8480727,8480748,8480762,8480796,8480797,8480798,8480800,8480801,8480802,8480803,8480806,8480807,8480813,8480817,8480825,8480828,8480829,8480830,8480831,8480834,8480835,8480839,8480840,8480842,8480843,8480848,8480849,8480855,8480860,8480865,8480871,8480873,8480874,8480876,8480878,8480879,8480887,8480891,8480893,8480947,8480950,8480980,8480981,8480990,8480995,8481006,8481013,8481014,8481020,8481024,8481030,8481032,8481033,8481035,8481043,8481056,8481065,8481068,8481077,8481122,8481133,8481161,8481167,8481178,8481219,8481237,8481477,8481481,8481491,8481517,8481519,8481522,8481523,8481524,8481525,8481527,8481528,8481529,8481532,8481533,8481535,8481544,8481546,8481551,8481553,8481554,8481556,8481557,8481559,8481560,8481563,8481564,8481567,8481568,8481569,8481577,8481580,8481581,8481582,8481591,8481593,8481596,8481598,8481599,8481601,8481604,8481605,8481606,8481607,8481609,8481611,8481617,8481618,8481624,8481641,8481655,8481656,8481668,8481692,8481704,8481711,8481712,8481715,8481716,8481719,8481721,8481725,8481726,8481732,8481754,8481789,8481806,8481848,8482055,8482062,8482070,8482072,8482073,8482074,8482076,8482077,8482078,8482079,8482087,8482088,8482089,8482090,8482092,8482093,8482094,8482095,8482097,8482100,8482103,8482105,8482109,8482110,8482111,8482113,8482116,8482117,8482118,8482122,8482123,8482124,8482125,8482126,8482131,8482132,8482137,8482142,8482145,8482146,8482148,8482149,8482155,8482157,8482159,8482165,8482166,8482167,8482168,8482172,8482175,8482176,8482177,8482178,8482188,8482193,8482201,8482206,8482245,8482259,8482408,8482411,8482445,8482447,8482451,8482460,8482465,8482470,8482475,8482476,8482482,8482487,8482496,8482511,8482515,8482516,8482623,8482634,8482641,8482655,8482659,8482660,8482661,8482665,8482666,8482667,8482671,8482673,8482679,8482684,8482691,8482698,8482699,8482702,8482703,8482705,8482713,8482720,8482726,8482730,8482733,8482737,8482740,8482745,8482747,8482749,8482751,8482758,8482761,8482762,8482765,8482766,8482768,8482775,8482781,8482783,8482785,8482787,8482803,8482804,8482807,8482809,8482821,8482858,8482859,8482861,8482874,8482877,8482896,8482911,8482929,8482947,8482953,8482964,8482982,8483039,8483114,8483203,8483395,8483398,8483406,8483424,8483425,8483431,8483432,8483433,8483445,8483447,8483450,8483452,8483455,8483457,8483460,8483463,8483464,8483465,8483466,8483468,8483471,8483472,8483476,8483485,8483487,8483489,8483490,8483491,8483493,8483495,8483497,8483499,8483500,8483503,8483506,8483510,8483512,8483513,8483515,8483516,8483524,8483525,8483526,8483531,8483548,8483553,8483565,8483567,8483570,8483573,8483609,8483630,8483676,8483678,8483686,8483690,8483703,8483710,8483711,8483728,8483733,8483746,8483752,8483768,8483771,8483808,8483841,8483890,8483930,8484135,8484136,8484142,8484144,8484145,8484149,8484150,8484153,8484158,8484160,8484164,8484166,8484168,8484170,8484180,8484185,8484186,8484197,8484203,8484210,8484214,8484221,8484223,8484227,8484230,8484240,8484241,8484258,8484262,8484268,8484287,8484304,8484305,8484321,8484386,8484387,8484388,8484403,8484428,8484471,8484529,8484762,8484768,8484779,8484783,8484794,8484798,8484800,8484801,8484806,8484821,8484829,8484839,8484860,8484901,8484911,8484958,8484994,8485366,8485385,8485402,8485493,8485511,8485512,8485702]::pg_catalog.int8[])
      ORDER BY i.nhl_player_id, i.id
      LIMIT 909
    ),
    aggregate_rows AS MATERIALIZED (
      SELECT count(*) AS row_count,
        COALESCE(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
          'id', r.id::text,
          'nhl_player_id', r.nhl_player_id::text,
          'verification_status', r.verification_status,
          'merged_into_id', r.merged_into_id::text,
          'verified_at', r.verified_at::text,
          'updated_at', r.updated_at::text
        ) ORDER BY r.nhl_player_id, r.id), '[]'::pg_catalog.jsonb) AS rows
      FROM identity_rows AS r
    ),
    identity_payload AS MATERIALIZED (
      SELECT a.row_count, pg_catalog.jsonb_build_object(
        'schema', 'forge-identity-read-v1',
        'project_ref_requested', 'fyhftlxokyjtpndbkfse',
        'input_sha256', '720722d259dccba61369a6e4507ab8e723a70e6798ca11971b35939aaab0d48d',
        'requested_count', 908,
        'returned_count', a.row_count,
        'bigint_encoding', 'decimal strings',
        'rows', a.rows
      ) AS payload
      FROM aggregate_rows AS a
    )
    SELECT CASE
      WHEN p.row_count > 908 THEN '{"status":"IDENTITY_ROW_OVERFLOW"}'::pg_catalog.jsonb
      WHEN pg_catalog.octet_length(p.payload::text) > 524288 THEN '{"status":"IDENTITY_BYTE_LIMIT"}'::pg_catalog.jsonb
      ELSE pg_catalog.jsonb_build_object(
        'status', 'OK', 'metadata', g.payload,
        'metadata_bytes', pg_catalog.octet_length(g.payload::text),
        'identity_bytes', pg_catalog.octet_length(p.payload::text),
        'identity', p.payload)
    END
    FROM identity_payload AS p
  )
END AS result
FROM gate AS g;
ROLLBACK;
